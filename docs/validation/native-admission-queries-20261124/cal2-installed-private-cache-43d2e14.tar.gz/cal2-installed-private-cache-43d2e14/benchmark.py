"""Qualify installed CAL2 attached to the continuously publishing private fixture."""

import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import measure as m
import replacement as retained


stage = Path(__file__).resolve().parent
baseline_unit = m.unit
source = m.load(m.stage / "persistent.json")
graphs = m.load(m.stage / "retained-live-verification.json")["graphs"]
reference = m.load(m.stage / "replacement-cuda-a/cuda-attach-01/ready-native.json")
expected_edges = {edge: value["format"] for edge, value in retained.native_links(reference).items()}


def command(*args, timeout=60):
    return subprocess.run([str(arg) for arg in args], timeout=timeout, capture_output=True, text=True)


def systemd_action(directory, unit, action):
    earlier = time.monotonic_ns()
    result = command("systemctl", "--user", action, unit, timeout=170)
    later = time.monotonic_ns()
    record = dict(request_ns=earlier, completed_ns=later, elapsed_s=m.seconds(later, earlier),
                  command=result.args, returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
    m.save(directory / (action + "-systemd.json"), record)
    if result.returncode != 0:
        raise RuntimeError(record)
    return record


def capture_native(directory, name, attached=False):
    objects = m.native_dump(directory / (name + "-native.json"))
    retained.fixture(source, objects)
    assert retained.graph_still_live(objects, graphs)
    links = retained.native_links(objects)
    if attached:
        assert len(links) == 10
        assert {edge: value["format"] for edge, value in links.items()} == expected_edges
        assert all(link["state"] in ("active", "paused") for link in links.values())
    else:
        assert not links, links
    return objects


def observer_ready(directory):
    m.check_children()
    return (directory / "observer-ready").is_file()


def control_ready(directory, phase):
    path = directory / (phase + ".json")
    if path.is_file():
        return m.load(path)
    m.check_children()
    return None


def output_evidence(directory, start):
    threshold = start["received_ns"]
    frames = m.cameras()
    rows = m.read_capture(directory)
    result = {}
    for branch in m.branches:
        offsets = [row for row in rows if row["name"] == branch + "-physical-offset" and
                   row["observed_ns"] > start["sent_ns"]]
        assert all(row["max_abs"] == 0 for row in offsets), offsets
        for offset in offsets:
            if offset["observed_ns"] <= threshold:
                continue
            camera = m.same_camera(offset, branch, frames)
            residual = m.modal_match(offset, branch, rows)
            if camera is None or residual is None or camera["observed_ns"] <= threshold:
                continue
            if residual["max_abs"] <= 0:
                continue
            pair = None
            previous = None
            if branch == "scc":
                pair = next((row for row in rows if row["name"] == "scc-pair-status" and row["payload"] == [1] and
                             m.same_camera(row, branch, [camera])), None)
                if pair is None:
                    continue
                previous = next((row for row in frames if row["camera"] == camera["camera"] and
                                 row["sequence"] + 1 == camera["sequence"] and
                                 row["domain"] == camera["domain"] and
                                 row["generation"] == camera["generation"] and
                                 row["observed_ns"] > threshold), None)
                if previous is None:
                    continue
            result[branch] = dict(camera=camera, previous_scc_camera=previous,
                                  offset=m.without_payload(offset),
                                  residual=m.without_payload(residual), pair=pair,
                                  camera_after_ack_s=m.seconds(camera["observed_ns"], threshold),
                                  first_observed_s=m.seconds(max(offset["observed_ns"], residual["observed_ns"],
                                       pair["observed_ns"] if pair else 0), threshold))
            break
    return result if len(result) == len(m.branches) else None


def lease_env():
    return dict(m.child_env)


def launch_control(directory, app, pid):
    command = ["taskset", "-c", "13", m.julia, "--startup-file=no", "--threads=2,1",
               "--project=" + str(app), str(stage / "open-control.jl"),
               str(directory), str(pid), str(m.socket)]
    log = directory / "control.log"
    with log.open("w") as sink:
        child = subprocess.Popen(command, env=lease_env(), stdout=sink, stderr=subprocess.STDOUT)
    m.children.append((child, log))
    return child


def process_evidence(pid):
    process = Path(f"/proc/{pid}")
    argv = process.joinpath("cmdline").read_bytes().rstrip(b"\0").decode().split("\0")
    assert not any(arg.startswith(("-J", "--sysimage")) for arg in argv), argv
    all_mappings = process.joinpath("maps").read_text().splitlines()
    maps = [line for line in all_mappings
            if "libpipewire-ao-0.3" in line or "/lib/julia/sys.so" in line or "PipeWireAORTC/" in line]
    dependency_images = sorted({line.split(maxsplit=5)[5] for line in all_mappings
                                if "/compiled/v1.13/" in line})
    assert any("/lib/julia/sys.so" in line for line in maps), maps
    assert "--compiled-modules=strict" in argv, argv
    cache_prefix = str(Path(os.environ["CAL2_EXPECTED_PRIVATE_CACHE"]).resolve(strict=True))
    mappings = [line for line in maps if "/compiled/v1.13/PipeWireAORTC/" in line]
    assert mappings and all(cache_prefix + "/" in line for line in mappings), mappings
    native_path = Path(mappings[0].split(maxsplit=5)[5])
    with native_path.open("rb") as stream:
        package_image_sha256 = hashlib.file_digest(stream, "sha256").hexdigest()
    status = [line for line in process.joinpath("status").read_text().splitlines()
              if line.startswith(("Cpus_allowed_list:", "Threads:", "VmRSS:"))]
    return dict(argv=argv, maps=maps, status=status, package_image=str(native_path),
                package_image_sha256=package_image_sha256, dependency_images=dependency_images)


def stop_journal(directory, unit, rtc, action, required=True):
    outcome = command("journalctl", "--user", "--no-pager", "-o", "cat",
                      "_SYSTEMD_INVOCATION_ID=" + rtc["invocation"])
    (directory / "invocation.journal").write_text(outcome.stdout)
    marker = "RTC systemd stop timing "
    timing = [json.loads(line[len(marker):]) for line in outcome.stdout.splitlines() if line.startswith(marker)]
    if not timing:
        if required:
            raise RuntimeError("No native Quit timing in invocation journal")
        return None
    native = only(timing)
    assert native["outcome"] == "completed", native
    assert native["invocation"] == rtc["invocation"]
    assert native["unit"] == unit
    deadline = native["deadline_ns"]
    actual = {phase: deadline - native[phase + "_remaining_ns"]
              for phase in ("quit_submission", "offline", "process_exit")}
    order = [action["request_ns"], *actual.values(), action["completed_ns"]]
    assert order == sorted(order), order
    m.save(directory / "native-quit.json", dict(record=native, **actual))
    return native


def only(items):
    assert len(items) == 1, items
    return items[0]


def publishing_snapshot():
    continuity = m.load(m.stage / "live-continuity.json")
    assert {camera["epochs"] for camera in continuity["cameras"].values()} == {1}, continuity
    assert {camera["sequence_gaps"] for camera in continuity["cameras"].values()} == {0}, continuity
    gpu = command("nvidia-smi", "--query-compute-apps=pid,gpu_uuid,used_gpu_memory",
                  "--format=csv,noheader,nounits")
    gpu.check_returncode()
    assert source["hil"]["pid"] in [int(row.split(",")[0]) for row in gpu.stdout.splitlines()], gpu
    return dict(continuity=continuity, gpu=gpu.stdout, source=source, graphs=graphs)


def capture_runtime(directory, root, phase):
    if root.exists():
        inventory = sorted(str(path.relative_to(root)) for path in root.rglob("*"))
    else:
        inventory = None
    m.save(directory / (phase + "-runtime-files.json"), inventory)
    return inventory


def trial(directory, arm, unit, app):
    directory.mkdir()
    capture_native(directory, "before")
    m.save(directory / "publishing-before.json", publishing_snapshot())
    assert m.status(baseline_unit)["MainPID"] == "0"
    assert m.status(unit)["MainPID"] == "0"
    instance = unit.removeprefix("pipewireao-session@").removesuffix(".service")
    runtime = m.runtime.parent / ("pipewireao-session-" + instance)
    capture_runtime(directory, runtime, "before")
    observer_env = dict(m.child_env, JULIA_DEPOT_PATH=os.environ["CAL2_OBSERVER_DEPOT_PATH"])
    m.launch(retained.stock, "12", "live-observe.jl", directory / "observer.log",
             retained.stock, m.socket, directory, m.stage / "observer-reference", env=observer_env)
    m.wait(lambda: observer_ready(directory), 90, "output observer ready")
    attach = systemd_action(directory, unit, "start")
    rtc = m.owner(unit)
    m.save(directory / "rtc-identity.json", rtc)
    m.save(directory / "rtc-process.json", process_evidence(rtc["pid"]))
    print(f"{directory.name}: held Ready in {attach['elapsed_s']:.3f} s", flush=True)
    ready = capture_native(directory, "ready", attached=True)
    links = retained.native_links(ready)
    link_serials = sorted(link["serial"] for link in links.values())
    files = capture_runtime(directory, runtime, "ready")
    if arm == "baseline":
        ledger = runtime / rtc["invocation"] / "launch.json"
    else:
        assert files == ["launch.json"], files
        ledger = runtime / "launch.json"
        assert Path(m.load(ledger)["config"]) == app / "systemd" / "rtc.conf"
    shutil.copyfile(ledger, directory / "ready-ledger.json")
    control = launch_control(directory, app, rtc["pid"])
    held = m.wait(lambda: control_ready(directory, "held"), 90, "fresh public Held Ready")
    (directory / "start").touch()
    start = m.wait(lambda: control_ready(directory, "started"), 20, "native Start acknowledgement")
    evidence = m.wait(lambda: output_evidence(directory, start), 90, "fresh LLOWFS and SCC open-loop output")
    m.save(directory / "live-frames.json", evidence)
    (directory / "read-running").touch()
    assert control.wait(timeout=25) == 0
    running = m.load(directory / "running.json")
    m.children[:] = [(child, log) for child, log in m.children if child != control]
    detached = systemd_action(directory, unit, "stop")
    native_quit = stop_journal(directory, unit, rtc, detached, required=False)
    assert m.status(unit)["MainPID"] == "0" and m.status(unit)["ActiveState"] == "inactive"
    assert m.status(unit)["Result"] == "success"
    stopped = m.load(ledger)
    m.save(directory / "stopped-ledger.json", stopped)
    assert stopped["phase"] == "stopped" and stopped["cleanup_complete"]
    assert stopped["systemd_quit"] == {"attempted": True, "accepted": True}
    files = capture_runtime(directory, runtime, "stopped")
    if arm != "baseline":
        assert files == ["launch.json"], files
    after = capture_native(directory, "after")
    assert not any(m.properties(obj).get("pipewire.sec.pid") == rtc["pid"]
                   for obj in after if obj["type"].endswith(":Client"))
    for name in ("cal2-llowfs-controller", "cal2-scc-controller"):
        assert not retained.by_name(after, name)
    registry = m.runtime.parent / "pipewireao-rtc" / "sessions"
    witness = registry / ("session-" + held["status"]["reply"]["session_id"] + ".pod")
    assert not witness.exists(), witness
    disconnected = m.wait(lambda: retained.advancing_source(detached["completed_ns"]),
                          30, "both independently advancing cameras after Quit")
    m.save(directory / "publishing-after.json", publishing_snapshot())
    retained.stop_observers(directory)
    outputs = [row for row in m.read_capture(directory) if row["name"].endswith("-physical-offset")
               and row["observed_ns"] >= start["sent_ns"]]
    assert all(row["max_abs"] == 0 for row in outputs), outputs
    m.save(directory / "open-offset-count.json", dict(observations=len(outputs), nonzero=0))
    record = dict(directory=directory.name, arm=arm, rtc=rtc, link_serials=link_serials, attach=attach,
                  detach=detached, native_quit=native_quit, started=start, fresh_open_frames=evidence,
                  first_camera_after_detach=disconnected)
    m.save(directory / "result.json", record)
    print(f"{directory.name}: detached in {detached['elapsed_s']:.3f} s; "
          + ", ".join(f"{branch} {entry['camera']['sequence']}" for branch, entry in evidence.items()),
          flush=True)
    return record


def artifact_receipt(destination, unit, app):
    result = command("systemctl", "--user", "cat", unit)
    result.check_returncode()
    (destination / "systemd-unit.txt").write_text(result.stdout)
    files = {}
    for path in (app / "Project.toml", app / "Manifest.toml", app / "deployment.conf",
                 app / "bin/pipewireao-rtc-session", app / "rtc/bin/pipewireao-rtc",
                 *sorted((app / "systemd").glob("*.json")), *sorted((app / "systemd").glob("*.conf"))):
        if path.is_file():
            with path.open("rb") as stream:
                files[str(path)] = hashlib.file_digest(stream, "sha256").hexdigest()
    m.save(destination / "installation-inputs.json", files)


def main(arm, unit, app, group, trial_count):
    app = Path(app)
    results = stage / group
    results.mkdir()
    with (m.runtime.parent / "rtc-devel-benchmark.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        peers = os.environ.get("CAL2_BENCH_PEER_UNITS", "").split()
        contenders = (unit, baseline_unit, *peers)
        if not all(m.status(contender)["ActiveState"] == "inactive" for contender in contenders):
            raise RuntimeError("RTC is already in use")
        artifact_receipt(results, unit, app)
        trials = []
        for index in range(1, int(trial_count) + 1):
            directory = results / f"{index:02}-{arm}"
            try:
                trials.append(trial(directory, arm, unit, app))
                m.save(results / "trials.json", trials)
            finally:
                if m.status(unit)["MainPID"] != "0":
                    result = command("systemctl", "--user", "stop", unit, timeout=170)
                    (directory / "emergency-stop.log").write_text(result.stdout + result.stderr)
                outcome = command("journalctl", "--user", "--no-pager", "-u", unit, "-n", "130")
                (directory / "unit.journal").write_text(outcome.stdout)
                for child, log in m.children.copy():
                    if child.poll() is None:
                        child.terminate()
                        try:
                            child.wait(timeout=8)
                        except subprocess.TimeoutExpired:
                            child.kill()
                            child.wait(timeout=8)
                    m.children.remove((child, log))


if __name__ == "__main__":
    main(*sys.argv[1:])
