#!/usr/bin/env bash
set -euo pipefail
cal2_cache_stage=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cal2_cache_unit=pipewireao-session@c2l-cuda-jhjhtfe9-cache-check.service
cal2_cache_link=$XDG_RUNTIME_DIR/systemd/user/$cal2_cache_unit
cal2_cache_dropin=$cal2_cache_link.d
exec 9>"$XDG_RUNTIME_DIR/rtc-devel-benchmark.lock"
flock -x 9
test "$(systemctl --user show "$cal2_cache_unit" -p MainPID --value)" = 0
test "$(readlink -- "$cal2_cache_link")" = "$cal2_cache_stage/installed-final/systemd/pipewireao-session@.service"
test -f "$cal2_cache_dropin/validation.conf"
rm -- "$cal2_cache_link" "$cal2_cache_dropin/validation.conf"
rmdir -- "$cal2_cache_dropin"
systemctl --user daemon-reload
systemctl --user show "$cal2_cache_unit" -p LoadState,ActiveState,MainPID
