#!/usr/bin/env bash
set -euo pipefail
cal2_cache_stage=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/rtc-cal2-cuda.jhjhtFE9/session-env.sh
cal2_cache_unit=pipewireao-session@c2l-cuda-jhjhtfe9-cache-check.service
cal2_cache_link=$XDG_RUNTIME_DIR/systemd/user/$cal2_cache_unit
cal2_cache_dropin=$cal2_cache_link.d
cal2_cache_depot=$(cat "$cal2_cache_stage/isolated-depot-path.txt")
cal2_cache_installed=$cal2_cache_stage/installed-final/systemd/pipewireao-session@.service
exec 9>"$XDG_RUNTIME_DIR/rtc-devel-benchmark.lock"
flock -x 9
for cal2_rtc in pipewireao-session@c2l-cuda-jhjhtfe9-measure.service \
                pipewireao-session@c2l-cuda-jhjhtfe9-direct.service \
                pipewireao-session@c2l-cuda-jhjhtfe9-native-query.service; do
    test "$(systemctl --user show "$cal2_rtc" -p MainPID --value)" = 0
done
test ! -e "$cal2_cache_link"
test ! -L "$cal2_cache_link"
test ! -e "$cal2_cache_dropin"
test -f "$cal2_cache_installed"
test -d "$cal2_cache_stage/installed-final/rtc-package-cache/compiled"
ln -s "$cal2_cache_installed" "$cal2_cache_link"
mkdir "$cal2_cache_dropin"
cat > "$cal2_cache_dropin/validation.conf" <<CONFIG
[Service]
Environment="JULIA_DEPOT_PATH=$cal2_cache_depot"
Environment="JULIA_LOAD_PATH=@:@stdlib"
Environment="JULIA_PKG_PRECOMPILE_AUTO=0"
Environment="JULIA_NUM_PRECOMPILE_TASKS=1"
Environment="JULIA_IMAGE_THREADS=1"
Environment="OPENBLAS_NUM_THREADS=1"
Environment="TMPDIR=$cal2_cache_stage/tmp"
Environment="XDG_CACHE_HOME=$cal2_cache_stage/xdg-cache"
Environment="POCL_CACHE_DIR=$cal2_cache_stage/pocl"
CONFIG
systemctl --user daemon-reload
systemctl --user cat "$cal2_cache_unit"
