#!/usr/bin/env bash
set -euo pipefail
cal2_cache_stage=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/rtc-cal2-cuda.jhjhtFE9/session-env.sh
export JULIA_DEPOT_PATH
JULIA_DEPOT_PATH=$(cat "$cal2_cache_stage/isolated-depot-path.txt")
export TMPDIR="$cal2_cache_stage/tmp"
export XDG_CACHE_HOME="$cal2_cache_stage/xdg-cache"
export POCL_CACHE_DIR="$cal2_cache_stage/pocl"
export CAL2_PRIOR_INSTALL="$cal2_fixture/candidate-app"
cal2_cache_repo=/home/dgamroth/workspaces/codex/worktrees/rtc-installed-package-cache
mkdir -p "$TMPDIR" "$XDG_CACHE_HOME" "$POCL_CACHE_DIR"
cal2_cache_destination="${2:-$cal2_cache_stage/installed}"
test ! -e "$cal2_cache_destination"
python3 "$cal2_cache_stage/stage-candidate.py" "$cal2_cache_repo" "$1" | tee "$cal2_cache_stage/source.json"
export CAL2_DIRECT_PACKAGE
CAL2_DIRECT_PACKAGE=$(jq -r .package "$cal2_cache_stage/source.json")
taskset -c 12,13 "$CAL2_VALIDATION_JULIA" --startup-file=no --threads=1,0 \
    --project="$cal2_cache_stage/export" -e '
        using PipeWireAORTC, PipeWireAO
        @assert pkgdir(PipeWireAORTC) == ENV["CAL2_DIRECT_PACKAGE"]
        @assert realpath(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir) == realpath(ENV["PIPEWIREAO_PREFIX"])
        @show pkgdir(PipeWireAORTC)
        @show pkgversion(PipeWireAORTC)
        println(PipeWireAORTC.SessionInstall.main(ARGS))
    ' -- --package "$cal2_cache_stage/export" --destination "$cal2_cache_destination" \
        --pipewire-prefix "$PIPEWIREAO_PREFIX" --julia-executable "$CAL2_VALIDATION_JULIA" \
        --graph-installation "$CAL2_PRIOR_INSTALL"
