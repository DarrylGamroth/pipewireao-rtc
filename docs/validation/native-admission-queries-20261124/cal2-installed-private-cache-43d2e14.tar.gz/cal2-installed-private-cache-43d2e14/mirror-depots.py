"""Use private compiled caches with the fixture's existing dependency files."""

import json
from pathlib import Path
import subprocess
import sys
import tomllib


def dependencies(paths):
    roots = ("PipeWireAORTC", "PipeWireAO", "PipeWireAO_jll")
    result = set()
    for path in paths:
        entries = tomllib.loads(Path(path).read_text())["deps"]
        remaining = list(roots)
        seen = set()
        while remaining:
            name = remaining.pop()
            if name in seen:
                continue
            seen.add(name)
            for entry in entries.get(name, []):
                remaining.extend(entry.get("deps", []))
        result.update(seen)
    return sorted(result)


def run(root, depot_list, manifests):
    packages = dependencies(manifests)
    original_depots = dict.fromkeys(Path(line).resolve() for line in Path(depot_list).read_text().splitlines())
    receipt = {}
    for index, original in enumerate(original_depots):
        view = root / "deps" / f"{index:02}"
        view.mkdir(parents=True)
        for directory in ("packages", "artifacts", "registries"):
            if original.joinpath(directory).is_dir():
                view.joinpath(directory).symlink_to(original / directory, target_is_directory=True)
        compiled = view / "compiled/v1.13"
        compiled.mkdir(parents=True)
        for package in packages:
            old = original / "compiled/v1.13" / package
            if old.is_dir():
                subprocess.run(["cp", "-a", "--reflink=auto", old, compiled], check=True)
        receipt[str(view)] = str(original)
    root.joinpath("mirrored-depots.json").write_text(json.dumps(receipt, indent=2) + "\n")
    root.joinpath("isolated-depot-path.txt").write_text(":".join([str(root / "depot"), *receipt]) + "\n")


if __name__ == "__main__":
    run(Path(sys.argv[1]).resolve(), sys.argv[2], sys.argv[3:])
