# Installed private RTC package image on retained CAL2

The normal installer receives the same CAL2 export, original graph installation
and shared native library prefix used in the retained fixture. The RTC package
source is pinned to commit `43d2e14e6dce247d4d4249c34cab58ef9f9a6c66`. The
application and all compiled installer and observer depot layers are under this
scratch directory. The mirrored depots reference existing dependency source
and artifact directories. The two existing operator and native-query unit
definitions were captured before the check. The disposable RTC has its own
systemd instance.

The verification uses standard Julia 1.13.3 and the installed service and
stop client. The running MainPID must have `--compiled-modules=strict` in
argv and must map its PipeWireAORTC package image from the installation's
`rtc-package-cache`. The receipt records the exact loaded image path and
hash. The generated stop launcher is saved along with the native Quit
journal.

The attach timer runs from the normal systemd Start request until it returns
after held Ready. A separate fresh native Status and registry dump confirm
all 10 exact Links and both controllers Open and unprimed. Native Start
releases the graphs. Both controllers remain Open. A separate receiver
associates nonzero live residuals and zero physical offsets with fresh
LLOWFS and SCC exposures. SCC additionally requires a valid pair. The
detach timer runs from the systemd stop request through its completion.
The terminal receipt confirms the accepted native Quit and cleanup. The
invocation journal retains any exact native Quit timing line.

All service operations are serialized through the shared benchmark lock.
The candidate process, the two retained graph services, the private
PipeWire core and the CUDA simulator have separate process lifetimes.
The experiment checks the unchanged core, camera and graph incarnations
and their continued publication after the candidate exits.

## Result on the retained CUDA CAL2 fixture

The installer staged 80 package directories. The colocated cache had
267,294,226 logical bytes across image and serialized files. The live
RTC mapped 80 distinct package images and each came from the private
cache. Its process used Julia's distribution system image and the
strict package-loading option. The generated service stop and cleanup
launcher also selected strict mode. The existing two RTC unit
definitions and checked shared RTC image hashes were identical after
the test.

The fresh RTC reached held Ready in 5.933 s and systemd's normal
native detach completed in 3.337 s. The exact terminal receipt
recorded native Quit accepted, cleanup complete and the invocation
stopped. LLOWFS exposure 53,066 produced its first matching output
0.508 s after Start acknowledgement, with a maximum absolute residual
of 4.0212157 × 10⁻⁸ and zero physical offset. SCC exposure 10,615
produced a matching valid pair with a maximum absolute residual of
8.246598 × 10⁻⁹ and zero physical offset 5.031 s after acknowledgement.
Both channels continued to publish after the stop with their original
acquisition and process identities.

A fresh offline strict Julia process imported the same installed
project with the installer and mirrored depot compiled directories
temporarily moved aside. The source and artifact paths and Julia's
distribution image remained available. The process exited with
status 0 and mapped all 80 package images from the installed private
cache. The first probe imported the package and reached the mapping
assertion. That assertion retained leading whitespace when parsing
the process mappings. The corrected probe trimmed the paths, and
both attempts are in the receipts. No second live attachment was
needed.
