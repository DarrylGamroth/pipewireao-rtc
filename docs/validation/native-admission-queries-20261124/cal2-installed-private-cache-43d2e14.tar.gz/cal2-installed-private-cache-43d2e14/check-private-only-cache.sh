#!/usr/bin/env bash
set -euo pipefail
cal2_cache_stage=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/rtc-cal2-cuda.jhjhtFE9/session-env.sh
export JULIA_DEPOT_PATH
JULIA_DEPOT_PATH=$(cat "$cal2_cache_stage/isolated-depot-path.txt")
export TMPDIR="$cal2_cache_stage/tmp"
export XDG_CACHE_HOME="$cal2_cache_stage/xdg-cache"
export POCL_CACHE_DIR="$cal2_cache_stage/pocl"
export CAL2_PRIVATE_CHECK_SOURCE
CAL2_PRIVATE_CHECK_SOURCE=$(jq -r .package "$cal2_cache_stage/source.json")
exec 9>"$XDG_RUNTIME_DIR/rtc-devel-benchmark.lock"
flock -x 9
IFS=: read -r -a cal2_peer_depots <<<"$JULIA_DEPOT_PATH"
cal2_hidden=()
restore() {
    for layer in "${cal2_hidden[@]}"; do
        mv -- "$layer/compiled.parked-$$" "$layer/compiled"
    done
}
trap restore EXIT
for layer in "${cal2_peer_depots[@]}"; do
    case "$layer" in
        "$cal2_cache_stage"/depot|"$cal2_cache_stage"/deps/*) ;;
        *) exit 1 ;;
    esac
    test "$(realpath -- "$layer")" = "$layer"
    if test -d "$layer/compiled"; then
        mv -- "$layer/compiled" "$layer/compiled.parked-$$"
        cal2_hidden+=("$layer")
    fi
done
code=0
taskset -c 12,13 "$CAL2_VALIDATION_JULIA" --startup-file=no --threads=1,0 --compiled-modules=strict \
    --project="$cal2_cache_stage/installed-final" -e '
        @assert all(path -> !isdir(joinpath(path, "compiled")), DEPOT_PATH)
        installed = joinpath(dirname(Base.active_project()), "rtc-package-cache")
        pushfirst!(DEPOT_PATH, installed)
        using PipeWireAORTC
        @assert pkgdir(PipeWireAORTC) == ENV["CAL2_PRIVATE_CHECK_SOURCE"]
        rows = filter(line -> occursin("/compiled/v1.13/", line), readlines("/proc/self/maps"))
        images = unique(strip(last(split(row; limit=6))) for row in rows)
        @assert !isempty(images) && all(path -> startswith(path, installed * "/"), images) images
        @show VERSION
        @show Base.active_project()
        @show pkgdir(PipeWireAORTC)
        @show length(images)
        @show DEPOT_PATH
        foreach(println, sort!(collect(images)))
    ' || code=$?
printf 'strict_exit_code=%s\n' "$code"
exit "$code"
