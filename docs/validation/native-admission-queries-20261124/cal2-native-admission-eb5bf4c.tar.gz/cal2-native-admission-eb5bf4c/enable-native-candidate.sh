#!/usr/bin/env bash
set -euo pipefail
cal2_native_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/rtc-cal2-cuda.jhjhtFE9/session-env.sh
cal2_native_app=$(realpath -- "${1:?Expected installed candidate path}")
cal2_native_unit=pipewireao-session@c2l-cuda-jhjhtfe9-native-query.service
cal2_operator_unit=pipewireao-session@c2l-cuda-jhjhtfe9-direct.service
cal2_prior_unit=pipewireao-session@c2l-cuda-jhjhtfe9-measure.service
cal2_native_link=$XDG_RUNTIME_DIR/systemd/user/$cal2_native_unit
cal2_native_dropin=$cal2_native_link.d
exec 9>"$XDG_RUNTIME_DIR/rtc-devel-benchmark.lock"
flock -x 9
test "$(systemctl --user show "$cal2_operator_unit" -p MainPID --value)" = 0
test "$(systemctl --user show "$cal2_prior_unit" -p MainPID --value)" = 0
test "$(readlink -- "$XDG_RUNTIME_DIR/systemd/user/$cal2_operator_unit")" = "$cal2_native_dir/installed-b24edf9/systemd/pipewireao-session@.service"
test -f "$cal2_native_app/systemd/rtc.conf"
test -f "$cal2_native_app/systemd/pipewireao-session@.service"
if test -L "$cal2_native_link"; then
    test "$(systemctl --user show "$cal2_native_unit" -p MainPID --value)" = 0
    case "$(readlink -- "$cal2_native_link")" in
        "$cal2_native_dir"/installed-native-*/systemd/pipewireao-session@.service) ;;
        *) exit 1 ;;
    esac
    test -f "$cal2_native_dropin/validation.conf"
    cal2_native_pending=$cal2_native_link.select-$$
    ln -s "$cal2_native_app/systemd/pipewireao-session@.service" "$cal2_native_pending"
    mv -Tf "$cal2_native_pending" "$cal2_native_link"
else
    test ! -e "$cal2_native_link"
    test ! -e "$cal2_native_dropin"
    ln -s "$cal2_native_app/systemd/pipewireao-session@.service" "$cal2_native_link"
    mkdir "$cal2_native_dropin"
    cat > "$cal2_native_dropin/validation.conf" <<CONFIG
[Service]
Environment="JULIA_DEPOT_PATH=$cal2_native_dir/depot:$JULIA_DEPOT_PATH"
Environment="JULIA_LOAD_PATH=@:@stdlib"
Environment="JULIA_PKG_PRECOMPILE_AUTO=0"
Environment="JULIA_NUM_PRECOMPILE_TASKS=1"
Environment="JULIA_IMAGE_THREADS=1"
Environment="OPENBLAS_NUM_THREADS=1"
Environment="TMPDIR=$TMPDIR"
Environment="XDG_CACHE_HOME=$XDG_CACHE_HOME"
Environment="POCL_CACHE_DIR=$POCL_CACHE_DIR"
CONFIG
fi
systemctl --user daemon-reload
if systemctl --user is-failed --quiet "$cal2_native_unit"; then
    systemctl --user reset-failed "$cal2_native_unit"
fi
systemctl --user cat "$cal2_native_unit"
