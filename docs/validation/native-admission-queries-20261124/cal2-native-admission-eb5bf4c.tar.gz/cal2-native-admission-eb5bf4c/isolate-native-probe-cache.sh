#!/usr/bin/env bash
set -euo pipefail
cal2_native_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/rtc-cal2-cuda.jhjhtFE9/session-env.sh
cal2_native_cache="$cal2_native_dir/native-query-cache"
cal2_native_unit=pipewireao-session@c2l-cuda-jhjhtfe9-native-query.service
cal2_operator_unit=pipewireao-session@c2l-cuda-jhjhtfe9-direct.service
cal2_native_unit_link=$XDG_RUNTIME_DIR/systemd/user/$cal2_native_unit
exec 9>"$XDG_RUNTIME_DIR/rtc-devel-benchmark.lock"
flock -x 9
test "$(systemctl --user show "$cal2_native_unit" -p MainPID --value)" = 0
test "$(systemctl --user show "$cal2_operator_unit" -p MainPID --value)" = 0
case "$(readlink -- "$cal2_native_unit_link")" in
    "$cal2_native_dir"/installed-native-*/systemd/pipewireao-session@.service) ;;
    *) exit 1 ;;
esac
cal2_native_config=$cal2_native_unit_link.d/zz-native-query-cache.conf
test ! -e "$cal2_native_config"
test -d "$cal2_native_cache/compiled/v1.13/PipeWireAORTC"
cat > "$cal2_native_config" <<CONFIG
[Service]
Environment="JULIA_DEPOT_PATH=$cal2_native_cache:$cal2_native_dir/depot:$JULIA_DEPOT_PATH"
CONFIG
systemctl --user daemon-reload
systemctl --user cat "$cal2_native_unit"
