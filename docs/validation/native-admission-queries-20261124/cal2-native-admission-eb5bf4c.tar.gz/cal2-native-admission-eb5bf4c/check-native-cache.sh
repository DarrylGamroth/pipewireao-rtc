#!/usr/bin/env bash
set -euo pipefail
cal2_native_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/rtc-cal2-cuda.jhjhtFE9/session-env.sh
export JULIA_DEPOT_PATH="$cal2_native_dir/depot:$JULIA_DEPOT_PATH"
cal2_native_app=$(realpath -- "${1:?Expected installed application}")
cal2_native_source_json=$(realpath -- "${2:?Expected source receipt path}")
cal2_native_compiled_mode=${3:-strict}
if test -n "${4:-}"; then
    export JULIA_DEPOT_PATH="$4:$JULIA_DEPOT_PATH"
fi
export CAL2_CACHE_EXPECTED_PACKAGE
CAL2_CACHE_EXPECTED_PACKAGE=$(jq -r .package "$cal2_native_source_json")
taskset -c 12,13 "$CAL2_VALIDATION_JULIA" --startup-file=no --threads=1,0 \
    --compiled-modules="$cal2_native_compiled_mode" --project="$cal2_native_app" -e '
        using PipeWireAORTC
        @assert pkgdir(PipeWireAORTC) == ENV["CAL2_CACHE_EXPECTED_PACKAGE"]
        @show VERSION
        @show pkgdir(PipeWireAORTC)
        @show Base.active_project()
        rows = filter(readlines("/proc/self/maps")) do row
            occursin("/compiled/v1.13/PipeWireAORTC/", row)
        end
        @assert !isempty(rows)
        foreach(println, rows)
    '
