# Native admission queries on the retained CUDA CAL2 fixture

The two RTC installations use the same running independent CUDA simulator,
private PipeWire core, pupil feeder, camera receiver, and previously installed
LLOWFS and SCC graph services. Each starts a fresh Julia 1.13.3 process with
the distribution system image. The unchanged operator unit selects the
baseline RTC at `b24edf9785c7ee8e5b958a2ce98f2e8dc5d8729d`. The candidate has
its own unit instance bound to the same retained services. The invocation
receipts identify the two installations and the unchanged provider, core
and graph process incarnations. The application manifests differ only in
the selected RTC package tree. The native transport prefix, graph and
calibration assets, CPU placements, and optical publication are shared.

Three baseline, three candidate, and three additional baseline starts ran
without a process sampler. The second baseline block immediately followed
the candidate block. The timed intervals run from the systemctl request until it
returns. A fresh native Ready status confirmed Hold and exactly 10 owned
Links. A separate native registry dump verified the declared Nodes, Ports,
NDArray formats and state. The output observer starts before timing.
Neither integrator receives Close or synthetic input. Both report Open at
Ready and after Start. Each trial qualifies a nonzero LLOWFS residual and
a nonzero SCC residual with valid pair status. Their matching camera
observations and the preceding SCC exposure were observed after Start
acknowledgement. Every observed physical offset after Start was exactly
zero.

The normal systemd Stop path positively completes native Quit. The RTC's
systemd runtime contains one fixed launch receipt at Ready and after
detach. The native registry and all retained process identities were
checked after each stop, then camera observations confirmed both streams
advanced without producer or graph replacement.

Separate untimed diagnostic activations sampled the exact RTC service
cgroup from the start request through its return. This sample can miss
children that start and exit between polls. The observed children and
sample gaps are retained separately from the timed trials. External
systemctl requests and independent registry dumps run outside that cgroup.

The interim `909c718` application finished installation. It was left
unselected when review found a scoped manager call and authentication
deadline needed correction. It contributed no activations or measurements.

## Results

The candidate pins RTC source `eb5bf4cb2ee499bdfb4316d61a84ca2cb84b7dd5`
and package tree `35e7dff8a7d703527696e5174845cf8324414c7b`. Installation
sealed the normalized direct configuration. Native CoreInfo and sd-bus
queries ran during direct MediaSession activation. The separate baseline
process probe observed 19 `systemctl show` children, one `pwao-dump`
child, and a child with the parser's truncated `pwao-spa-json-d` process
name. The separate candidate probe observed none of those query children.
Process polling can miss short-lived processes. The process probes are
outside the timing cohort.

| Cache-present block | Ready, median (s) | Ready, range (s) | Detach, median (s) | Detach, range (s) |
| --- | ---: | ---: | ---: | ---: |
| Earlier baseline | 5.430 | 5.426–5.452 | 2.880 | 2.863–2.963 |
| Candidate | 6.387 | 6.340–7.928 | 3.561 | 3.452–3.678 |
| Later baseline | 5.897 | 5.890–6.225 | 3.090 | 3.008–3.177 |

The later baseline was slower than the earlier one. The candidate
median remained 0.490 s slower to Ready and 0.471 s slower to detach
than the later baseline. The nine trials establish the observed range
on this development host. They do not isolate the costs of Julia
compilation, native negotiation, individual D-Bus requests, or the
additional placement and final readiness checks.

On the first return to the baseline installed tree, a Julia package-image
compiler child ran within the service cgroup. That start reached Ready
in 167.875 s. Its functional results and compiler process witness are
preserved. The later cache-present baseline excludes this cold trial.
An additional cache-present trial reached Ready in 6.082 s and its
systemd stop command returned success. The expected exact-invocation
native Quit timing message did not appear in the journal. The harness
kept the partial trial and completed a replacement.

The operator unit still points at its original baseline installation.
A fresh Julia process loaded that installed project's RTC package image
with `--compiled-modules=strict` from the original cache. The candidate
diagnostic used a second cache with its own strictly verified package
image to keep the operator cache available. The candidate unit is
installed separately and detached. The baseline RTCs are also detached.
The simulator, private core and both retained graphs kept their systemd
and native identities. Both cameras advanced after the final diagnostic.

Replay `replay-native-admission.py` with the archive directory followed
by `native-admission-baseline-b24edf9`, `native-admission-eb5bf4c`, and
`native-admission-qualified-post-b24edf9`. It rechecks the nine retained
native topologies, controller states, acquisition identities, outputs,
and camera sequence continuity using the bounded camera trace.
