"""Sample subprocesses in the selected RTC service cgroup until held Ready."""

import fcntl
import os
from pathlib import Path
import statistics
import sys
import threading
import time

import benchmark as b

m = b.m
operator = "pipewireao-session@c2l-cuda-jhjhtfe9-direct.service"
unit = os.environ.get("CAL2_PROBE_UNIT", operator)


def unit_property(name):
    return b.command("systemctl", "--user", "show", unit, "--property=" + name,
                     "--value").stdout.strip()


def expected_cgroup():
    uid = m.runtime.parent.name
    slice_name = unit_property("Slice")
    assert slice_name == r"app-pipewireao\x2dsession.slice", slice_name
    return Path("/sys/fs/cgroup", "user.slice", f"user-{uid}.slice", f"user@{uid}.service",
                "app.slice", slice_name, unit)


def process(pid):
    root = Path("/proc", pid)
    cmdline = root.joinpath("cmdline").read_bytes().rstrip(b"\0").split(b"\0")
    return dict(argv=[entry.decode(errors="replace") for entry in cmdline],
                comm=root.joinpath("comm").read_text().rstrip())


def sample(cgroup, armed, stop, records, gaps):
    previous = None
    armed.set()
    while not stop.is_set():
        sample_ns = time.monotonic_ns()
        if previous is not None:
            gaps.append(sample_ns - previous)
        previous = sample_ns
        try:
            pids = cgroup.joinpath("cgroup.procs").read_text().split()
        except FileNotFoundError:
            pids = []
        for pid in pids:
            if pid in records:
                records[pid]["last_observed_ns"] = sample_ns
                continue
            try:
                detail = process(pid)
            except (FileNotFoundError, ProcessLookupError):
                continue
            if detail["argv"]:
                records[pid] = dict(pid=int(pid), first_observed_ns=sample_ns,
                                    last_observed_ns=sample_ns, **detail)
        stop.wait(0.001)


def probe(output, app, expected):
    output.mkdir()
    with (m.runtime.parent / "rtc-devel-benchmark.lock").open("a") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX)
        assert m.status(operator)["ActiveState"] == "inactive"
        assert m.status(unit)["ActiveState"] == "inactive"
        assert m.status(b.baseline_unit)["ActiveState"] == "inactive"
        b.artifact_receipt(output, unit, app)
        b.capture_native(output, "before")
        m.save(output / "publishing-before.json", b.publishing_snapshot())
        cgroup = expected_cgroup()
        records, gaps = {}, []
        armed, done = threading.Event(), threading.Event()
        try:
            writer = threading.Thread(target=sample, args=(cgroup, armed, done, records, gaps))
            writer.start()
            armed.wait()
            try:
                b.systemd_action(output, unit, "start")
            finally:
                done.set()
                writer.join()
            evidence = dict(cgroup=str(cgroup), arm=expected, sample_count=len(gaps),
                            median_gap_ms=statistics.median(gaps) / 1e6,
                            max_gap_ms=max(gaps) / 1e6, observed=list(records.values()))
            m.save(output / "activation-processes.json", evidence)
            rtc = m.owner(unit)
            m.save(output / "rtc-identity.json", rtc)
            assert str(cgroup) == "/sys/fs/cgroup" + unit_property("ControlGroup")
            assert str(rtc["pid"]) in records, evidence
            assert b.process_evidence(rtc["pid"])["argv"][0].endswith("/julia")
            b.capture_native(output, "ready", attached=True)
            detached = b.systemd_action(output, unit, "stop")
            b.stop_journal(output, unit, rtc, detached, required=False)
            b.capture_native(output, "after")
            m.save(output / "camera-after-detach.json", m.wait(
                lambda: b.retained.advancing_source(detached["completed_ns"]), 30,
                "both cameras advance after process diagnostic"))
            m.save(output / "publishing-after.json", b.publishing_snapshot())
            assert m.status(unit)["ActiveState"] == "inactive"
            targets = {}
            for record in records.values():
                executable = Path(record["argv"][0]).name
                if executable == "systemctl" and "show" in record["argv"]:
                    targets.setdefault("systemctl show", []).append(record)
                if executable == "pwao-dump" or record["comm"] == "pwao-dump":
                    targets.setdefault("pwao-dump", []).append(record)
                if executable == "pwao-spa-json-dump" or record["comm"] == "pwao-spa-json-d":
                    targets.setdefault("pwao-spa-json-dump", []).append(record)
            m.save(output / "observed-query-children.json", targets)
            if expected == "baseline":
                assert set(targets) == {"systemctl show", "pwao-dump", "pwao-spa-json-dump"}, targets
            else:
                assert not targets, targets
            print(f"{expected} activation query children observed: "
                  f"{dict((name, len(entries)) for name, entries in targets.items())}", flush=True)
        finally:
            if m.status(unit)["MainPID"] != "0":
                b.systemd_action(output, unit, "stop")


if __name__ == "__main__":
    probe(b.stage / sys.argv[3], Path(sys.argv[1]).resolve(strict=True), sys.argv[2])
