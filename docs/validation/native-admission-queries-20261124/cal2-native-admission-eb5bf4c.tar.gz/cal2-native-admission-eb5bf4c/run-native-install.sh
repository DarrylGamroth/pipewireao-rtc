#!/usr/bin/env bash
set -euo pipefail
cal2_direct_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/rtc-cal2-cuda.jhjhtFE9/session-env.sh
export JULIA_DEPOT_PATH="$cal2_direct_dir/depot:$JULIA_DEPOT_PATH"
export CAL2_PRIOR_INSTALL="$cal2_fixture/candidate-app"
cal2_direct_repo=/home/dgamroth/workspaces/codex/worktrees/rtc-native-admission-queries
cal2_direct_destination="${2:-$cal2_direct_dir/installed}"
test ! -e "$cal2_direct_destination"
python3 "$cal2_direct_dir/stage-candidate.py" "$cal2_direct_repo" "$1" | tee "$cal2_direct_dir/source.json"
cal2_direct_pkg=$(jq -r '.package' "$cal2_direct_dir/source.json")
export CAL2_DIRECT_PACKAGE="$cal2_direct_pkg"
taskset -c 12,13 "$CAL2_VALIDATION_JULIA" --startup-file=no --threads=1,0 \
    --project="$cal2_direct_dir/export" -e '
        using PipeWireAORTC, PipeWireAO
        @assert pkgdir(PipeWireAORTC) == ENV["CAL2_DIRECT_PACKAGE"]
        @assert realpath(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir) == realpath(ENV["PIPEWIREAO_PREFIX"])
        @show pkgdir(PipeWireAORTC)
        @show pkgversion(PipeWireAORTC)
        println(PipeWireAORTC.SessionInstall.main(ARGS))
    ' -- --package "$cal2_direct_dir/export" --destination "$cal2_direct_destination" \
        --pipewire-prefix "$PIPEWIREAO_PREFIX" --julia-executable "$CAL2_VALIDATION_JULIA" \
        --graph-installation "$CAL2_PRIOR_INSTALL"
