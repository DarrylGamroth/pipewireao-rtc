"""Select the three fully witnessed, cache-present post-candidate trials."""

import json
from pathlib import Path


def load(path):
    return json.loads(path.read_text())


def run():
    root = Path(__file__).resolve().parent
    original = "native-admission-baseline-post-b24edf9"
    replacement = "native-admission-baseline-post-extra-b24edf9"
    qualified = root / "native-admission-qualified-post-b24edf9"
    qualified.mkdir()
    selected = [("02-native-baseline-post", original),
                ("01-native-baseline-post", replacement),
                ("02-native-baseline-post", replacement)]
    trials = []
    origins = {}
    for index, (attempt, group) in enumerate(selected, 1):
        rows = load(root / group / "trials.json")
        trial = next(row for row in rows if row["directory"] == attempt)
        assert trial["native_quit"]["outcome"] == "completed"
        name = f"{index:02}-native-baseline-post"
        qualified.joinpath(name).symlink_to(Path("..", group, attempt), target_is_directory=True)
        trials.append(dict(trial, directory=name))
        origins[name] = dict(group=group, attempt=attempt, invocation=trial["rtc"]["invocation"])
    (qualified / "trials.json").write_text(json.dumps(trials, indent=2) + "\n")
    (qualified / "origins.json").write_text(json.dumps(origins, indent=2) + "\n")


if __name__ == "__main__":
    run()
