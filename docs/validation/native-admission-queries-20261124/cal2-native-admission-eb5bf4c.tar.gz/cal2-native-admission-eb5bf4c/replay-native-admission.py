"""Replay native-link and camera-output checks from the archived CAL2 trial data."""

import csv
import json
import math
from pathlib import Path
import sys


def load(path):
    return json.loads(path.read_text())


def properties(obj):
    return obj.get("info", {}).get("props", {})


def links(path):
    objects = {obj["id"]: obj for obj in load(path)}
    topology = {}
    for obj in objects.values():
        props = properties(obj)
        if not obj["type"].endswith(":Link") or not props.get("object.path", "").startswith("pipewireao/session/"):
            continue
        assert props["object.linger"] is False
        assert obj["info"]["state"] in ("active", "paused")
        endpoints = []
        for end, direction in (("output", "out"), ("input", "in")):
            node = properties(objects[int(props["link." + end + ".node"])])
            port = properties(objects[int(props["link." + end + ".port"])])
            assert port["port.direction"] == direction
            endpoints.extend((node["node.name"], port["port.name"]))
        edge = tuple(endpoints)
        assert edge not in topology
        assert obj["info"]["format"]["mediaSubtype"] == "ndarray"
        topology[edge] = obj["info"]["format"]
    return topology


def read_cameras(path):
    series = {"cal2-llowfs": [], "cal2-scc": []}
    with path.open(newline="") as stream:
        for record in csv.DictReader(stream, delimiter="\t"):
            for field in ("sequence", "model_ns", "generation", "observed_ns", "exposure_ns"):
                record[field] = int(record[field])
            record["max_abs"] = float(record["max_abs"])
            series[record["camera"]].append(record)
    for camera, observations in series.items():
        assert len({(row["domain"], row["generation"]) for row in observations}) == 1
        assert all(b["sequence"] - a["sequence"] == 1 and
                   b["model_ns"] > a["model_ns"] and b["observed_ns"] > a["observed_ns"]
                   for a, b in zip(observations, observations[1:])), camera
    return series


def frame_id(row):
    return row["domain"], row["generation"], row["model_ns"], row["acquired_sequence"]


def camera_id(row):
    return row["domain"], row["generation"], row["model_ns"], row["sequence"]


def first_usable(outputs, captures, branch, start):
    camera_index = {camera_id(row): row for row in captures}
    by_sequence = {row["sequence"]: row for row in captures}
    residuals = {frame_id(row): row for row in outputs if row["name"] == branch + "-modal-residual"}
    pairs = {frame_id(row): row for row in outputs
             if row["name"] == "scc-pair-status" and row["payload"] == [1]}
    for offset in outputs:
        if offset["name"] != branch + "-physical-offset" or offset["observed_ns"] < start["sent_ns"]:
            continue
        assert offset["max_abs"] == 0
        if offset["observed_ns"] <= start["received_ns"]:
            continue
        ident = frame_id(offset)
        exposure = camera_index.get(ident)
        residual = residuals.get(ident)
        if exposure is None or residual is None or exposure["observed_ns"] <= start["received_ns"]:
            continue
        if not math.isfinite(residual["max_abs"]) or residual["max_abs"] <= 0:
            continue
        pair = None
        previous = None
        if branch == "scc":
            pair = pairs.get(ident)
            previous = by_sequence.get(exposure["sequence"] - 1)
            if pair is None or previous is None or previous["observed_ns"] <= start["received_ns"]:
                continue
        following = max(offset["observed_ns"], residual["observed_ns"], pair["observed_ns"] if pair else 0)
        return exposure, offset, residual, pair, previous, (following - start["received_ns"]) / 1e9
    raise AssertionError("No qualifying output for " + branch)


def check_phase(path, state, held):
    record = load(path)
    status = record["status"]["reply"]
    assert status["ok"] and status["state"] == state
    assert status["result"]["running"] == (not held)
    assert status["result"]["owned_links"] == 10
    suffix = "pipewireao.correction-control.correction:closed"
    assert len(record["properties"]) == 2
    for graph in record["properties"]:
        props = graph["reply"]["result"]["properties"]
        assert props["correction:closed"]["value"] is False
        assert props[suffix + ".state"]["value"] == "Open"
        assert props[suffix + ".requested"]["value"] is False
        assert not props[suffix + ".fault"]["value"]
        if held:
            assert props[suffix + ".primed"]["value"] is False


def replay(root, groups):
    cameras = read_cameras(root / "camera-trace-window.tsv")
    expected = links(root / groups[0] / "01-native-baseline" / "ready-native.json")
    assert len(expected) == 10
    graph_receipt, provider_receipt = None, None
    trials = []
    incarnations = set()
    all_link_serials = set()
    for group in groups:
        group_path = root / group
        items = load(group_path / "trials.json")
        assert len(items) == 3
        for trial in items:
            invocation = trial["rtc"]["invocation"]
            assert invocation not in incarnations
            incarnations.add(invocation)
            link_serials = set(trial["link_serials"])
            assert len(link_serials) == 10 and link_serials.isdisjoint(all_link_serials)
            all_link_serials.update(link_serials)
            trace = group_path / trial["directory"]
            assert links(trace / "before-native.json") == {}
            assert links(trace / "ready-native.json") == expected
            assert links(trace / "after-native.json") == {}
            check_phase(trace / "held.json", "Ready", True)
            check_phase(trace / "running.json", "Running", False)
            assert load(trace / "ready-runtime-files.json") == ["launch.json"]
            assert load(trace / "stopped-runtime-files.json") == ["launch.json"]
            assert trial["native_quit"]["outcome"] == "completed"
            for final in ("publishing-before.json", "publishing-after.json"):
                continuity = load(trace / final)
                graph_receipt = graph_receipt or continuity["graphs"]
                provider_receipt = provider_receipt or continuity["source"]
                assert graph_receipt == continuity["graphs"] and provider_receipt == continuity["source"]
            outputs = [json.loads(row) for row in (trace / "output-trace.jsonl").read_text().splitlines()]
            for branch in ("llowfs", "scc"):
                exposure, offset, residual, pair, previous, seconds = first_usable(
                    outputs, cameras["cal2-" + branch], branch, trial["started"])
                reference = trial["fresh_open_frames"][branch]
                assert exposure == reference["camera"]
                assert offset["observed_ns"] == reference["offset"]["observed_ns"]
                assert residual["observed_ns"] == reference["residual"]["observed_ns"]
                assert pair == reference["pair"] and previous == reference["previous_scc_camera"]
                assert seconds == reference["first_observed_s"]
            for branch, sample in trial["first_camera_after_detach"].items():
                assert sample in cameras[branch]
                assert sample["observed_ns"] > trial["detach"]["completed_ns"]
            assert all(row["max_abs"] == 0 for row in outputs if row["name"].endswith("-physical-offset") and
                       row["observed_ns"] >= trial["started"]["sent_ns"])
            trials.append(trial["arm"] + "/" + trial["directory"])
    assert len(trials) == 3 * len(groups)
    return dict(trials=trials, checked_links_per_trial=len(expected), gap_free_camera_ranges={
        camera: [rows[0]["sequence"], rows[-1]["sequence"]] for camera, rows in cameras.items()
    })


if __name__ == "__main__":
    result = replay(Path(sys.argv[1]), sys.argv[2:])
    print(json.dumps(result, indent=2))
