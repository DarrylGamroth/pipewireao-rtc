"""Save the bounded retained camera observations needed to replay timed CAL2 trials."""

import csv
import json
from pathlib import Path
import sys


def run(source, destination, groups):
    trials = [trial for group in groups
              for trial in json.loads((Path(group) / "trials.json").read_text())]
    start = min(record["attach"]["request_ns"] for record in trials)
    end = max(frame["observed_ns"] for record in trials for frame in record["first_camera_after_detach"].values())
    with Path(source).open() as live, Path(destination).open("x") as saved:
        saved.write(live.readline())
        for row in live:
            fields = row.split("\t")
            if len(fields) != 8:
                continue
            observed = int(fields[5])
            if start <= observed <= end:
                saved.write(row)


if __name__ == "__main__":
    run(*sys.argv[1:3], sys.argv[3:])
