using PipeWireAORTC
const RTC = PipeWireAORTC
const R = RTC.SessionRuntime
const C = RTC.Common
const Cmds = RTC.RunnerCommands

function capture_threads(path, owners)
    open(path, "w") do output
        println(output, "monotonic_ns=", time_ns())
        for role in sort!(collect(keys(owners)))
            pid = owners[role]["pid"]
            println(output, "role=", role, " pid=", pid)
            print(output, read(`ps -L -p $pid -o pid,tid,psr,cls,rtprio,stat,comm`, String))
            for tid in sort!(readdir("/proc/$pid/task"))
                task = "/proc/$pid/task/$tid"
                try
                    affinity = only(filter(line -> startswith(line, "Cpus_allowed_list:"),
                                          readlines(joinpath(task, "status"))))
                    sched = chomp(read(joinpath(task, "schedstat"), String))
                    println(output, tid, ' ', affinity, " schedstat=", sched)
                catch error
                    error isa SystemError || rethrow()
                end
            end
        end
    end
end

function sample_property_adoption(handle, raw)
    graph = "gpi2-jfg-frame-graph"
    target = "closed-loop-correction:closed"
    readback() = R.control!(handle, Cmds.parse(["properties", graph]))
    initial = readback()
    C.write_json(joinpath(raw, "properties-initial.json"), initial)
    initial["ok"] === true || return
    property = get(initial["result"]["properties"], target, nothing)
    property === nothing && return
    original = Bool(property["value"])
    for (index, desired) in enumerate((!original, original))
        reply = R.control!(handle, Cmds.parse(["property", graph, target, "bool", string(desired)]))
        C.write_json(joinpath(raw, "property-request-$index.json"), reply)
        sleep(3)
        C.write_json(joinpath(raw, "property-observed-$index.json"), readback())
    end
end

function run_measurement(stage, raw, prefix; baseline_seconds, profiler_seconds, properties)
    handle = R.attach(stage)
    marks = Dict{String,Any}()
    open(joinpath(raw, "unit"), "w") do io
        println(io, handle.unit)
    end
    try
        ready = R.ready(handle)
        @show ready["phase"] ready["observation_remote"] ready["processes"]
        flush(stdout)
        C.write_json(joinpath(raw, "ready.json"), ready)
        remote = ready["observation_remote"]
        config = joinpath(ready["private_runtime"], "session")
        env = (
            "PIPEWIREAO_CONFIG_DIR" => config,
            "PIPEWIREAO_MODULE_DIR" => joinpath(prefix, "lib", "pipewire-ao-0.3"),
            "PIPEWIREAO_SPA_PLUGIN_DIR" => joinpath(prefix, "lib", "spa-ao-0.2"),
        )
        dump = addenv(`$(joinpath(prefix, "bin", "pwao-dump")) -N -r $remote`, env...)
        write(joinpath(raw, "registry-ready.json"), read(dump, String))
        capture_threads(joinpath(raw, "threads-ready.txt"), ready["processes"])
        full_graph_trace = isdir(joinpath(raw, "callback-maps"))
        if properties && !full_graph_trace
            baseline_seconds = min(15, baseline_seconds)
            profiler_seconds = min(8, profiler_seconds)
            properties = false
            @warn "Mapped graph trace unavailable; collecting a short HIL-only pacing record"
        end
        marks["run_requested"] = time_ns()
        live = R.running!(handle)
        marks["running_confirmed"] = time_ns()
        @show live["phase"]
        flush(stdout)
        sleep(10)
        marks["baseline_begin"] = time_ns()
        capture_threads(joinpath(raw, "threads-baseline-begin.txt"), live["processes"])
        sleep(baseline_seconds)
        marks["baseline_end"] = time_ns()
        capture_threads(joinpath(raw, "threads-baseline-end.txt"), live["processes"])
        profiler = addenv(
            `timeout --signal=INT --kill-after=2s $(string(profiler_seconds, "s")) $(joinpath(prefix, "bin", "pwao-profiler")) -r $remote -J -o $(joinpath(raw,"profiler-table.log"))`,
            env...,
        )
        marks["profiler_begin"] = time_ns()
        code = open(joinpath(raw,"profiler.json"), "w") do out
            open(joinpath(raw,"profiler.err"), "w") do err
                run(pipeline(ignorestatus(profiler); stdout=out, stderr=err)).exitcode
            end
        end
        marks["profiler_end"] = time_ns()
        @show code
        graph_pid = live["processes"]["julia"]["pid"]
        graph_tids = [tid for tid in readdir("/proc/$graph_pid/task") if
            chomp(read("/proc/$graph_pid/task/$tid/comm", String)) == "julia-data-loop"]
        if length(graph_tids) == 1 && (full_graph_trace || basename(dirname(raw)) != "rate-2000")
            tid = only(graph_tids)
            perf_data = joinpath(raw, "graph-perf.data")
            marks["perf_begin"] = time_ns()
            open(joinpath(raw, "graph-perf.err"), "w") do err
                run(pipeline(ignorestatus(`perf record --event cpu-clock:u --freq 999 --tid $tid --output $perf_data -- sleep 25`); stderr=err))
            end
            marks["perf_end"] = time_ns()
        end
        if properties
            marks["properties_begin"] = time_ns()
            try
                sample_property_adoption(handle, raw)
            catch error
                @warn "Property adoption check failed" exception=(error, catch_backtrace())
            finally
                marks["properties_end"] = time_ns()
            end
        end
        status = R.control!(handle, Cmds.parse(["status"]))
        C.write_json(joinpath(raw, "status.json"), status)
        @show status
        marks["quit_requested"] = time_ns()
    finally
        C.write_json(joinpath(raw, "marks.json"), marks)
        flush(stdout)
        receipt = R.stop!(handle)
        C.write_json(joinpath(raw, "stop.json"), receipt)
        @assert receipt["systemd_quit"]["accepted"] === true
        println("QUIT ACKNOWLEDGED")
    end
end

run_measurement(ARGS[1], ARGS[2], ARGS[3]; baseline_seconds=parse(Int, ARGS[4]), profiler_seconds=parse(Int, ARGS[5]), properties=basename(dirname(ARGS[2])) == "rate-2000")
