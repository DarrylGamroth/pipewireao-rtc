using PipeWireAORTC, UUIDs
const RTC = PipeWireAORTC
const R = RTC.SessionRuntime
const C = RTC.Common
application, stage, prefix, depot = ARGS
@assert join(DEPOT_PATH, ':') == depot
mkpath(stage)
installed = joinpath(stage, "installed")
RTC.SessionInstall.install((; package=application, destination=installed, pipewire_prefix=prefix))
suffix = first(replace(string(uuid4()), "-" => ""), 12)
unit = "pipewireao-session@" * suffix * ".service"
root = R.runtime_directory(unit)
unit_file = joinpath(installed, "systemd", unit)
cp(joinpath(installed, "systemd", "pipewireao-session@.service"), unit_file)
dropin = joinpath(ENV["XDG_RUNTIME_DIR"], "systemd", "user", unit * ".d")
mkpath(dirname(dropin))
mkdir(dropin)
write(joinpath(dropin, "depot.conf"),
    "[Service]\nEnvironment=JULIA_DEPOT_PATH=$depot JULIA_LOAD_PATH=@:@stdlib\n")
C.write_json(joinpath(stage, "pending-session.json"),
    Dict("unit"=>unit, "runtime_root"=>root, "installed"=>installed); atomic=true)
started = false
try
    run(`systemctl --user link --runtime $unit_file`)
    run(`systemctl --user daemon-reload`)
    global started = true
    run(`systemctl --user start $unit`)
    handle = R.attach(root)
    R._receipt(stage, handle)
catch error
    R._reconcile_failed_start!(stage, unit, root, unit_file, started, error)
    rethrow()
end
