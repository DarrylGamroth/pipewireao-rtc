import csv
import struct
import sys
from pathlib import Path

root = Path(sys.argv[1])
maps = root / "callback-maps"

def load(name, kind):
    return list(struct.iter_unpack("<" + kind, (maps / name).read_bytes()))

start = load("start_ns", "Q")
end = load("end_ns", "Q")
rows = sum(stamp[0] != 0 for stamp in start)
assert 0 < rows < len(start), "trace absent or at capacity"
assert all(a[0] for a in start[:rows]), "noncontiguous callback trace"
assert all(a[0] <= b[0] for a, b in zip(start[:rows], end[:rows], strict=True)), "incomplete callback trace"
seq = load("sequence", "Q")
offset = load("offset", "q")
begin_sample = load("allocation_start", "Qqii")
end_sample = load("allocation_end", "Qqii")
property_change = load("properties_changed", "?")
parameter_change = load("parameters_changed", "?")
succeeded = load("succeeded", "?")

def flag(condition):
    return "true" if condition else "false"

with (root / "callbacks.csv").open("x", newline="") as f:
    out = csv.writer(f)
    out.writerow("callback,sequence,offset,start_ns,end_ns,allocated_bytes,allocation_valid,gc_epoch_start,gc_epoch_end,thread_id,properties_changed,parameters_changed,succeeded".split(","))
    for i in range(rows):
        ea, ba, ta, ga = begin_sample[i]
        eb, bb, tb, gb = end_sample[i]
        valid = ea == eb and ta == tb and ga == gb == 1 and bb >= ba
        out.writerow((i + 1, seq[i][0], offset[i][0], start[i][0], end[i][0], bb - ba if valid else "",
                      flag(valid), ea, eb, ta, flag(property_change[i][0]), flag(parameter_change[i][0]),
                      flag(succeeded[i][0])))

trace = (root / "gc.bin").read_bytes()
begun, finished, data_tid = struct.unpack_from("<QQi", trace)
collections = list(struct.iter_unpack("<QQQ", trace[24:]))
assert begun == finished < len(collections), "collector trace incomplete or at capacity"
with (root / "gc.csv").open("x", newline="") as f:
    out = csv.writer(f)
    out.writerow(("epoch", "begin_ns", "end_ns", "full"))
    for i, (begin, finish, mode) in enumerate(collections[:begun], 1):
        assert 0 < begin <= finish
        out.writerow((i, begin, finish, mode))

print(f"callback capacity {len(start)}, records {rows}, GC events {begun}, graph data TID {data_tid}")
