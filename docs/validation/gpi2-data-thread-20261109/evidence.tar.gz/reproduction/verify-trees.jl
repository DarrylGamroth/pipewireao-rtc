using Pkg, TOML, Test, PipeWireAO, PipeWireAORTC
root = only(ARGS)
manifest = TOML.parsefile(joinpath(root, "environment", "Manifest.toml"))
packages = Dict(dep.name => dep for dep in values(Pkg.dependencies()))
@testset "release source trees and SDK" begin
    for name in ("PipeWireAORTC", "PipeWireAO", "PipeWireAO_jll", "PipeWireAOQueue_jll",
                 "FilterGraphAlgorithms", "FilterGraphs", "FilterGraphPipeWire",
                 "AdaptiveOpticsSim", "AdaptiveOpticsSimPipeWireHIL", "Proper")
        entry = only(manifest["deps"][name])
        package = packages[name]
        @test package.is_tracking_registry
        @test string(package.version) == entry["version"]
        @test bytes2hex(Pkg.GitTools.tree_hash(package.source)) == entry["git-tree-sha1"]
        println(name, ' ', package.version, ' ', package.tree_hash)
    end
    @test PipeWireAO.library_version() == v"4.0.2"
    prefix = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
    queue = PipeWireAORTC.SessionLaunch.PipeWireAOQueue_jll.libpipewire_module_queue
    @test basename(prefix) == "b84754cc61ae9a8e33d31ec4352f188fa5405581"
    @test isfile(queue)
    @test !isfile(joinpath(prefix, "lib", "pipewire-ao-0.3", basename(queue)))
    write(joinpath(root, "artifact-path"), prefix * "\n")
    println("prefix=", prefix, " queue=", realpath(queue))
end
