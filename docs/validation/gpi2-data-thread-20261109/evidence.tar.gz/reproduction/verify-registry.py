import json
import sys
from pathlib import Path

for directory in map(Path, sys.argv[1:]):
    ready = json.loads((directory / "ready.json").read_text())
    records = json.loads((directory / "registry-ready.json").read_text())

    def index(interface):
        return {r["id"]: r for r in records if r["type"] == "PipeWire:Interface:" + interface}

    def properties(record):
        return record.get("info", {}).get("props", {})

    clients, nodes, ports, links = map(index, ("Client", "Node", "Port", "Link"))
    names = {properties(record)["node.name"]: ident for ident, record in nodes.items()
             if "node.name" in properties(record)}

    def client_pid(record):
        return int(properties(clients[int(properties(record)["client.id"])])["application.process.id"])

    controller = names["gpi2-jfg-frame-graph"]
    assert client_pid(nodes[controller]) == ready["processes"]["julia"]["pid"]
    simulator = ("simulator-wfs", "simulator-woofer", "simulator-tweeter", "simulator-tiptilt")
    for name in simulator:
        assert client_pid(nodes[names[name]]) == ready["processes"]["simulator"]["pid"]
    assert len(links) == 32
    assert all(client_pid(link) == ready["session_pid"] for link in links.values())

    def node(port):
        return int(properties(ports[port])["node.id"])

    routes = {(node(link["info"]["output-port-id"]), node(link["info"]["input-port-id"]))
              for link in links.values()}
    assert (names["simulator-wfs"], controller) in routes
    assert all((controller, names[sink]) in routes for sink in simulator[1:])
    print(f"{directory.name}: RTC owns 32 Links and the WFS/controller/three-sink routes match")
