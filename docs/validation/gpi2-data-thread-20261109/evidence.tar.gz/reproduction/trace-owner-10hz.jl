using PipeWireAORTC
using Libdl

function flush_trace(fgpw, metrics, library, path)
    Base.invokelatest(fgpw._write_callback_metrics, metrics)
    open(path, "w") do output
        println(output, "epoch,begin_ns,end_ns,full")
        count = ccall(Libdl.dlsym(library, :timing_gc_count), UInt64, ())
        record = Ref{NTuple{3,UInt64}}()
        get_record = Libdl.dlsym(library, :timing_gc_record)
        for index in 0:(count > 0 ? count - 1 : -1)
            ccall(get_record, Cint, (UInt64, Ref{NTuple{3,UInt64}}), index, record) == 1 || break
            println(output, index + 1, ',', join(record[], ','))
        end
        println("GPI2_GC_COLLECTIONS count=", count)
        thread_id = ccall(Libdl.dlsym(library, :timing_data_tid), Cint, ())
        println("GPI2_DATA_THREAD_TID ", thread_id)
    end
end

function register_trace(fgpw, root)
    fgpw.enable_callback_metrics!()
    factory = fgpw._callback_metrics_factory[]
    fgpw._callback_metrics_factory[] = function (input_count)
        metrics = factory(input_count)
        metrics === nothing && error("trace unexpectedly disabled")
        library = metrics.sample.library
        # The upstream application joins the native data thread before returning.
        atexit(() -> flush_trace(fgpw, metrics, library, joinpath(root, "raw", "gc.csv")))
        return metrics
    end
    return fgpw
end

function load_science()
    fgpw = Base.require(Main, :FilterGraphPipeWire)
    return Base.invokelatest(register_trace, fgpw, dirname(@__DIR__))
end

root = dirname(@__DIR__)
ENV["JULIA_FGPW_CALLBACK_METRICS_CAPACITY"] = "262144"
ENV["JULIA_FGPW_CALLBACK_METRICS_PATH"] = joinpath(root, "raw", "callbacks.csv")
ENV["JULIA_FGPW_CALLBACK_METRICS_LIBRARY"] = joinpath(root, "tools", "libgpi2_metrics.so")
PipeWireAORTC.GraphOwner._main(ARGS; load_science)
