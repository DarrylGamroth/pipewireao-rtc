using PipeWireAORTC
using Mmap

function mapped_trace_vector(path, value, capacity)
    open(path, "w+") do file
        return fill!(Mmap.mmap(file, Vector{typeof(value)}, capacity), value)
    end
end

function register_trace(fgpw, root, capacity)
    fgpw.enable_callback_metrics!()
    factory = fgpw._callback_metrics_factory[]
    capacity_key = "JULIA_FGPW_CALLBACK_METRICS_CAPACITY"
    # Service graph preparation enables its default factory when this is nonzero.
    # Set capacity only during cold node construction, after graph preparation.
    ENV[capacity_key] = "0"
    fgpw._callback_metrics_factory[] = function (input_count)
        ENV[capacity_key] = string(capacity)
        base_metrics = try
            factory(input_count)
        finally
            ENV[capacity_key] = "0"
        end
        base_metrics === nothing && error("trace unexpectedly disabled")
        length(base_metrics.start_ns) == capacity || error("trace capacity differs")
        dir = joinpath(root, "raw", "callback-maps")
        mkdir(dir)
        empty_sample = fgpw.CallbackAllocationSample(0, 0, -1, 0)
        mapvec(name, value) = mapped_trace_vector(joinpath(dir, name), value, capacity)
        metrics = fgpw.GraphCallbackMetrics(
            base_metrics.sample, base_metrics.path,
            mapvec("sequence", UInt64(0)), mapvec("offset", Int64(0)),
            mapvec("start_ns", UInt64(0)), mapvec("end_ns", UInt64(0)),
            mapvec("allocation_start", empty_sample), mapvec("allocation_end", empty_sample),
            mapvec("properties_changed", false), mapvec("parameters_changed", false),
            mapvec("succeeded", false), 0, UInt64(0),
        )
        println("GPI2_MAPPED_TRACE path=", dir, " capacity=", capacity)
        flush(stdout)
        return metrics
    end
    return fgpw
end

function load_science()
    fgpw = Base.require(Main, :FilterGraphPipeWire)
    return Base.invokelatest(register_trace, fgpw, dirname(@__DIR__), 65536)
end

root = dirname(@__DIR__)
ENV["JULIA_FGPW_CALLBACK_METRICS_PATH"] = joinpath(root, "raw", "callbacks.csv")
ENV["JULIA_FGPW_CALLBACK_METRICS_LIBRARY"] = joinpath(root, "tools", "libgpi2_metrics.so")
ENV["GPI2_GC_MAP"] = joinpath(root, "raw", "gc.bin")
PipeWireAORTC.GraphOwner._main(ARGS; load_science)
