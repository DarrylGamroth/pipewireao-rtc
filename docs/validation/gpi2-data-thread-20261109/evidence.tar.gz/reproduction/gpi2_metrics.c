/* Investigative instrumentation for the exact Julia build used by the run.
 * Build against that installation's headers, never hardcode TLS offsets.
 * Julia's allocd resets during GC. A pre-GC epoch invalidates crossing samples.
 */
#define _GNU_SOURCE
#include <julia.h>
#include <julia_gcext.h>
#include <stdatomic.h>
#include <stdint.h>
#include <time.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>

#if JULIA_VERSION_MAJOR != 1 || JULIA_VERSION_MINOR != 13 || defined(MMTK_GC)
#error "This investigative shim requires the exact Julia 1.13 stock-GC headers"
#endif
_Static_assert(ATOMIC_LLONG_LOCK_FREE == 2, "GC epoch must use lock-free atomics");

static _Atomic(uint64_t) gc_epoch;
enum { GC_CAPACITY = 16384 };
struct gc_trace {
    _Atomic(uint64_t) sampled_gc;
    _Atomic(uint64_t) completed_gc;
    _Atomic(int) data_tid;
    uint64_t gc_records[GC_CAPACITY][3];
};
_Static_assert(offsetof(struct gc_trace, gc_records) == 24, "Unexpected trace layout");
static struct gc_trace memory_trace;
static struct gc_trace *trace = &memory_trace;
static _Thread_local uint64_t active_epoch;

static uint64_t monotonic_ns(void)
{
    struct timespec stamp;
    clock_gettime(CLOCK_MONOTONIC, &stamp);
    return (uint64_t)stamp.tv_sec * UINT64_C(1000000000) + (uint64_t)stamp.tv_nsec;
}

static void before_gc(int full)
{
    uint64_t index = atomic_fetch_add_explicit(&gc_epoch, 1, memory_order_relaxed);
    active_epoch = index + 1;
    atomic_store_explicit(&trace->sampled_gc, index + 1, memory_order_relaxed);
    if (index < GC_CAPACITY) {
        trace->gc_records[index][0] = monotonic_ns();
        trace->gc_records[index][2] = full != 0;
    }
}

static void after_gc(int full)
{
    (void)full;
    if (active_epoch > 0 && active_epoch <= GC_CAPACITY) {
        trace->gc_records[active_epoch - 1][1] = monotonic_ns();
        atomic_fetch_add_explicit(&trace->completed_gc, 1, memory_order_release);
    }
    active_epoch = 0;
}

static int map_trace(void)
{
    const char *path = getenv("GPI2_GC_MAP");
    if (path == NULL)
        return 1;
    int fd = open(path, O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
    if (fd < 0)
        return 0;
    if (ftruncate(fd, sizeof(*trace)) != 0) {
        close(fd);
        return 0;
    }
    void *memory = mmap(NULL, sizeof(*trace), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    if (memory == MAP_FAILED)
        return 0;
    trace = memory;
    return 1;
}

typedef struct {
    uint64_t epoch;
    int64_t allocated;
    int32_t thread_id;
    int32_t gc_enabled;
} jfg_allocation_sample;

int jfg_metrics_init(void)
{
    if (jl_ver_major() != JULIA_VERSION_MAJOR ||
        jl_ver_minor() != JULIA_VERSION_MINOR ||
        jl_ver_patch() != JULIA_VERSION_PATCH)
        return 0;
    if (!map_trace())
        return 0;
    jl_gc_set_cb_pre_gc(before_gc, 1);
    jl_gc_set_cb_post_gc(after_gc, 1);
    return 1;
}

jfg_allocation_sample jfg_metrics_sample(void)
{
    jl_ptls_t tls = jl_get_ptls_states();
    if (tls->tid != 0 && atomic_load_explicit(&trace->data_tid, memory_order_relaxed) == 0)
        atomic_store_explicit(&trace->data_tid, gettid(), memory_order_relaxed);
    jfg_allocation_sample sample = {
        atomic_load_explicit(&gc_epoch, memory_order_relaxed),
        jl_atomic_load_relaxed(&tls->gc_tls_common.gc_num.allocd),
        tls->tid,
        jl_gc_is_enabled()
    };
    return sample;
}
