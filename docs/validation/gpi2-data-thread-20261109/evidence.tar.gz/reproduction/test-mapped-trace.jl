using Test, FilterGraphPipeWire
wrapper, library, root = ARGS
source = first(split(read(wrapper, String), "\nroot = dirname(@__DIR__)"; limit=2))
include_string(Main, source, wrapper)
ENV["JULIA_FGPW_CALLBACK_METRICS_CAPACITY"] = "16"
ENV["JULIA_FGPW_CALLBACK_METRICS_PATH"] = joinpath(root, "raw", "callbacks.csv")
ENV["JULIA_FGPW_CALLBACK_METRICS_LIBRARY"] = library
ENV["GPI2_GC_MAP"] = joinpath(root, "raw", "gc.bin")
register_trace(FilterGraphPipeWire, root, 16)
captured_factory = FilterGraphPipeWire._callback_metrics_factory[]
@test_throws SystemError FilterGraphPipeWire.prepare_service_graph(
    joinpath(root, "absent.conf"); algorithms=Dict()
)
@test FilterGraphPipeWire._callback_metrics_factory[] === captured_factory
const F = FilterGraphPipeWire
metrics = F._callback_metrics_from_environment(1)
using PipeWireAO
function frame!(m, sequence, allocate, collect)
    header = PipeWireAO.BufferHeader(UInt32(0), UInt32(0), Int64(0), Int64(0), sequence)
    i = F._begin_callback_metrics!(m, header)
    value = allocate ? Vector{UInt8}(undef, 4096) : nothing
    collect && GC.gc()
    F._end_callback_metrics!(m, i, false, false, true)
    return value
end
frame!(metrics, UInt64(1), true, false)
frame!(metrics, UInt64(2), false, true)
@test metrics.count == 2
@test all(metrics.succeeded[1:2])
@test metrics.sequence[1:2] == [1, 2]
@test metrics.allocation_end[2].epoch > metrics.allocation_start[2].epoch
