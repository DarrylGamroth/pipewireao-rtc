import csv
import json
import math
import sys
from bisect import bisect_right
from collections import Counter, defaultdict
from pathlib import Path

raw = Path(sys.argv[1])
marks = json.loads((raw / "marks.json").read_text())
callback = []
gc = []
if (raw / "callbacks.csv").exists():
    with (raw / "callbacks.csv").open() as f:
        callback = list(csv.DictReader(f))
        for row in callback:
            for k in ("callback", "sequence", "start_ns", "end_ns", "gc_epoch_start", "gc_epoch_end", "thread_id"):
                row[k] = int(row[k])
            row["allocated_bytes"] = int(row["allocated_bytes"]) if row["allocation_valid"] == "true" else None
            for k in ("properties_changed", "parameters_changed", "succeeded"):
                row[k] = row[k] == "true"
    with (raw / "gc.csv").open() as f:
        gc = [{k: int(v) for k, v in row.items()} for row in csv.DictReader(f)]
assert all(g["epoch"] == i and 0 < g["begin_ns"] <= g["end_ns"] for i, g in enumerate(gc, 1)), "invalid collector hook pairing"
hil_path, = (raw / "hil").glob("phase-timing-*.json")
hil_data = json.loads(hil_path.read_text())
hil = [dict(zip(hil_data["columns"], row, strict=True)) for row in hil_data["rows"]]
assert len(hil) == hil_data["record_count"] <= hil_data["capacity"]
period = hil_data["period_ns"]
target_period = 500_000

def stats(values):
    v = sorted(values)
    if not v:
        return {"n": 0}
    return {"n": len(v), **{f"p{p:g}": v[math.ceil(p / 100 * len(v)) - 1] for p in (50, 95, 99, 99.9, 100)}}

def deltas(values):
    return [b - a for a, b in zip(values, values[1:])]

def gap_and_duplicates(sequence):
    return {"duplicate_or_reorder": sum(g <= 0 for g in deltas(sequence)),
            "missing_between_ends": sum(g - 1 for g in deltas(sequence) if g > 1)}

def pacing_ledger(rows, begin, end):
    slots = rows[0]["deadline_ns"] if rows else 0
    if not rows or slots == 0:
        return {}
    assert all(row["next_deadline_ns"] - row["deadline_ns"] == period * (1 + row["missed_periods"]) for row in rows)
    assert all(before["next_deadline_ns"] == after["deadline_ns"] for before, after in zip(rows, rows[1:]))
    begin = max(begin, slots)
    end = min(end, rows[-1]["next_deadline_ns"])
    if begin >= end:
        return {}
    first = slots + (begin - slots + period - 1) // period * period
    nominal = max(0, (end - first + period - 1) // period)
    selected = [r for r in rows if begin <= r["deadline_ns"] < end]
    late = sum(r["received_ns"] > r["deadline_ns"] + period for r in selected)
    return {
        "nominal_slots": nominal,
        "published_frames": len(selected),
        "skipped_slots": nominal - len(selected),
        "published_command_after_slot": late,
        "slots_without_on_time_command": nominal - len(selected) + late,
    }

def gc_info(rows, begin, end):
    active = [g for g in gc if g["begin_ns"] < end and g["end_ns"] > begin]
    return {
        "collections_within_or_crossing_window": len(active),
        "hook_span_ns": stats(g["end_ns"] - g["begin_ns"] for g in active),
        "callbacks_crossing_pre_gc_epoch": sum(r["gc_epoch_start"] != r["gc_epoch_end"] for r in rows),
        "callbacks_overlapping_gc_hook_span": sum(
            any(g["begin_ns"] < r["end_ns"] and g["end_ns"] > r["start_ns"] for g in active)
            for r in rows),
    }

def window(begin, end):
    hr = [r for r in hil if begin <= r["published_ns"] < end]
    cr = [r for r in callback if begin <= r["start_ns"] < end]
    by_sequence = defaultdict(list)
    for r in callback:
        by_sequence[r["sequence"]].append(r)
    joined = []
    for row in hr:
        matches = [r for r in by_sequence[row["sequence"]]
                   if row["published_ns"] <= r["start_ns"] <= r["end_ns"] <= row["received_ns"]]
        if len(matches) == 1:
            joined.append((row, matches[0]))
    measured = [r for r in cr if r["allocated_bytes"] is not None]
    elapsed = [r["end_ns"] - r["start_ns"] for r in cr if r["end_ns"] >= r["start_ns"]]
    return {
        "window_ns": end - begin,
        "graph": None if not callback else {
            "callbacks": len(cr),
            "succeeded": sum(r["succeeded"] for r in cr),
            "valid_allocations": len(measured),
            "nonzero_allocations": sum(r["allocated_bytes"] > 0 for r in measured),
            "bytes_by_frame": dict(Counter(r["allocated_bytes"] for r in measured)),
            "allocated_total": sum(r["allocated_bytes"] for r in measured),
            "properties_changed": sum(r["properties_changed"] for r in cr),
            "parameters_changed": sum(r["parameters_changed"] for r in cr),
            "Julia_thread_ids": dict(Counter(r["thread_id"] for r in cr)),
            "service_ns": stats(elapsed),
            "service_over_500_us": sum(e > target_period for e in elapsed),
            "start_interval_ns": stats(deltas([r["start_ns"] for r in cr])),
            "start_interval_abs_error_ns": stats(abs(g - period) for g in deltas([r["start_ns"] for r in cr])),
            "sequence": gap_and_duplicates([r["sequence"] for r in cr]),
            **gc_info(cr, begin, end),
        },
        "pacing_ledger": pacing_ledger(hil, begin, end),
        "hil": {
            "completed": len(hr),
            "joined_to_graph": len(joined),
            "missing_graph_matches": [row["sequence"] for row in hr if not any(row is h for h, _ in joined)],
            "publication_rate_hz": ((len(hr) - 1) * 1e9 / (hr[-1]["published_ns"] - hr[0]["published_ns"])) if len(hr) > 1 else None,
            "skipped_slots": sum(r["missed_periods"] for r in hr),
            "release_lateness_ns": stats(r["started_ns"] - r["deadline_ns"] for r in hr),
            "model_step_ns": stats(r["step_finished_ns"] - r["step_started_ns"] for r in hr),
            "publication_interval_abs_error_ns": stats(abs(g - period) for g in deltas([r["published_ns"] for r in hr])),
            "publish_to_graph_start_ns": stats(g["start_ns"] - h["published_ns"] for h, g in joined),
            "graph_end_to_last_command_ns": stats(h["received_ns"] - g["end_ns"] for h, g in joined),
            "publish_to_last_command_ns": stats(r["received_ns"] - r["published_ns"] for r in hr),
            "release_to_last_command_ns": stats(r["received_ns"] - r["deadline_ns"] for r in hr),
            "release_to_last_command_over_period": sum(r["received_ns"] > r["deadline_ns"] + period for r in hr),
            "publish_to_last_command_over_500_us": sum(r["received_ns"] > r["published_ns"] + target_period for r in hr),
            "process_gc_time_delta_ns": hr[-1]["process_gc_time_ns"] - hr[0]["process_gc_time_ns"] if hr else None,
            "process_allocated_delta_bytes": hr[-1]["process_allocated_bytes"] - hr[0]["process_allocated_bytes"] if hr else None,
            "sequence": gap_and_duplicates([r["sequence"] for r in hr]),
        },
    }

profiles = defaultdict(list)
current_driver = None
profiler_path = raw / "profiler.json"
if profiler_path.is_file():
    for record in json.loads(profiler_path.read_text()):
        if not record:
            continue
        if record["type"] == "info":
            current_driver = None
        if record["type"] == "driver":
            current_driver = record["name"]
        if record["type"] in {"driver", "follower"}:
            profiles[(current_driver, record["name"])].append(record)

summary = {}
for name in ("baseline", "profiler", "perf", "properties"):
    if name + "_begin" in marks and name + "_end" in marks:
        summary[name] = window(marks[name + "_begin"], marks[name + "_end"])
summary["hil_pacing_period_ns"] = period
summary["complete_trace"] = {
    "graph_samples": len(callback) if callback else None,
    "hil_completed_samples": len(hil),
    "hil_skipped_slots": sum(r["missed_periods"] for r in hil),
    "pacing_ledger": pacing_ledger(hil, hil[0]["deadline_ns"], hil[-1]["next_deadline_ns"]) if hil else {},
    "hil_sequence": gap_and_duplicates([r["sequence"] for r in hil]),
    "property_adoptions": [r for r in callback if r["properties_changed"]],
    "parameter_adoptions": [r for r in callback if r["parameters_changed"]],
    "gc_event_count": len(gc) if callback else None,
    "gc_hook_span_ns": stats(g["end_ns"] - g["begin_ns"] for g in gc) if callback else None,
}
summary["native_profiler"] = {}
for (driver, owner), records in profiles.items():
    finite = [r for r in records if 0 < r["signal"] <= r["awake"] <= r["finish"]]
    finite = list({(r["signal"], r["awake"], r["finish"]): r for r in finite}.values())
    if finite:
        summary["native_profiler"][str(driver) + " -> " + owner] = {
            "record_count": len(records),
            "time_ordered_records": len(finite),
            "status": Counter(r["status"] for r in records),
            "xrun_first": records[0]["xrun_count"], "xrun_last": records[-1]["xrun_count"],
            "signal_to_awake_ns": stats(r["awake"] - r["signal"] for r in finite),
            "awake_to_finish_ns": stats(r["finish"] - r["awake"] for r in finite),
            "awake_to_finish_over_500_us": sum(r["finish"] - r["awake"] > target_period for r in finite),
        }
activations = profiles[("simulator-wfs", "gpi2-jfg-frame-graph")]
matched = []
if activations:
    activations = sorted({(r["awake"], r["finish"], r["signal"])
                          for r in activations if 0 < r["signal"] <= r["awake"] <= r["finish"]})
    awakes = [a[0] for a in activations]
    for r in callback:
        i = bisect_right(awakes, r["start_ns"]) - 1
        if i >= 0:
            awake, finish, signal = activations[i]
            if r["start_ns"] <= r["end_ns"] <= finish:
                matched.append((awake, finish, signal, r))
summary["native_profiler_matched_controller"] = {
    "matches": len(matched),
    "signal_to_awake_ns": stats(awake - signal for awake, _, signal, _ in matched),
    "awake_to_callback_ns": stats(r["start_ns"] - awake for awake, _, _, r in matched),
    "callback_end_to_finish_ns": stats(finish - r["end_ns"] for _, finish, _, r in matched),
    "awake_to_finish_ns": stats(finish - awake for awake, finish, _, _ in matched),
    "native_service_over_500_us": sum(finish - awake > target_period for awake, finish, _, _ in matched),
}
print(json.dumps(summary, indent=2, sort_keys=True))
