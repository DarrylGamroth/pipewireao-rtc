#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
export CAL2_FINAL_RTC_PROJECT="$1"
cd "$cal2_fixture"
test -f "$CAL2_FINAL_RTC_PROJECT/Manifest.toml"
test -f "$cal2_fixture/persistent.json"
{
    date --iso-8601=seconds
    uptime
    cat /proc/pressure/cpu
} > live-host-start.txt
nice -n 10 taskset -c 15 python3 capture-source-load.py > live-source-load.jsonl 2> live-source-load.log &
load_monitor=$!
stop_monitor() {
    if kill -0 "$load_monitor" 2>/dev/null; then
        kill "$load_monitor"
        wait "$load_monitor" || true
    fi
}
trap stop_monitor EXIT
python3 -u live_measure.py final-live-gated
{
    date --iso-8601=seconds
    uptime
    cat /proc/pressure/cpu
} > live-host-end.txt
