#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
trial_project="/var/tmp/rtc-fast-ready.EMkUd4YF/$1"
base_project=/var/tmp/rtc-ndarray-integration.beRGH1/cal2/candidate-combined-gated-install
export JULIA_LOAD_PATH="$trial_project:@:@stdlib"
"$julia" --startup-file=no --threads=1,0 --project="$base_project" -e '
using PipeWireAORTC
println(pathof(PipeWireAORTC))
for line in unique(split(line)[end] for line in eachline("/proc/self/maps") if occursin("/PipeWireAORTC/", line) && endswith(line, ".so"))
    println(line)
end'
