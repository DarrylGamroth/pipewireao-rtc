import json
import os
import re
import shutil
import sys
import time

import measure as m

APP = m.P("/var/tmp/rtc-ndarray-integration.beRGH1/cal2/candidate-combined-gated-install")

def recent_cameras():
    rows = m.cameras()
    return {branch: next(row for row in reversed(rows) if row["camera"] == "cal2-" + branch)
            for branch in m.branches}

def native_fixture(persistent):
    assert m.owner(m.core_name) == persistent["core"]
    assert m.owner(m.hil_name) == persistent["hil"]
    assert m.socket.stat().st_ino == persistent["inode"]

def continued(camera, prior):
    return all(camera[b]["domain"] == prior[b]["domain"]
               and camera[b]["generation"] == prior[b]["generation"]
               and camera[b]["sequence"] > prior[b]["sequence"]
               and camera[b]["model_ns"] > prior[b]["model_ns"] for b in m.branches)

def install_unit(variant, directory):
    content = (APP / "systemd/pipewireao-session@.service").read_text()
    for name in ("CORE_UNIT", "CORE_SOCKET", "SOURCE_UNIT"):
        var = "PIPEWIREAORTC_" + name
        content, count = re.subn(fr'Environment="{var}=[^"]+"',
                                 f'Environment="{var}={os.environ[var]}"', content)
        assert count == 1, (var, count)
    if variant == "traced":
        helper = APP / "bin/pipewireao-rtc-session"
        original = helper.read_text()
        helper_shell = directory / "trace-session"
        helper_shell.write_text(original.replace(
            ' -O0 -e ', f' -O0 --trace-compile="{directory}/trace-$1.log" --trace-compile-timing -e '))
        helper_shell.chmod(0o755)
        for phase in ("ExecStartPre", "ExecStartPost"):
            content = content.replace(f'{phase}="{helper}"', f'{phase}="{helper_shell}"')
    if variant in ("prepare-min", "combined", "final", "final-live"):
        helper = APP / "bin/pipewireao-rtc-session"
        helper_shell = directory / "min-session"
        original = helper.read_text()
        helper_shell.write_text(original.replace("prepare|publish)", "prepare)").replace(
            " -O0 -e ", " -O0 --compile=min -e "))
        helper_shell.chmod(0o755)
        content = content.replace(f'ExecStartPre="{helper}"', f'ExecStartPre="{helper_shell}"')
    if variant in ("rtc-diagnostic", "combined", "final", "final-live"):
        if variant in ("final", "final-live"):
            locator = m.P(os.environ["CAL2_FINAL_RTC_PROJECT"])
        else:
            project = {"rtc-diagnostic": "diag-project", "combined": "shared-project"}[variant]
            locator = m.P("/var/tmp/rtc-fast-ready.EMkUd4YF") / project
        assert (locator / "Manifest.toml").is_file()
        rtc = APP / "rtc/bin/pipewireao-rtc"
        rtc_shell = directory / "traced-rtc"
        rtc_shell.write_text(f'#!/bin/sh\nexport JULIA_LOAD_PATH="{locator}:@:@stdlib"\nexec "{rtc}" "$@"\n')
        rtc_shell.chmod(0o755)
        content = content.replace(f'ExecStart="{rtc}"', f'ExecStart="{rtc_shell}"')
    if variant == "candidate":
        helper = APP / "bin/pipewireao-rtc-session"
        helper_shell = m.stage / "candidate-session"
        assert helper_shell.is_file()
        for phase in ("ExecStartPre", "ExecStartPost"):
            content = content.replace(f'{phase}="{helper}"', f'{phase}="{helper_shell}"')
    m.unit_file.write_text(content)
    (directory / "unit.service").write_text(content)
    m.system("daemon-reload")

def trial(variant, directory, persistent, prior):
    native_fixture(persistent)
    before = m.native_dump(directory / "before-native.json")
    assert m.permanent(before) == persistent["native"] and not m.session_links(before)
    install_unit(variant, directory)
    last_cameras = recent_cameras()
    started, ready = m.start_service(directory)
    rtc = m.owner(m.unit)
    status = m.status(m.unit)
    result = {"variant": variant, "service_request_ns": started, "service_ready_ns": ready,
              "service_to_ready_s": m.seconds(ready, started), "service": status, "rtc": rtc,
              "core": persistent["core"], "hil": persistent["hil"], "private_socket_inode": persistent["inode"],
              "cameras_before_start": last_cameras, "cameras_at_ready": recent_cameras()}
    m.save(directory / "timing.json", result)
    print(f"{directory.name} systemd Ready {m.seconds(ready, started):.3f} s", flush=True)
    ledger_file = m.rtc_runtime / rtc["invocation"] / "launch.json"
    ledger = m.load(ledger_file)
    shutil.copyfile(ledger_file, directory / "ready-ledger.json")
    assert ledger["session_pid"] == rtc["pid"] and ledger["phase"] == "prepared"
    assert ledger["owners"]["core"]["pid"] == persistent["core"]["pid"] and ledger["owners"]["core"]["external"]
    assert ledger["owners"]["simulator"]["pid"] == persistent["hil"]["pid"] and ledger["owners"]["simulator"]["external"]
    assert ledger["owners"]["simulator"]["control-protocol"] == "external-stream"
    native_fixture(persistent)
    if variant in ("rtc-diagnostic", "combined", "final"):
        proc = m.P(f"/proc/{rtc['pid']}")
        for resource in ("maps", "cmdline", "status"):
            scratch_file = directory / f"rtc-{resource}"
            scratch_file.write_bytes((proc / resource).read_bytes())
        if variant == "final":
            image = (m.stage / "final-image.txt").read_text().splitlines()[1]
            assert image in (directory / "rtc-maps").read_text(), image
            assert (directory / "rtc-cmdline").read_bytes().rstrip(b"\0").decode().split("\0") == ledger["session_process"]["argv"]
    if variant == "rtc-diagnostic":
        journal = m.run("journalctl", "--user", "--no-pager", "-o", "json",
                        "_SYSTEMD_INVOCATION_ID=" + rtc["invocation"],
                        "_PID=" + str(rtc["pid"]), capture_output=True, text=True).stdout
        (directory / "rtc-live-journal.jsonl").write_text(journal)
        through_ready = [entry["MESSAGE"] for line in journal.splitlines()
                         if (entry := json.loads(line)) and entry.get("MESSAGE")
                         and int(entry["__MONOTONIC_TIMESTAMP"]) <= (ready // 1000)]
        messages = [bytes(message).decode(errors="replace") if isinstance(message, list) else message
                    for message in through_ready]
        (directory / "rtc-through-ready.log").write_text("\n".join(messages) + "\n")
    captured = m.native_dump(directory / "ready-native.json")
    links = m.session_links(captured)
    assert m.permanent(captured) == persistent["native"] and len(links) == len(set(links)) == 10
    result["rtc_links"] = links
    for previous in prior:
        assert rtc["invocation"] != previous["rtc"]["invocation"]
        assert set(links).isdisjoint(previous["rtc_links"])
    for branch in m.branches:
        camera, prior_camera = result["cameras_at_ready"][branch], last_cameras[branch]
        assert (camera["domain"], camera["generation"]) == (prior_camera["domain"], prior_camera["generation"])
        assert camera["sequence"] >= prior_camera["sequence"]
    m.graph_startup_phases(directory, ledger)
    child = m.launch(APP, "13", "live-control.jl", directory / "ready-control.log", ledger_file, directory, m.socket, "restart")
    assert child.wait(120) == 0, directory / "ready-control.log"
    online = m.load(directory / "control-online.json")
    assert online["ready"]["reply"]["state"] == "Ready"
    assert all(item["properties"]["reply"]["result"]["properties"]["correction:closed"]["value"] is False
               for item in online["held"])
    assert online["started"]["reply"]["ok"] and online["started"]["reply"]["state"] == "Running"
    result.update(native_ready_and_both_open=True, native_start=online["started"],
                  native_start_s=m.seconds(online["started"]["received_ns"], online["started"]["sent_ns"]))
    m.save(directory / "timing.json", result)
    stop_requested = time.monotonic_ns()
    m.system("stop", m.unit, timeout=320)
    stop_completed = time.monotonic_ns()
    stopped = m.load(ledger_file)
    shutil.copyfile(ledger_file, directory / "stopped-ledger.json")
    assert stopped["phase"] == "stopped" and stopped["cleanup_complete"]
    assert stopped["systemd_quit"] == {"attempted": True, "accepted": True}
    inactive = m.status(m.unit)
    assert inactive["ActiveState"] == "inactive" and inactive["Result"] == "success", inactive
    assert not m.P(ledger["discovery_locator"]).exists()
    native_fixture(persistent)
    after = m.native_dump(directory / "after-native.json")
    assert m.permanent(after) == persistent["native"] and not m.session_links(after)
    result.update(quit_s=m.seconds(stop_completed, stop_requested), native_quit=True,
                  systemd_after_quit=inactive,
                  quit_requested_ns=stop_requested, quit_completed_ns=stop_completed)
    m.save(directory / "timing.json", result)
    print(f"{directory.name} native Ready/both Open, Start {result['native_start_s']:.3f} s, Quit {result['quit_s']:.3f} s", flush=True)
    return result

def exercise(variants):
    for path in (m.unit_file, m.dropin, m.rtc_runtime):
        assert not os.path.lexists(path), path
    persistent = m.load(m.stage / "persistent.json")
    prior = []
    for timing in sorted(m.stage.glob("trial-*/timing.json")):
        record = m.load(timing)
        if record.get("native_quit"):
            prior.append(record)
    m.dropin.mkdir(parents=True)
    try:
        (m.dropin / "fixture.conf").write_text("[Service]\n" + "".join(
            f'Environment="{k}={os.environ[k]}"\n' for k in m.keep))
        for variant in variants:
            directory = m.stage / f"trial-{time.monotonic_ns()}-{variant}"
            directory.mkdir()
            try:
                prior.append(trial(variant, directory, persistent, prior))
            finally:
                m.clean_trial(directory)
    finally:
        m.unit_file.unlink(missing_ok=True)
        (m.dropin / "fixture.conf").unlink(missing_ok=True)
        m.dropin.rmdir()
        if m.rtc_runtime.is_dir():
            shutil.rmtree(m.rtc_runtime)
        m.system("daemon-reload")

def verify_cameras():
    persistent = m.load(m.stage / "persistent.json")
    for timing in sorted(m.stage.glob("trial-*/timing.json")):
        record = m.load(timing)
        if record.get("native_quit") and "cameras_after_quit" not in record:
            frames = m.wait(lambda: m.cameras_after(record["quit_completed_ns"]), 310,
                            "both cameras advancing after Quit")
            assert continued(frames, record["cameras_at_ready"])
            record["cameras_after_quit"] = frames
            m.save(timing, record)
    native_fixture(persistent)

if __name__ == "__main__":
    arguments = sys.argv[1:]
    if arguments == ["audit-cameras"]:
        verify_cameras()
    else:
        exercise(arguments)
