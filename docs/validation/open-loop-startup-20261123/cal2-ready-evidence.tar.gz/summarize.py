import json
from pathlib import Path

stage = Path(__file__).resolve().parent
records = []
for location in sorted(stage.glob("trial-*/timing.json")):
    directory = location.parent
    timing = json.loads(location.read_text())
    origin = timing["service_request_ns"]
    samples = []
    for line in (directory / "startup-schedstat.jsonl").read_text().splitlines():
        samples.append(json.loads(line))
    leaders = {}
    for process in ("prepare", "rtc", "publish"):
        same = [r for r in samples if r["role"] == process]
        if same:
            last = same[-1]
            leaders[process] = {
                "pid": last["pid"],
                "first_observed_after_request_s": (same[0]["monotonic_ns"] - origin) / 1e9,
                "last_observed_after_request_s": (last["monotonic_ns"] - origin) / 1e9,
                "cpu_s": last["runtime_ns"] / 1e9, "runnable_wait_s": last["runnable_wait_ns"] / 1e9,
                "samples": len(same),
            }
    records.append(dict(directory=directory.name, variant=timing["variant"],
                         ready_s=timing["service_to_ready_s"],
                         rtc_started_s=(int(timing["service"]["ExecMainStartTimestampMonotonic"]) * 1000 - origin) / 1e9,
                         native_ready=timing.get("native_ready_and_both_open"),
                         start_s=timing.get("native_start_s"), quit_s=timing.get("quit_s"),
                         both_cameras_after_quit="cameras_after_quit" in timing,
                         leaders=leaders))
output = json.dumps(records, indent=2, sort_keys=True) + "\n"
(stage / "summary.json").write_text(output)
print(output, end="")
