#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
cd "$cal2_fixture"
for ((i=0; i<450; i++)); do
    [[ -f warm-lease-released ]] && break
    sleep 1
done
test -f warm-lease-released
exec 9>>/run/user/1000/rtc-devel-benchmark.lock
flock -x 9
if [[ -e pause-feed ]]; then
    python3 - <<'PY'
import measure as m
import time
resumed = time.monotonic_ns()
(m.stage / "pause-feed").unlink()
cameras = m.cameras()
observed = {branch: next(row for row in reversed(cameras) if row["camera"] == "cal2-" + branch)
            for branch in m.branches}
assert m.system("show", m.hil_name, "-p", "FreezerState", "--value",
                capture_output=True, text=True).stdout.strip() == "running"
m.save(m.stage / "publication-before-rtc.json", {
    "feeder_resumed_ns": resumed, "cameras_already_published": observed})
PY
fi
set +e
python3 -u trials.py "$@"
trial_status=$?
set -e
flock -u 9
python3 trials.py audit-cameras
exit "$trial_status"
