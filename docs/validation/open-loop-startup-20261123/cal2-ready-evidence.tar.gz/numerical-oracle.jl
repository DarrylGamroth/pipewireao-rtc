using PipeWireAORTC, SHA
const RTC = PipeWireAORTC
const Fits = Base.require(Base.PkgId(Base.UUID("525bcba6-941b-5504-bd06-fd0dc1a4d2eb"), "FITSIO"))
app, directory = ARGS
input = RTC.Common.read_json(joinpath(directory,"oracle-input.json"))
answer = Dict{String,Any}()
for branch in ("llowfs","scc")
    prepared = RTC.Common.read_json(joinpath(app,"rtc",branch*"-parameters.conf"))
    binding = only(entry for entry in prepared["parameters"] if entry["port"]=="command-projection")
    @assert binding["axes"] == [2,1] && binding["hdu"] == 1
    fits_path = normpath(joinpath(app,"rtc",binding["path"]))
    fits_image = Fits.FITS(fits_path,"r") do f
        read(f[binding["hdu"]])
    end
    projection = permutedims(Float32.(fits_image), (2,1))
    @assert size(projection) == (2304,8)
    graph = RTC.DeploymentConfiguration.decode(joinpath(app,"rtc",branch*"-graph.conf"), ENV["PIPEWIREAO_PREFIX"])
    nodes = graph["filter.graph"]["nodes"]
    integrator = only(n for n in nodes if n["name"]=="correction")
    @assert integrator["label"] == "leaky-integrator-f32"
    @assert integrator["props"] == Dict("closed" => false, "gain" => -0.05, "pole" => 1)
    @assert integrator["config"]["initial_state"] == 0
    @assert !any(contains("clamp"), keys(integrator["config"]))
    case = input[branch]
    closed = case["physical"]
    residual = case["modal"]
    for k in ("acquired_sequence","domain","generation","model_ns")
        @assert closed[k] == residual[k]
    end
    camera = case["camera"]
    @assert closed["acquired_sequence"] == camera["sequence"]
    @assert closed["generation"] == camera["generation"] && closed["domain"] == camera["domain"]
    @assert closed["model_ns"] == camera["model_ns"]
    command = Float32(integrator["props"]["gain"]) .* Float32.(residual["payload"])
    observed = Float32.(closed["payload"])
    expected = Float64.(projection) * Float64.(command)
    absolute_dots = abs.(Float64.(projection)) * abs.(Float64.(command))
    error_abs = abs.(Float64.(observed) .- expected)
    threshold = 16eps(Float32) .* absolute_dots .+ floatmin(Float32)
    @assert all(error_abs .<= threshold) (branch, maximum(error_abs), maximum(threshold))
    @assert length(observed) == 2304 && minimum(observed) < 0 < maximum(observed)
    @assert all(signbit(observed[i]) == signbit(expected[i]) for i in eachindex(observed)
                if abs(expected[i]) > threshold[i])
    answer[branch] = (; acquisition=closed["acquired_sequence"], domain=closed["domain"],
        generation=closed["generation"], camera_model_pts_ns=closed["model_ns"], modal_residual=residual["payload"],
        maximum_observed_opd_m=maximum(abs,observed), maximum_oracle_opd_m=maximum(abs,expected),
        minimum_observed_opd_m=minimum(observed), maximum_signed_observed_opd_m=maximum(observed),
        negative_channels=count(x -> x < 0, observed), positive_channels=count(x -> x > 0, observed),
        zero_channels=count(iszero, observed), physical_offset_sha256=bytes2hex(sha256(reinterpret(UInt8,observed))),
        projection_fits_sha256=RTC.Common.sha256_file(fits_path),
        maximum_abs_error_m=maximum(error_abs), maximum_abs_tolerance_m=maximum(threshold), channels_compared=length(observed))
end
RTC.Common.write_json(joinpath(directory,"numerical-oracle.json"), answer; atomic=true)
