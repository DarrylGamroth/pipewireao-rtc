set -eu
root=$1
samples=$2
warmup=$3
case_name=$4
mkdir "$case_name"
replay_corpus="$HOME/workspaces/codex/pipewire/JuliaFilterGraph.jl/benchmark/results/gpi2-scaling-20261104/fp16-graph-frames/raw_frames_U16.bin"
mount -t tmpfs tmpfs /dev/shm
ip link set lo up
ulimit -c 0
children=""
cleanup() {
    for pid in $children; do kill -INT "$pid" 2>/dev/null || true; done
    sleep 0.25
    for pid in $children; do kill -TERM "$pid" 2>/dev/null || true; done
    for pid in $children; do wait "$pid" 2>/dev/null || true; done
}
trap cleanup EXIT
b="$root/heart-base/source/testServer/bin/dmSimulatorTester"
taskset -c 12 "$b" -id 0 -rPort 6100 -cmdLen 97 -output -1 -sendResponse >"$case_name/woofer.log" 2>&1 & children="$children $!"
taskset -c 12 "$b" -id 1 -rPort 6200 -cmdLen 2304 -output -1 -sendResponse >"$case_name/tweeter.log" 2>&1 & children="$children $!"
taskset -c 12 "$b" -id 0 -rPort 6300 -tts -output -1 -sendResponse >"$case_name/tiptilt.log" 2>&1 & children="$children $!"
g="$root/heart-gpi2/source/template/bin"
LD_PRELOAD="$root/heart-busy-poll.so" taskset -c 2,4,6,14 "$g/gpiTemplate" -nohuge -shm -host gpi2-workstation -config workstation.yaml -telFileRootPath "$case_name" >"$case_name/heart.log" 2>&1 &
pid=$!
children="$children $pid"
for i in $(seq 1 160); do
  kill -0 "$pid"
  if grep -q 'About to create listening address' "$case_name/heart.log"; then break; fi
  sleep 0.05
done
sleep 0.5
for command in INIT RUN CORRECT; do
    timeout 6s "$g/gpiTemplateCmdClient" -cmdName "$command" >"$case_name/$command.log" 2>&1
    grep -q 'status<0><SUCCESS>' "$case_name/$command.log"
done
ps -L -p "$pid" -o pid,tid,psr,cls,rtprio,comm >"$case_name/threads.txt"
"$root/heart-replay" "$replay_corpus" "$warmup" "$samples" "$case_name/arrivals.csv" >"$case_name/replay.log" 2>&1
timeout 4s "$g/gpiTemplateCmdClient" -cmdName SHUTDOWN >"$case_name/SHUTDOWN.log" 2>&1 || true
