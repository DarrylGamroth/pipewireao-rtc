#define _GNU_SOURCE
#include <arpa/inet.h>
#include <assert.h>
#include <errno.h>
#include <linux/if_packet.h>
#include <linux/filter.h>
#include <sys/prctl.h>
#include <net/ethernet.h>
#include <net/if.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <poll.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>
#include "protocol.h"
#include "dm-protocol.h"

enum { ROWS = 242, COLUMNS = 240, FRAME_BYTES = ROWS * COLUMNS * 2, OUTPUTS = 3 };
static const unsigned ports[OUTPUTS] = { 6100, 6200, 6300 };
static const unsigned elements[OUTPUTS] = { 97, 2304, 2 };
static const unsigned target[OUTPUTS] = { 0, 1, 0 };
static uint64_t period = 500000;
struct event {
    uint64_t nominal, offered, sent, completed[OUTPUTS];
};
struct capture {
    int socket;
    unsigned count;
    struct event *events;
    unsigned invalid, duplicates, foreign;
    _Atomic uint64_t stop;
};
static uint64_t timestamp(void)
{
    struct timespec t;
    assert(clock_gettime(CLOCK_MONOTONIC, &t) == 0);
    return (uint64_t)t.tv_sec * 1000000000 + t.tv_nsec;
}
static void bind_cpu(unsigned cpu)
{
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu, &set);
    assert(sched_setaffinity(0, sizeof(set), &set) == 0);
}
static void *receive_commands(void *context)
{
    struct capture *c = context;
    bind_cpu(10);
    uint8_t payload[OUTPUTS][2304 * sizeof(float)];
    struct heart_std_dm_assembler assemblers[OUTPUTS];
    for (unsigned i = 0; i < OUTPUTS; i++) {
        const struct heart_std_dm_receiver_profile profile = {
            .dm_target_id = target[i], .actuator_count = elements[i],
            .checksum_policy = HEART_STD_DM_CHECKSUM_REQUIRED
        };
        assert(heart_std_dm_assembler_init(&assemblers[i], &profile, payload[i],
                                          elements[i] * sizeof(float)) == 0);
    }
    while (timestamp() < atomic_load(&c->stop)) {
        struct pollfd pollfd = { .fd = c->socket, .events = POLLIN };
        if (poll(&pollfd, 1, 30) <= 0)
            continue;
        uint8_t buffer[65536];
        struct sockaddr_ll address;
        socklen_t length = sizeof(address);
        ssize_t size = recvfrom(c->socket, buffer, sizeof(buffer), MSG_DONTWAIT,
                                (struct sockaddr *)&address, &length);
        uint64_t received = timestamp();
        if (size < 28 || address.sll_pkttype != PACKET_OUTGOING)
            continue;
        size_t header = (buffer[0] & 15) * 4u;
        if (header < 20 || header + 8 > (size_t)size || buffer[9] != IPPROTO_UDP)
            continue;
        unsigned port = (buffer[header+2] << 8u) | buffer[header+3];
        unsigned i;
        for (i = 0; i < OUTPUTS && port != ports[i]; i++) { }
        if (i == OUTPUTS)
            continue;
        struct heart_std_dm_header message;
        const uint8_t *datagram = buffer + header + 8;
        size_t bytes = (size_t)size - header - 8;
        if (heart_std_dm_parse_header(datagram, bytes, &message) != 0) {
            c->invalid++;
            continue;
        }
        if (message.id_frame == 0 || message.id_frame > c->count) {
            c->foreign++;
            continue;
        }
        int result = heart_std_dm_assembler_push(&assemblers[i], datagram, bytes);
        if (result < 0) {
            c->invalid++;
        } else if (result == HEART_STD_DM_ASSEMBLY_COMPLETE) {
            uint64_t *receipt = &c->events[message.id_frame-1].completed[i];
            if (*receipt) c->duplicates++;
            else *receipt = received;
        }
    }
    return NULL;
}
int main(int argc, char **argv)
{
    assert(argc == 5);
    const char *rate = getenv("HEART_REPLAY_RATE");
    if (rate) period = 1000000000 / strtoul(rate, NULL, 10);
    unsigned warmup = strtoul(argv[2], NULL, 10);
    unsigned measured = strtoul(argv[3], NULL, 10);
    struct capture capture = { .count = warmup + measured };
    capture.events = calloc(capture.count, sizeof(*capture.events));
    assert(capture.events);
    FILE *input = fopen(argv[1], "rb");
    assert(input && fseek(input, 0, SEEK_END) == 0);
    long size = ftell(input);
    assert(size > 0 && size % FRAME_BYTES == 0);
    unsigned corpus_count = size / FRAME_BYTES;
    uint16_t *corpus = malloc(size), *row_major = malloc(size);
    assert(corpus && row_major);
    rewind(input);
    assert(fread(corpus, 1, size, input) == (size_t)size);
    fclose(input);
    for (unsigned frame = 0; frame < corpus_count; frame++)
        for (unsigned row = 0; row < ROWS; row++)
            for (unsigned col = 0; col < COLUMNS; col++)
                row_major[(size_t)frame*ROWS*COLUMNS+row*COLUMNS+col] =
                    corpus[(size_t)frame*ROWS*COLUMNS+col*ROWS+row];
    free(corpus);

    const struct heart_std_wfs_encoder_profile profile = {
        .wfs_source = 0, .pixel_type = HEART_STD_WFS_PIXEL_RAW,
        .num_columns = COLUMNS, .num_rows = ROWS, .pixels_per_datagram = 3840,
        .checksum_policy = HEART_STD_WFS_CHECKSUM_NONE,
    };
    uint16_t packets;
    size_t frame_size;
    assert(heart_std_wfs_encoder_profile_validate(&profile, &packets, &frame_size) == 0);
    assert(frame_size == FRAME_BYTES);
    capture.socket = socket(AF_PACKET, SOCK_DGRAM, htons(ETH_P_ALL));
    assert(capture.socket >= 0);
    struct sock_filter filter[] = {
        BPF_STMT(BPF_LD | BPF_H | BPF_ABS, 22),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, 6100, 2, 0),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, 6200, 1, 0),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, 6300, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, UINT32_MAX),
        BPF_STMT(BPF_RET | BPF_K, 0),
    };
    struct sock_fprog program = { .len=sizeof(filter)/sizeof(*filter), .filter=filter };
    assert(setsockopt(capture.socket, SOL_SOCKET, SO_ATTACH_FILTER, &program, sizeof(program)) == 0);
    int wanted = 8 * 1024 * 1024;
    assert(setsockopt(capture.socket,SOL_SOCKET,SO_RCVBUF,&wanted,sizeof(wanted)) == 0);
    struct sockaddr_ll loopback = { .sll_family = AF_PACKET, .sll_protocol = htons(ETH_P_ALL),
                                    .sll_ifindex = (int)if_nametoindex("lo") };
    assert(bind(capture.socket,(struct sockaddr *)&loopback,sizeof(loopback)) == 0);
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in destination = { .sin_family = AF_INET, .sin_port = htons(6000),
                                       .sin_addr.s_addr = htonl(INADDR_LOOPBACK) };
    assert(sock >= 0 && connect(sock,(struct sockaddr *)&destination,sizeof(destination)) == 0);
    pthread_t observer;
    atomic_store(&capture.stop, UINT64_MAX);
    assert(pthread_create(&observer,NULL,receive_commands,&capture) == 0);
    bind_cpu(8);
    assert(prctl(PR_SET_TIMERSLACK, 1, 0, 0, 0) == 0);
    uint64_t first = timestamp() + 100000000;
    unsigned errors = 0;
    for (unsigned i = 0; i < capture.count; i++) {
        struct event *event = &capture.events[i];
        event->nominal = first + period * i;
        struct timespec due = { .tv_sec = event->nominal / 1000000000,
                                .tv_nsec = event->nominal % 1000000000 };
        int status;
        do { status = clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&due,NULL); } while (status == EINTR);
        assert(status == 0);
        event->offered = timestamp();
        struct timespec wall;
        assert(clock_gettime(CLOCK_REALTIME, &wall) == 0);
        uint64_t exposure_timestamp = (uint64_t)wall.tv_sec * 1000000000 + wall.tv_nsec;
        const uint8_t *frame = (const uint8_t *)row_major + (size_t)(i%corpus_count)*FRAME_BYTES;
        for (uint16_t packet = 1; packet <= packets; packet++) {
            uint8_t datagram[HEART_STD_WFS_UDP_PAYLOAD_SIZE];
            size_t bytes;
            assert(heart_std_wfs_encode_datagram(&profile,frame,frame_size,packet,
                                                exposure_timestamp,i+1,datagram,sizeof(datagram),&bytes) == 0);
            if (send(sock,datagram,bytes,MSG_DONTWAIT) != (ssize_t)bytes) {
                errors++;
                break;
            }
            if (packet == packets) event->sent = timestamp();
        }
    }
    atomic_store(&capture.stop,timestamp()+1000000000);
    assert(pthread_join(observer,NULL) == 0);
    struct tpacket_stats stats;
    socklen_t stats_size = sizeof(stats);
    assert(getsockopt(capture.socket,SOL_PACKET,PACKET_STATISTICS,&stats,&stats_size) == 0);
    FILE *out = fopen(argv[4],"w");
    assert(out);
    fprintf(out,"sequence,phase,nominal_deadline_ns,offered_ns,publication_ns,woofer_ns,tweeter_ns,tiptilt_ns\n");
    for (unsigned i=0;i<capture.count;i++) {
        struct event *e=&capture.events[i];
        fprintf(out,"%u,%s,%llu,%llu,%llu,%llu,%llu,%llu\n",i+1,i<warmup?"warmup":"measured",
                (unsigned long long)e->nominal,(unsigned long long)e->offered,(unsigned long long)e->sent,
                (unsigned long long)e->completed[0],(unsigned long long)e->completed[1],(unsigned long long)e->completed[2]);
    }
    assert(fclose(out)==0);
    printf("HEART_REPLAY total=%u send_errors=%u invalid=%u duplicates=%u foreign=%u capture_packets=%u capture_drops=%u\n",
           capture.count,errors,capture.invalid,capture.duplicates,capture.foreign,stats.tp_packets,stats.tp_drops);
    return 0;
}
