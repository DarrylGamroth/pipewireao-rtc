using FITSIO, Random
rng=MersenneTwister(86401)
root=only(ARGS)
function random_matrix(file, columns, rows, scale, centre)
    matrix = scale .* (rand(rng, Float32, columns, rows) .- centre)
    FITS(joinpath(root,file*"_rand.fits"), "w") do output
        write(output,matrix)
    end
end
random_matrix("gpi2_controlMatrix", 4*2825, 1810, 0.0002f0, 0.5f0)
random_matrix("pdm0ModesToActuators", 97, 97, 0.0005f0, 0.5f0)
random_matrix("pdm0ActuatorsToModes", 97, 1810, 0.1f0, 0.4f0)
random_matrix("pdm1ModesToActuators", 1713, 2304, 0.0009f0, 0.5f0)
random_matrix("pdm1ActuatorsToModes", 1810, 2304, 0.1f0, 0.4f0)
random_matrix("ttToPdm0", 2, 97, 0.1f0, 0.4f0)
