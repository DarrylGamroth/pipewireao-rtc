import csv
import json
import math
from pathlib import Path
import sys

path=Path(sys.argv[1])
with path.open() as f:
    rows=[{k: int(v) if v.isdigit() else v for k,v in row.items()}
          for row in csv.DictReader(f) if row["phase"]=="measured"]
period = rows[1]["nominal_deadline_ns"]-rows[0]["nominal_deadline_ns"]
for a,b in zip(rows,rows[1:]):
    assert b["nominal_deadline_ns"]-a["nominal_deadline_ns"]==period
    assert b["sequence"]==a["sequence"]+1

def stats(items):
    v=sorted(items)
    if not v:
        return {"count":0}
    return {"count":len(v),"min":v[0],"max":v[-1],
            **{f"p{p:g}":v[math.ceil(len(v)*p/100)-1] for p in (50,95,99,99.9)}}

keys=("woofer_ns","tweeter_ns","tiptilt_ns")
published=[r for r in rows if r["publication_ns"]]
completed=[r for r in published if all(r[k] for k in keys)]
for r in completed:
    assert min(r[k] for k in keys) >= r["nominal_deadline_ns"], r
late=sum(max(r[k] for k in keys)-r["nominal_deadline_ns"]>period for r in completed)
result={
    "offered":len(rows), "published":len(published),"all_commands":len(completed),
    "partial_commands":sum(any(r[k] for k in keys) and not all(r[k] for k in keys) for r in published),
    "completed_late":late,
    "slots_without_on_time_command":len(rows)-len(completed)+late,
    "nominal_to_offer_ns":stats(r["offered_ns"]-r["nominal_deadline_ns"] for r in rows),
    "nominal_to_publication_ns":stats(r["publication_ns"]-r["nominal_deadline_ns"] for r in published),
    "nominal_to_command_ns":stats(max(r[k] for k in keys)-r["nominal_deadline_ns"] for r in completed),
    "publication_to_command_ns":stats(max(r[k] for k in keys)-r["publication_ns"] for r in completed),
    "publication_cadence_error_ns":stats(abs(b["publication_ns"]-a["publication_ns"]-period)
        for a,b in zip(published,published[1:]) if b["sequence"]==a["sequence"]+1),
}
print(json.dumps(result,indent=2,sort_keys=True))
