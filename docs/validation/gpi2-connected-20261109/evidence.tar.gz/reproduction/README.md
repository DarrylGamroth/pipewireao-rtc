# Connected timing reproduction

Use the exact package cohort from Project.toml and Manifest.toml, Julia
1.13.3, and the PipeWireAO 4.0.2 AVX2 SDK. The retained detector input and
calibration are external to this archive. The fixture loader verifies both.
Set GPI2_APPLICATION to the instrument repository's GPI2 directory,
GPI2_INPUTS to the saved-frame fixture directory, GPI2_REPLAY_CORPUS to its
raw_frames_U16.bin, and PIPEWIREAO_PREFIX to the registered SDK artifact.
Set OPENBLAS_NUM_THREADS=1. Use CPUs with the recorded physical-core
separation, adjusting the copied launcher/configuration if needed.

Obtain benchmark/native/rtc_latency_client.c from the FilterGraphPipeWire-v0.5.3
tag and apply replay.patch. Build it with cc -O3, the SDK pkg-config entry
libpipewire-ao-0.3, an SDK library rpath, and -lm. Build gpi2_metrics.c as a
shared library against the headers and libjulia of the exact Julia build.

The archived launcher expects the scripts and the sampler shared library
under tools/, the two environment files under env/, the compiled replay
under the parent directory, and the copied private configuration files next
to it. Invoke campaign.py with the case name, trace or bare, measured frame
count and warmup frame count. The suffix -rt selects the FIFO client configs
and verifies the three live data-loop policies before starting replay.

Run analyze.py against each retained run directory to regenerate its summary.

The HEART comparison uses hardware-disabled builds in separate source trees.
heart/heart-build.sh lists the serial build steps and expected dependency
directories. Apply heart/workstation.patch to the upstream quickstart
configuration and generate the seeded synthetic FITS files with
heart/heart-fixtures.jl. The other files under heart/ record affinity,
loopback execution and packet replay. Use the std WFS/DM protocol sources at
the plugin revision recorded in workstation-identities.txt when compiling the
replay. The final rows come from single-light and single-target.
