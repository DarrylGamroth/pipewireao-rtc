# CAL2 persistent graph owners on a private PipeWire core

Use the installed CAL2 CPU application at
`/var/tmp/rtc-ndarray-integration.beRGH1/cal2/candidate-combined-gated-install`
for control science, with the retained fixed-pupil HIL application at
`/var/tmp/cal2-independent.UcNIRN/final-install`. The source runs in its own
systemd service under the matching PipeWireAO artifact. A separate fixture
feeds pupils and observes original LLOWFS and SCC acquisition identities.
The previously qualified optical settings and measured source inputs stay fixed.
Only the installation name and RTC dependency change in the controller app.

`session-env.sh` identifies the private socket, units, dependency depot and
binary. `driver.py` starts the source and feed before any controller enters.
The feed starts paused after both first camera receipts when `pause-feed`
exists, then advances for the campaign after `source-resumed.json` records
resume and the marker disappears. The feeder stages each deterministic pupil
every 32 s of wall time with the original 2 ms model-time spacing. It rejects
an overwrite of the pending producer slot and logs its staging receipts.
The native camera taps are independent of this pacing. The scripts scope services and cleanup to
the fixture name.

From this directory, use `build.sh SOURCE_COMMIT` to stage the immutable RTC
source by Git tree hash and generate the installed service, two persistent
graph units and their manifest. Installation repeats graph qualification
before any measured activation. Run `campaign.sh --full-optical` after the
source is publishing and the installation marker is present. `--negative`
additionally replaces one required graph service under its same unit name and
changes a single coefficient in a private calibration file after the positive
series. That last selector invalidates the installation's retained seal.

The campaign records cold and already-running graph owner activations on the
same installation. Request-to-Ready starts before the systemctl start request
and ends after its acknowledged return. Native Ready, absence of graph
outputs from camera exposures during Hold, fresh Open and rejection of Close
before priming are verified separately. Native Link receipts preserve the
actual port names, object serials and NDArray formats.

The warm fault trial uses the existing numerical oracle on the matched
first explicit closed loop correction in each branch. It then sends SIGKILL
to the exact RTC MainPID while the session is Running. The client bound to
that session must lose authority. Its native session, graph and bootstrap
object serials and managed Links must retire while both graph services keep
their original InvocationID, PID, process start ticks and bootstrap instance.
A third RTC session admits new objects and confirms new LLOWFS and SCC
priming with zero offsets. LLOWFS receipts during each RTC-off interval and
unchanged acquisition domains and advancing, exposure-consistent model timestamps
for both cameras establish continued publication. The report lists any missing
tap observations explicitly.
Native Stop and systemd Quit cover clean release. Explicit graph service stops
verify full graph teardown while the independently supervised detector and
PipeWire core remain active.

This is optical simulation and functional software validation using a
non-actuating calibration profile. Startup observations are individual
durations on this host. They do not establish a timing distribution,
hardware behavior, controller capacity or a speedup guarantee.
