#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
variant=${CAL2_VALIDATION_VARIANT:-candidate}
export JULIA_IMAGE_THREADS=${CAL2_VALIDATION_BUILD_IMAGE_THREADS:-1}
app=$(python3 "$cal2_fixture/stage.py" "$variant" "$1")
source_path=$(jq -r '.source' "$cal2_fixture/$variant-source.json")
taskset -c 12,13 "$julia" --startup-file=no --threads=1,0 --project="$app"   "$cal2_fixture/offline-build.jl" "$app" "$PIPEWIREAO_PREFIX" "$source_path"
sha256sum "$app"/{bin/pipewireao-rtc-session,systemd/*.json,systemd/*.service,deployment.conf,Manifest.toml,Project.toml,rtc/bin/pipewireao-rtc}
touch "$cal2_fixture/$variant-ready"
