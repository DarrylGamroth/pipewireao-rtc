#!/usr/bin/env bash
cal2_fixture=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/cal2-independent.UcNIRN/environment.sh
cal2_tag="owner-${cal2_fixture##*.}"
export JULIA_DEPOT_PATH="$cal2_fixture/depot:/var/tmp/rtc-ndarray-integration.beRGH1/cal2/depot:/var/tmp/cal2-live-prime.12QydM/depot:$JULIA_DEPOT_PATH"
export PIPEWIREAORTC_CORE_UNIT="c2l-$cal2_tag-core.service"
export PIPEWIREAORTC_CORE_SOCKET="/run/user/$(id -u)/c2l-$cal2_tag/c"
export PIPEWIREAORTC_SOURCE_UNIT="c2l-$cal2_tag-hil.service"
export PIPEWIREAO_PREFIX="$prefix" CAL2_VALIDATION_JULIA="$julia"
export TMPDIR="$cal2_fixture/tmp" XDG_CACHE_HOME="$cal2_fixture/xdg-cache" POCL_CACHE_DIR="$cal2_fixture/pocl"
export CAL2_VALIDATION_TAG="$cal2_tag"
export CAL2_VALIDATION_QUEUE_MODULE=/home/dgamroth/.julia/artifacts/20afa07132938ae663c7cf4c10f00172ca40e70f/lib/pipewire-ao-0.3/libpipewire-module-queue.so
export CAL2_VALIDATION_HIL_ENTRYPOINT=/var/tmp/cal2-independent.UcNIRN/private-depot/packages/AdaptiveOpticsSimPipeWireHIL/SuCGV/src/independent.jl
export CAL2_STAGE_REPOSITORY=/home/dgamroth/workspaces/codex/worktrees/rtc-independent-graph-owners
