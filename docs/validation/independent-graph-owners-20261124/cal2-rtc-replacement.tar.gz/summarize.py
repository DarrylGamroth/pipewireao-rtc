import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("campaign", type=Path)
args = parser.parse_args()
root = args.campaign
records = []
for name in ("cold", "warm-abrupt", "warm-recovery", "warm-llowfs", "replace-required-owner"):
    directory = root / name
    lifecycle = directory / "lifecycle.json"
    if not lifecycle.is_file():
        continue
    record = json.loads(lifecycle.read_text())
    open_measurements = {branch: item["camera"]["sequence"]
                         for branch, item in record.get("fresh_open_priming", {}).items()}
    corrections = {branch: {key: row[key] for key in ("acquisition", "channels_compared",
                                                       "minimum_observed_opd_m", "maximum_signed_observed_opd_m",
                                                       "maximum_abs_error_m", "maximum_abs_tolerance_m")}
                   for branch, row in record.get("first_signed_correction", {}).items()}
    records.append(dict(name=name, request_to_ready_s=record["request_to_systemd_ready_s"],
                        rtc=record["rtc"], graph_owners=record["graph_owners"],
                        session_authority=record["session_authority"],
                        graph_endpoints=record["graph_endpoints"], link_serials=[link["serial"] for link in record["links"]],
                        verified_native_ready="native_ready" in record,
                        open_measurements=open_measurements, first_signed_corrections=corrections,
                        old_authority_withdrawn=(directory / "old-authority-withdrawn.json").exists(),
                        stop=record.get("stop"), owner_replacement=record.get("owner_replacement")))
report = {"activations": records}
for name in ("source-continuity", "full-shutdown", "passed"):
    result = root / f"{name}.json"
    if result.exists():
        report[name] = json.loads(result.read_text())
print(json.dumps(report, indent=2, sort_keys=True))
