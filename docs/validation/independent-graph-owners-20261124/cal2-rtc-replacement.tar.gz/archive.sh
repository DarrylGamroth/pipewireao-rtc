#!/usr/bin/env bash
set -euo pipefail
fixture=$(cd -- "$(dirname -- "$0")" && pwd)
variant=${CAL2_VALIDATION_VARIANT:-candidate}
attempt=${CAL2_VALIDATION_ATTEMPT:-1}
campaign="replacement-$attempt"
cd "$fixture"
python3 summarize.py "$campaign" > "$campaign/summary.json"
archive="$fixture/$campaign-receipts.tar.gz"
inputs=(
  "$campaign" "$variant-source.json" "$variant-build.log"
  "$variant-app/Project.toml" "$variant-app/Manifest.toml" "$variant-app/deployment.conf"
  "$variant-app/systemd/graph-owners.json" "$variant-app/systemd/graph-owner-assets.json"
  REPRODUCE.md archive.sh campaign.sh build.sh stage.py offline-build.jl replacement.py summarize.py
  session-env.sh driver.py feed.jl live-correction-control.jl live-observe.jl measure.py numerical-oracle.jl
  core-config observer-reference host.json persistent.json source-resumed.json camera-trace.tsv pupil-pacing.tsv fixture.log feed.log
  check-native-map.py check-native-map.log
)
if [[ -f first-llowfs.f32 ]]; then
    inputs+=(first-llowfs.f32 first-llowfs.json)
fi
if [[ -f stalled-source/feed.log ]]; then
    inputs+=(stalled-source source-stall.json source-stall-native.json)
fi
if [[ -f journal.txt ]]; then
    inputs+=(journal.txt)
fi
tar -czf "$archive" "${inputs[@]}"
sha256sum "$archive"
