#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
test -e "$cal2_fixture/warm-lease-released"
test -e "$cal2_fixture/${CAL2_VALIDATION_VARIANT:-candidate}-ready"
exec flock -x "/run/user/$(id -u)/rtc-devel-benchmark.lock"   python3 -u "$cal2_fixture/replacement.py" "$@"
