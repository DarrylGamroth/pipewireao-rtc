from pathlib import Path
import json
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
source = Path(sys.argv[1])
records = json.loads((root/"replacement-map-diagnostic/maps-and-abi.json").read_text())
parser = re.search(r"(?ms)^function graph_library_mapping\(line, library, inode\)\n.*?^end",
                   source.read_text()).group()
code = parser+"""
before(line, library, inode) = let fields = split(line; limit = 6)
    length(fields) == 6 && fields[6] == library && tryparse(UInt64, fields[5]) == inode
end
for input in eachline(stdin)
    line, library, inode = split(input, '\\t')
    number = parse(UInt64, inode)
    @assert !before(line, library, number)
    @assert graph_library_mapping(line, library, number)
    @assert !graph_library_mapping(line, library, number + 1)
    @assert !graph_library_mapping(line, library * "-other", number)
end
"""
inputs = "\n".join("\t".join((line, case["manifest_path"], str(case["expected_inode"])))
                   for case in records.values() for line in case["raw"])
subprocess.run(["julia", "--startup-file=no", "-e", code], input=inputs, text=True, check=True)
print("All 12 CAL2 maps records reject before and pass after; wrong paths and inodes still reject.")
