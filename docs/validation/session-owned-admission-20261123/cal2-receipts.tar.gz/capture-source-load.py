import json
import os
from pathlib import Path
import subprocess
import time

stage = Path(__file__).resolve().parent
persistent = json.loads((stage/"persistent.json").read_text())
roles = {
    "core": "PIPEWIREAORTC_CORE_UNIT",
    "hil": "PIPEWIREAORTC_SOURCE_UNIT",
}

def process_stat(pid):
    return Path(f"/proc/{pid}/stat").read_text().rsplit(")",1)[1].split()

def cpu_set(status):
    return next(line.split()[1] for line in status.splitlines()
                if line.startswith("Cpus_allowed_list:"))

def details(role, unit):
    pid = persistent[role]["pid"]
    root = Path(f"/proc/{pid}")
    process = process_stat(pid)
    if int(process[19]) != persistent[role]["ticks"]:
        raise RuntimeError(f"{role} process identity changed")
    group_root = Path("/sys/fs/cgroup")
    group = subprocess.check_output(["systemctl","--user","show",unit,"--property=ControlGroup","--value"],
                                    text=True).strip()
    cgroup_path = group_root/group.lstrip("/")
    cpuset_path = next((path/"cpuset.cpus.effective" for path in (cgroup_path, *cgroup_path.parents)
                        if path.is_relative_to(group_root) and (path/"cpuset.cpus.effective").is_file()), None)
    return {"pid":pid,"unit":unit,"control_group":group,
            "effective_cgroup_cpuset":cpuset_path.read_text().strip() if cpuset_path else None,
            "effective_cgroup_cpuset_path":str(cpuset_path) if cpuset_path else None,
            "leader_affinity":cpu_set((root/"status").read_text()),"start_ticks":int(process[19])}

def sample_threads(process):
    threads = {}
    for thread in Path(f"/proc/{process['pid']}/task").iterdir():
        try:
            run, queued, _ = map(int,(thread/"schedstat").read_text().split())
            last_cpu = int((thread/"stat").read_text().rsplit(")",1)[1].split()[36])
            threads[thread.name] = {
                "name":(thread/"comm").read_text().strip(),
                "allowed":cpu_set((thread/"status").read_text()),"last_cpu":last_cpu,
                "run_ns":run,"runqueue_ns":queued,
            }
        except FileNotFoundError:
            continue
    return threads

def sample_host():
    counters = {}
    for line in Path("/proc/stat").read_text().splitlines():
        name, *fields = line.split()
        if name.startswith("cpu") and name[3:].isdigit():
            counters[name[3:]] = list(map(int,fields[:8]))
    return counters

definitions = {role:details(role, os.environ[key]) for role,key in roles.items()}
print(json.dumps({"definitions":definitions,"host_ticks_per_second":os.sysconf("SC_CLK_TCK"),
                  "host_tick_fields":["user","nice","system","idle","iowait","irq","softirq","steal"]}),flush=True)
while True:
    point = {"monotonic_ns":time.monotonic_ns(),"host":sample_host()}
    for role,record in definitions.items():
        stat = process_stat(record["pid"])
        if int(stat[19]) != record["start_ticks"]:
            raise RuntimeError(f"{role} process identity changed")
        point[role] = {
            "user_ticks":int(stat[11]),"system_ticks":int(stat[12]),
            "threads":sample_threads(record),
        }
    print(json.dumps(point,separators=(",",":")),flush=True)
    time.sleep(1)
