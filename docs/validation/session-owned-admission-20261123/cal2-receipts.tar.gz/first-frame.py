import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import measure as m

def fixture(source):
    assert m.owner(m.core_name) == source["core"]
    assert m.owner(m.hil_name) == source["hil"]
    assert m.socket.stat().st_ino == source["inode"]
    state = m.system("show", m.hil_name, "-p", "FreezerState", "--value", capture_output=True, text=True).stdout
    assert state.strip() == "running"

def recent_cameras():
    rows = m.cameras()
    return {branch: next(row for row in reversed(rows) if row["camera"] == "cal2-"+branch)
            for branch in m.branches}

def match_second_candidate(directory):
    completed = [m.load(path) for path in m.stage.glob("trial-*/timing.json")
                 if path.parent != directory]
    if not any(record["variant"] == "final" and record.get("native_quit") for record in completed):
        return
    baseline = next(record for record in completed if record["variant"] == "baseline" and record.get("native_quit"))
    previous = baseline["cameras_before_start"]["scc"]
    target_ns = baseline["service_request_ns"] - previous["observed_ns"]
    parity = previous["sequence"] % 2
    deadline = time.monotonic() + 325
    schedule = {"baseline_scc_parity": parity, "target_source_scc_age_ns": target_ns}
    while time.monotonic() < deadline:
        m.check_children()
        camera = recent_cameras()["scc"]
        age = time.monotonic_ns() - camera["observed_ns"]
        if camera["sequence"] % 2 == parity and target_ns <= age <= target_ns + 400_000_000:
            schedule.update(matched=True, source=camera, actual_age_ns=age)
            break
        time.sleep(0.05 if abs(age-target_ns) < 400_000_000 else 0.2)
    else:
        schedule.update(matched=False, timeout_s=325)
    m.save(directory/"source-phase-schedule.json", schedule)


def next_path(directory, name):
    def exists():
        if (directory / name).is_file():
            return True
        m.check_children()
        return False
    return exists

def first_frames(directory, start):
    rows = m.read_capture(directory)
    receipt = m.load(directory/"timing.json")
    cameras = m.cameras()
    result = {}
    for branch in m.branches:
        matched = []
        for residual in rows:
            if residual["name"] != branch+"-modal-residual" or residual["observed_ns"] < start["sent_ns"]:
                continue
            camera = m.same_camera(residual, branch, cameras)
            if camera is None or camera["observed_ns"] < receipt["service_request_ns"] or camera["sequence"] <= receipt["cameras_before_start"][branch]["sequence"]:
                continue
            offsets = [row for row in rows if row["name"] == branch+"-physical-offset"
                       and m.same_camera(row, branch, [camera])]
            if not offsets:
                continue
            assert len(offsets) == 1 and offsets[0]["max_abs"] == 0
            assert residual["max_abs"] > 0
            pair = None
            if branch == "scc":
                flags = [row for row in rows if row["name"] == "scc-pair-status"
                         and m.same_camera(row, branch, [camera])]
                if not flags:
                    continue
                assert len(flags) == 1 and flags[0]["payload"] == [1]
                pair = flags[0]
            matched.append((residual, offsets[0], camera, pair))
        if not matched:
            return None
        first, offset, camera, pair = min(matched, key=lambda item: item[0]["observed_ns"])
        result[branch] = {"residual": m.without_payload(first), "physical_offset": m.without_payload(offset),
                          "camera": camera, "pair": pair}
    return result

def snapshot_processes(directory, ledger):
    for role, record in ledger["owners"].items():
        pid = record["pid"]
        proc = Path(f"/proc/{pid}")
        (directory / f"{role}-maps.txt").write_bytes((proc / "maps").read_bytes())
        command = (proc / "cmdline").read_bytes().rstrip(b"\0").decode().split("\0")
        m.save(directory / f"{role}-argv.json", command)
        if role.startswith("cal2-"):
            assert "--qualify-at-install" in command
            assert command[command.index("--prime-on-output")+1] == "modal-residual"
            assert "ExportedGraphWarmup" in (directory / f"{role}-maps.txt").read_text()
    m.graph_startup_phases(directory, ledger)
    phases = m.load(directory/"graph-startup-phases.json")
    for branch in m.branches:
        warmup = [event for event in phases["cal2-"+branch]["events"] if event["phase"] == "warm up graph"]
        assert len(warmup) == 1 and warmup[0]["status"] == "skipped" and warmup[0]["reason"] == "offline qualification"

def trial(variant, directory, source):
    fixture(source)
    current = m.native_dump(directory / "before-native.json")
    assert m.permanent(current) == source["native"] and not m.session_links(current)
    app = m.stage / f"{variant}-app"
    engineering = os.environ.get("CAL2_QUICK_START") == "1"
    startup_only = os.environ.get("CAL2_STARTUP_ONLY") == "1"
    assert not (engineering and startup_only)
    observer = None
    stock_app = Path("/var/tmp/rtc-ndarray-integration.beRGH1/cal2/candidate-combined-gated-install")
    shutil.copyfile(app/"systemd/pipewireao-session@.service",m.unit_file)
    shutil.copyfile(m.unit_file,directory/"unit.service")
    m.system("daemon-reload")
    # Keep observer and control implementations exactly the same across arms.
    if not engineering:
        observer = m.launch(stock_app, "12", "live-observe.jl", directory/"observer.log", stock_app, m.socket, directory, m.stage/"observer-reference")
    m.launch(stock_app, "13", "prearmed-control.jl", directory/"control.log", directory, m.socket)
    if not engineering:
        m.wait(next_path(directory, "observer-ready"), 130, "pre-start output taps")
    m.wait(next_path(directory, "control-armed"), 160, "prearmed native Start client")
    observations = m.rates(m.native_dump(directory/"observer-native.json"))
    assert len(observations) == 8
    if variant == "final":
        match_second_candidate(directory)
    before_cameras = recent_cameras()
    started, ready = m.start_service(directory)
    rtc = m.owner(m.unit)
    ledger_file = m.rtc_runtime / rtc["invocation"] / "launch.json"
    m.save(directory/"release-control.json", {"ledger": str(ledger_file), "released_ns": time.monotonic_ns()})
    ledger = m.load(ledger_file)
    shutil.copyfile(ledger_file, directory/"ready-ledger.json")
    unit_info = m.status(m.unit)
    observed_recipe = m.system("show", m.unit, "-p", "Type,NotifyAccess,ExecStartPost",
                               capture_output=True, text=True).stdout
    (directory/"systemd-recipe.txt").write_text(observed_recipe)
    if variant != "baseline":
        lines = observed_recipe.splitlines()
        assert "Type=notify" in lines and "NotifyAccess=main" in lines
        assert not any(line.startswith("ExecStartPost=") and line != "ExecStartPost=" for line in lines)
    assert ledger["session_pid"] == rtc["pid"]
    assert ledger["owners"]["core"]["external"] and ledger["owners"]["core"]["pid"] == source["core"]["pid"]
    assert ledger["owners"]["simulator"]["external"] and ledger["owners"]["simulator"]["pid"] == source["hil"]["pid"]
    assert ledger["owners"]["simulator"]["control-protocol"] == "external-stream"
    snapshot_processes(directory, ledger)
    rtc_proc = Path(f"/proc/{rtc['pid']}")
    (directory/"rtc-maps.txt").write_bytes((rtc_proc/"maps").read_bytes())
    command = (rtc_proc/"cmdline").read_bytes().rstrip(b"\0").decode().split("\0")
    m.save(directory/"rtc-argv.json",command)
    assert command == ledger["session_process"]["argv"]
    captured=m.native_dump(directory/"ready-native.json")
    links=m.session_links(captured)
    assert m.permanent(captured) == source["native"] and len(links) == len(set(links)) == 10
    for previous in m.stage.glob("trial-*/timing.json"):
        timing = m.load(previous)
        if "rtc_links" in timing:
            assert set(links).isdisjoint(timing["rtc_links"])
    receipt = {"variant": variant, "engineering": engineering, "startup_only": startup_only, "source": source, "rtc": rtc, "rtc_links": links, "service": unit_info,
        "package": m.load(m.stage / f"{variant}-source.json"),
        "service_request_ns": started, "service_ready_ns": ready,
        "service_to_ready_s": m.seconds(ready, started), "cameras_before_start": before_cameras}
    m.save(directory/"timing.json", receipt)
    print(f"{variant} ready {receipt['service_to_ready_s']:.3f} s", flush=True)
    m.wait(next_path(directory, "control-online.json"), 110, "native Ready and Start acknowledgements")
    control = m.load(directory/"control-online.json")
    assert control["ready"]["reply"]["state"] == "Ready"
    assert control["start"]["reply"]["state"] == "Running"
    assert control["start"]["sent_ns"] >= ready
    receipt["control"] = control
    m.save(directory/"timing.json", receipt)
    if not engineering and not startup_only:
        first = m.wait(lambda: first_frames(directory, control["start"]), 620, "both first usable live frames")
        rows=m.read_capture(directory)
        for row in rows:
            if row["observed_ns"] < control["start"]["sent_ns"]:
                for branch in m.branches:
                    if row["name"].startswith(branch+"-"):
                        sample = m.same_camera(row, branch, m.cameras())
                        assert sample is None or sample["observed_ns"] < started, row
        assert all(row["max_abs"] == 0 for row in rows
                   if row["name"].endswith("-physical-offset") and row["observed_ns"] >= control["start"]["sent_ns"])
        for branch, frame in first.items():
            arrival = frame["residual"]["observed_ns"]
            frame["service_request_to_usable_s"] = m.seconds(arrival, started)
            frame["service_ready_to_usable_s"] = m.seconds(arrival, ready)
            frame["start_ack_to_usable_s"] = m.seconds(arrival, control["start"]["received_ns"])
            frame["camera_to_usable_s"] = m.seconds(arrival, frame["camera"]["observed_ns"])
            print(f"{variant} {branch} frame {frame['camera']['sequence']}, Ready-to-usable {frame['service_ready_to_usable_s']:.3f} s", flush=True)
        receipt["first_usable"] = first
    (directory/"check-open").touch()
    m.wait(next_path(directory, "control-checked.json"), 100, "post-frame open-loop readback")
    receipt["open_after_first_frames"] = m.load(directory/"control-checked.json")
    m.save(directory/"timing.json", receipt)
    (directory/"workers-stopped").touch()
    (directory/"observer-stop").touch()
    for child, log in m.children:
        if startup_only and child is observer and child.poll() is None:
            # This supplemental interval is complete before draining science.
            child.terminate()
            status = child.wait(timeout=15)
            assert status in (0, -signal.SIGTERM, 128+signal.SIGTERM), log
            receipt["startup_only_observer_exit"] = status
        else:
            assert child.wait(timeout=60) == 0, log
    m.children.clear()
    quit_requested = time.monotonic_ns()
    m.system("stop", m.unit, timeout=320)
    quit_completed = time.monotonic_ns()
    stopped = m.load(ledger_file)
    shutil.copyfile(ledger_file, directory/"stopped-ledger.json")
    assert stopped["phase"] == "stopped" and stopped["cleanup_complete"]
    assert stopped["systemd_quit"] == {"attempted": True, "accepted": True}
    after = m.status(m.unit)
    assert after["Result"] == "success" and after["ActiveState"] == "inactive"
    fixture(source)
    captured = m.native_dump(directory/"after-native.json")
    assert m.permanent(captured) == source["native"] and not m.session_links(captured)
    receipt.update(quit_requested_ns=quit_requested, quit_completed_ns=quit_completed,
                   quit_s=m.seconds(quit_completed, quit_requested), native_quit=True)
    m.save(directory/"timing.json", receipt)
    print(f"{variant} native Quit {receipt['quit_s']:.3f} s", flush=True)

def exercise(variant):
    for path in (m.unit_file, m.dropin, m.rtc_runtime):
        assert not os.path.lexists(path), path
    source = m.load(m.stage/"persistent.json")
    m.wait(lambda: (m.stage/"resumed-cameras.json").is_file(), 310, "both already-publishing camera streams")
    directory = m.stage / f"trial-{time.monotonic_ns()}-{variant}"
    directory.mkdir()
    m.dropin.mkdir(parents=True)
    try:
        (m.dropin/"fixture.conf").write_text("[Service]\n"+"".join(f'Environment="{k}={os.environ[k]}"\n' for k in m.keep))
        try:
            trial(variant, directory, source)
        finally:
            m.clean_trial(directory)
    finally:
        m.unit_file.unlink(missing_ok=True)
        (m.dropin/"fixture.conf").unlink(missing_ok=True)
        m.dropin.rmdir()
        if m.rtc_runtime.is_dir():
            shutil.rmtree(m.rtc_runtime)
        m.system("daemon-reload")

def audit():
    source = m.load(m.stage/"persistent.json")
    for evidence in sorted(m.stage.glob("trial-*/timing.json")):
        receipt = m.load(evidence)
        if receipt.get("native_quit") and "cameras_after_quit" not in receipt:
            frames = m.wait(lambda: m.cameras_after(receipt["quit_completed_ns"]), 300, "both cameras after Quit")
            for branch, frame in frames.items():
                first = (receipt["first_usable"][branch]["camera"] if "first_usable" in receipt
                         else receipt["cameras_before_start"][branch])
                assert frame["domain"] == first["domain"] and frame["generation"] == first["generation"]
                assert frame["sequence"] > first["sequence"] and frame["model_ns"] > first["model_ns"]
            receipt["cameras_after_quit"] = frames
            m.save(evidence, receipt)
    fixture(source)

if __name__ == "__main__":
    if sys.argv[1] == "audit":
        audit()
    else:
        exercise(sys.argv[1])
