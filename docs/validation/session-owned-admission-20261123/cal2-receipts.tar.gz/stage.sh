#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
variant="$1"
app=$(python3 "$cal2_fixture/stage.py" "$@")
source_path=$(jq -r '.source' "$cal2_fixture/$variant-source.json")
"$julia" --startup-file=no --threads=1,0 --project="$app" "$cal2_fixture/offline-build.jl" "$app" "$PIPEWIREAO_PREFIX" "$source_path"
"$julia" --startup-file=no -O0 --project="$app" -e 'using PipeWireAORTC; @show pkgdir(PipeWireAORTC)'
sha256sum "$app"/{bin/pipewireao-rtc-session,systemd/pipewireao-session@.service,deployment.conf,Manifest.toml,Project.toml,rtc/bin/pipewireao-rtc}
touch "$cal2_fixture/$variant-ready"
