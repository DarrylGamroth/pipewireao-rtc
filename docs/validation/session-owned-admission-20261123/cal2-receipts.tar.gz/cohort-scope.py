import hashlib
import json
from pathlib import Path
import tomllib

stage = Path(__file__).resolve().parent
variants = ("baseline", "candidate", "final")
assets = ("Project.toml", "deployment.conf", "instrument.yaml", "instrument.json",
          "simulation.conf", "generated", "graph-startup", "calibration", "profiles",
          "shared-runtime", "rtc")
def sha(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data,"sha256").hexdigest()

data = {}
for variant in variants:
    app = stage/(variant+"-app")
    manifest = tomllib.loads((app/"Manifest.toml").read_text())
    paths = sorted({entry for name in assets for entry in
             ([app/name] if (app/name).is_file() else (app/name).rglob("*"))
             if entry.is_file() and "depot" not in entry.relative_to(app).parts})
    data[variant] = {
       "source": json.loads((stage/(variant+"-source.json")).read_text()),
       "non_rtc_dependencies": {key: value for key,value in manifest["deps"].items() if key != "PipeWireAORTC"},
       "application_files": {str(path.relative_to(app)): sha(path) for path in paths},
    }
reference = data["baseline"]
for variant in variants[1:]:
    for field in ("non_rtc_dependencies", "application_files"):
        if data[variant][field] != reference[field]:
            different = sorted(key for key in reference[field].keys() | data[variant][field].keys()
                               if reference[field].get(key) != data[variant][field].get(key))
            raise AssertionError((variant,field,different))
print(json.dumps({"same_application_files_sha256":reference["application_files"],
                  "same_non_rtc_manifest_dependencies":reference["non_rtc_dependencies"],
                  "rtc_sources":{variant: data[variant]["source"] for variant in variants}},
                 indent=2, sort_keys=True))
