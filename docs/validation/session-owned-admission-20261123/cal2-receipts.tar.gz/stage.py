import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tomllib

stage = Path(__file__).resolve().parent
repo = Path(os.environ.get("CAL2_STAGE_REPOSITORY",
    "/home/dgamroth/workspaces/codex/worktrees/rtc-session-owned-admission"))
stock = Path("/var/tmp/rtc-ndarray-integration.beRGH1/cal2/candidate-combined-gated-install")
julia = os.environ["CAL2_VALIDATION_JULIA"]
variant, commit = sys.argv[1:]
commit = subprocess.check_output(["git", "-C", repo, "rev-parse", f"{commit}^{{commit}}"], text=True).strip()
tree = subprocess.check_output(["git", "-C", repo, "rev-parse", f"{commit}^{{tree}}"], text=True).strip()
slug = subprocess.check_output(
    [julia, "--startup-file=no", "-e", 'using UUIDs; print(Base.version_slug(UUID("a3e2c7da-f73f-4284-8482-36ac422b34e6"), Base.SHA1(hex2bytes(only(ARGS)))))', tree],
    text=True)
package = stage / "depot/packages/PipeWireAORTC" / slug
if not package.is_dir():
    package.mkdir(parents=True)
    archive = subprocess.Popen(["git", "-C", repo, "archive", commit], stdout=subprocess.PIPE)
    subprocess.run(["tar", "-x", "-C", package], stdin=archive.stdout, check=True)
    assert archive.wait() == 0
app = stage / f"{variant}-app"
metadata = tomllib.loads((package / "Project.toml").read_text())
def ignore(directory, entries):
    return {name for name in entries
            if name in (".rtc-export.git", "depot") or (directory == str(stock) and name in ("bin", "systemd"))}
if not app.is_dir():
    shutil.copytree(stock, app, copy_function=os.link, ignore=ignore)
    manifest = app / "Manifest.toml"
    original = manifest.read_text()
    metadata = tomllib.loads((package / "Project.toml").read_text())
    pattern = r"(\[\[deps\.PipeWireAORTC\]\]\n)(.*?)(?=\n\[\[deps\.)"
    match = re.search(pattern, original, flags=re.S)
    new = re.sub(r'^deps = .*$', "deps = " + json.dumps(sorted(metadata["deps"])), match[2], count=1, flags=re.M)
    new = re.sub(r'^git-tree-sha1 = .*$', "git-tree-sha1 = " + json.dumps(tree), new, count=1, flags=re.M)
    new = re.sub(r'^version = .*$', "version = " + json.dumps(metadata["version"]), new, count=1, flags=re.M)
    manifest.unlink()
    manifest.write_text(original[:match.start(2)] + new + original[match.end(2):])
readback = tomllib.loads((app / "Manifest.toml").read_text())["deps"]["PipeWireAORTC"][0]
assert readback["git-tree-sha1"] == tree and readback["version"] == metadata["version"]
(stage / f"{variant}-source.json").write_text(json.dumps({"commit": commit, "tree": tree, "source": str(package), "app": str(app)}, indent=2)+"\n")
print(app)
