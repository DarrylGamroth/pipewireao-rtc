#!/usr/bin/env bash
set -euo pipefail
umask 077
cd -- "$(dirname -- "$0")"
archive="$(dirname -- "$PWD")/cal2-receipts.tar.gz"
shopt -s nullglob
include=(
  README.md archive-cal2.sh
  baseline-source.json candidate-source.json final-source.json
  baseline-build.log candidate-build.log final-build.log
  baseline-trial.log baseline-repetition.log candidate-engineering.log final-trial-*.log
  cohort-scope.json summary.json continuity.json host-and-reference.txt teardown.json
  fixture.log journal.txt feed.log camera-trace.tsv source-load.jsonl
  core-config observer-reference
  persistent.json publication-before-rtc.json resumed-cameras.json
  before-first-native.json
  trial-* excluded-observer-label-* excluded-negative-observer-* negative-placement-*
  negative-placement.log negative-continuity.log extra-continuity.log
  stage.py stage.sh trial.sh session-env.sh run.sh driver.py measure.py
  capture-source-load.py feed.jl first-frame.py live-observe.jl prearmed-control.jl
  offline-build.jl summarize.py recover-baseline.py resume.py cohort-scope.py continuity.py negative-placement.py teardown-cal2.py
)
for variant in baseline candidate final; do
    include+=("$variant-app"/{Manifest.toml,Project.toml,deployment.conf,instrument.json,instrument.yaml,simulation.conf})
    include+=("$variant-app"/{bin/pipewireao-rtc-session,rtc/bin/pipewireao-rtc,systemd/pipewireao-session@.service})
done
for entry in diagnostic-instrumentation.patch diagnostic-build.log diagnostic-source.json diagnostic-trial.log; do
    if [[ -f diagnostic-trial.log && -f "$entry" ]]; then include+=("$entry"); fi
done
verified=()
for entry in "${include[@]}"; do
    [[ -e "$entry" ]] && verified+=("$entry")
done
tar -czf "$archive.tmp" -- "${verified[@]}"
tar -tzf "$archive.tmp" > "$archive.contents.tmp"
mv -- "$archive.tmp" "$archive"
mv -- "$archive.contents.tmp" "$archive.contents"
(cd -- "$(dirname -- "$archive")" && sha256sum "$(basename -- "$archive")") > "$archive.sha256"
