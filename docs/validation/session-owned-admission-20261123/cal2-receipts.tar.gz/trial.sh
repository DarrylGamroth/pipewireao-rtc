#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
cd "$cal2_fixture"
variant="$1"
for ((i=0; i<550; i++)); do
    [[ -f warm-lease-released && -f "$variant-ready" ]] && break
    sleep 1
done
test -f warm-lease-released
test -f "$variant-ready"
exec 9>>/run/user/1000/rtc-devel-benchmark.lock
flock -x 9
if [[ -e pause-feed ]]; then
    python3 - <<'PY'
import time, measure as m
source_state = m.system("show", m.hil_name, "-p", "FreezerState", "--value", capture_output=True, text=True).stdout
assert source_state.strip() == "running"
(m.stage/"pause-feed").unlink()
m.save(m.stage/"publication-before-rtc.json", {"resumed_ns": time.monotonic_ns(), "before": m.cameras()})
PY
fi
set +e
python3 -u first-frame.py "$variant"
status=$?
set -e
flock -u 9
exit "$status"
