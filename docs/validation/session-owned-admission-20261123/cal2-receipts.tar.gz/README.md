# CAL2 session-owned readiness measurements

The CAL2 fixed-pupil simulator, feeder, camera taps and private PipeWire core
are independent of the RTC unit. The feeder paused only after initial fixture
qualification to hand off the workstation timing lease. Both cameras published
again before the measured baseline. The feeder, simulator, core and model
clock then continued across every RTC start, Quit and gap.

Each RTC package is extracted from the recorded Git commit into an immutable
tree-hash slot in a scratch depot. The application keeps the same CAL2 assets,
PipeWire artifact and non-RTC manifest pins. Its lifecycle script and systemd
unit come from that RTC package's installer. Package images and both graph
qualifications build offline before the measured service request.

The service interval starts immediately before invoking `systemctl --user start`
and ends when the successful command returns. An output observer and control
client are armed before this point. The control client independently reads
native Ready and both Open properties before requesting Start, then records
the Start send and matching Running reply. Camera and output observations use
the host monotonic clock. First usable means the earliest nonzero modal
residual matched to a captured camera acquisition and its zero physical
offset by domain, generation, sequence and model time. SCC additionally
requires a completed-pair output matched to the same acquisition. These are
observations at separate taps, so the camera-to-residual observation delta
includes both taps' scheduling and is not a graph execution time measurement.
SCC wall time includes the wait for independently generated exposures.
The first-usable interval ends at the qualifying residual receipt, correlated
retrospectively with the camera, zero offset and SCC pair receipts. The
complete-confirmation interval ends at the latest of those receipts and
captures when all the matching evidence was available to the observer.

The camera domains and core/source process identities are retained in
`persistent.json`. Every accepted run captures ten unique session Link serials,
the native control receipts, the process argument vectors and maps, idle
correction readback after both first usable frames, and original camera
acquisition identities advancing after Quit. The package images and active
`--qualify-at-install` graphs are checked alongside explicit runtime journal
records of skipping optical warmup. No physical hardware is involved.

The initial baseline diagnostic was excluded when the observer asserted an
obsolete label for skipped warmup. The retained baseline startup, Open and
first-frame gates passed. Its observer timed out waiting for a second output
on each tap after the first usable SCC frame had already been recorded. The
observer was cancelled after the measurements and the normal systemd stop path
acknowledged native Quit. `recover-baseline.py` paired that run's saved control
and frame receipts with the terminal ledger copied before runtime cleanup,
the systemd stop journal and the native registry after service exit. The next
observer version only changes the condition for finishing after measurement,
allowing the first valid output from each tap to satisfy the exit check.

The results use these RTC revisions.

| Role | Revision | Acceptance scope |
| --- | --- | --- |
| Baseline | `59e328d` | The installed separate publication-helper path. One optical run and one timing-only warm repeat with the same output and control clients prearmed. |
| Engineering | `1b90155` | Early installed notification proof and native lifecycle only. Its offline final-image build ran concurrently on separate CPUs, and the result is outside the performance comparison. |
| Final | `9ba551e` | Installed required-owner, native held-Link, Status, placement, and discovery fence. Two optical runs. |

`cohort-scope.json` verifies equal non-RTC manifest records and byte-equal
application declarations, graph sources, launcher entry point, and calibration
inputs across the cohorts. Graph package images were built separately for each
exact RTC package tree. Their mapping and installation qualification receipts
are retained with each activation. All monotonic receipts use the same `rtc-devel` boot. The process placements, external HIL identities, and
host load samples are in the individual receipts and `source-load.jsonl`.
No sampled process was identified as a package precompiler during the
retained measured starts.

RTC Start send and its authenticated Running reply are separate observations
from systemd Ready. Ready-to-Start-send includes the test's post-Ready
evidence capture and Start release. Native Quit is verified from the stopped
ledger and the empty session Link set with the original independent endpoints
still present. The original baseline Quit stop interval comes from the
systemd journal. The supplemental baseline and both final Quit stop intervals
use systemctl stop command round trips.

`continuity.json` verifies contiguous, monotonic camera acquisition and model
time in one domain and generation for both streams since the resume before
the baseline. The simulator exposes configured millisecond model cadences.
The wall time between simulated exposures on this host is much longer. A/B
run 2 aligns the preceding SCC camera sequence parity and age with the
baseline. It still waits for the source's actual wall-clock exposure times.

The archive carries the exact package trees by Git SHA, app manifests,
deployment descriptors, launchers, harness and native receipts. Large
calibration arrays and compiled images are represented by their provenance
and hashes rather than bundled. The source acquisition log is retained in
full, including bootstrap and the initial pre-measurement pause.

## Measured results

| Run | Service to Ready (s) | Start send to Running acknowledgement (s) | Ready to LLOWFS residual (s) | Ready to SCC residual (s) | Sampled lifecycle leader CPU (s) |
| --- | ---: | ---: | ---: | ---: | ---: |
| Baseline optical | 15.200 | 0.399 | 4.267 | 157.796 | 11.978 |
| Final 1 | 14.798 | 0.358 | 20.159 | 194.041 | 9.923 |
| Final 2 | 14.899 | 0.357 | 22.954 | 147.618 | 9.984 |
| Baseline timing repeat | 13.743 | 0.362 | — | — | 10.561 |

The final Ready times are within the range of the two measured baseline
starts. The sampled preparation and RTC leader CPU total is lower
in each final start than the sampled preparation, publisher, and RTC
leader total of either baseline. These samples cover process leaders near
the Ready boundary. They do not sum all threads or directly measure
the causal effect of a particular startup phase.

The last subtraction between independently scheduled camera and output
tap timestamps is signed. On final run 2 the SCC residual tap arrived
3.492 ms before the matching camera tap. The entire matched SCC record
was available 147.630 s after Ready.

The first wrong-CPU diagnostic was interrupted by the observer after a
permission failure while reading the process executable symlink. Its
replay uses the exact managed Julia command line and kernel affinity
fields. The original observer error and canceled invocation are retained
under their own excluded trial directory.
