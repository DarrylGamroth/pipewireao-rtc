using PipeWireAORTC, PipeWireAO
const RTC = PipeWireAORTC
const C = RTC.ControlClient
const GRAPHS = ("cal2-llowfs-controller", "cal2-scc-controller")

function request(client, operation, args...)
    sent_ns = time_ns()
    reply = C.request!(client, RTC.SessionCodec.RunnerCommand(operation, args...);
        deadline=C.monotonic()+35)
    return (; sent_ns, received_ns=time_ns(), reply=RTC.RunnerCommands.render(reply)), reply
end

function open_loop(client, graph)
    properties, _ = request(client, :properties, graph)
    @assert properties.reply["ok"]
    values = properties.reply["result"]["properties"]
    @assert values["correction:closed"]["value"] === false
    @assert values["pipewireao.correction-control.correction:closed.state"]["value"] == "Open"
    return properties
end

function dispatch_start(directory, socket)
    command = RTC.Common.read_json(joinpath(directory, "release-control.json"))
    d = RTC.Common.read_json(command["ledger"])
    @assert d["remote"] == socket
    client = C.connect(RTC.SessionProfile.Profile(), socket, "pipewireao.rtc.session.cal2",
        d["session_pid"], d["session_control_instance"]; deadline=C.monotonic()+40)
    try
        with_thread_loop_lock(client.loop) do _
            C.healthy(client)
            @assert client.observation.node_identity == d["session_uuid"]
            @assert client.observation.owner_pid == d["session_pid"]
            @assert client.observation.instance == d["session_control_instance"]
        end
        ready, completion = request(client, :status)
        RTC.SessionCLI.confirm_ready(completion)
        held = map(graph -> open_loop(client, graph), GRAPHS)
        start, _ = request(client, :session_start)
        @assert start.reply["ok"] && start.reply["state"] == "Running"
        RTC.Common.write_json(joinpath(directory, "control-online.json"),
            (; ready, held, start, uuid=d["session_uuid"], pid=d["session_pid"],
                endpoint=client.global_id, endpoint_serial=client.serial); atomic=true)
        timedwait(() -> isfile(joinpath(directory,"check-open")), 1000; pollint=0.01) == :ok ||
            error("timed out awaiting open-loop recheck")
        check = map(graph -> open_loop(client, graph), GRAPHS)
        RTC.Common.write_json(joinpath(directory, "control-checked.json"), check; atomic=true)
    finally
        close(client)
    end
end

function main(directory, socket)
    precompile(dispatch_start, (String,String))
    touch(joinpath(directory, "control-armed"))
    timedwait(() -> isfile(joinpath(directory, "release-control.json")), 900; pollint=0.01) == :ok ||
        error("timed out awaiting the startup service")
    dispatch_start(directory, socket)
end
main(ARGS...)
