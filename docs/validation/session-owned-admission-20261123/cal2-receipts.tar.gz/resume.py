import time
import measure as m

m.wait(lambda: (m.stage/"warm-lease-released").is_file(), 500, "private source preflight")
source_state = m.system("show", m.hil_name, "-p", "FreezerState", "--value", capture_output=True, text=True).stdout
assert source_state.strip() == "running"
before = m.cameras()
(m.stage/"pause-feed").unlink()
resumed = time.monotonic_ns()
m.save(m.stage/"publication-before-rtc.json", {"resumed_ns": resumed, "before": before})
after = m.wait(lambda: m.cameras_after(resumed), 310, "both cameras publishing after resumption")
m.save(m.stage/"resumed-cameras.json", after)
print(after, flush=True)
