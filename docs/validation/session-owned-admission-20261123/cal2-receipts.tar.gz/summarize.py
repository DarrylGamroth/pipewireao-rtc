import csv
import json
from pathlib import Path

stage = Path(__file__).resolve().parent
with (stage/"camera-trace.tsv").open() as trace:
    cameras = list(csv.DictReader(trace, delimiter="\t"))
def seconds(later, earlier):
    return (int(later)-int(earlier))/1e9
def records(path):
    return (json.loads(line) for line in path.read_text().splitlines() if line)
def output_queues(path):
    dump = json.loads(path.read_text())
    queues = {}
    for item in dump:
        props = item.get("info", {}).get("props", {})
        name = props.get("node.name", "")
        if item["type"].endswith(":Module") and "queue.stats.publications" in props and any(
                label in name for label in ("physical-offset", "modal-residual", "pair-status")):
            queues[name] = {key.removeprefix("queue.stats."): value for key,value in props.items()
                            if key.startswith("queue.stats.")}
    return queues

result = []
for path in sorted(stage.glob("trial-*/timing.json")):
    trial = json.loads(path.read_text())
    req, ready = trial["service_request_ns"], trial["service_ready_ns"]
    service = trial["service"]
    main_ns = int(service["ExecMainStartTimestampMonotonic"])*1000
    source = trial["cameras_before_start"]
    observed = {"trial": path.parent.name, "variant": trial["variant"], "commit": trial["package"]["commit"],
                "service_to_ready_s": trial["service_to_ready_s"],
                "engineering": trial.get("engineering", False), "startup_only": trial.get("startup_only", False),
                "systemd_ready_enter_ns": int(service["ActiveEnterTimestampMonotonic"])*1000,
                "service_to_rtc_main_s": seconds(main_ns,req), "rtc_main_to_ready_s": seconds(ready, main_ns),
                "source_scc_before_request": source["scc"]["sequence"],
                "source_scc_sequence_parity": source["scc"]["sequence"] % 2,
                "source_scc_age_at_service_request_s": seconds(req,source["scc"]["observed_ns"]),
                "systemd_native_quit_s": trial.get("quit_s"), "quit_timer": trial.get("quit_source", "systemctl_stop_round_trip"),
                "both_cameras_after_quit": "cameras_after_quit" in trial}
    cpus = {}
    for row in records(path.parent/"startup-schedstat.jsonl"):
        cpus[row["role"]] = {"pid":row["pid"], "leader_cpu_s":row["runtime_ns"]/1e9,
                            "leader_runnable_wait_s":row["runnable_wait_ns"]/1e9,
                            "last_sample_after_request_s":seconds(row["monotonic_ns"],req)}
    observed["last_startup_leader_samples"] = cpus
    observed["lifecycle_leader_cpu_s"] = sum(row["leader_cpu_s"] for role,row in cpus.items()
                                             if role in ("prepare","publish","rtc"))
    observed["startup_package_precompile_seen"] = any("precompile" in role for role in cpus)
    if trial.get("native_quit"):
        counts_before = output_queues(path.parent/"observer-native.json")
        counts_after = output_queues(path.parent/"after-native.json")
        assert counts_before.keys() == counts_after.keys()
        observed["output_queue_deltas"] = {
            name: {key: counts_after[name][key] - counts_before[name][key]
                   for key in ("publications", "deliveries", "replacements", "dropped-arrivals", "protocol-errors")}
            for name in counts_before}
    if "control" in trial:
        start = trial["control"]["start"]
        observed.update(ready_to_start_request_s=seconds(start["sent_ns"],ready),
                        start_request_to_ack_s=seconds(start["received_ns"], start["sent_ns"]))
    if "first_usable" in trial:
        observed["branches"] = {}
        for branch, result_ in trial["first_usable"].items():
            camera = result_["camera"]
            arrival = camera["observed_ns"]
            earlier = [int(row["sequence"]) for row in cameras if row["camera"] == "cal2-"+branch and
                       row["domain"] == camera["domain"] and int(row["generation"]) == camera["generation"] and
                       trial["control"]["start"]["sent_ns"] <= int(row["observed_ns"]) < arrival]
            matched = [row["observed_ns"] for row in
                       (camera, result_["residual"], result_["physical_offset"], result_["pair"])
                       if row is not None]
            confirmation = max(matched)
            observed["branches"][branch] = {
                "sequence":camera["sequence"], "domain":camera["domain"], "generation":camera["generation"],
                "model_ns":camera["model_ns"], "earlier_camera_sequences_after_start_request":earlier,
                "ready_to_camera_observation_s":seconds(arrival,ready),
                "start_ack_to_camera_observation_s":seconds(arrival, trial["control"]["start"]["received_ns"]),
                "service_request_to_usable_s":result_["service_request_to_usable_s"],
                "service_ready_to_usable_s":result_["service_ready_to_usable_s"],
                "start_ack_to_usable_s":result_["start_ack_to_usable_s"],
                "camera_to_usable_observer_delta_s":result_["camera_to_usable_s"],
                "ready_to_complete_frame_confirmation_s": seconds(confirmation, ready),
                "start_ack_to_complete_frame_confirmation_s": seconds(confirmation, trial["control"]["start"]["received_ns"]),
                "complete_frame_confirmation_after_residual_s": seconds(confirmation, result_["residual"]["observed_ns"]),
                "modal_residual_peak":result_["residual"]["max_abs"],
                "physical_offset_peak":result_["physical_offset"]["max_abs"]}
    result.append(observed)
report = json.dumps(result, indent=2, sort_keys=True) + "\n"
(stage/"summary.json").write_text(report)
print(report, end="")
