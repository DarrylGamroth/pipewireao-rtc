import ctypes
import importlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import time

import measure as m
runner = importlib.import_module("first-frame")
m.instance = f"c2l-{m.tag}-placement"
m.unit = f"pipewireao-session@{m.instance}.service"
m.unit_file = m.unit_dir / m.unit
m.dropin = m.unit_dir / (m.unit+".d")
m.rtc_runtime = m.runtime.parent / f"pipewireao-session-{m.instance}"

def observe_registry(path):
    libc = ctypes.CDLL(None, use_errno=True)
    fd = libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
    assert fd >= 0, ctypes.get_errno()
    # Discovery may create directly or atomically rename the published record.
    assert libc.inotify_add_watch(fd, os.fsencode(path), 0x008 | 0x080 | 0x100 | 0x200) >= 0
    return fd

def registry_events(fd):
    buffer = b""
    while True:
        try:
            buffer += os.read(fd, 65536)
        except BlockingIOError:
            break
    events = []
    while buffer:
        _, mask, cookie, length = struct.unpack_from("iIII", buffer)
        name = buffer[16:16+length].rstrip(b"\x00").decode(errors="replace")
        events.append({"name":name,"mask":mask,"cookie":cookie})
        buffer = buffer[16+length:]
    return events

def install(directory, app):
    assert 5 in os.sched_getaffinity(0)
    unit = (app/"systemd/pipewireao-session@.service").read_text()
    assert "CPUAffinity=3\n" in unit
    lines = unit.splitlines(keepends=True)
    targets = [index for index, line in enumerate(lines) if line.startswith("ExecStart=")]
    assert len(targets) == 1
    index = targets[0]
    executable = shutil.which("taskset")
    assert executable
    lines[index] = lines[index].replace("ExecStart=", f'ExecStart="{executable}" -c 5 ', 1)
    unit = "".join(lines)
    m.unit_file.write_text(unit)
    (directory/"unit.service").write_text(unit)
    m.system("daemon-reload")

def exercise():
    for path in (m.unit_file, m.dropin, m.rtc_runtime):
        assert not os.path.lexists(path), path
    assert m.system("show", m.unit, "-p", "LoadState", "--value", capture_output=True,
                    text=True).stdout.strip() == "not-found"
    source = m.load(m.stage/"persistent.json")
    runner.fixture(source)
    directory = m.stage/f"negative-placement-{time.monotonic_ns()}"
    directory.mkdir()
    app = m.stage/"final-app"
    registry = Path(os.environ["XDG_RUNTIME_DIR"])/"pipewireao-rtc"/"sessions"
    assert registry.is_dir()
    fd = observe_registry(registry)
    m.dropin.mkdir(parents=True)
    process = None
    try:
        (m.dropin/"fixture.conf").write_text("[Service]\n"+"".join(f'Environment="{k}={os.environ[k]}"\n' for k in m.keep))
        install(directory, app)
        before = runner.recent_cameras()
        started = time.monotonic_ns()
        with (directory/"systemctl.log").open("w") as output:
            process = subprocess.Popen(["systemctl","--user","start",m.unit], stdout=output, stderr=subprocess.STDOUT)
            seen = {}
            status_snapshots = []
            invocations = set()
            deadline = time.monotonic()+95
            while process.poll() is None:
                if time.monotonic() >= deadline:
                    raise TimeoutError("misplaced RTC did not terminate")
                unit = m.status(m.unit)
                status_snapshots.append(unit)
                invocation = unit["InvocationID"]
                if invocation:
                    invocations.add(invocation)
                pid = int(unit["MainPID"])
                if pid > 0 and pid not in seen:
                    proc = Path(f"/proc/{pid}")
                    try:
                        argv = (proc/"cmdline").read_bytes().rstrip(b"\0").decode().split("\0")
                        if Path(argv[0]).name == "julia" and any("MediaSession.main" in arg for arg in argv):
                            line = next(line for line in (proc/"status").read_text().splitlines()
                                        if line.startswith("Cpus_allowed_list:"))
                            seen[pid] = {"affinity":line.split()[1], "argv":argv}
                    except (FileNotFoundError, PermissionError, ProcessLookupError, StopIteration):
                        pass
                time.sleep(0.15)
        finished = time.monotonic_ns()
        status = m.status(m.unit)
        m.save(directory/"observations.json", status_snapshots)
        assert len(invocations) == 1, invocations
        invocation = invocations.pop()
        logs = m.run("journalctl", "--user", "--no-pager", "-o", "short-monotonic",
                     "_SYSTEMD_INVOCATION_ID="+invocation, capture_output=True, text=True).stdout
        (directory/"invocation.log").write_text(logs)
        ledger = m.load(m.rtc_runtime / invocation / "launch.json")
        m.save(directory/"launch-final.json", ledger)
        events = registry_events(fd)
        m.save(directory/"registry-events.json", events)
        locator = "session-" + ledger["session_uuid"] + ".pod"
        assert not any(event["name"] == locator for event in events), events
        assert not (registry/locator).exists()
        assert process.returncode != 0 and status["ActiveState"] == "failed", status
        assert status["ActiveEnterTimestampMonotonic"] in ("", "0")
        assert not any(unit["ActiveState"] == "active" for unit in status_snapshots)
        assert len(seen) == 1 and next(iter(seen.values()))["affinity"] == "5"
        assert ("affinity [5] exceeds deployment envelope" in logs or
                "must remain SCHED_OTHER on housekeeping CPU 3" in logs), logs
        runner.fixture(source)
        globals_ = m.native_dump(directory/"after-native.json")
        assert m.permanent(globals_) == source["native"] and not m.session_links(globals_)
        evidence = {"managed_ready":False, "locator_published":False, "source":source,
                    "request_ns":started, "returned_ns":finished, "status":status, "systemctl_exit":process.returncode,
                    "processes":seen, "cameras_before":before}
        m.save(directory/"result.json", evidence)
        print(f"Wrong RTC leader placement rejected. Receipts in {directory}",flush=True)
    finally:
        if process is not None and process.poll() is None:
            process.terminate()
            process.wait(timeout=10)
        os.close(fd)
        subprocess.run(["systemctl", "--user", "stop", m.unit], timeout=190, check=False)
        if m.status(m.unit)["ActiveState"] == "failed":
            m.system("reset-failed", m.unit, timeout=20)
        m.unit_file.unlink(missing_ok=True)
        (m.dropin/"fixture.conf").unlink(missing_ok=True)
        m.dropin.rmdir()
        if m.rtc_runtime.is_dir():
            shutil.rmtree(m.rtc_runtime)
        m.system("daemon-reload")

def audit():
    directory = max(m.stage.glob("negative-placement-*/result.json"), key=lambda path: path.stat().st_mtime_ns)
    evidence = m.load(directory)
    frames = m.wait(lambda: m.cameras_after(evidence["returned_ns"]), 300,
                    "both cameras advancing after rejected activation")
    for branch, camera in frames.items():
        before = evidence["cameras_before"][branch]
        assert camera["sequence"] > before["sequence"] and camera["model_ns"] > before["model_ns"]
        assert camera["domain"] == before["domain"] and camera["generation"] == before["generation"]
    runner.fixture(evidence["source"])
    evidence["cameras_after"] = frames
    m.save(directory, evidence)

if __name__ == "__main__":
    import sys
    if sys.argv[1:] == ["audit"]:
        audit()
    else:
        exercise()
