import csv
import json
import statistics
from pathlib import Path

stage = Path(__file__).resolve().parent
resumed_ns = json.loads((stage/"publication-before-rtc.json").read_text())["resumed_ns"]
with (stage/"camera-trace.tsv").open() as trace:
    frames = list(csv.DictReader(trace, delimiter="\t"))
output = {}
for branch in ("llowfs","scc"):
    rows = [row for row in frames if row["camera"] == "cal2-"+branch and
            int(row["observed_ns"]) >= resumed_ns]
    assert len(rows) > 3
    chronological = sorted(rows,key=lambda row: int(row["observed_ns"]))
    identities = {(row["domain"],row["generation"]) for row in chronological}
    assert len(identities) == 1, identities
    deltas = []
    for previous,current in zip(chronological, chronological[1:]):
        assert int(current["sequence"]) == int(previous["sequence"])+1
        assert int(current["model_ns"])-int(previous["model_ns"]) == int(current["exposure_ns"])
        deltas.append((int(current["observed_ns"])-int(previous["observed_ns"]))/1e9)
    output[branch] = {"count":len(chronological), "first":chronological[0],"latest":chronological[-1],
                      "observation_gap_s":{"median":statistics.median(deltas), "max":max(deltas)}}
print(json.dumps(output, indent=2, sort_keys=True))
