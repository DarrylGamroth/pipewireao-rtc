using PipeWireAORTC
using PipeWireAO
RTC = PipeWireAORTC
app, prefix, expected = ARGS
@assert pkgdir(RTC) == expected
@assert realpath(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir) == realpath(prefix)
@show pkgdir(RTC)
@show pkgversion(RTC)
RTC.SessionInstall.finish_install(app, prefix, first(Base.julia_cmd().exec), nothing)
