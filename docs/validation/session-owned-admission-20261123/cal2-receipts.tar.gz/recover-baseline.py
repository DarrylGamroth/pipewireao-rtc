from decimal import Decimal
import importlib
import json
from pathlib import Path
import re
import sys

import measure as m
runner = importlib.import_module("first-frame")
directory = Path(sys.argv[1])
receipt = m.load(directory/"timing.json")
source = receipt["source"]
control = m.load(directory/"control-online.json")["start"]
assert receipt["control"]["start"] == control
checked = m.load(directory/"control-checked.json")
assert all(result["reply"]["result"]["properties"]["correction:closed"]["value"] is False
           for result in checked)
first = runner.first_frames(directory, control)
assert first and set(first) == set(m.branches)
assert all(frame["max_abs"] == 0 for frame in m.read_capture(directory)
           if frame["name"].endswith("-physical-offset") and frame["observed_ns"] >= control["sent_ns"])
for frame in first.values():
    arrival = frame["residual"]["observed_ns"]
    frame["service_request_to_usable_s"] = m.seconds(arrival, receipt["service_request_ns"])
    frame["service_ready_to_usable_s"] = m.seconds(arrival, receipt["service_ready_ns"])
    frame["start_ack_to_usable_s"] = m.seconds(arrival, control["received_ns"])
    frame["camera_to_usable_s"] = m.seconds(arrival, frame["camera"]["observed_ns"])
ledger = m.load(directory/"stopped-ledger-recovered.json")
assert ledger["invocation"] == receipt["rtc"]["invocation"]
assert ledger["phase"] == "stopped" and ledger["cleanup_complete"]
assert ledger["systemd_quit"] == {"attempted": True, "accepted": True}
journal = (directory/"journal.log").read_text().splitlines()
def latest_after_service(marker):
    line = next(line for line in reversed(journal) if marker in line)
    stamp = re.search(r"^\[ *([0-9.]+)\]", line)[1]
    return int(Decimal(stamp) * 10**9)
quit_requested = latest_after_service("Stopping " + m.unit)
quit_completed = latest_after_service("Stopped " + m.unit)
quit_record = next(json.loads(line.split("RTC systemd stop timing ", 1)[1]) for line in reversed(journal)
    if "RTC systemd stop timing " in line)
assert quit_record["invocation"] == ledger["invocation"] and quit_record["outcome"] == "completed"
runner.fixture(source)
after = m.native_dump(directory/"after-native.json")
assert m.permanent(after) == source["native"] and not m.session_links(after)
receipt.update(first_usable=first, open_after_first_frames=checked, native_quit=True,
    quit_source="systemd journal, orderly native Quit from harness cleanup after observer tail timeout",
    quit_requested_ns=quit_requested, quit_completed_ns=quit_completed,
    quit_s=m.seconds(quit_completed, quit_requested), observer_tail="cancelled after measured first-frame and Open receipts")
m.save(directory/"timing.json",receipt)
