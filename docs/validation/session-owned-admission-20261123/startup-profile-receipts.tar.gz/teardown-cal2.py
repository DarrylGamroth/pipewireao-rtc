import json
import os
from pathlib import Path
import signal
import subprocess
import time

import measure as m

directory = m.stage
units = [m.unit, f"pipewireao-session@c2l-{m.tag}.service",
         f"pipewireao-session@c2l-{m.tag}-placement.service", m.hil_name, m.core_name]
monitor = int((directory/"source-monitor.pid").read_text()) if (directory/"source-monitor.pid").exists() else None
cmdline = Path(f"/proc/{monitor}/cmdline")
if monitor is not None and cmdline.exists():
    args = cmdline.read_bytes().split(b"\0")
    assert any(Path(os.fsdecode(arg)).name == "capture-source-load.py" for arg in args), args
    os.kill(monitor, signal.SIGTERM)
(directory/"finish").touch()

def unit_state(name):
    return dict(line.split("=",1) for line in subprocess.check_output(
        ["systemctl","--user","show",name,"-p","ActiveState,MainPID,LoadState"], text=True).splitlines()
        if "=" in line)

deadline = time.monotonic()+190
while time.monotonic()<deadline:
    states = {name:unit_state(name) for name in units}
    if not m.runtime.exists() and all(item["ActiveState"] == "inactive" and
            item.get("MainPID","0") in ("","0") and item["LoadState"] == "not-found" for item in states.values()):
        break
    time.sleep(1)
else:
    raise TimeoutError(states)
m.save(directory/"teardown.json",{"at_monotonic_ns":time.monotonic_ns(),"session_and_source_units":states,
       "private_runtime_removed":not m.runtime.exists(),"source_monitor_pid":monitor,
       "source_monitor_gone":not cmdline.exists()})
assert not cmdline.exists()
