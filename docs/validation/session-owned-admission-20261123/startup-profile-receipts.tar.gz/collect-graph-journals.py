from pathlib import Path
import json
import subprocess

stage = Path(__file__).resolve().parent
for ledger in stage.glob("trial-*/ready-ledger.json"):
    for role,item in json.loads(ledger.read_text())["owners"].items():
        if not role.startswith("cal2-"):
            continue
        receipt = ledger.parent / f"{role}-monotonic-journal.log"
        if not receipt.exists():
            with receipt.open("wb") as file:
                subprocess.run(["journalctl","--user","-u",item["unit"],"--all","--no-pager",
                                "-o","short-monotonic"],stdout=file,check=True)
