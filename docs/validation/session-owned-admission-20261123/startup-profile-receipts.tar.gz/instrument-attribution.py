from pathlib import Path
import sys

source = Path(sys.argv[1])

def inject(relative, operations):
    p = source / relative
    text = p.read_text()
    for old, new in operations:
        assert text.count(old) == 1, (relative, old, text.count(old))
        text = text.replace(old, new)
    p.write_text(text)

def marker(label, indent):
    return ' ' * indent + f'PipeWireAORTC.cal2_attribution("{label}")'

def before(label, statement, indent):
    return statement, marker(label, indent) + "\n" + statement

def after(label, statement, indent):
    return statement, statement + "\n" + marker(label, indent)

def around(label, statement, indent):
    return statement, marker(label+"_begin", indent)+"\n"+statement+"\n"+marker(label+"_end", indent)

inject("src/PipeWireAORTC.jl", [
    ('include("media_session/MediaSession.jl")', '''const CAL2_PROCESS = Ref(:none)
const CAL2_PRINT_COMPILATION = Ref(false)

function cal2_attribution(label, effect = "")
    kind = CAL2_PROCESS[]
    kind === :none && return nothing
    now_ns = time_ns()
    compile_ns, recompile_ns = Base.cumulative_compile_time_ns()
    cpu_ns = Common.startup_process_cpu_ns()
    println(stderr, "C2ATTR ", kind, " ", getpid(), " ", label, " ", now_ns, " ",
        something(cpu_ns, -1), " ", compile_ns, " ", recompile_ns, " ", effect)
    return nothing
end

function cal2_attribution_end()
    CAL2_PROCESS[] === :none && return
    CAL2_PRINT_COMPILATION[] && ccall(:jl_force_trace_compile_timing_disable, Cvoid, ())
    Base.cumulative_compile_timing(false)
    CAL2_PROCESS[] = :none
    return nothing
end

function __init__()
    mode = get(ENV, "CAL2_ATTRIBUTION_MODE", "")
    mode in ("trace", "phases") || return
    if length(ARGS) == 2 && first(ARGS) == "-c" &&
            get(ENV, "RTC_CONFIG", nothing) == last(ARGS) &&
            haskey(ENV, "PIPEWIREAORTC_SYSTEMD_UNIT")
        CAL2_PROCESS[] = :rtc
    elseif !isempty(ARGS) && first(ARGS) == "prepare" && haskey(ENV, "INVOCATION_ID")
        CAL2_PROCESS[] = :prepare
    else
        return
    end
    Base.cumulative_compile_timing(true)
    CAL2_PRINT_COMPILATION[] = mode == "trace"
    CAL2_PRINT_COMPILATION[] && ccall(:jl_force_trace_compile_timing_enable, Cvoid, ())
    cal2_attribution("package_init")
    return nothing
end

include("media_session/MediaSession.jl")''')
])
inject("src/media_session/MediaSession.jl", [
    ("import ..Common\n", "import ..PipeWireAORTC\nimport ..Common\n"),
])
inject("src/deployment/session_launch.jl", [
    before("prepare_render_setup", "    session = render_inputs!(request, spec, bindings, runtime)", 4),
    before("prepare_owner_reservations", '        services = Dict{String,S.Service}()', 8),
    before("prepare_core_verify", '        wait_core!(core, remote)', 8),
    before("prepare_owner_fragments", '        # HEART\'s source command needs the real controller PID. Keep this', 8),
    before("prepare_start_graphs", '            S.start_services!(cohort, record["cohort_unit"], runtime, record)', 12),
    after("prepare_graph_services_started", '            S.start_services!(cohort, record["cohort_unit"], runtime, record)', 12),
    before("prepare_render_main_config", '        config = render!(\n', 8),
    around("prepare_validate_owners", '''        for (role, item) in owner_records
            service = recorded_service(coordinator, role, item)
            S.verify!(service)
        end''', 8),
    around("prepare_analysis_stage", '        start_analysis!(package, prefix, spec, record; deadline = analysis_deadline, clock)', 8),
])
inject("src/deployment/session_cli.jl", [
    ("        SessionLaunch.main(argv; render!, validate_profile = require_node_owners)",
     '        PipeWireAORTC.cal2_attribution("prepare_cli_begin")\n'
     '        SessionLaunch.main(argv; render!, validate_profile = require_node_owners)\n'
     '        PipeWireAORTC.cal2_attribution("prepare_cli_end")\n'
     '        PipeWireAORTC.cal2_attribution_end()'),
    around("placement", '    record["placement_snapshot"] = _placement_snapshot(context; deadline, clock)', 4),
    around("retain_ledger", '    SessionLaunch.launch_record!(record["runtime"], record)', 4),
    around("discovery", '    context.discovery = _verified_discovery!(record, session_record)', 4),
    ("    _verify_main(context; deadline, clock)\n    pid, ticks, _ = context.process",
     '    PipeWireAORTC.cal2_attribution("publish_main_identity_begin")\n'
     '    _verify_main(context; deadline, clock)\n'
     '    PipeWireAORTC.cal2_attribution("publish_main_identity_end")\n'
     '    pid, ticks, _ = context.process'),
])
inject("src/media_session/session.jl", [
    around("session_construction", "    session = Session(last(arguments))", 4),
    around("initial_installed_identity", "    deployment = SessionCLI.installed_admission(file; clock)", 4),
    before("serve", "        serve!(session)", 8),
    ('    session.active_task = @async execute_effect!(session, job)',
     '    PipeWireAORTC.cal2_attribution("effect_submit", nameof(typeof(ticket.effect)))\n'
     '    session.active_task = @async execute_effect!(session, job)'),
    ('        result = perform!(session, job, ticket.effect)',
     '        PipeWireAORTC.cal2_attribution("effect_begin", nameof(typeof(ticket.effect)))\n'
     '        result = perform!(session, job, ticket.effect)\n'
     '        PipeWireAORTC.cal2_attribution("effect_end", nameof(typeof(ticket.effect)))'),
    ('    if result !== nothing\n        update!(session, result)',
     '    if result !== nothing\n'
     '        PipeWireAORTC.cal2_attribution("effect_apply_begin", nameof(typeof(result.ticket.effect)))\n'
     '        update!(session, result)\n'
     '        PipeWireAORTC.cal2_attribution("effect_apply_end", nameof(typeof(result.ticket.effect)))'),
])
launch = (source / "src/deployment/session_launch.jl").read_text()
assert "import ..PipeWireAORTC" in launch
inject("src/media_session/admission.jl", [
    before("verify_client_connect_begin", '    client = ControlClient.connect(', 4),
    after("verify_client_connect_end", '    admission.client = client', 4),
    around("verify_main_identity", '    SessionCLI.verify_admission!(admission.deployment, endpoint; deadline, clock)', 4),
    before("native_status_begin", '        completion = ControlClient.request!(', 8),
    after("native_status_end", '        SessionCLI.confirm_ready(completion)', 8),
    before("publication_begin", '        SessionCLI.publish_ready!(admission.deployment, endpoint; deadline, clock) do', 8),
    before("publication_end", '        admission.result = DiscoveryPublished()', 8),
    around("fence_proof_client_retire", '    close(something(admission.client))', 4),
    around("fence_native_sync", '    synchronize!(session, job)', 4),
    around("fence_held_links", '    verify_held_links!(session)', 4),
    ('        SessionCLI.notify_ready!()',
     '        PipeWireAORTC.cal2_attribution("notify_begin")\n'
     '        SessionCLI.notify_ready!()\n'
     '        PipeWireAORTC.cal2_attribution("notify_end")\n'
     '        PipeWireAORTC.cal2_attribution_end()'),
])
