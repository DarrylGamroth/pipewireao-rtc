#!/usr/bin/env bash
set -euo pipefail
shopt -s nullglob
umask 077
cd -- "$(dirname -- "$0")"
archive="$PWD-receipts.tar.gz"
members=(
  README.md attribution.json ab-images.json ab-image-sizes.json
  install-manifests
  import-*.log import-*.time graph-load-cpu0-*.log graph-load-cpu0-*.time plot-ready-profile.py *.png
  trial-* excluded-*
  reference-build.log diagnostic-build.log optimized-build.log
  reference-run*.log diagnostic-*.log optimized-run*.log
  reference-source.json diagnostic-source.json optimized-source.json
  optimized-commit optimized-precompile.patch instrument-attribution.patch
  host-placement.txt host-boot-id.txt
  before-first-native.json persistent.json camera-trace.tsv source-load.jsonl
  publication-before-rtc.json resumed-cameras.json continuity.json
  fixture.log journal.txt teardown.json
  driver.py session-env.sh run.sh stage.py stage.sh offline-build.jl feed.jl first-frame.py
  measure.py trial.sh prearmed-control.jl live-observe.jl capture-source-load.py resume.py
  parse-attribution.py compare-images.py collect-graph-journals.py instrument-attribution.py
  continuity.py teardown-cal2.py exec-rtc-optimized archive-attribution.sh
)
for variant in reference diagnostic optimized; do
    cache_dir="install-manifests/$variant"
    mkdir -p "$cache_dir"
    for file in Manifest.toml Project.toml deployment.conf bin/pipewireao-rtc-session systemd/pipewireao-session@.service; do
        if [[ -f "$variant-app/$file" ]]; then cp -- "$variant-app/$file" "$cache_dir/"; fi
    done
done
found=()
for path in "${members[@]}"; do
    if [[ -e "$path" ]]; then found+=("$path"); fi
done
tar -czf "$archive.tmp" -- "${found[@]}"
tar -tzf "$archive.tmp" > "$archive.contents"
mv -- "$archive.tmp" "$archive"
(cd -- "$(dirname -- "$archive")" && sha256sum -- "$(basename -- "$archive")") > "$archive.sha256"
(cd -- "$(dirname -- "$archive")" && sha256sum --check "$(basename -- "$archive").sha256")
