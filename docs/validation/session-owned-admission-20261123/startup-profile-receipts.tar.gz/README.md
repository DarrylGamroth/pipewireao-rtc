# CAL2 RTC startup attribution

The production reference is PipeWireAORTC `5a6313924c8f764ba522b37bb6ae9a24c39c5d05`
on Julia 1.13.3. The scheduler, PipeWire core, graph owners, source and
optical calibration match the installed CAL2 application. This was a new
private systemd user fixture. Its already-publishing simulator, private
core and model clock continued across the timed activations. The feeder
paused only during fixture bootstrap before the first service request. One
initial reference invocation was excluded when a mixed-case temporary
instance name failed the production lowercase name validation. The
corrected instance retained the same source and core.

The stopwatch starts before the synchronous `systemctl --user start` and
ends when that command returns successfully. The independently prearmed
client verified native Ready and both correction properties Open, followed
by native Quit. It did not issue Start. The retained graph packages loaded
their offline qualification images and both journaled skipping live graph
warmup.
No physical hardware was used.

The exact reference used the normal installed launcher and unmodified
package image. Two separate runs with the patched diagnostic tree used the
same admission checks and exact verified process argv. One enabled phase
markers with process CPU and Julia cumulative compile counters. The other
also printed compilation signatures. Phase values come from the phase-only
run. Runtime trace output split some initial marker lines while compiling
the logging calls, so trace phase associations are approximate and raw
journal lines are preserved. The systemd D-Bus control-command start
timestamp was zero. The helper subtotal runs from the service request to
the actual ExecStartPre exit timestamp.

| Arm | Service request to Ready | Service request to ExecStartPre exit | RTC main to Ready |
| --- | ---: | ---: | ---: |
| Exact untraced reference | 13.508 s | 2.470 s | 11.037 s |
| Phase markers | 13.659 s | 2.514 s | 11.144 s |
| Signature-traced | 13.857 s | recorded in attribution.json | recorded in attribution.json |

The phase-only RTC reached package initialization 1.122 s after main
entry. It had accrued 8.008 process CPU seconds at notification and Julia's
post-import cumulative compile counter advanced 6.519 s. The standalone
warm-cache RTC import probes spent 0.896 and 0.907 s in `using PipeWireAORTC`
inclusive. The graph package import probes on CPU0 spent 1.742–1.773 s in
their package imports with 2.05–2.07 s whole process round trips. Later graph
log labels for loading FilterGraphPipeWire cover only the already loaded
binding and do not measure process startup imports. The older contended
CPU14 graph import probes are retained as excluded measurements.

ConnectOwners was the largest conditional wait at 3.128 s wall and 0.423 s
of RTC process CPU. Both graph owners ran their startup concurrently during
this interval. Their process launches preceded the RTC's wait. In the
phase-only run, LLOWFS and SCC preparation took 0.493 and 0.655 s, of which
0.455 and 0.576 s were compilation. Their entry to the prepared graph took
0.698 and 0.905 s, almost entirely compilation. Both graphs then logged
that online optical warmup had been skipped. The ConnectOwners completion
was correlated with native owner acknowledgement.

After the owners connected, RTC Link creation, the separate admission
client, native Status, placement publication and proof-client retirement
still paid first-use compilation costs. Actual final synchronization
was 2.32 ms, exact held-Link checking was 0.45 ms and the systemd notify
call took 0.14 ms in the phase-only run. Native deadlines are upper limits.
The measurement did not identify a fixed multi-second admission sleep.
CPU and compile values are overlapping observations of work in the same
process. Nested phase rows in the JSON are inclusive.

## A/B of offline startup compilation

The scratch candidate `1b3d3cb03273fca8dd895576b2129752a1556d8f` adds
five compile directives to the uninstrumented reference. The trace recorded
the real GlobalRemoved update at 892.3 ms during proof-client retirement,
the Status dispatch closure at 182.2 ms, RequestReceived at 121.8 ms,
LinkUpdated at 106.1 ms and the placement snapshot at 81.9 ms. The patch
uses stable method signatures and the concrete Status dispatch action in
the existing offline workload. These trace durations indicate candidate
specializations. They may include nested compilation and do not add to
an independent wall-clock estimate.

Only the managed main process loaded the candidate cache through the
private unit's exec-preserving load-path wrapper. The existing installed
launcher remained the final executable path into the same Julia argument
vector. Prepare, stop, the simulator, core and both scientific graph
processes retained the reference application bindings. The candidate
main cache's matching .ji file identifies its source hash directory.
Every mapped compiled graph image, including PipeWireAORTC bootstrap
dependencies, matched the reference by file path, inode and SHA-256.

| Order | Arm | Service to Ready | RTC main to Ready | Sampled RTC leader CPU |
| --- | --- | ---: | ---: | ---: |
| A1 | Reference | 13.508 s | 11.037 s | 7.639 s |
| B1 | Candidate | 12.303 s | 9.755 s | 6.301 s |
| A2 | Reference | 13.401 s | 10.959 s | 7.632 s |
| B2 | Candidate | 12.106 s | 9.613 s | 6.382 s |

Two paired savings were 1.205 s and 1.295 s. The main process saved about
1.25–1.34 sampled leader CPU seconds, with its sampled runnable wait at
0.074–0.080 s across arms. Leader samples are taken near the Ready boundary
with up to 200 ms sampling lag. The study does not estimate a startup
percentile. The first candidate activation that reached systemd Ready was
excluded because a recorder local variable shadowed the external source
receipt. Its normal systemd cleanup and observer error are retained.
Every retained arm independently read native Ready and both Open properties,
observed ten unique new Links, then completed native Quit and cleared all
session Links and the discovery locator.
