from pathlib import Path
import json
import sys
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt

trial, output = map(Path, sys.argv[1:])
report = json.loads((trial / "phases.json").read_text())
timing = json.loads((trial / "timing.json").read_text())
origin = timing["service_request_ns"]
main = int(timing["service"]["ExecMainStartTimestampMonotonic"]) * 1000
markers = report["markers"]
def mark(role, label, effect=None):
    return next(r for r in markers if r["role"] == role and r["label"] == label and r["effect"] == effect)
def at(label, effect=None):
    return mark("rtc", label, effect)
ns = lambda x: (x["ns"] - origin) / 1e9
begin, opened, links, verify, publish, end = (at("package_init"), at("effect_begin", "ConnectOwners"), at("effect_end", "ConnectOwners"), at("effect_begin", "VerifyAdmission"), at("publication_begin"), at("notify_end"))
rows = [
    ("Launch the controller services", 0, (main-origin)/1e9, mark("prepare","package_init"), mark("prepare","prepare_cli_end")),
    ("Start the RTC and identify owners", (main-origin)/1e9, ns(opened), begin, opened),
    ("Connect to the two controllers", ns(opened), ns(links), opened, links),
    ("Find graphs, connect Links and hold", ns(links), ns(verify), links, verify),
    ("Verify the RTC and request Status", ns(verify), ns(publish), verify, publish),
    ("Publish and confirm Ready", ns(publish), (timing["service_ready_ns"]-origin)/1e9, publish, end),
]
fig, ax = plt.subplots(figsize=(10.7, 4.45))
fig.subplots_adjust(left=.292, right=.812, bottom=.215, top=.76)
fig.patch.set_facecolor("white")
navy, blue, green, gray = "#182f42", "#32617c", "#247466", "#465d69"
fig.text(.025,.925,"CAL2 restart to Ready",fontsize=18,fontweight="bold",color=navy)
fig.text(.026,.855,"One measured activation with both cameras already publishing and both integrators open.",fontsize=10,color=gray)
for i,(name,start,stop,lo,hi) in enumerate(rows):
    ax.barh(i,stop-start,left=start,height=.49,color=green if i==2 else blue)
    wall = stop-start
    comp = (hi["compile_ns"] - lo["compile_ns"]) / 1e9
    ax.text(1.045,i,f"{wall:.2f} s",ha="center",va="center",transform=ax.get_yaxis_transform(),fontsize=10,color=navy)
    ax.text(1.205,i,f"{comp:.2f} s"+("*" if i<2 else ""),ha="center",va="center",transform=ax.get_yaxis_transform(),fontsize=10,color=navy)
ax.text(1.045,1.04,"Elapsed",ha="center",transform=ax.transAxes,fontsize=10,fontweight="bold",color=navy)
ax.text(1.205,1.04,"In compiler",ha="center",transform=ax.transAxes,fontsize=10,fontweight="bold",color=navy)
ax.set_yticks(range(len(rows)),[r[0] for r in rows])
ax.set_ylim(len(rows)-.45,-.55)
ax.set_xlim(0,14)
ax.set_xticks(range(0,15,2))
ax.tick_params(axis="both",length=0,labelcolor=navy,labelsize=10,pad=6)
ax.set_xlabel("Seconds since the service start request",color=gray,labelpad=8)
ax.spines[:].set_visible(False)
ax.grid(axis="x",color="#dce4e8",linewidth=.8)
ax.set_axisbelow(True)
fig.text(.026,.038,"* Compilation timing began after package initialization in each process. Graph processes ran in parallel.",fontsize=9,color=gray)
fig.savefig(output,dpi=150)
