from functools import cache
import hashlib
import json
from pathlib import Path
import re
import subprocess

stage = Path(__file__).resolve().parent
def load(path):
    return json.loads(path.read_text())

@cache
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def mapped_images(path):
    images = {}
    for record in path.read_text().splitlines():
        fields = record.split(maxsplit=5)
        if len(fields) != 6:
            continue
        file = Path(fields[5])
        if not file.is_absolute() or not file.name.endswith(".so") or not file.exists():
            continue
        if "/compiled/" in str(file):
            images[str(file)] = {"inode":int(fields[4]), "sha256":sha(file)}
    return images

def source_in_cache(image, source_path):
    ji = Path(image).with_suffix(".ji")
    artifact = str(source_path).split("/depot/")[1]+"/src/PipeWireAORTC.jl"
    return any(artifact in line for line in subprocess.check_output(
        ["strings","-a",str(ji)],text=True,errors="replace").splitlines())

control = None
results = []
for path in sorted(stage.glob("trial-*/timing.json")):
    data = load(path)
    if data["attribution_mode"] not in ("reference","optimized"):
        continue
    folder = path.parent
    expected = Path(data["package"]["source"])
    maps = mapped_images(folder/"rtc-maps.txt")
    package_images={name:item for name,item in maps.items() if "/PipeWireAORTC/" in name}
    assert len(package_images) == 1
    assert source_in_cache(next(iter(package_images)), expected), (package_images, expected)
    owners = {}
    for role in ("cal2-llowfs","cal2-scc"):
        image = mapped_images(folder/f"{role}-maps.txt")
        assert any("ExportedGraphWarmup" in name for name in image)
        package = [name for name in image if "/PipeWireAORTC/" in name]
        assert len(package) == 1
        reference = Path(load(stage/"reference-source.json")["source"])
        assert source_in_cache(package[0],reference)
        owners[role] = image
    if control is None:
        control = owners
    same_owner_images = owners == control
    if not same_owner_images:
        difference={role:sorted(set(owners[role]) ^ set(control[role])) for role in owners}
        raise AssertionError((folder,difference))
    results.append({"trial":folder.name,"mode":data["attribution_mode"],"rtc_package_images":package_images,
                    "source":str(expected), "same_graph_images_as_reference":same_owner_images,
                    "linked_source":data["source"]})
print(json.dumps({"trials":results,"reference_graph_images":control},indent=2,sort_keys=True))
