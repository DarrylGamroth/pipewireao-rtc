import collections
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MARKER = re.compile(r"^C2ATTR (rtc|prepare) (\d+) (\S+) (\d+) (-?\d+) (\d+) (\d+)(?: (\S+))?\s*$")
TRACE = re.compile(r"#=\s*(\d+(?:\.\d+)?)\s*ms\s*=#\s*(precompile\(.*\))$")
def seconds(later, earlier, divisor=1e9):
    return (int(later)-int(earlier))/divisor

def timed_events(records, pairs, origin):
    latest_start = {}
    counts = collections.Counter()
    output = []
    for row in records:
        label = row["label"]
        effect = row.get("effect")
        if label in pairs:
            latest_start[(pairs[label],effect)] = row
        if (label,effect) not in latest_start:
            continue
        start = latest_start.pop((label,effect))
        counts[(start["label"],effect)] += 1
        output.append({
            "phase":start["label"], "effect": effect, "occurrence": counts[(start["label"],effect)],
            "after_service_request_s":seconds(start["ns"],origin),
            "wall_s":seconds(row["ns"],start["ns"]),
            "process_cpu_s":seconds(row["cpu_ns"],start["cpu_ns"]),
            "compilation_s":seconds(row["compile_ns"],start["compile_ns"]),
            "recompilation_s":seconds(row["recompile_ns"],start["recompile_ns"]),
        })
    return output

def capture(directory):
    timing=json.loads((directory/"timing.json").read_text())
    journal = subprocess.check_output(
        ["journalctl","--user","--no-pager","-o","json","--all",
         "_SYSTEMD_INVOCATION_ID="+timing["rtc"]["invocation"]],text=True)
    (directory/"current-invocation.jsonl").write_text(journal)
    markers = []
    traces = []
    current_marker = {}
    for line in journal.splitlines():
        entry = json.loads(line)
        text=entry.get("MESSAGE","")
        if not isinstance(text,str):
            continue
        if found := MARKER.fullmatch(text):
            kind,pid,label,ts,cpu,compile_,recompile_,effect = found.groups()
            item = {"role":kind,"pid":int(pid),"label":label,"ns":int(ts),
                    "cpu_ns":int(cpu),"compile_ns":int(compile_),"recompile_ns":int(recompile_),"effect":effect}
            markers.append(item)
            current_marker[int(pid)] = item
        elif found := TRACE.search(text):
            pid=int(entry["_PID"])
            parent=current_marker.get(pid,{})
            traces.append({"pid":pid,"ms":float(found[1]),"signature":found[2],
                           "since_marker":parent.get("label"),"effect":parent.get("effect"),
                           "role":parent.get("role")})
    # The runtime tracer may split the first stdio marker while compiling print.
    # The phase-only arm has the complete, uncontaminated marker stream.
    ready = timing["service_ready_ns"]
    req = timing["service_request_ns"]
    main = int(timing["service"]["ExecMainStartTimestampMonotonic"])*1000
    dbus = json.loads((directory/"unit-dbus.json").read_text())
    commands = dbus["ExecStartPre"]["data"]
    if len(commands) == 1 and isinstance(commands[0],list) and len(commands[0]) == 1:
        commands = commands[0]
    assert len(commands) == 1 and len(commands[0]) == 10, commands
    _,_,_,_,pre_start_us,_,pre_exit_us,pre_pid,exit_code,exit_status = commands[0]
    assert pre_start_us <= pre_exit_us and pre_exit_us*1000 > req and pre_pid > 0 and exit_status == 0
    rtc_pairs = {row["label"]:row["label"].removesuffix("_begin")+"_end"
                 for row in markers if row["role"]=="rtc" and row["label"].endswith("_begin")}
    rtc_pairs["effect_submit"] = "effect_begin"
    prep = [row for row in markers if row["role"]=="prepare"]
    rtc = [row for row in markers if row["role"]=="rtc"]
    for trace in traces:
        if trace["role"] is None:
            trace["role"] = "rtc" if trace["pid"] == timing["rtc"]["pid"] else "prepare" if trace["pid"] == pre_pid else None
    prep_pairs = {before["label"]:after["label"] for before,after in zip(prep,prep[1:])}
    assert len({row["pid"] for row in rtc}) <= 1
    if rtc:
        assert {row["pid"] for row in rtc} == {timing["rtc"]["pid"]}
        assert (timing["attribution_mode"] == "trace" or rtc[0]["label"] == "package_init") and rtc[-1]["label"] == "notify_end"
    if prep:
        assert {row["pid"] for row in prep} == {pre_pid}
        assert (timing["attribution_mode"] == "trace" or prep[0]["label"] == "package_init") and prep[-1]["label"] == "prepare_cli_end"
    if timing["attribution_mode"] == "trace":
        assert traces and rtc and prep
    startup = {"service_to_ready_s":seconds(ready,req),
               "service_to_prepare_exit_s":seconds(pre_exit_us*1000,req),
               "service_to_prepare_entry_s":seconds(pre_start_us*1000,req) if pre_start_us else None,
               "prepare_process_wall_s":seconds(pre_exit_us,pre_start_us,1e6) if pre_start_us else None,
               "prepare_exit_to_rtc_main_s":seconds(main,pre_exit_us*1000),
               "rtc_main_to_ready_s":seconds(ready,main)}
    if rtc and prep and rtc[0]["label"] == prep[0]["label"] == "package_init":
        startup.update(rtc_entry_to_package_init_s=seconds(rtc[0]["ns"],main),
                       rtc_cpu_at_package_init_s=rtc[0]["cpu_ns"]/1e9,
                       rtc_compile_after_package_init_through_notify_s=seconds(rtc[-1]["compile_ns"],rtc[0]["compile_ns"]),
                       rtc_cpu_at_notify_s=rtc[-1]["cpu_ns"]/1e9,
                       service_to_prepare_package_init_s=seconds(prep[0]["ns"],req),
                       prepare_cpu_at_package_init_s=prep[0]["cpu_ns"]/1e9,
                       prepare_cpu_at_return_s=prep[-1]["cpu_ns"]/1e9,
                       prepare_compile_after_package_init_s=seconds(prep[-1]["compile_ns"],prep[0]["compile_ns"]),
                       rtc_notify_to_service_return_s=seconds(ready,rtc[-1]["ns"]))
    sch = collections.defaultdict(list)
    with (directory/"startup-schedstat.jsonl").open() as src:
        for line in src:
            sample = json.loads(line)
            sch[sample["role"]].append(sample)
    output = {"trial":directory.name, "mode":timing["attribution_mode"],"timing":startup,
              "prepare":timed_events(prep,prep_pairs,req),"rtc":timed_events(rtc,rtc_pairs,req),
              "final_leader_samples":{key:value[-1] for key,value in sch.items()},
              "markers":markers, "published_signatures":len(traces),
              "expensive_signatures":sorted(traces,key=lambda row:row["ms"],reverse=True)[:40]}
    (directory/"compile-signatures.json").write_text(json.dumps(traces)+"\n")
    (directory/"phases.json").write_text(json.dumps(output,indent=2)+"\n")
    return output

paths = [Path(name).resolve() for name in sys.argv[1:]]
if not paths:
    paths=sorted(path.parent for path in ROOT.glob("trial-*/timing.json"))
out=[capture(path) for path in paths]
print(json.dumps(out,indent=2))
