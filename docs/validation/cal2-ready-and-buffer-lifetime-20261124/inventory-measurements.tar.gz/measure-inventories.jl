using PipeWireAORTC

const SessionCLI = PipeWireAORTC.SessionCLI

function measure(operation, name, pass)
    cpu() = parse(Int64, first(split(read("/proc/thread-self/schedstat", String)))) / 1.0e9
    before = cpu()
    sample = @timed operation()
    after = cpu()
    println(join((pass, name, sample.time, after - before, sample.compile_time, sample.bytes), '\t'))
    return nothing
end

function measure_inventories(application, activation_digest, graph_digest)
    graph_assets = joinpath(application, "systemd", "graph-owner-assets.json")
    for pass in 1:2
        measure("activation", pass) do
            SessionCLI.activation_document(application, activation_digest)
        end
        measure("graph-assets", pass) do
            SessionCLI.SessionLaunch.verify_graph_assets!(graph_assets, graph_digest)
        end
    end
end

measure_inventories(ARGS...)
