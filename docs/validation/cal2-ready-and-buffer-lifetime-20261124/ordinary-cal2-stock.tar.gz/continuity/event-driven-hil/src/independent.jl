# Run one independently supervised simulator on a preexisting PipeWire core.
Base.exit_on_sigint(false)

try
    @info "Loading simulation packages"
    Base.require(Main, :PipeWireAORTC)
    if !isempty(get(ENV, "PIPEWIREAO_OPTICAL_STARTUP", ""))
        Base.require(Main, :PipeWireAOOpticalStartup)
    end
    hil = Base.require(Main, :AdaptiveOpticsSimPipeWireHIL)
    Base.invokelatest(hil.Simulation.independent_main, ARGS)
catch error
    while error isa Union{LoadError,InitError}
        error = error.error
    end
    error isa InterruptException || rethrow()
end
