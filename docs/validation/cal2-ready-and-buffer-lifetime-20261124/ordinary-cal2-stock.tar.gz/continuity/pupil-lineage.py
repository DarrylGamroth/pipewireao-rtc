# Report every admitted pupil and account for holds, overwrites and incomplete teardown.
import argparse
import collections
import csv
from pathlib import Path
import sys

from decode import events

parser = argparse.ArgumentParser()
parser.add_argument("--hil", type=Path, required=True)
parser.add_argument("--tap", type=Path, required=True)
args = parser.parse_args()

pupil = collections.defaultdict(dict)
camera_attempts = {}
last_llowfs_pts = -1
for kind, path in (("hil", args.hil), ("tap", args.tap)):
    for _, event, stream, domain, gen, seq, pts, timestamp, flags in events(path):
        if not seq:
            continue
        if stream == 1:
            pupil[(domain,gen,seq,pts)][(kind,event)] = timestamp
        if kind == "hil" and stream in (2,3) and event == "stage-attempt":
            camera_attempts[(stream,pts)] = timestamp
            if stream == 2:
                last_llowfs_pts = max(last_llowfs_pts,pts)

writer = csv.writer(sys.stdout, delimiter="\t", lineterminator="\n")
writer.writerow(("domain", "generation", "sequence", "model_ns", "stage_ns",
    "native_queue_ns", "hil_arrival_ns", "hil_drain_ns", "llowfs_completion_ns",
    "scc_window_completion_ns", "disposition"))
for key, points in sorted(pupil.items()):
    _, _, seq, pts = key
    def ts(origin,event):
        return points.get((origin,event),"")
    llowfs = camera_attempts.get((2,pts),"")
    # The SCC exposure ending with this pupil starts four pupil intervals earlier.
    scc = camera_attempts.get((3,pts-8_000_000),"") if seq % 5 == 0 else ""
    disposition = ""
    if not ts("tap","native-queued"):
        disposition = "pupil-not-queued"
    elif not ts("hil","native-received"):
        disposition = "pupil-not-received"
    elif not ts("hil","drained"):
        disposition = "pupil-not-drained"
    elif not llowfs:
        disposition = "pupil-without-exposure" if pts < last_llowfs_pts else "trailing-unfinished-pupil"
    elif seq % 5 == 0 and not scc:
        disposition = "missing-scc-completion"
    writer.writerow((*key, ts("tap","staged"), ts("tap","native-queued"),
        ts("hil","native-received"), ts("hil","drained"),llowfs,scc,disposition))
