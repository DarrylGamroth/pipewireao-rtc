#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
cd "$cal2_fixture"

driver_pid="$1"
previous="$2"
queue_module="$3"
case "$previous" in stock|narrow) ;; *) exit 1 ;; esac
test -f "$queue_module"
test -f "replacement-$previous/publication-result.json"
test -f "replacement-$previous/lifecycle-passed.json"
for unit in "pipewireao-session@${CAL2_VALIDATION_SESSION_INSTANCE:-c2l-${CAL2_VALIDATION_TAG,,}-measure}.service" \
            "pipewireao-graph-cal2-${CAL2_VALIDATION_TAG,,}-cal2-llowfs.service" \
            "pipewireao-graph-cal2-${CAL2_VALIDATION_TAG,,}-cal2-scc.service"; do
    test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
mapfile -d '' -t driver_args < "/proc/$driver_pid/cmdline"
test "${driver_args[0]}" = python3
test "${driver_args[1]}" = -u
if test "${driver_args[2]}" = driver.py; then
    test "$(readlink "/proc/$driver_pid/cwd")" = "$cal2_fixture"
else
    test "${driver_args[2]}" = "$cal2_fixture/driver.py"
fi

touch finish
deadline=$((SECONDS+150))
while test -r "/proc/$driver_pid/cmdline"; do
    test "$SECONDS" -le "$deadline"
    sleep 1
done
test ! -e "$PIPEWIREAORTC_CORE_SOCKET"
for unit in "$PIPEWIREAORTC_CORE_UNIT" "$PIPEWIREAORTC_SOURCE_UNIT"; do
    test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
mkdir "$previous-provider"
mv fixture.log feed.log hil-native.log core-native.log journal.txt before-first-native.json \
   persistent.json camera-trace.tsv pupil-pacing.tsv first-llowfs.f32 first-llowfs.json "$previous-provider/"
mv hil-array-trace.tsv.*.bin tap-array-trace.tsv.*.bin graph-ingress.*.bin "$previous-provider/"
python3 - <<'PY'
from pathlib import Path
for name in ("finish", "stop-feed", "feed-ready", "warm-lease-released"):
    path = Path(name)
    assert path.is_file() and path.stat().st_size == 0 and path.stat().st_nlink == 1
    path.unlink()
PY
export CAL2_VALIDATION_QUEUE_MODULE="$queue_module"
export CAL2_HIL_PROJECT="$cal2_fixture/continuity/event-driven-provider-env"
touch narrow-source-started
PYTHONDONTWRITEBYTECODE=1 exec taskset -c 14,15 python3 -u "$cal2_fixture/driver.py" > fixture.log 2>&1
