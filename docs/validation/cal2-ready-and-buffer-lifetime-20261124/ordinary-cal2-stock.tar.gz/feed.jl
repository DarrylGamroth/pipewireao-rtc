using PipeWireAO, PipeWireAORTC, PipeWireAO_jll
using AdaptiveOpticsSimPipeWireHIL: PipeWireArrayStreamOptions, with_array_streams,
    with_array_stream, array_stream_status, stage_pipewire_array!, drain_pipewire_array!
using UUIDs
const RTC = PipeWireAORTC
include(joinpath(ARGS[4], "classic_observation.jl"))
include(joinpath(ARGS[4], "sealed_cal2_pupil.jl"))

function global_node(reg, name)
    nodes=find_globals(reg;interface="PipeWire:Interface:Node",properties=("node.name"=>name,))
    isempty(nodes) && return nothing
    return only(nodes)
end

function attach(owner,reg,output_name,input_name)
    ends = Ref{Any}()
    timedwait(300;pollint=0.02) do
        with_array_stream(owner,1) do _
            output,input=global_node(reg,output_name),global_node(reg,input_name)
            (output===nothing || input===nothing) && return false
            outputs=find_globals(reg;interface="PipeWire:Interface:Port",
                properties=("node.id"=>string(output.id),"port.direction"=>"out"))
            inputs=find_globals(reg;interface="PipeWire:Interface:Port",
                properties=("node.id"=>string(input.id),"port.direction"=>"in"))
            (isempty(outputs) || isempty(inputs)) && return false
            ends[]=(output,only(outputs),input,only(inputs))
            return true
        end
    end==:ok || error("CAL2 feed endpoints did not appear for $output_name → $input_name")
    with_array_stream(owner,1) do _
        out_node,out_port,in_node,in_port=ends[]
        link=create_object(owner.core,"link-factory",Link;properties=Dict(
            "link.output.node"=>string(out_node.id),"link.output.port"=>string(out_port.id),
            "link.input.node"=>string(in_node.id),"link.input.port"=>string(in_port.id),
            "link.passive"=>"false","object.linger"=>"false","object.path"=>"independent-cal2/$output_name/$input_name"))
        return (;link,tracker=track_info!(link),ends=ends[])
    end
end

function run_feed(application, remote, evidence)
    simulation=RTC.Common.read_json(joinpath(application,"simulation.conf"))
    profile=RTC.Common.read_json(joinpath(application,"deployment.conf"))
    session=RTC.DeploymentConfiguration.decode(joinpath(application,profile["session"]),PipeWireAO_jll.artifact_dir)
    input, sensor_input, _=pupil_source(application,session)
    cam_names=(simulation["sensor_nodes"]["llowfs"],simulation["sensor_nodes"]["scc"])
    specs=map(cam_names) do name
        model=only(row for row in session["sources"] if row["node.name"]==name)
        port=only(model["ports"])
        format=NdArrayFormat(NdArray.F32_LE,Tuple(Int.(port["shape"]));layout=NdArray.ROW_MAJOR,
            rate=SPA.Fraction(parse.(Int,split(port["rate"],'/'))...))
        metadata = if name == cam_names[2]
            (RTC.Common.ACQUISITION_METADATA...,
                MetadataRequirement(SPA.META_OPTICAL_CHOPPING;required=true),
                MetadataRequirement(SPA.META_ELECTRICAL_TRIGGER;required=true))
        else
            RTC.Common.ACQUISITION_METADATA
        end
        PipeWireArrayStreamOptions(;node_name="independent-cal2-observe-"*name,
            media_name="Independent CAL2 observe "*name,schema=port["schema"],format,
            metadata,buffers=simulation["sensor_buffers"])
    end
    payload=synthetic_pupil(last(input.format.shape))
    source_domain=AcquisitionDomain(ntuple(_->rand(UInt8),16))
    interval=UInt64(2_000_000)
    stop=joinpath(evidence,"stop-feed")
    ready=joinpath(evidence,"feed-ready")
    pause=joinpath(evidence,"pause-feed")
    paused=joinpath(evidence,"feed-paused")
    ready_branch = get(ENV, "CAL2_VALIDATION_SOURCE_READY_BRANCH", "both")
    @assert ready_branch in ("both", "llowfs")
    mkpath(evidence)
    with_array_streams((input,specs...);remote,input=(false,true,true)) do owner
        reg=with_array_stream(_ -> Registry(owner.core),owner,1)
        links=Any[]
        images=map(spec -> zeros(Float32,spec.format.shape),specs)
        per_camera=Dict{String,Tuple{AcquisitionIdentity,Int64}}()
        try
            push!(links,attach(owner,reg,input.node_name,sensor_input))
            for (name,spec) in zip(cam_names,specs)
                push!(links,attach(owner,reg,name,spec.node_name))
            end
            timedwait(30;pollint=0.02) do
                with_array_stream(owner,1) do _
                    all(links) do link
                        has_current_info(link.tracker) || return false
                        info=current_info(link.tracker)
                        if info.state==PipeWireAO.LINK_STATE_ERROR
                            output,input=link.ends[1],link.ends[3]
                            error("CAL2 Link $(output.properties["node.name"]) -> $(input.properties["node.name"]): $(info.error)")
                        end
                        info.state in (PipeWireAO.LINK_STATE_PAUSED,PipeWireAO.LINK_STATE_ACTIVE)
                    end
                end
            end==:ok || error("CAL2 feed and camera Links did not negotiate")
            open(joinpath(evidence,"camera-trace.tsv"),"w") do trace
                println(trace,"camera\tsequence\tmodel_ns\tgeneration\tdomain\tobserved_ns\texposure_ns\tmax_abs")
                sequence=UInt64(0)
                # Pace the deterministic pupil stream independently of either lossy camera tap.
                # The wall interval exceeds a normally completed real CAL2 pupil calculation.
                publication_interval = UInt64(32_000_000_000)
                pacing_file = joinpath(evidence, "pupil-pacing.tsv")
                write(pacing_file, "pupil_sequence\tstaged_ns\tllowfs_at_boundary\tscc_at_boundary\n")
                while !isfile(stop)
                    if isfile(ready) && isfile(pause)
                        touch(paused)
                        while isfile(pause) && !isfile(stop)
                            sleep(0.05)
                        end
                        rm(paused; force=true)
                        isfile(stop) && break
                    end
                    previous_status = array_stream_status(owner, 1)
                    !previous_status.pending && !previous_status.failed &&
                        previous_status.dropped == previous_status.rejected == 0 ||
                        error("Pupil source cannot overwrite a pending or failed slot: $previous_status")
                    sequence+=1
                    id=AcquisitionIdentity(source_domain,UInt64(1),sequence)
                    pts=Int64(sequence-1)*Int64(interval)
                    stage_pipewire_array!(owner,1,payload;identity=id,pts,duration=interval) ||
                        error("CAL2 pupil $sequence was rejected by its staging slot")
                    started=time_ns()
                    next_publication = started + publication_interval
                    while time_ns() < next_publication && !isfile(stop)
                        trigger_process!(owner)
                        for index in 1:2
                            name=cam_names[index]
                            r=drain_pipewire_array!(images[index],owner,index+1)
                            r===nothing && continue
                            i=something(r.identity)
                            if haskey(per_camera,name)
                                previous, previous_pts=per_camera[name]
                                i.domain==previous.domain && i.generation==previous.generation ||
                                    error("$name camera domain or generation changed")
                                i.sequence>previous.sequence && r.pts>previous_pts ||
                                    error("$name camera exposure chronology regressed")
                            end
                            all(isfinite,images[index]) || error("$name contains a nonfinite pixel")
                            r.duration>0 || error("$name was missing exposure duration")
                            if index == 1 && !haskey(per_camera, name)
                                # Preserve the actual Float32 camera array for the private-core
                                # lifecycle replay. Julia Array order is recorded by its shape.
                                open(joinpath(evidence, "first-llowfs.f32"), "w") do data
                                    write(data, images[index])
                                end
                                RTC.Common.write_json(joinpath(evidence, "first-llowfs.json"), (;
                                    shape = size(images[index]), layout = "Julia column-major Float32",
                                    domain = bytes2hex(collect(i.domain.bytes)),
                                    generation = i.generation, sequence = i.sequence, model_ns = r.pts,
                                ); atomic = true)
                            end
                            per_camera[name]=(i,r.pts)
                            println(trace,join((name,i.sequence,r.pts,i.generation,
                                bytes2hex(collect(i.domain.bytes)),time_ns(),r.duration,maximum(abs,images[index])),'\t'))
                            flush(trace)
                            if index==1
                                pupil_sequence, phase = divrem(r.pts, Int64(interval))
                                phase == 0 && 0 <= pupil_sequence < sequence &&
                                    i.sequence <= pupil_sequence + 1 ||
                                    error("CAL2 LLOWFS exposure is outside the staged pupil chronology")
                            end
                        end
                        source_ready = ready_branch == "both" ?
                            length(per_camera) == 2 : haskey(per_camera, first(cam_names))
                        source_ready && !isfile(ready) && touch(ready)
                        sleep(0.01)
                    end
                    observed(name) = haskey(per_camera, name) ? per_camera[name][1].sequence : 0
                    open(pacing_file,"a") do pacing
                        println(pacing, join((sequence,started,observed(cam_names[1]),observed(cam_names[2])),'\t'))
                    end
                end
            end
        finally
            with_array_stream(owner,1) do _
                for item in reverse(links)
                    close(item.tracker)
                    close(item.link)
                end
                close(reg)
            end
        end
    end
end
run_feed(ARGS[1:3]...)
