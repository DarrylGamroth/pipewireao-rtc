#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
cd "$cal2_fixture"

attempt="$1"
provider="$2"
variant="$3"
case "$attempt" in stock|narrow|final) ;; *) exit 1 ;; esac
case "$variant" in baseline|candidate) ;; *) exit 1 ;; esac
cohort="replacement-$attempt"
app="$variant-app"
test -s "$provider/persistent.json"
test -d "$cohort"
hil_pid=$(jq -r '.hil.pid' "$provider/persistent.json")
tap_pid=$(jq -r '.native["independent-cal2-observe-cal2-llowfs"].client_pid' "$provider/persistent.json")
mapfile -t graph_traces < <(jq -r '.[].unit_identity.pid| "graph-ingress." + (. | tostring) + ".bin"' "$cohort/prestarted-graph-owners.json")
graph_paths=()
for graph in "${graph_traces[@]}"; do
    graph_paths+=("$provider/$graph")
done
python3 continuity/lineage.py \
    --hil "$provider/hil-array-trace.tsv.$hil_pid.bin" --tap "$provider/tap-array-trace.tsv.$tap_pid.bin" \
    --graph "${graph_paths[@]}" > "$cohort/detector-lineage.tsv"
python3 continuity/decode.py "$provider/hil-array-trace.tsv.$hil_pid.bin" \
    "$provider/tap-array-trace.tsv.$tap_pid.bin" "${graph_paths[@]}" > "$cohort/transport-events.tsv"
python3 settle_receipts.py "$cohort" "$provider" > "$cohort/settled-joins.log"
tar -czf "ordinary-cal2-$attempt.tar.gz" \
    "$cohort" "ordinary-$attempt.log" "$variant-source.json" "$variant-build.log" \
    queue-provenance.json installed-asset-comparison.json core-config/daemon.conf core-config/client.conf \
    "$provider"/{persistent.json,fixture.log,feed.log,core-native.log,hil-native.log,journal.txt,before-first-native.json,camera-trace.tsv,pupil-pacing.tsv} \
    "$provider/hil-array-trace.tsv.$hil_pid.bin" "$provider/tap-array-trace.tsv.$tap_pid.bin" "${graph_paths[@]}" \
    "$app"/{Project.toml,Manifest.toml,deployment.conf} \
    "$app"/systemd/{session-activation.json,graph-owner-assets.json,graph-owners.json,pipewireao-session@.service} \
    "$app"/systemd/pipewireao-graph-*.service \
    driver.py ordinary.py matched.py replacement.py measure.py settle_receipts.py feed.jl numerical-oracle.jl \
    live-correction-control.jl live-observe.jl archive-ordinary.sh switch-queue-module.sh \
    continuity/{decode.py,lineage.py,pupil-lineage.py,continuity_trace.jl} \
    continuity/event-driven-provider-env/{Project,Manifest}.toml \
    continuity/event-driven-hil/src/{independent,array_streams}.jl
gzip -t "ordinary-cal2-$attempt.tar.gz"
sha256sum "ordinary-cal2-$attempt.tar.gz"
