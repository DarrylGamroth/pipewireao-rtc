"""Compare the direct and legacy starts of one installed CAL2 build."""
import argparse
import hashlib
import mmap
import os
from pathlib import Path
import re
import shutil
import struct
import time

import measure as m
import replacement as retained
from continuity.decode import EVENTS, ROW

app, stage, scratch = retained.app, retained.stage, retained.scratch
tap_receipts = m.cameras
start_service = m.start_service
camera_streams = {}
traces = {}

class EventTrace:
    def __init__(self, path):
        with path.open("rb") as file:
            self.data = mmap.mmap(file.fileno(), 0, access=mmap.ACCESS_READ)
        self.offset = 0
        self.rows = []

    def events(self):
        while self.offset < len(self.data):
            kind, channel, lo, hi, gen, seq, pts, timestamp = ROW.unpack_from(self.data, self.offset)
            if timestamp == 0:
                break
            self.offset += ROW.size
            if kind == 10:
                continue
            assert kind in EVENTS
            self.rows.append(dict(event=EVENTS[kind], stream=channel & 0xffffffff,
                                   domain=struct.pack("<QQ", lo, hi).hex(),
                                   generation=gen, sequence=seq, model_ns=pts if pts < 2**63 else pts - 2**64,
                                   observed_ns=timestamp, flags=channel >> 32))
        assert self.offset < len(self.data), "A continuity trace filled"
        return self.rows


def events(prefix, pid):
    path = stage / f"{prefix}.{pid}.bin"
    if path not in traces:
        traces[path] = EventTrace(path)
    return traces[path].events()


def identity(row):
    return tuple(row[key] for key in ("domain", "generation", "sequence", "model_ns"))


def camera_map(source):
    rows = events("hil-array-trace.tsv", source["hil"]["pid"])
    queued = {identity(event): event["stream"] for event in rows if event["event"] == "native-queued"}
    taps = tap_receipts()
    for branch in m.branches:
        camera = "cal2-" + branch
        observed = [row for row in taps if row["camera"] == camera]
        indices = {queued[identity(row)] for row in observed if identity(row) in queued}
        assert len(indices) == 1, (camera, indices)
        camera_streams[indices.pop()] = dict(camera=camera, exposure_ns=observed[0]["exposure_ns"])
    assert set(camera_streams) == {2, 3}, camera_streams
    m.save(scratch / "source-camera-streams.json", camera_streams)

    def source_publications():
        published = [dict(row, **camera_streams[row["stream"]]) for row in
                     events("hil-array-trace.tsv", source["hil"]["pid"])
                     if row["event"] == "native-queued" and row["stream"] in camera_streams]
        return sorted(published, key=lambda row: row["observed_ns"])

    m.cameras = source_publications


def first_correction(directory, branch, close):
    rows = m.read_capture(directory)
    cameras = m.cameras()
    for row in rows:
        if (row["name"] != branch + "-physical-offset" or
            row["max_abs"] == 0 or row["observed_ns"] < close["sent_ns"]):
            continue
        camera = m.same_camera(row, branch, cameras)
        modal = m.modal_match(row, branch, rows)
        if camera is None or modal is None:
            return None
        if branch == "scc":
            statuses = [result for result in rows if result["name"] == "scc-pair-status"
                        and m.same_camera(result, branch, [camera])]
            if not statuses:
                return None
            assert len(statuses) == 1 and statuses[0]["payload"] == [1], statuses
        assert camera["observed_ns"] > close["sent_ns"], (camera, close)
        return row, modal, camera
    return None


def evidence(directory, source, graphs, receipt):
    tap_pids = {int(owner["client_pid"]) for name, owner in source["native"].items()
                if name.startswith("independent-cal2-observe-")}
    assert len(tap_pids) == 1, tap_pids
    tap = events("tap-array-trace.tsv", tap_pids.pop())
    seen_by_tap = {identity(row): row for row in tap if row["event"] == "native-received"
                   and row["stream"] in (2, 3)}
    tap_accepted = {identity(row): row for row in tap if row["event"] == "receive-accepted"
                    and row["stream"] in (2, 3)}
    read_by_tap = {identity(row): row for row in tap_receipts()}
    running = receipt.get("running", {}).get("started", {})
    started = running.get("sent_ns")
    native_ready = receipt["native_ready"]["ready"]["received_ns"]
    stopped = receipt["stop"]
    cameras = m.cameras()
    result = {}
    oracle = m.load(directory / "oracle-input.json") if (directory / "oracle-input.json").exists() else {}
    for branch in m.branches:
        camera = "cal2-" + branch
        pid = graphs[camera]["unit_identity"]["pid"]
        ingress = {identity(row): row for row in events("graph-ingress", pid)
                   if row["event"] == "graph-ingress" and row["sequence"]}
        def boundaries(publication):
            key = identity(publication)
            return dict(publication=publication, tap_callback=seen_by_tap.get(key),
                        tap_accepted=tap_accepted.get(key), tap_drained=read_by_tap.get(key),
                        graph_ingress=ingress.get(key))
        observed = [boundaries(row) for row in cameras if row["camera"] == camera and
                    receipt["request_ns"] <= row["observed_ns"]]
        held = [row for row in observed if native_ready <= row["publication"]["observed_ns"] <
                (started or stopped["request_ns"])]
        off = [row for row in observed if row["publication"]["observed_ns"] > stopped["completed_ns"]]
        assert all(row["graph_ingress"] is None for row in off), off
        open_sample = receipt.get("fresh_open_priming", {}).get(branch)
        entry = dict(held=held, after_stop=off, publications=observed,
                     missing_tap_drains=[row["publication"]["sequence"] for row in observed
                                         if row["tap_drained"] is None])
        if open_sample is not None:
            first = boundaries(open_sample["camera"])
            assert first["graph_ingress"], first
            if receipt.get("both_cameras_held"):
                assert held, (camera, receipt["mode"])
            entry.update(open_sample=first, timings_s=dict(
                request_to_ready=m.seconds(receipt["ready_ns"], receipt["request_ns"]),
                ready_to_native_ready=m.seconds(native_ready, receipt["ready_ns"]),
                ready_to_start_request=m.seconds(started, receipt["ready_ns"]),
                start_request_to_ack=m.seconds(running["received_ns"], started),
                start_ack_to_first_usable=m.seconds(open_sample["residual"]["observed_ns"], running["received_ns"]),
            ))
            if branch in oracle:
                close = oracle[branch]["close"]
                corrected = boundaries(oracle[branch]["camera"])
                assert corrected["graph_ingress"], corrected
                entry["closed_sample"] = corrected
                entry["timings_s"].update(
                    close_request_to_ack=m.seconds(close["received_ns"], close["sent_ns"]),
                    close_request_to_first_corrected=m.seconds(oracle[branch]["physical"]["observed_ns"], close["sent_ns"]),
                    close_ack_to_first_corrected=m.seconds(oracle[branch]["physical"]["observed_ns"], close["received_ns"]),
                )
        result[camera] = entry
    m.save(directory / "detector-paths.json", result)


def check_publication_progress():
    result = {}
    source = m.load(stage / "persistent.json")
    raw = events("hil-array-trace.tsv", source["hil"]["pid"])
    for branch in m.branches:
        camera = "cal2-" + branch
        rows = [row for row in m.cameras() if row["camera"] == camera]
        missing = []
        model_gaps = []
        for left, right in zip(rows, rows[1:]):
            distance = right["sequence"] - left["sequence"]
            assert (right["domain"], right["generation"]) == (left["domain"], left["generation"])
            model_step = right["model_ns"] - left["model_ns"]
            assert distance > 0 and model_step > 0
            if model_step != distance * left["exposure_ns"]:
                model_gaps.append(dict(before=left["sequence"], after=right["sequence"], model_step_ns=model_step))
            missing.extend(range(left["sequence"] + 1, right["sequence"]))
        stream = rows[0]["stream"]
        delivered = {identity(row) for row in rows}
        overwritten = [row["sequence"] for row in raw if row["event"] == "output-overwritten" and
                       row["stream"] == stream and identity(row) not in delivered]
        result[camera] = dict(count=len(rows), first=rows[0], last=rows[-1],
                              missing_publications=sorted(set(missing + overwritten)),
                              variable_model_steps=model_gaps)
    m.save(scratch / "source-publication-continuity.json", result)
    assert all(not item["missing_publications"] for item in result.values()), result


def installed_templates():
    direct = (app / "systemd/pipewireao-session@.service").read_text()
    prior = (stage / "previous-template.service").read_text()
    old_directives = [
        line.replace("/var/tmp/rtc-independent-owners.4YQJfN8f/candidate-4-app", str(app))
        for line in prior.splitlines()
        if line.startswith(("ExecStartPre=", "EnvironmentFile=", "ExecStart="))
    ]
    assert len(old_directives) == 3
    assert "ExecStartPre=" not in direct and "EnvironmentFile=" not in direct, direct
    assert len(re.findall(r"^ExecStart=", direct, re.M)) == 1
    old_directives.append("UnsetEnvironment=PIPEWIREAORTC_ACTIVATION_SHA256")
    alternate = re.sub(r"^ExecStart=.*$", lambda _: "\n".join(old_directives), direct, flags=re.M)
    assert alternate != direct
    for mode, template in {"legacy": alternate, "direct": direct}.items():
        path = scratch / (mode + ".service")
        path.write_text(template)
        yield mode, path


def install_units(files, claimed):
    m.unit_dir.mkdir(parents=True, exist_ok=True)
    retained.install_runtime_units(files, claimed)


def set_mode(mode, templates):
    prior = m.status(m.unit)
    assert prior["MainPID"] == "0" and prior["ActiveState"] in ("inactive", "failed"), prior
    new = m.unit_file.with_suffix(".replacement")
    assert not os.path.lexists(new)
    new.symlink_to(templates[mode])
    new.replace(m.unit_file)
    m.system("daemon-reload")
    if prior["ActiveState"] == "failed":
        m.system("reset-failed", m.unit)


def thread_placement(pid):
    threads = {}
    for task in sorted(Path(f"/proc/{pid}/task").iterdir()):
        try:
            fields = dict(line.split(":", 1) for line in (task / "status").read_text().splitlines())
        except FileNotFoundError:
            continue
        threads[task.name] = {
            "name": fields["Name"].strip(),
            "cpus": fields["Cpus_allowed_list"].strip(),
        }
    return threads


def start(mode, name, source, graphs, units, edges):
    directory = scratch / name
    launch_file, ledger, receipt, known_owners, known_edges = retained.start(directory, source, graphs, units, edges)
    assert known_owners == graphs and known_edges == edges
    props_name = ("MainPID,ExecMainPID,InvocationID,ControlGroup,FragmentPath,DropInPaths,Type,NotifyAccess,"
                  "ExecStartPre,ExecStart,ExecStop,ExecStopPost,EnvironmentFiles,CPUAffinity,"
                  "InactiveExitTimestampMonotonic,ExecMainStartTimestampMonotonic,ActiveEnterTimestampMonotonic")
    status = m.system("show", m.unit, "-p", props_name, text=True, capture_output=True).stdout
    properties = dict(line.split("=", 1) for line in status.splitlines() if "=" in line)
    pid = receipt["rtc"]["pid"]
    assert int(properties["ExecMainPID"]) == int(properties["MainPID"]) == pid
    assert properties["InvocationID"] == ledger["invocation"] == receipt["rtc"]["invocation"]
    assert properties["Type"] == "notify" and properties["NotifyAccess"] == "main"
    assert bool(properties.get("ExecStartPre")) == (mode == "legacy"), properties
    assert bool(properties.get("EnvironmentFiles")) == (mode == "legacy"), properties
    assert properties["CPUAffinity"] == "3", properties
    assert all(0 < int(properties[key]) <= int(properties["ActiveEnterTimestampMonotonic"])
               for key in ("InactiveExitTimestampMonotonic", "ExecMainStartTimestampMonotonic"))
    proc = Path(f"/proc/{pid}")
    cgroup = (proc / "cgroup").read_text().strip().split(":", 2)[2]
    assert cgroup == properties["ControlGroup"]
    actual = list(filter(None, (proc / "cmdline").read_text().split("\0")))
    (directory / "main-exe.txt").write_text(str((proc / "exe").readlink()) + "\n")
    (directory / "main-status.txt").write_text((proc / "status").read_text())
    try:
        mappings = [line for line in (proc / "maps").read_text().splitlines()
                    if "PipeWireAORTC/" in line or "libpipewire-ao-0.3" in line]
        (directory / "main-code-maps.txt").write_text("\n".join(mappings) + "\n")
    except PermissionError as error:
        (directory / "main-code-maps.txt").write_text(str(error) + "\n")
    (directory / "systemd.txt").write_text(status)
    role_pids = {"rtc": pid, "core": source["core"]["pid"], "simulator": source["hil"]["pid"]}
    role_pids.update({role: graph["unit_identity"]["pid"] for role, graph in known_owners.items()})
    m.save(directory / "thread-placement.json",
           {role: {"pid": owner_pid, "threads": thread_placement(owner_pid)}
            for role, owner_pid in role_pids.items()})
    receipt.update(mode=mode, effective_argv=actual, unit_properties=properties)
    m.save(directory / "lifecycle.json", receipt)
    return directory, launch_file, ledger, receipt


def timed_service_start(directory):
    def cpu_times():
        return {fields[0]: list(map(int, fields[1:])) for line in Path("/proc/stat").read_text().splitlines()
                if (fields := line.split()) and re.fullmatch(r"cpu[0-9]+", fields[0])}
    cpu_before = cpu_times()
    sent, acknowledged = start_service(directory)
    cpu_after = cpu_times()
    m.save(directory / "systemd-ready.json", dict(request_ns=sent, ready_ns=acknowledged,
          request_to_systemd_ready_s=m.seconds(acknowledged, sent), service=m.status(m.unit),
          cpu_times_before=cpu_before, cpu_times_after=cpu_after))
    return sent, acknowledged


def input_receipts(directory, source, units, templates):
    filenames = ("Manifest.toml", "Project.toml", "deployment.conf", "rtc/session.conf.in",
                 "rtc/llowfs-graph.conf", "rtc/scc-graph.conf", "rtc/llowfs-parameters.conf",
                 "rtc/scc-parameters.conf", "systemd/graph-owner-assets.json",
                 "bin/pipewireao-rtc-session", "rtc/bin/pipewireao-rtc")
    files = [app / path for path in filenames]
    files.extend((*units.values(), *templates.values()))
    hil_app = Path("/var/tmp/cal2-independent.UcNIRN/final-install")
    files.extend(hil_app / path for path in ("Manifest.toml", "Project.toml", "simulation.conf"))
    digests = {}
    for path in files:
        with path.open("rb") as file:
            digests[str(path)] = hashlib.file_digest(file, "sha256").hexdigest()
    m.save(directory / "frozen-inputs.json", dict(source=source, files=digests,
          rtc=m.load(stage / (retained.variant + "-source.json")),
          boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip()))
    with (directory / "host-cpu-topology.csv").open("w") as output:
        m.run("lscpu", "-p=CPU,CORE,SOCKET,NODE", stdout=output)


def run(plan, *, instrumented=True, both_cameras_after_kill=False):
    scratch.mkdir()
    source = m.load(stage / "persistent.json")
    camera_map(source)
    files = retained.fixture_inputs()
    units = {role: path.name for role, path in files.items()}
    claimed = []
    try:
        install_units(files, claimed)
        templates = dict(installed_templates())
        input_receipts(scratch, source, files, templates)
        known = Path("/var/tmp/rtc-owned-admission-evidence/cal2/trial-391742671609147-final")
        known_links = retained.native_links(m.load(known / "ready-native.json"))
        edges = {key: value["format"] for key, value in known_links.items()}
        graphs = retained.prestart_graphs(units, source)
        if instrumented:
            for graph in graphs.values():
                pid = graph["unit_identity"]["pid"]
                events("graph-ingress", pid)
        print("Both persistent graph services prestarted", flush=True)
        for name, mode, stop, optical, running in plan:
            set_mode(mode, templates)
            print(f"{name}: starting the {mode} lane", flush=True)
            directory, launch_file, ledger, receipt = start(mode, name, source, graphs, units, edges)
            if running:
                if optical:
                    native_ready = receipt["native_ready"]["ready"]["received_ns"]
                    m.wait(lambda: m.cameras_after(native_ready), 205, "both camera sources advance while Held")
                started = retained.start_open(directory, receipt)
                if optical:
                    retained.optical_open(directory, receipt, started)
                    retained.optical_close(directory, receipt)
            if stop == "kill":
                (directory / "watch-old-authority").touch()
            elif running:
                index = 2 + len(retained.optical_branches) if optical else 2
                receipt["native_stop"] = m.acknowledge(directory, index, "stop")
                (directory / "control-stop").touch()
            if stop == "graceful":
                (directory / "workers-stopped").touch()
            retained.session_gap(directory, launch_file, ledger, receipt, source, graphs, stop)
            if optical or (both_cameras_after_kill and stop == "kill"):
                after = m.wait(lambda: m.cameras_after(receipt["stop"]["completed_ns"]), 205,
                               "both camera sources advance while the RTC is absent")
                receipt["stop"]["publications_while_off"] = after
                m.save(directory / "lifecycle.json", receipt)
            if instrumented:
                evidence(directory, source, graphs, receipt)
        check_publication_progress()
        retained.full_shutdown(source, units, wait_for_camera=False)
        m.save(scratch / "passed.json", {"plan": plan})
    finally:
        for child, _ in m.children:
            if child.poll() is None:
                child.terminate()
                child.wait(timeout=20)
        m.children.clear()
        try:
            retained.remove_runtime_units(claimed)
        finally:
            retained.capture_journal(claimed)
            if m.rtc_runtime.is_dir():
                shutil.rmtree(m.rtc_runtime)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--post-fix", action="store_true")
    parser.add_argument("--event-driven", action="store_true")
    args = parser.parse_args()
    m.start_service = timed_service_start
    m.first_after_adoption = first_correction
    # ABBA order brackets possible startup drift. Each lane is also allowed one unmeasured priming startup.
    warmup = [
        ("warmup-legacy", "legacy", "graceful", False, False),
        ("warmup-direct", "direct", "graceful", False, False),
    ]
    trials = [
        ("01-legacy", "legacy", "graceful", False, True),
        ("02-direct", "direct", "kill", False, True),
        ("03-direct", "direct", "graceful", True, True),
        ("04-legacy", "legacy", "kill", True, True),
        ("recovery-direct", "direct", "graceful", False, True),
    ]
    post_fix = [
        ("01-legacy-optical", "legacy", "kill", True, True),
        ("02-direct-optical", "direct", "kill", True, True),
        ("recovery-direct", "direct", "graceful", False, True),
    ]
    event_driven = [
        ("01-direct-forced", "direct", "kill", False, True),
        ("02-direct-optical", "direct", "graceful", True, True),
        ("recovery-direct", "direct", "graceful", False, True),
    ]
    plan = warmup if args.smoke else event_driven if args.event_driven else post_fix if args.post_fix else warmup + trials
    run(plan, instrumented=not args.smoke, both_cameras_after_kill=args.event_driven)
