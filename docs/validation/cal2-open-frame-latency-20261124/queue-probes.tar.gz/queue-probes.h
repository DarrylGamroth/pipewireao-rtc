/* Diagnostic acquisition timestamps, private core only. One mapping per output queue. */
#include <fcntl.h>
#include <sys/mman.h>
#define TRACE_ROWS 65536
struct trace_key { uint8_t domain[16]; uint64_t generation, sequence; int64_t pts; uint64_t header_sequence; };
struct trace_row { uint64_t event, ns; struct trace_key key; };
_Static_assert(sizeof(struct trace_row)==64,"trace record layout");

static uint64_t trace_now(void)
{
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (uint64_t)ts.tv_sec * SPA_NSEC_PER_SEC + ts.tv_nsec;
}
static struct trace_row *open_queue_trace(const char *name)
{
	const char *directory = getenv("CAL2_QUEUE_TRACE_DIR");
	if (!directory || !name || (strcmp(name,"cal2-llowfs-modal-residual-queue-input") &&
			strcmp(name,"cal2-llowfs-physical-offset-queue-input"))) return NULL;
	char path[4096];
	if (snprintf(path,sizeof(path),"%s/%s.%ld.bin",directory,name,(long)getpid()) >= (int)sizeof(path)) return NULL;
	int fd=open(path,O_CREAT|O_EXCL|O_CLOEXEC|O_RDWR,0600);
	if (fd<0) return NULL;
	size_t bytes=TRACE_ROWS*sizeof(struct trace_row);
	struct trace_row *rows=MAP_FAILED;
	if (!ftruncate(fd,bytes))
		rows=mmap(NULL,bytes,PROT_WRITE|PROT_READ,MAP_SHARED,fd,0);
	close(fd);
	if (rows==MAP_FAILED) return NULL;
	memset(rows,0,bytes);
	return rows;
}
static bool trace_identity(struct pw_buffer *buffer,struct trace_key *key)
{
	if (!buffer || !buffer->buffer) return false;
	const struct spa_meta_acquisition_identity *id=spa_buffer_find_meta_data(
			buffer->buffer,SPA_META_AcquisitionIdentity,sizeof(*id));
	const struct spa_meta_header *hdr=spa_buffer_find_meta_data(
			buffer->buffer,SPA_META_Header,sizeof(*hdr));
	if (!id || !hdr) return false;
	memcpy(key->domain,id->domain,sizeof(key->domain));
	key->sequence=id->sequence; key->generation=id->generation;
	key->pts=hdr->pts; key->header_sequence=hdr->seq;
	return true;
}
