from pathlib import Path
p=Path('queue-src/src/modules/queue/module-queue.c')
s=p.read_text()
def add(before,after):
 global s
 assert s.count(before)==1,before
 s=s.replace(before,after)
add('struct impl {','''#include "queue-probes.h"
struct impl {
	struct trace_row *trace_rows;
	_Atomic uint32_t trace_count;
	uint64_t trace_previous_cycle;
''')
add('static void impl_free(struct impl *impl);','''static void queue_stamp(struct impl *impl,unsigned event,uint64_t ns,const struct trace_key *key)
{
	uint32_t n=atomic_fetch_add_explicit(&impl->trace_count,1,memory_order_relaxed);
	if (n<TRACE_ROWS) impl->trace_rows[n]=(struct trace_row){.event=event,.ns=ns,.key=*key};
}
static void impl_free(struct impl *impl);''')
add('pw_properties_setf(impl->capture_props, PWAO_QUEUE_ID_PROPERTY,','''impl->trace_rows=open_queue_trace(pw_properties_get(impl->capture_props,PW_KEY_NODE_NAME));
	atomic_init(&impl->trace_count,0);
	pw_properties_setf(impl->capture_props, PWAO_QUEUE_ID_PROPERTY,''')
add('free(impl->format);\n\tpw_properties_free(impl->capture_props);','''if (impl->trace_rows) munmap(impl->trace_rows, TRACE_ROWS*sizeof(struct trace_row));
	free(impl->format);
	pw_properties_free(impl->capture_props);''')
add('slot = input_slot_from_buffer(buffer);\n\t\tif (slot == NULL)', '''struct trace_key capture_key;
		bool tracing=impl->trace_rows && trace_identity(buffer,&capture_key);
		if (tracing) queue_stamp(impl,1,trace_now(),&capture_key);
		slot = input_slot_from_buffer(buffer);
		if (slot == NULL)''')
add('result = pwao_queue_ring_admit(&impl->pending, token,','''if (tracing) queue_stamp(impl,2,trace_now(),&capture_key);
		result = pwao_queue_ring_admit(&impl->pending, token,''')
add('static void playback_process(void *data)\n{\n\tstruct impl *impl = data;', '''static void playback_process(void *data)
{
	struct impl *impl = data;
	uint64_t previous_cycle=0,cycle=0;
	if (impl->trace_rows) {
		previous_cycle=impl->trace_previous_cycle;
		impl->trace_previous_cycle=cycle=trace_now();
	}''')
add('result = transfer_buffer(impl, input_index, output_slot);','''struct trace_key playback_key;
	bool tracing=impl->trace_rows && trace_identity(impl->inputs[input_index].capture,&playback_key);
	if (tracing) {
		queue_stamp(impl,3,previous_cycle,&playback_key);
		queue_stamp(impl,4,cycle,&playback_key);
		queue_stamp(impl,5,trace_now(),&playback_key);
	}
	result = transfer_buffer(impl, input_index, output_slot);
	if (tracing) queue_stamp(impl,6,trace_now(),&playback_key);''')
add('result = pw_stream_queue_buffer(impl->playback, output_slot->playback);','''if (tracing) queue_stamp(impl,7,trace_now(),&playback_key);
	result = pw_stream_queue_buffer(impl->playback, output_slot->playback);
	if (tracing && result >= 0) queue_stamp(impl,8,trace_now(),&playback_key);''')
p.write_text(s)
