#!/usr/bin/env bash
# Operate the retained private CUDA CAL2 fixture created in this directory.
set -eu
cal2_ops_stage=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$cal2_ops_stage/session-env.sh"
cal2_ops_instance="c2l-${CAL2_VALIDATION_TAG,,}-measure"
cal2_ops_rtc="pipewireao-session@${cal2_ops_instance}.service"
cal2_ops_llowfs="pipewireao-graph-cal2-${CAL2_VALIDATION_TAG,,}-cal2-llowfs.service"
cal2_ops_scc="pipewireao-graph-cal2-${CAL2_VALIDATION_TAG,,}-cal2-scc.service"
cal2_ops_feeder="c2l-$CAL2_VALIDATION_TAG-feeder-supervisor.service"
cal2_ops_retention="c2l-$CAL2_VALIDATION_TAG-log-retention.service"
case "${1:-status}" in
    status)
        systemctl --user show -p Id,ActiveState,MainPID,InvocationID \
            "$cal2_ops_rtc" "$cal2_ops_llowfs" "$cal2_ops_scc" \
            "$PIPEWIREAORTC_CORE_UNIT" "$PIPEWIREAORTC_SOURCE_UNIT" \
            "$cal2_ops_feeder" "$cal2_ops_retention"
        if test -f "$cal2_ops_stage/live-continuity.json"; then
            cat "$cal2_ops_stage/live-continuity.json"
        fi
        ;;
    attach)
        systemctl --user start "$cal2_ops_rtc"
        ;;
    start)
        cal2_ops_runtime="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}/pipewireao-session-$cal2_ops_instance"
        taskset -c 13 "$CAL2_VALIDATION_JULIA" --startup-file=no --threads=2,1 \
            --project="$cal2_ops_stage/candidate-app" -e '
                import PipeWireAORTC
                runtime = PipeWireAORTC.SessionRuntime
                println(runtime.running!(runtime.attach(only(ARGS)))["phase"])
            ' "$cal2_ops_runtime"
        ;;
    detach)
        systemctl --user stop "$cal2_ops_rtc"
        ;;
    shutdown)
        systemctl --user stop "$cal2_ops_rtc" "$cal2_ops_llowfs" "$cal2_ops_scc"
        touch "$cal2_ops_stage/finish"
        deadline=$((SECONDS + 180))
        while systemctl --user is-active --quiet "$cal2_ops_feeder"; do
            if ((SECONDS >= deadline)); then
                printf 'Timed out waiting for the private CAL2 source and core to exit.\n' >&2
                exit 1
            fi
            sleep 1
        done
        systemctl --user stop "$cal2_ops_retention"
        ;;
    *)
        printf 'Use %s {status|attach|start|detach|shutdown}\n' "$0" >&2
        exit 2
        ;;
esac
