"""Observe the installed CAL2 lifecycle against one already-publishing source."""
import argparse
import os
import shutil
import struct
import subprocess
import time
from pathlib import Path

import measure as m

stage = m.stage
variant = os.environ.get("CAL2_VALIDATION_VARIANT", "candidate")
app = stage / (variant + "-app")
stock = Path("/var/tmp/rtc-ndarray-integration.beRGH1/cal2/candidate-combined-gated-install")
scratch = stage / ("replacement-" + os.environ.get("CAL2_VALIDATION_ATTEMPT", "1"))
roles = ("cal2-llowfs", "cal2-scc")
optical_branches = m.branches
endpoint_prefix = "pipewireao.rtc."
environment = tuple(m.keep)
previous_sessions = []
previous_controls = []
previous_links = set()


def by_name(objects, name):
    return [obj for obj in objects if obj["type"].endswith(":Node")
            and m.properties(obj).get("node.name") == name]


def node_identity(objects, obj):
    props = m.properties(obj)
    client = next(candidate for candidate in objects if candidate["id"] == int(props["client.id"]))
    return dict(id=obj["id"], serial=props["object.serial"],
                name=props["node.name"], client_serial=m.properties(client)["object.serial"],
                pid=int(m.properties(client)["pipewire.sec.pid"]),
                instance=props.get("pipewireao.rtc-control.instance"),
                profile=props.get("pipewireao.rtc-control.profile"))


def native_links(objects):
    by_id = {obj["id"]: obj for obj in objects}
    records = {}
    for node in objects:
        obj = m.properties(node)
        path = str(obj.get("object.path", ""))
        if node["type"].endswith(":Link") and path.startswith("pipewireao/session/"):
            output_node = m.properties(by_id[int(obj["link.output.node"])])
            input_node = m.properties(by_id[int(obj["link.input.node"])])
            output_port = m.properties(by_id[int(obj["link.output.port"])])
            input_port = m.properties(by_id[int(obj["link.input.port"])])
            assert obj["object.linger"] is False
            assert output_port["port.direction"] == "out"
            assert input_port["port.direction"] == "in"
            actual = node["info"]["format"]
            assert actual["mediaSubtype"] == "ndarray"
            edge = (output_node["node.name"], output_port["port.name"],
                    input_node["node.name"], input_port["port.name"])
            assert edge not in records
            records[edge] = dict(serial=obj["object.serial"], path=path,
                state=node["info"]["state"], format=actual, output_port_serial=output_port["object.serial"],
                input_port_serial=input_port["object.serial"])
    return records


def latest_by_camera():
    current = {}
    for observation in m.cameras():
        current[observation["camera"]] = observation
    return current


def advancing_source(after_ns):
    rows = m.cameras()
    fresh = {role: next((row for row in rows if row["camera"] == role and
                         row["observed_ns"] > after_ns), None) for role in roles}
    return fresh if all(fresh.values()) else None


def fixture(source, objects):
    assert m.owner(m.core_name) == source["core"]
    assert m.owner(m.hil_name) == source["hil"]
    assert m.socket.stat().st_ino == source["inode"]
    assert m.permanent(objects) == source["native"]
    assert m.system("show", m.hil_name, "-p", "FreezerState", "--value",
                    capture_output=True, text=True).stdout.strip() == "running"


def graph_baseline(objects, graph_units, owners):
    snapshot = {}
    bootstraps = {}
    for role, unit in graph_units.items():
        record = owners[role]
        unit_id = m.owner(unit)
        assert int(record["pid"]) == unit_id["pid"] and record["invocation"] == unit_id["invocation"]
        assert int(record["start-ticks"]) == unit_id["ticks"] and record["unit"] == unit
        selected = by_name(objects, record["bootstrap-node"])
        assert len(selected) == 1, (role, selected)
        bootstrap = node_identity(objects, selected[0])
        assert bootstrap["pid"] == unit_id["pid"]
        assert int(bootstrap["instance"]) == int(record["bootstrap-instance"])
        snapshot[role] = dict(unit=unit, unit_identity=unit_id,
                              bootstrap_name=bootstrap["name"], incarnation=bootstrap["instance"])
        bootstraps[role] = bootstrap
    return snapshot, bootstraps


def graph_still_live(objects, graphs):
    for graph in graphs.values():
        assert m.owner(graph["unit"]) == graph["unit_identity"]
        candidates = by_name(objects, graph["bootstrap_name"])
        if not candidates:
            return False
        assert len(candidates) == 1
        observation = node_identity(objects, candidates[0])
        assert observation["pid"] == graph["unit_identity"]["pid"]
        assert observation["instance"] == graph["incarnation"]
    return True


def native_identity(objects, ledger):
    authority = {}
    for suffix, instance_key in (("session", "session_control_instance"),
                                 ("controller", "session_controller_instance")):
        name = endpoint_prefix + suffix + "." + ledger["name"]
        matches = by_name(objects, name)
        assert len(matches) == 1, (name, matches)
        endpoint = node_identity(objects, matches[0])
        assert endpoint["pid"] == ledger["session_pid"]
        assert int(endpoint["instance"]) == int(ledger[instance_key])
        authority[suffix] = endpoint
    graphs = {}
    for role in roles:
        selected = by_name(objects, role+"-controller")
        assert len(selected) == 1, (role, selected)
        graph = node_identity(objects, selected[0])
        assert graph["pid"] == ledger["owners"][role]["pid"]
        props = m.properties(selected[0])
        assert props["pipewireao.run-control"] and props["pipewireao.reset-control"]
        graphs[role] = graph
    return authority, graphs


def capture_failed_start(directory, graph_units):
    failures = {}
    for role, unit in {"rtc": m.unit, **graph_units}.items():
        state = m.status(unit)
        detail = {"unit": unit, "systemd": state}
        pid = int(state["MainPID"])
        if pid:
            try:
                detail["maps"] = [entry for entry in Path(f"/proc/{pid}/maps").read_text().splitlines()
                                  if "libpipewire-ao-0.3.so" in entry]
                detail["stat"] = Path(f"/proc/{pid}/stat").read_text()
            except FileNotFoundError:
                pass
        failures[role] = detail
    m.save(directory / "failed-start-services.json", failures)
    history = directory / "failure-ledgers"
    history.mkdir()
    for ledger in m.rtc_runtime.glob("*/launch.json"):
        shutil.copyfile(ledger, history / (ledger.parent.name + ".json"))
    m.native_dump(directory / "failed-start-native.json")


def start(directory, source, graphs, graph_units, expected_edges):
    directory.mkdir()
    before = m.native_dump(directory / "before-native.json")
    fixture(source, before)
    assert not native_links(before)
    if graphs:
        graph_still_live(before, graphs)
    else:
        assert all(m.status(unit)["MainPID"] == "0" for unit in graph_units.values())
    receipt = {"camera_before_start": latest_by_camera(),
               "graph_owners_prestarted": graphs is not None}
    observer = m.launch(stock, "12", "live-observe.jl", directory / "observer.log",
             stock, m.socket, directory, stage / "observer-reference")
    m.wait(lambda: ready_file(directory / "observer-ready"), 140, "prearmed output observer")
    stat = Path(f"/proc/{observer.pid}/stat").read_text().rsplit(")", 1)[1].split()
    receipt["observer"] = dict(pid=observer.pid, start_ticks=int(stat[19]),
                               ready_witnessed_ns=time.monotonic_ns())
    try:
        request_ns, ready_ns = m.start_service(directory)
    except subprocess.CalledProcessError:
        capture_failed_start(directory, graph_units)
        raise
    rtc = m.owner(m.unit)
    runtime = m.rtc_runtime / rtc["invocation"]
    launch_file = runtime / "launch.json"
    ledger = m.load(launch_file)
    shutil.copyfile(launch_file, directory / "ready-ledger.json")
    shutil.copyfile(ledger["config"], directory / "rtc.conf")
    complete = m.native_dump(directory / "ready-native.json")
    fixture(source, complete)
    assert ledger["session_pid"] == rtc["pid"]
    assert ledger["owners"]["core"]["external"] and ledger["owners"]["core"]["pid"] == source["core"]["pid"]
    assert ledger["owners"]["simulator"]["external"] and ledger["owners"]["simulator"]["pid"] == source["hil"]["pid"]
    per_owner, bootstrap_endpoints = graph_baseline(complete, graph_units, ledger["owners"])
    assert graphs is None or per_owner == graphs, (per_owner, graphs)
    authority, graph_endpoints = native_identity(complete, ledger)
    edges = native_links(complete)
    assert len(edges) == 10 and all(edge["state"] in ("paused", "active") for edge in edges.values())
    assert expected_edges is None or {key: value["format"] for key, value in edges.items()} == expected_edges
    link_serials = {link["serial"] for link in edges.values()}
    assert link_serials.isdisjoint(previous_links)
    assert all(endpoint["serial"] != old[kind]["serial"] and endpoint["instance"] != old[kind]["instance"]
               for old in previous_sessions for kind, endpoint in authority.items())
    assert all(graph_endpoints[role]["serial"] != old[role]["serial"] for old in previous_controls for role in roles)
    previous_sessions.append(authority)
    previous_controls.append(graph_endpoints)
    previous_links.update(link_serials)
    for role, record in per_owner.items():
        pid = record["unit_identity"]["pid"]
        command_line = Path(f"/proc/{pid}/cmdline").read_bytes().rstrip(b"\0").decode().split("\0")
        image_maps = [line for line in Path(f"/proc/{pid}/maps").read_text().splitlines()
                      if "ExportedGraphWarmup" in line or "libpipewire-ao-0.3" in line]
        m.save(directory / f"{role}-process.json", dict(command_line=command_line, mapped_dependencies=image_maps))
    receipt.update(rtc=rtc, request_ns=request_ns, ready_ns=ready_ns,
                   request_to_systemd_ready_s=m.seconds(ready_ns, request_ns),
                   graph_owners=per_owner, bootstrap_endpoints=bootstrap_endpoints,
                   session_authority=authority, graph_endpoints=graph_endpoints,
                   links=[dict(out_node=key[0], out_port=key[1], in_node=key[2], in_port=key[3], **item)
                          for key, item in edges.items()])
    m.save(directory / "lifecycle.json", receipt)
    print(f"{directory.name}: systemd Ready in {receipt['request_to_systemd_ready_s']:.3f} s", flush=True)
    control = m.launch(stock, "13", "live-correction-control.jl", directory / "control.log",
             launch_file, directory, m.socket, "held-only")
    receipt["control_pid"] = control.pid
    m.wait(lambda: ready_file(directory / "control-online.json"), 140, "native Status Ready")
    native = m.load(directory / "control-online.json")
    assert native["ready"]["reply"]["state"] == "Ready"
    assert native["ready"]["reply"]["result"]["owned_links"] == len(edges)
    assert native["ready"]["reply"]["result"]["running"] is False
    assert native["pid"] == rtc["pid"] and native["uuid"] == ledger["session_uuid"]
    receipt["native_ready"] = native
    m.save(directory / "lifecycle.json", receipt)
    return launch_file, ledger, receipt, per_owner, {key: value["format"] for key, value in edges.items()}


def ready_file(path):
    m.check_children()
    return path.is_file()


def start_open(directory, receipt, *, wait_for_camera=True):
    # Witness a new camera publication while both graph attachments are held.
    native_ready_ns = receipt["native_ready"]["ready"]["received_ns"]
    def held_camera():
        m.check_children()
        row = latest_by_camera().get("cal2-llowfs")
        if row is not None and row["observed_ns"] >= native_ready_ns:
            return row
        return None
    camera = m.wait(held_camera, 140, "fresh LLOWFS camera under native Ready/Hold") if wait_for_camera else held_camera()
    held_rows = m.read_capture(directory)
    cameras = m.cameras()
    for output in held_rows:
        branch = output["name"].split("-")[0]
        if matched := m.same_camera(output, branch, cameras):
            assert matched["observed_ns"] < receipt["request_ns"], (output, matched)
    result = m.acknowledge(directory, 1, "start")
    assert result["started"]["reply"]["state"] == "Running"
    receipt.update(held_camera=camera, running=result)
    m.save(directory / "lifecycle.json", receipt)
    return result["started"]


def optical_open(directory, receipt, started):
    def usable():
        matched = {branch: m.output_matches(directory, branch, started["sent_ns"], False) for branch in optical_branches}
        if all(matched.values()):
            rows = m.read_capture(directory)
            qualified = {}
            for branch, (offset, residual, camera) in matched.items():
                assert camera["observed_ns"] > started["sent_ns"], camera
                assert residual["max_abs"] > 0 and offset["max_abs"] == 0
                assert all(r["max_abs"] == 0 for r in rows if r["name"] == branch+"-physical-offset"
                         and r["observed_ns"] >= started["sent_ns"])
                pair = None
                if branch == "scc":
                    pair = next((r for r in rows if r["name"] == "scc-pair-status" and r["payload"] == [1]
                                 and m.same_camera(r, branch, [camera])), None)
                    if pair is None:
                        return None
                qualified[branch] = dict(offset=m.without_payload(offset), residual=m.without_payload(residual),
                                         camera=camera, pair=pair)
            return qualified
        return None
    receipt["fresh_open_priming"] = m.wait(usable, 650, "LLOWFS measurement and SCC completed pair with zero offsets")
    m.save(directory / "lifecycle.json", receipt)
    for branch, evidence in receipt["fresh_open_priming"].items():
        print(f"{directory.name}: fresh open {branch} acquisition {evidence['camera']['sequence']}", flush=True)


def optical_close(directory, receipt):
    closes = {branch: m.acknowledge(directory, index, "close", f"cal2-{branch}-controller", seconds=505)["closed"]
              for index, branch in enumerate((branch for branch in ("scc", "llowfs")
                                                if branch in optical_branches), 2)}
    corrections = {}
    for branch, close in closes.items():
        physical, modal, camera = m.wait(lambda: m.first_after_adoption(directory, branch, close), 440,
                                          branch + " first signed correction after explicit Close")
        previous = receipt["fresh_open_priming"][branch]["camera"]
        assert camera["sequence"] > previous["sequence"] and camera["observed_ns"] >= close["sent_ns"]
        corrections[branch] = dict(physical=physical, modal=modal, camera=camera, close=close)
    m.save(directory / "oracle-input.json", corrections)
    m.run("taskset", "-c", "15", m.julia, "--startup-file=no", "--project="+str(stock),
          stage / "numerical-oracle.jl", stock, directory, timeout=150, env=m.child_env)
    receipt["first_signed_correction"] = m.load(directory / "numerical-oracle.json")
    m.save(directory / "lifecycle.json", receipt)
    print(f"{directory.name}: signed first corrections verified for {', '.join(corrections)}", flush=True)


def stop_observers(directory):
    (directory / "workers-stopped").touch()
    (directory / "observer-stop").touch()
    (directory / "control-stop").touch()
    for child, log in m.children.copy():
        assert child.wait(timeout=70) == 0, log
        m.children.remove((child, log))


def session_gap(directory, launch_file, ledger, receipt, source, graphs, mode, *, observe_off_camera=True):
    stop_requested_ns = time.monotonic_ns()
    if mode == "graceful":
        m.system("stop", m.unit, timeout=320)
        stopped = m.load(launch_file)
        shutil.copyfile(launch_file, directory / "stopped-ledger.json")
        assert stopped["phase"] == "stopped" and stopped["cleanup_complete"]
        assert stopped["systemd_quit"] == {"attempted": True, "accepted": True}
        assert m.status(m.unit)["Result"] == "success"
    elif mode == "kill":
        pid = receipt["rtc"]["pid"]
        assert m.owner(m.unit) == receipt["rtc"]
        m.system("kill", "--kill-whom=main", "--signal=SIGKILL", m.unit)
        def finished_cleanup():
            current = m.status(m.unit)
            if current["ActiveState"] in ("failed", "inactive") and current["MainPID"] == "0":
                return current
            return None
        after = m.wait(finished_cleanup, 80, "systemd cleanup after RTC MainPID SIGKILL")
        assert after["Result"] in ("signal", "core-dump"), (pid, after)
        m.wait(lambda: (directory / "old-authority-withdrawn.json").is_file(), 25, "old native client rejected")
        (directory / "workers-stopped").touch()
    else:
        raise ValueError(mode)
    stop_completed_ns = time.monotonic_ns()
    assert not Path(ledger["discovery_locator"]).exists()
    def withdrawn():
        objects = m.native_dump(directory / "after-native.json")
        fixture(source, objects)
        if not graph_still_live(objects, graphs):
            return None
        old = [*receipt["session_authority"].values(), *receipt["graph_endpoints"].values(),
               *receipt["bootstrap_endpoints"].values()]
        for retired in old:
            if any(obj["type"].endswith(":Node") and m.properties(obj).get("object.serial") == retired["serial"]
                   for obj in objects):
                return None
        assert not native_links(objects)
        return objects
    m.wait(withdrawn, 35, "retired graph control and session endpoints")

    def next_camera():
        return next((row for row in m.cameras() if row["observed_ns"] > stop_completed_ns), None)
    advancing = m.wait(next_camera, 250, "an independent camera advancing while session absent") \
        if observe_off_camera else next_camera()
    cameras = [row for row in m.cameras() if row["observed_ns"] > stop_completed_ns]
    assert all(not m.same_camera(row, row["name"].split("-")[0], cameras)
               for row in m.read_capture(directory))
    receipt["stop"] = dict(mode=mode, request_ns=stop_requested_ns, completed_ns=stop_completed_ns,
                           systemd=m.status(m.unit), observed_while_off=advancing,
                           streams_seen_while_off=sorted({row["camera"] for row in cameras}))
    m.save(directory / "lifecycle.json", receipt)
    stop_observers(directory)
    text = f"{directory.name}: {mode} ended session; both controller processes unchanged"
    if advancing is not None:
        text += f"; {advancing['camera']} {advancing['sequence']} arrived during the gap"
    print(text, flush=True)


def replace_required_owner(source, graph_units, graphs, edges):
    directory = scratch / "replace-required-owner"
    launch_file, ledger, receipt, owners, _ = start(directory, source, graphs, graph_units, edges)
    assert owners == graphs
    start_open(directory, receipt, wait_for_camera=optical_branches == m.branches)
    role = "cal2-llowfs"
    unit = graph_units[role]
    m.save(directory / "command-2.json", {"operation": "observe_fault"})
    m.system("restart", unit, timeout=120)
    replacement = m.owner(unit)
    assert replacement["invocation"] != graphs[role]["unit_identity"]["invocation"]
    assert replacement["ticks"] != graphs[role]["unit_identity"]["ticks"]
    m.wait(lambda: ready_file(directory / "response-2.json"), 75, "native Fault on required owner replacement")
    fault = m.load(directory / "response-2.json")
    assert fault["observed"]["reply"]["state"] == "Fault"
    stop_observers(directory)
    m.system("stop", m.unit, timeout=320)
    after = m.native_dump(directory / "after-native.json")
    fixture(source, after)
    assert not native_links(after) and not Path(ledger["discovery_locator"]).exists()
    assert m.owner(unit) == replacement
    untouched = "cal2-scc"
    assert m.owner(graph_units[untouched]) == graphs[untouched]["unit_identity"]
    receipt["owner_replacement"] = dict(unit=unit, previous=graphs[role]["unit_identity"],
                                        replacement=replacement, fault=fault)
    m.save(directory / "lifecycle.json", receipt)
    print("Replacing one required graph owner under the same unit name revoked Running", flush=True)


def refused_changed_calibration(source, graph_units, *, verify_cleanup=False):
    directory = scratch / "refused-changed-calibration"
    directory.mkdir()
    target = (app / "generated/chopped-calibration-cred2-roi-f32/llowfs/artifacts/command-projection.fits")
    original = stock / target.relative_to(app)
    assert target.stat().st_ino != original.stat().st_ino and target.read_bytes() == original.read_bytes()
    observed = {}
    for role, unit in graph_units.items():
        observed[role] = m.owner(unit)
    with target.open("r+b") as coeff:
        header = coeff.read(2880)
        assert b"BITPIX  =                  -32" in header and b"END " in header
        first = struct.unpack(">f", coeff.read(4))[0]
        coeff.seek(2880)
        coeff.write(struct.pack(">f", first + 0.125))
    original_first = struct.unpack(">f", original.read_bytes()[2880:2884])[0]
    assert first == original_first and target.read_bytes() != original.read_bytes()
    initial = m.status(m.unit)
    request_ns = time.monotonic_ns()
    with (directory / "systemctl-start.log").open("w") as sink:
        result = subprocess.run(["systemctl", "--user", "start", m.unit], stdout=sink,
                                stderr=subprocess.STDOUT, timeout=130)
    assert result.returncode != 0
    terminal = m.status(m.unit)
    assert terminal["MainPID"] == "0" and terminal["ActiveState"] == "failed"
    assert int(terminal["ActiveEnterTimestampMonotonic"]) * 1000 < request_ns
    journal = m.run("journalctl", "--user", "-u", m.unit, "--lines=100", "--no-pager",
                    "-o", "json", capture_output=True, text=True).stdout
    invocation_journal = [entry for line in journal.splitlines() if line
                          and int((entry := m.json.loads(line))["__MONOTONIC_TIMESTAMP"]) * 1000 >= request_ns]
    m.save(directory / "journal.json", invocation_journal)
    messages = [entry["MESSAGE"] for entry in invocation_journal if isinstance(entry.get("MESSAGE"), str)]
    assert any("persistent graph input changed" in message and str(target) in message
               for message in messages)
    if verify_cleanup:
        stopped = m.load(m.rtc_runtime / terminal["InvocationID"] / "launch.json")
        m.save(directory / "failed-ledger.json", stopped)
        assert stopped["phase"] == "failed" and stopped["cleanup_complete"]
        assert "persistent graph input changed" in m.json.dumps(stopped["error"])
        stop_hook = m.system("show", m.unit, "-p", "ExecStopPost", capture_output=True, text=True).stdout
        (directory / "stop-hook.txt").write_text(stop_hook)
        assert "code=exited" in stop_hook and "status=0" in stop_hook
        assert not any("owner ledger unavailable" in message for message in messages)
    no_links = m.native_dump(directory / "after-native.json")
    fixture(source, no_links)
    assert not native_links(no_links)
    assert all(m.owner(graph_units[role]) == identity for role, identity in observed.items())
    m.save(directory / "receipt.json", dict(before=initial, after=terminal, roles=observed,
                                            original_first=original_first, candidate_first=first+0.125))
    print("Changed authored FITS coefficient denied Ready while both graph owners remained active", flush=True)


def full_shutdown(source, graph_units, *, wait_for_camera=True):
    m.system("stop", *graph_units.values(), timeout=150)
    stopped_ns = time.monotonic_ns()
    after = m.native_dump(scratch / "full-shutdown-native.json")
    fixture(source, after)
    assert not native_links(after)
    for unit in graph_units.values():
        state = m.status(unit)
        assert state["ActiveState"] == "inactive" and state["MainPID"] == "0", state
    for role in roles:
        assert not by_name(after, role+"-controller")
        assert not by_name(after, endpoint_prefix+"bootstrap."+role)
    after_shutdown = m.wait(lambda: next((row for row in m.cameras() if row["observed_ns"] > stopped_ns), None),
                            250, "source exposure after full graph shutdown") if wait_for_camera else None
    m.save(scratch / "full-shutdown.json", {"requested_graph_stops": graph_units,
        "graphs": {role: m.status(unit) for role, unit in graph_units.items()},
        "source": m.owner(m.hil_name), "core": m.owner(m.core_name),
        "camera_after_graph_shutdown": after_shutdown})
    print("Full graph shutdown leaves the separately supervised source and core live", flush=True)


def camera_continuity(start_ns):
    result = {}
    for role in roles:
        rows = [row for row in m.cameras() if row["camera"] == role and row["observed_ns"] > start_ns]
        assert len(rows) >= 2, (role, rows)
        assert len({(row["domain"], row["generation"]) for row in rows}) == 1
        missed = []
        for previous, current in zip(rows, rows[1:]):
            assert current["observed_ns"] > previous["observed_ns"]
            delta = current["sequence"] - previous["sequence"]
            assert delta > 0
            assert current["model_ns"] - previous["model_ns"] == delta * current["exposure_ns"]
            if delta > 1:
                missed.append(dict(after=previous["sequence"], before=current["sequence"], count=delta-1))
        result[role] = dict(first=rows[0], last=rows[-1], count=len(rows), missed_observations=missed)
    m.save(scratch / "source-continuity.json", result)


def fixture_inputs():
    current = app / "systemd"
    result = {}
    for role in roles:
        choices = list(current.glob("pipewireao-graph-*-"+role+".service"))
        assert len(choices) == 1, (role, choices)
        result[role] = choices[0]
    return result


def install_runtime_units(graph_files, claimed):
    unit_sources = {m.unit: app / "systemd" / "pipewireao-session@.service"}
    unit_sources.update({path.name: path for path in graph_files.values()})
    for unit in unit_sources:
        assert not os.path.lexists(m.unit_dir / unit)
        assert not (m.unit_dir / (unit + ".d")).exists()
        assert m.system("show", unit, "-p", "LoadState", "--value",
                        capture_output=True, text=True).stdout.strip() == "not-found"
    for unit, path in unit_sources.items():
        target = m.unit_dir / unit
        claimed.append(unit)
        target.symlink_to(path)
        if unit == m.unit:
            drop = target.with_name(target.name + ".d")
            drop.mkdir()
            (drop / "validation.conf").write_text("[Service]\n"+"".join(
                f'Environment="{key}={os.environ[key]}"\n' for key in environment))
        shutil.copyfile(path, scratch / unit)
    m.system("daemon-reload")
    return unit_sources


def remove_runtime_units(unit_names):
    for unit in unit_names:
        try:
            m.system("stop", unit, timeout=170)
        except Exception as failure:
            print(f"Cleanup of {unit} reported {failure}", flush=True)
    for unit in unit_names:
        target = m.unit_dir / unit
        drop = target.with_name(target.name + ".d")
        (drop / "validation.conf").unlink(missing_ok=True)
        if drop.is_dir():
            drop.rmdir()
        target.unlink(missing_ok=True)
    m.system("daemon-reload")


def capture_journal(units):
    for unit in units:
        with (scratch / (unit + ".journal")).open("w") as sink:
            m.run("journalctl", "--user", "--no-pager", "-o", "short-monotonic",
                  "-u", unit, stdout=sink, timeout=30)


def prestart_graphs(graph_units, source):
    m.system("start", *graph_units.values(), timeout=45)
    def prepared():
        objects = m.native_dump(scratch / "before-warm-native.json")
        fixture(source, objects)
        result = {}
        for role, unit in graph_units.items():
            name = endpoint_prefix + "bootstrap." + role
            candidates = by_name(objects, name)
            if not candidates:
                return None
            assert len(candidates) == 1
            endpoint = node_identity(objects, candidates[0])
            identity = m.owner(unit)
            assert endpoint["pid"] == identity["pid"]
            result[role] = dict(unit=unit, unit_identity=identity, bootstrap_name=name,
                                incarnation=endpoint["instance"])
        return result
    graphs = m.wait(prepared, 60, "independent CAL2 graph bootstrap endpoints")
    m.save(scratch / "prestarted-graph-owners.json", graphs)
    return graphs


def run(start_only, full_optical, negative, warm_only, short_correction, negative_only,
        verify_calibration):
    scratch.mkdir()
    source = m.load(stage / "persistent.json")
    graph_files = fixture_inputs()
    graph_units = {role: path.name for role, path in graph_files.items()}
    units = []
    try:
        install_runtime_units(graph_files, units)
        resumed = m.load(stage / "source-resumed.json")
        assert not (stage / "pause-feed").exists()
        resume_ns = resumed["resumed_ns"]
        required = ("cal2-llowfs",) if short_correction else roles
        def live_before_session():
            latest = latest_by_camera()
            if all(latest.get(role, {}).get("observed_ns", 0) > resume_ns for role in required):
                return latest
            return None
        latest = m.wait(live_before_session, 195, "independent camera publication before activation")
        m.save(scratch / "source-live-before-rtc.json", dict(**resumed, latest_before_session=latest))
        reference = Path("/var/tmp/rtc-owned-admission-evidence/cal2/trial-391742671609147-final")
        known_links = native_links(m.load(reference / "ready-native.json"))
        graphs = prestart_graphs(graph_units, source) if warm_only else None
        edges = {key: value["format"] for key, value in known_links.items()}
        phases = (("cold", "graceful"), ("warm-abrupt", "kill"), ("warm-recovery", "graceful"))
        phases = phases[1:] if warm_only else phases[:1] if start_only else phases
        if short_correction:
            phases = (("warm-llowfs", "graceful"),)
        if negative_only:
            phases = ()
        for phase, outcome in phases:
            directory = scratch / phase
            launch_file, ledger, receipt, graphs, edges = start(directory, source, graphs, graph_units, edges)
            signed_correction = full_optical and phase in ("warm-abrupt", "warm-llowfs")
            if not start_only:
                running = start_open(directory, receipt,
                                     wait_for_camera=optical_branches == m.branches or short_correction)
                if signed_correction:
                    optical_open(directory, receipt, running)
                    optical_close(directory, receipt)
            if outcome == "graceful":
                if not start_only:
                    index = 2 + len(optical_branches) if signed_correction else 2
                    receipt["native_stop"] = m.acknowledge(directory, index, "stop")
                (directory / "workers-stopped").touch()
                (directory / "control-stop").touch()
            else:
                (directory / "watch-old-authority").touch()
            session_gap(directory, launch_file, ledger, receipt, source, graphs, outcome)
        m.save(scratch / "session-replacement-completed.json", {
            "phases": [phase for phase, _ in phases],
            "optical_branches": optical_branches if full_optical else [],
        })
        if negative:
            replace_required_owner(source, graph_units, graphs, edges)
        if negative or verify_calibration:
            refused_changed_calibration(source, graph_units, verify_cleanup=verify_calibration)
        full_shutdown(source, graph_units, wait_for_camera=not (negative_only or verify_calibration))
        if not start_only and not short_correction and not negative_only:
            camera_continuity(resume_ns)
        m.save(scratch / "passed.json", {"phases": [phase for phase, _ in phases],
            "optical_branches": optical_branches if full_optical else [], "additional_negative": negative,
            "calibration_cleanup_checked": verify_calibration})
    finally:
        for child, _ in m.children:
            if child.poll() is None:
                child.terminate()
                child.wait(timeout=20)
        m.children.clear()
        try:
            remove_runtime_units(units)
        finally:
            capture_journal(units)


if __name__ == "__main__":
    argument = argparse.ArgumentParser()
    argument.add_argument("--start-only", action="store_true")
    argument.add_argument("--full-optical", action="store_true")
    argument.add_argument("--negative", action="store_true")
    argument.add_argument("--warm-only", action="store_true")
    argument.add_argument("--short-correction", action="store_true")
    argument.add_argument("--negative-only", action="store_true")
    argument.add_argument("--verify-calibration", action="store_true")
    argument.add_argument("--optical-branch", choices=("both", "llowfs", "scc"), default="both")
    args = argument.parse_args()
    if args.optical_branch != "both":
        optical_branches = (args.optical_branch,)
    assert not args.short_correction or (
        args.warm_only and args.full_optical and args.optical_branch == "llowfs" and not args.negative
    )
    assert not args.negative_only or (args.warm_only and args.negative and not args.full_optical)
    run(args.start_only, args.full_optical, args.negative, args.warm_only, args.short_correction,
        args.negative_only, args.verify_calibration)
