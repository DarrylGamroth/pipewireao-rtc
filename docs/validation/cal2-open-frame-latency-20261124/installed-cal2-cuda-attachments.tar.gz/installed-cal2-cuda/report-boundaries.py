"""Join the CAL2 modal residual from the same source acquisition through delivery."""
import argparse
from collections import defaultdict
import csv
import json
from pathlib import Path
from statistics import median
import struct

WIRE = struct.Struct("<8Q")
QUEUE = struct.Struct("<QQ16sQQqQ")
NANOSECONDS_PER_MS = 1_000_000

def load_json(path):
    return json.loads(path.read_text())

def identity(domain, generation, sequence, pts):
    return domain, int(generation), int(sequence), int(pts)

def identity_row(row, sequence="sequence"):
    return identity(row["domain"], row["generation"], row[sequence], row["model_ns"])

def observations(path):
    for event, stream, low, high, gen, seq, pts, ns in WIRE.iter_unpack(path.read_bytes()):
        if ns and seq:
            if pts >= 2**63:
                pts -= 2**64
            yield event, stream & 0xffffffff, identity(struct.pack("<QQ", low, high).hex(),
                gen, seq, pts), ns

def find_path(path):
    return path if path.is_file() else None

def events(path, selected):
    indexed = defaultdict(dict)
    if path is not None:
        for event, stream, key, ns in observations(path):
            name = selected.get((event, stream))
            if name is not None:
                indexed[key].setdefault(name, ns)
    return indexed

def add_queue(path, indexed):
    if path is None:
        return
    labels = {1: "queue_capture", 2: "queue_admit", 3: "queue_previous_playback_cycle",
        4: "queue_playback_cycle", 5: "queue_copy_begin", 6: "queue_copy_end",
        7: "queue_submit_begin", 8: "queue_submit_end"}
    for event, ns, domain, gen, seq, pts, header_seq in QUEUE.iter_unpack(path.read_bytes()):
        if event in labels and seq and ns:
            key = identity(domain.hex(), gen, seq, pts)
            indexed[key].setdefault(labels[event], ns)

def add_native(path, indexed, output_port):
    if path is None:
        return
    result_labels = {("I", 0, "D"): "native_graph_dequeue",
        ("I", 0, "G"): "native_graph_callback_begin",
        ("I", 0, "E"): "native_graph_callback_end",
        ("O", output_port, "O"): "native_graph_queue_begin",
        ("O", output_port, "Q"): "native_graph_queue_end"}
    with path.open() as stream:
        capsule = next(stream).strip()
        if "omitted=0" not in capsule:
            raise ValueError(f"Native trace omitted records: {capsule}")
        for row in csv.DictReader(stream):
            event = result_labels.get((row["direction"], int(row["port"]), row["event"]))
            if event and int(row["sequence"]):
                key = identity(row["domain"], row["generation"], row["sequence"], row["pts"])
                indexed[key].setdefault(event, int(row["monotonic_ns"]))

INTERVALS = {
    "start_ack_to_source_publication_ms": ("start_ack", "source_queued"),
    "source_stage_to_source_publication_ms": ("source_staged", "source_queued"),
    "source_to_independent_tap_callback_ms": ("source_queued", "tap_received"),
    "source_to_independent_tap_drain_ms": ("source_queued", "tap_drained"),
    "source_to_graph_ingress_ms": ("source_queued", "graph_ingress"),
    "source_to_native_graph_dequeue_ms": ("source_queued", "native_graph_dequeue"),
    "native_graph_dequeue_to_julia_callback_ms": ("native_graph_dequeue", "native_graph_callback_begin"),
    "native_graph_to_julia_ingress_ms": ("native_graph_callback_begin", "graph_ingress"),
    "graph_ingress_to_execute_ms": ("graph_ingress", "graph_execute_begin"),
    "graph_execution_wall_ms": ("graph_execute_begin", "graph_execute_end"),
    "graph_execute_end_to_staged_output_ms": ("graph_execute_end", "graph_staged"),
    "native_graph_queue_call_ms": ("native_graph_queue_begin", "native_graph_queue_end"),
    "julia_stage_to_capture_queue_ms": ("graph_staged", "queue_capture"),
    "native_graph_queue_to_capture_queue_ms": ("native_graph_queue_end", "queue_capture"),
    "queue_capture_to_admit_ms": ("queue_capture", "queue_admit"),
    "queue_residence_until_copy_ms": ("queue_admit", "queue_copy_begin"),
    "queue_admit_to_playback_cycle_ms": ("queue_admit", "queue_playback_cycle"),
    "playback_cycle_period_ms": ("queue_previous_playback_cycle", "queue_playback_cycle"),
    "playback_cycle_to_copy_ms": ("queue_playback_cycle", "queue_copy_begin"),
    "queue_copy_ms": ("queue_copy_begin", "queue_copy_end"),
    "native_queue_playback_submit_ms": ("queue_submit_begin", "queue_submit_end"),
    "queue_playback_to_observer_ms": ("queue_submit_end", "observer_process_entry"),
    "observer_callback_to_dequeue_ms": ("observer_process_entry", "observer_dequeued"),
    "observer_dequeue_to_metadata_ms": ("observer_dequeued", "observer_decoded"),
    "observer_metadata_to_payload_ms": ("observer_decoded", "observer_observed"),
    "native_source_queue_to_observer_ms": ("source_queued", "observer_observed"),
    "graph_output_stage_to_observer_ms": ("graph_staged", "observer_observed"),
    "graph_ingress_to_observer_ms": ("graph_ingress", "observer_observed"),
    "start_ack_to_observer_ms": ("start_ack", "observer_observed"),
    "source_inter_frame_ms": ("previous_source_queued", "source_queued"),
}

ORDERED = (
    "source_staged", "source_queued", "native_graph_dequeue", "native_graph_callback_begin",
    "graph_ingress", "graph_execute_begin", "graph_execute_end", "graph_staged",
    "native_graph_callback_end", "native_graph_queue_begin", "native_graph_queue_end",
    "queue_capture", "queue_admit", "queue_copy_begin", "queue_copy_end",
    "queue_submit_begin", "queue_submit_end", "observer_process_entry",
    "observer_dequeued", "observer_decoded", "observer_observed",
)

def ordering_warnings(times):
    points = [(name, times[name]) for name in ORDERED if times.get(name) is not None]
    return [f"{left}>{right}" for (left, begin), (right, end) in zip(points, points[1:]) if end < begin]

def distribution(values):
    seen = [value for value in values if value is not None]
    return None if not seen else {"n": len(seen), "median": median(seen), "min": min(seen), "max": max(seen)}

def estimate(times, fields):
    begin, end = (times.get(key) for key in fields)
    return (end - begin) / NANOSECONDS_PER_MS if begin is not None and end is not None else None

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", type=Path)
    parser.add_argument("trials", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    stage, trials, destination = args.stage, args.trials, args.destination
    persistent = load_json(stage / "persistent.json")
    hil_pid = persistent["hil"]["pid"]
    tap_pid = persistent["native"]["independent-cal2-observe-cal2-llowfs"]["client_pid"]
    core_pid = persistent["core"]["pid"]
    by_source = events(find_path(stage / f"hil-array-trace.tsv.{hil_pid}.bin"),
        {(2, 2): "source_staged", (3, 2): "source_queued"})
    by_tap = events(find_path(stage / f"tap-array-trace.tsv.{tap_pid}.bin"),
        {(4, 2): "tap_received", (5, 2): "tap_accepted"})
    tap_drains = {identity_row(row): int(row["observed_ns"])
        for row in csv.DictReader((stage / "camera-trace.tsv").open(), delimiter="\t")
        if row["camera"] == "cal2-llowfs"}
    ports = {"physical-offset": 0, "modal-residual": 1}
    queues = {port: defaultdict(dict) for port in ports}
    for port in queues:
        queue = find_path(stage / f"cal2-llowfs-{port}-queue-input.{core_pid}.bin")
        add_queue(queue, queues[port])
    source_times = sorted((record["source_queued"], key) for key, record in by_source.items()
        if "source_queued" in record)
    for index, (ns, key) in enumerate(source_times):
        if index and source_times[index - 1][1][:2] == key[:2]:
            by_source[key]["previous_source_queued"] = source_times[index - 1][0]
    output = []
    summary = {}
    for directory in sorted(trials.iterdir()):
        if not (directory / "lifecycle.json").is_file() or not (directory / "output-trace.jsonl").is_file():
            continue
        receipt = load_json(directory / "lifecycle.json")
        start = receipt.get("running", {}).get("started")
        if start is None:
            continue
        stop = receipt.get("stop", {}).get("request_ns", 2**63)
        graph_owner = receipt["graph_owners"]["cal2-llowfs"]
        pid = graph_owner.get("unit_identity", graph_owner)["pid"]
        graph_path = find_path(stage / f"graph-ingress.{pid}.bin")
        native_paths = sorted((stage / "native-boundary").glob(f"ndarray-filter-{pid}-*.csv"))
        if len(native_paths) > 1:
            raise ValueError(f"Identify the controller's native filter explicitly: {native_paths}")
        graphs = {}
        for name, native_port in ports.items():
            graph = events(graph_path,
                {(15, 1): "graph_ingress", (17, 1): "graph_execute_begin",
                 (18, 1): "graph_execute_end", (19, native_port + 1): "graph_staged"})
            add_native(native_paths[0] if native_paths else None, graph, native_port)
            graphs[name] = graph
        observer = [json.loads(line) for line in (directory / "output-trace.jsonl").read_text().splitlines()]
        offsets = {identity_row(row, "acquired_sequence"): row for row in observer
            if row["name"] == "llowfs-physical-offset" and row["max_abs"] == 0}
        rows = {"modal-residual": [], "physical-offset": [], "complete-open": []}
        for residual in observer:
            if (residual["name"] != "llowfs-modal-residual" or
                not start["sent_ns"] <= residual["observed_ns"] <= stop):
                continue
            key = identity_row(residual, "acquired_sequence")
            offset = offsets.get(key)
            if (offset is None or not start["sent_ns"] <= offset["observed_ns"] <= stop or
                by_source.get(key, {}).get("source_queued", 0) < start["sent_ns"]):
                continue
            both = {}
            for port, observed in (("modal-residual", residual), ("physical-offset", offset)):
                times = {**by_source.get(key, {}), **by_tap.get(key, {}),
                         **graphs[port].get(key, {}), **queues[port].get(key, {}),
                         "tap_drained": tap_drains.get(key), "start_ack": start["received_ns"],
                         "start_sent": start["sent_ns"],
                         "observer_process_entry": observed.get("observer_process_entry_ns"),
                         "observer_dequeued": observed.get("observer_dequeued_ns"),
                         "observer_decoded": observed.get("observer_metadata_ns"),
                         "observer_observed": observed["observed_ns"]}
                durations = {name: estimate(times, fields) for name, fields in INTERVALS.items()}
                record = {"trial": directory.name, "lane": port, "output_port": port,
                    "frame_in_trial": len(rows[port]) + 1, "domain": key[0], "generation": key[1],
                    "sequence": key[2], "model_ns": key[3],
                    "ordering_warnings": ",".join(ordering_warnings(times)), **durations,
                    **{f"{name}_ns": ts for name, ts in times.items()}}
                both[port] = record
                rows[port].append(record)
                output.append(record)
            complete = max(both.values(), key=lambda row: row["observer_observed_ns"])
            complete = {**complete, "lane": "complete-open"}
            rows["complete-open"].append(complete)
            output.append(complete)
        if rows["complete-open"]:
            summary[directory.name] = {}
            for lane, measured in rows.items():
                summary[directory.name][lane] = {"frames": len(measured),
                    "first_sequence": measured[0]["sequence"], "last_sequence": measured[-1]["sequence"],
                    "first_output": measured[0]["output_port"],
                    "first": {name: measured[0][name] for name in INTERVALS},
                    "subsequent": {name: distribution(row[name] for row in measured[1:]) for name in INTERVALS}}
    destination.mkdir(exist_ok=True, parents=True)
    fields = list(dict.fromkeys(column for row in output for column in row))
    with (destination / "llowfs-boundaries.tsv").open("w") as stream:
        if fields:
            writer = csv.DictWriter(stream, fieldnames=fields, delimiter="\t")
            writer.writeheader()
            writer.writerows(output)
    (destination / "llowfs-boundary-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    if not output:
        raise SystemExit("No LLOWFS residual had a fresh, identical open physical offset")

if __name__ == "__main__":
    main()
