"""Archive exact CAL2 receipt inputs and trial outputs without copying model assets."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time

stage = Path(__file__).resolve().parent
trials = stage / sys.argv[1]
destination = stage / "receipts"
archive = stage / "installed-cal2-cuda-attachments.tar.gz"
source = json.loads((stage / "persistent.json").read_text())
owners = json.loads((trials / "prestarted-graph-owners.json").read_text())

top_level = [
    "candidate-source.json", "candidate-build.log", "cuda-resolution.log", "gpu-initial.csv",
    "session-env.sh", "launch-fixture.sh", "driver.py", "feed.jl", "cuda-trials.py", "build.sh",
    "stage.py", "offline-build.jl", "measure.py", "matched.py", "ordinary.py", "replacement.py",
    "report-boundaries.py", "snapshot-evidence.py", "summarize-cuda.py", "cal2-ops.sh", "retain-live-logs.py",
    "live-correction-control.jl", "live-observe.jl", "quiet-private-core.sh", "boundary-julia-parse-and-clock.log",
    "patch-boundary-julia.py", "observer-reference", "persistent.json", "cuda-trials-a.log",
    "camera-trace.tsv", "pupil-pacing.tsv", "before-first-native.json", "first-llowfs.json",
    "core-config/daemon.conf", "core-config/client.conf",
    "continuity/decode.py", "continuity/event-driven-provider-env/Project.toml",
    "continuity/event-driven-provider-env/Manifest.toml", "source-app/simulation.conf",
    "continuity/event-driven-hil/ext/PipeWireAORTCExt/independent_optical.jl",
    "continuity/event-driven-hil/src/array_streams.jl", "continuity/event-driven-hil/src/continuity_trace.jl",
    "candidate-app/Project.toml", "candidate-app/Manifest.toml", "candidate-app/deployment.conf",
    "candidate-app/systemd/graph-owner-assets.json", "candidate-app/systemd/graph-owners.json",
    "candidate-app/systemd/session-activation.json", "candidate-app/systemd/pipewireao-session@.service",
]
top_level.extend(str(path.relative_to(stage)) for path in
                 (stage / "candidate-app/systemd").glob("pipewireao-graph-*.service"))
top_level.append(f"hil-array-trace.tsv.{source['hil']['pid']}.bin")
tap = source["native"]["independent-cal2-observe-cal2-llowfs"]["client_pid"]
top_level.append(f"tap-array-trace.tsv.{tap}.bin")
top_level.extend(f"graph-ingress.{item['unit_identity']['pid']}.bin" for item in owners.values())
for port in ("modal-residual", "physical-offset"):
    top_level.append(f"cal2-llowfs-{port}-queue-input.{source['core']['pid']}.bin")
for extra in ("live-continuity.json", "retained-live-verification.json", "private-log-level.log",
              "operations.md", "provenance.json", "analysis-summary.md"):
    if (stage / extra).is_file():
        top_level.append(extra)


def read_command(arguments):
    return subprocess.run(arguments, capture_output=True, text=True, timeout=20, check=True).stdout


def selected_lines(path, match):
    with path.open() as file:
        return "".join(line for line in file if match.search(line))


def main():
    destination.mkdir(exist_ok=True)
    for name in top_level:
        target = destination / name
        source_file = stage / name
        assert source_file.exists(), name
        if target.exists() and any(token in name for token in
                ("array-trace.", "graph-ingress.", "queue-input.", "camera-trace.tsv", "pupil-pacing.tsv")):
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        if source_file.is_dir():
            shutil.copytree(source_file, target, dirs_exist_ok=True)
        else:
            shutil.copy2(source_file, target)
    for name in ("fixture.log", "feed.log", "hil-native.log"):
        target = destination / name
        if not target.exists():
            shutil.copy2(stage / name, target)
    failure = stage / "failed-cold-attempt"
    if failure.exists():
        target = destination / failure.name
        target.mkdir(exist_ok=True)
        for name in ("fixture.log", "feed.log", "hil-native.log"):
            shutil.copy2(failure / name, target / name)
    driver = re.compile(r"PipeWireAO-Telemetry-Driver|withdrawal-returns|recycled slot|dequeue.*busy|declared bind")
    if not (destination / "core-selected.log").exists():
        (destination / "core-selected.log").write_text(selected_lines(stage / "core-native.log", driver))
    shutil.copytree(trials, destination / "trials", dirs_exist_ok=True)
    (destination / "system-gpu.csv").write_text(read_command(
        ["nvidia-smi", "--query-gpu=uuid,name,driver_version,memory.total", "--format=csv"]))
    (destination / "system-kernel.txt").write_text(read_command(["uname", "-srmo"]))
    (destination / "receipt-copy.json").write_text(json.dumps(dict(
        snapshot_monotonic_ns=time.monotonic_ns(), source=source["hil"], core=source["core"],
        included_outputs=trials.name), indent=2) + "\n")
    temp = archive.with_suffix(".tmp")
    with tarfile.open(temp, "w:gz", compresslevel=6) as tar:
        tar.add(destination, arcname="installed-cal2-cuda")
    temp.replace(archive)
    with archive.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    archive.with_name(archive.name + ".sha256").write_text(digest + "  " + archive.name + "\n")
    print(archive, digest)


if __name__ == "__main__":
    main()
