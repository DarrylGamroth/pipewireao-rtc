# CAL2 observer timing probes

The native base is PipeWireAO v4.0.8 at
`2080cba77c33f069fa436b0ce96cbace934296fb`. The released x86-64 SDK artifact
hash is `77da251765f3124df77322c562e67a7c7742ab1d` and its library SHA-256 is
`56660ca188a0b8c83bbbd27634ff6b2a1d375722c0d7d32e58465cf3c52dec19`.
The Julia binding is PipeWireAO 0.9.6 with registered tree
`bee94d9a9446d3db6a6ab5c475bf42a79310d5fb` and package slug `Evk5U`.
The RTC source is `a4cacb81b0d4a4c4389233da7b57e0be5a83aa0f`.

## Build in a private scratch directory

Set `trace_sources` to this extracted archive. Populate `native-src` with a
Git archive of the native revision above and keep the released SDK read-only.

```sh
python3 "$trace_sources/scripts/patch-native.py" native-src/src/pipewire/ndarray-filter.c
python3 "$trace_sources/scripts/patch-observer-native.py" native-src/src/pipewire/stream.c
meson setup build native-src     -Ddocs=disabled -Dexamples=disabled -Dauto_features=disabled     -Dbuildtype=release -Dc_args=-DPW_ENABLE_DIAGNOSTIC_TRACE
ninja -C build src/pipewire/libpipewire-ao-0.3.so.0.4008.0
```

Clone the released SDK into a scratch prefix and replace only its
`lib/libpipewire-ao-0.3.so.0.4008.0` with the built library. This is the
SDK for attachments 04 and 05. Its measured SHA-256 is
`6835372641046246aebff6d1f8d073419f89253c6707b74e9d13786f73d80271`.
Copy the registered Julia binding to the scratch depot's
`packages/PipeWireAO/Evk5U` and apply `patch-observer-binding.py` to its
`src/stream.jl`. The scratch file must be writable during patching.

To build the C-only variant, apply `patch-observer-leave.py` to the same
scratch `native-src/src/pipewire/stream.c` after building the first library.
Rebuild the same target. Clone the released SDK into a second scratch
prefix and replace that copy's library with the newly built library.
Attachment 06 measured SHA-256
`3322b5905d5de9bd1570b0d59e05c23356c4e7cfa453d7a268d9ea881d1f6`.
Use the original Julia binding source for this attachment.

Each scratch observer depot has an
`artifacts/Overrides.toml` assigning `PipeWireAO` under package UUID
`cde84cf6-9a21-5ce0-b5e3-1526e778c30b` to its absolute scratch SDK prefix.
Prepend that depot to JULIA_DEPOT_PATH for the independent observer only.
Set PW_CAL2_OBSERVER_TRACE_DIRECTORY to a writable, already created scratch
directory. The normal app, core, simulator and controller services retain the
released SDK. Leave the native ndarray trace environment unset for these
observer-only attachments. The standalone native graph patch reconstructs the
library build inputs, but took no records in the observer cohort.

## Trace order

Each process writes `observer-native.<pid>.<observer-index>.bin`. The binary
record is little-endian `<QQ16sQQqQ` with event, CLOCK_MONOTONIC ns, acquisition
domain, generation, sequence, model timestamp, and Header sequence. Ignore
records with event zero. Mode 04/05 traces the physical offset at index 1
and modal residual at index 2. Mode 06 traces all five observer streams.

| Event | Boundary |
| --- | --- |
| 1 | Observer-local native input processing obtains an actual buffer. |
| 2 | Native stream is about to invoke its Julia listener. |
| 3 | First Julia binding wrapper timestamp. |
| 4 | Julia callback selection has completed and its lock is released. |
| 5 | Native dequeue successfully returns the buffer to the observer. |
| 6 | Immediately before the Julia callback-lock operation. |
| 7 | Immediately after that lock is acquired. |
| 8 | Native stream has returned from its Julia listener. |

Events 3, 4, 6 and 7 use the patched observer binding in attachments 04
and 05. Their chronology uses recorded timestamps. Event 8 supplies the
return boundary with the stock binding in attachment 06. Compare the two
ports for the same complete acquisition identity. Neither the absence of a
record before the first receipt nor the gap between listener return and a
later receipt excludes observer-loop work unrelated to a recorded acquisition.

The initial accumulator receipts for 04, 05 and 06 show both output ports.
In 06 no identified receipt occurred before Start on any of the five traced
streams. No identified buffer receipt or listener mark occurred between the
residual listener return and the physical offset receipt. The raw trace
files and per-frame tables are in the separate main observer archive.
