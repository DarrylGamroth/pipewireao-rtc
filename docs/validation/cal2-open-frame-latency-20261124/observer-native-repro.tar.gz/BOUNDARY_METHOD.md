# CAL2 open LLOWFS frame timing

Join records by acquisition domain, generation, sequence, and model timestamp.
Use LLOWFS source and graph process IDs from the trial receipts. Qualify an
open measurement when the residual and the zero physical offset have the same
identity and both arrive during the accepted Start to Stop window. Keep the
modal-residual and physical-offset rows. Take the later observed row for
complete-open and use that same port's timestamps throughout the row.

The simulator trace measures host staging and native camera queue submission.
The independent tap records its receive callback and subsequent drain. Those
tap events establish continuity and are independent of the controller.

The FilterGraphPipeWire scratch probe records Julia ingress, the interval
around the scientific graph call, and output staging after native output
metadata and availability are set. The graph interval is wall time around
the selected method. It includes time the graph thread spends waiting or
descheduled during the call. The LLOWFS graph uses the existing CPU
complete-frame FIFO path. The CUDA optical provider is an independent
process. Its host timestamps do not measure GPU kernel duration.

The traced copy queue logs native capture dequeue, admission, servicing playback
cycle, copy begin and end, and the playback queue call. Queue residence runs
from the admission record to copy start. The previous playback cycle record
can occur before the current acquisition. The observer records its Julia
process entry after callback dispatch, native stream dequeue return,
metadata decode, and first validated payload observation. Playback submission
to Julia observer entry combines native delivery and callback dispatch.
With the stock SDK, graph output staging to queue capture combines the remainder
of the graph callback, native output publication, and queue capture scheduling.

The optional separate whole-cohort 4.0.8 diagnostic SDK writes controller
CSV when its filter is destroyed. Native event D is a dequeued input, G and E
enclose its call into Julia, O precedes the native output queue call, and Q
records successful completion. Its records carry full acquisition identity,
native port, and activation. It is a separate measurement epoch from the
stock SDK. C clock samples use CLOCK_MONOTONIC, and Julia time_ns used the same
clock on the measured host. All timestamps are in host nanoseconds, while
model timestamps identify exposures. No clock alignment fit is used.

The queue and graph traces use fixed-capacity prefaulted storage. Probe
overhead is included. Compare later samples within the same cohort and report
sample counts, ranges, and medians. Separate the observed first usable frame
from the subsequent measured frames. The telemetry driver comes from the
actual Link and core scheduler assignment, with its quantum and rate carried
in the receipt.

## Observer-only diagnostic attachments

Attachments 04 and 05 loaded a scratch native stream probe and an observer-only
Julia binding overlay. The probe records the receipt of an actual native input
buffer, the point before the native library calls the listener, the first Julia
binding body timestamp, the binding callback lock attempt and acquisition,
the dispatch of the observer callable after unlocking, and successful native
dequeue. The first Julia body timestamp is after entry through the C-call
trampoline. A delay before it cannot distinguish Julia first specialization,
runtime entry, or descheduling within that interval. Observer prearming
precedes the RTC timing window. The first diagnostic prearm emitted a Julia
package-cache fallback warning.

Attachment 06 loaded a second scratch native stream probe with the ordinary
stock PipeWireAO Julia binding. It records native input receipt, listener
entry and return, and successful native dequeue on all five observer streams.
The return record retains the exact acquisition identity copied before the
native listener starts. The observer script, Julia optimization flags and
placement match the stock observations. The CUDA simulator, core and
controller PIDs remain those of the original sweep.

Without RT_PROCESS, PipeWireAO 4.0.8 gives the observer node an async main-loop
class. Once local stream processing obtains a buffer, its native process
function calls the listener inline. Therefore native queue submission to
observer-local receipt includes the native delivery and availability of the
shared observer loop. It is a mixed interval. The five-stream trace records
callbacks associated with real acquisition identities, so an empty or
unrelated wakeup can still fall outside its records. The full chronology is
in first-observer-order.json. Only a per-frame later-port chain represents
time to both open outputs.
