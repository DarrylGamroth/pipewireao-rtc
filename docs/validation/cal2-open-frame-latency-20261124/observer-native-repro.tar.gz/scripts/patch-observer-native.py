from pathlib import Path
import sys

path = Path(sys.argv[1])
code = path.read_text()
def replace(original, replacement):
    global code
    assert code.count(original) == 1, (original[:90], code.count(original))
    code = code.replace(original, replacement)

replace("#include <errno.h>\n", "#include <errno.h>\n#include <fcntl.h>\n#include <stdatomic.h>\n")
replace("static bool mlock_warned = false;\n", """static bool mlock_warned = false;

#define OBSERVER_TRACE_CAPACITY 16384u
struct observer_trace_record {
	uint64_t event;
	uint64_t monotonic_ns;
	uint8_t domain[SPA_ACQUISITION_DOMAIN_SIZE];
	uint64_t generation;
	uint64_t sequence;
	int64_t pts;
	uint64_t header_sequence;
};
""")
replace("\tstruct spa_callbacks rt_callbacks;\n", """	struct spa_callbacks rt_callbacks;

	struct observer_trace_record *observer_trace;
	_Atomic uint32_t observer_trace_index;
""")
replace("static inline uint32_t update_requested(struct stream *impl)\n", """static int init_observer_trace(struct stream *impl, const char *name)
{
	const char *dir = getenv("PW_CAL2_OBSERVER_TRACE_DIRECTORY");
	uint32_t pid, index;
	char unused;
	char file[PATH_MAX];
	void *mapping;
	size_t bytes = OBSERVER_TRACE_CAPACITY * sizeof(*impl->observer_trace);
	int fd, length;

	if (dir == NULL || name == NULL ||
	    sscanf(name, "classic-integration-observer-%u-%u%c", &pid, &index, &unused) != 2 ||
	    pid != (uint32_t)getpid() || (index != 1 && index != 2))
		return 0;

	length = snprintf(file, sizeof(file), "%s/observer-native.%u.%u.bin", dir, pid, index);
	if (length < 0 || (size_t)length >= sizeof(file))
		return -ENAMETOOLONG;
	fd = open(file, O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
	if (fd < 0)
		return -errno;
	if (ftruncate(fd, bytes) < 0) {
		int res = -errno;
		close(fd);
		return res;
	}
	mapping = mmap(NULL, bytes, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	int res = mapping == MAP_FAILED ? -errno : 0;
	close(fd);
	if (res < 0)
		return res;
	memset(mapping, 0, bytes);
	impl->observer_trace = mapping;
	return 0;
}

static inline void trace_observer(struct stream *impl, const struct buffer *buffer,
		uint64_t event, uint64_t timestamp)
{
	const struct spa_meta_acquisition_identity *identity;
	const struct spa_meta_header *header;
	struct observer_trace_record *record;
	struct timespec now;
	uint32_t index;

	if (impl->observer_trace == NULL || buffer == NULL)
		return;
	if (timestamp == 0) {
		if (clock_gettime(CLOCK_MONOTONIC, &now) < 0)
			return;
		timestamp = (uint64_t)now.tv_sec * 1000000000u + now.tv_nsec;
	}
	identity = spa_buffer_find_meta_data(buffer->this.buffer,
			SPA_META_AcquisitionIdentity, sizeof(*identity));
	header = spa_buffer_find_meta_data(buffer->this.buffer, SPA_META_Header, sizeof(*header));
	if (identity == NULL || header == NULL || identity->generation == 0)
		return;
	index = atomic_fetch_add_explicit(&impl->observer_trace_index, 1, memory_order_relaxed);
	if (index >= OBSERVER_TRACE_CAPACITY)
		return;
	record = &impl->observer_trace[index];
	record->monotonic_ns = timestamp;
	memcpy(record->domain, identity->domain, sizeof(record->domain));
	record->generation = identity->generation;
	record->sequence = identity->sequence;
	record->pts = header->pts;
	record->header_sequence = header->seq;
	__atomic_store_n(&record->event, event, __ATOMIC_RELEASE);
}

static inline void trace_observer_front(struct stream *impl, uint64_t event, uint64_t timestamp)
{
	uint32_t index, id;

	if (impl->observer_trace == NULL ||
	    spa_ringbuffer_get_read_index(&impl->dequeued.ring, &index) < 1)
		return;
	id = impl->dequeued.ids[index & MASK_BUFFERS];
	if (id < impl->n_buffers)
		trace_observer(impl, &impl->buffers[id], event, timestamp);
}

SPA_EXPORT
void pw_stream_cal2_observer_trace(struct pw_stream *stream, uint64_t event, uint64_t timestamp)
{
	struct stream *impl = SPA_CONTAINER_OF(stream, struct stream, this);

	trace_observer_front(impl, event, timestamp);
}

static inline uint32_t update_requested(struct stream *impl)
""")
replace("""	if (impl->rt_callbacks.funcs && !impl->disconnecting)
		spa_callbacks_call_fast(&impl->rt_callbacks, struct pw_stream_events, process, 0);
""", """	if (impl->rt_callbacks.funcs && !impl->disconnecting) {
		trace_observer_front(impl, 2, 0);
		spa_callbacks_call_fast(&impl->rt_callbacks, struct pw_stream_events, process, 0);
	}
""")
replace("""		/* push new buffer */
		pw_log_trace_fp("%p: push %d %p", stream, b->id, io);
""", """		/* push new buffer */
		trace_observer(impl, b, 1, 0);
		pw_log_trace_fp("%p: push %d %p", stream, b->id, io);
""")
replace("""	impl->warn_mlock = context->settings.mem_warn_mlock;

	return impl;
""", """	impl->warn_mlock = context->settings.mem_warn_mlock;

	if ((res = init_observer_trace(impl, name)) < 0) {
		free(this->name);
		goto error_properties;
	}
	return impl;
""")
replace("""	pw_properties_free(impl->port_props);
	free(impl);
}

SPA_EXPORT
void pw_stream_destroy""", """	pw_properties_free(impl->port_props);
	if (impl->observer_trace != NULL)
		munmap(impl->observer_trace,
				OBSERVER_TRACE_CAPACITY * sizeof(*impl->observer_trace));
	free(impl);
}

SPA_EXPORT
void pw_stream_destroy""")
replace("""	SPA_FLAG_SET(b->flags, BUFFER_FLAG_DEQUEUED);

	return &b->this;
""", """	SPA_FLAG_SET(b->flags, BUFFER_FLAG_DEQUEUED);
	trace_observer(impl, b, 5, 0);

	return &b->this;
""")
path.write_text(code)
