from pathlib import Path
import sys
path = Path(sys.argv[1])
s = path.read_text()

def replace(a,b):
    global s
    assert s.count(a) == 1, (a[:70], s.count(a))
    s = s.replace(a,b)

replace("(index != 1 && index != 2)", "(index < 1 || index > 5)")
replace("static inline void trace_observer(struct stream *impl, const struct buffer *buffer,",
        "static inline struct observer_trace_record *trace_observer(struct stream *impl, const struct buffer *buffer,")
a = s.index("static inline struct observer_trace_record *trace_observer(")
b = s.index("\nSPA_EXPORT\nvoid pw_stream_cal2_observer_trace", a)
snippet = s[a:b].replace("return;", "return NULL;")
snippet = snippet.replace("__atomic_store_n(&record->event, event, __ATOMIC_RELEASE);\n}",
    "__atomic_store_n(&record->event, event, __ATOMIC_RELEASE);\n\treturn record;\n}")
snippet = snippet.replace("static inline void trace_observer_front(",
    "static inline struct observer_trace_record *trace_observer_front(")
snippet = snippet.replace("if (id < impl->n_buffers)\n\t\ttrace_observer(impl, &impl->buffers[id], event, timestamp);",
    "if (id < impl->n_buffers)\n\t\treturn trace_observer(impl, &impl->buffers[id], event, timestamp);\n\treturn NULL;")
s = s[:a] + snippet + s[b:]
a = """static inline uint32_t update_requested(struct stream *impl)
"""
b = """static inline void trace_observer_leave(struct stream *impl,
		const struct observer_trace_record *entry)
{
	struct timespec now;
	struct observer_trace_record *record;
	uint32_t index;

	if (entry == NULL || clock_gettime(CLOCK_MONOTONIC, &now) < 0)
		return;
	index = atomic_fetch_add_explicit(&impl->observer_trace_index, 1, memory_order_relaxed);
	if (index >= OBSERVER_TRACE_CAPACITY)
		return;
	record = &impl->observer_trace[index];
	record->monotonic_ns = (uint64_t)now.tv_sec * 1000000000u + now.tv_nsec;
	memcpy(record->domain, entry->domain, sizeof(record->domain));
	record->generation = entry->generation;
	record->sequence = entry->sequence;
	record->pts = entry->pts;
	record->header_sequence = entry->header_sequence;
	__atomic_store_n(&record->event, 8, __ATOMIC_RELEASE);
}

static inline uint32_t update_requested(struct stream *impl)
"""
replace(a,b)

replace("""		trace_observer_front(impl, 2, 0);
		spa_callbacks_call_fast(&impl->rt_callbacks, struct pw_stream_events, process, 0);""",
    """		const struct observer_trace_record *entry = trace_observer_front(impl, 2, 0);
		spa_callbacks_call_fast(&impl->rt_callbacks, struct pw_stream_events, process, 0);
		trace_observer_leave(impl, entry);""")
path.write_text(s)
