from pathlib import Path
import sys

path = Path(sys.argv[1])
code = path.read_text()
def replace(original, replacement):
    global code
    assert code.count(original) == 1, (original[:100], code.count(original))
    code = code.replace(original, replacement)

replace('uint64_t frame;\n\tuint32_t port;', '''uint64_t frame;
	uint64_t sequence;
	uint64_t generation;
	int64_t pts;
	uint8_t domain[SPA_ACQUISITION_DOMAIN_SIZE];
	uint32_t port;''')
pos = code.index('static void ingress_trace_add')
before, code = code[:pos], code[pos:]
replace('const struct spa_meta_header *header = NULL;', '''const struct spa_meta_header *header = NULL;
	const struct spa_meta_acquisition_identity *identity = NULL;''')
replace('''	if (buffer != NULL && buffer->buffer != NULL)
		header = spa_buffer_find_meta_data(buffer->buffer,
				SPA_META_Header, sizeof(*header));''', '''	if (buffer != NULL && buffer->buffer != NULL) {
		header = spa_buffer_find_meta_data(buffer->buffer,
				SPA_META_Header, sizeof(*header));
		identity = spa_buffer_find_meta_data(buffer->buffer,
				SPA_META_AcquisitionIdentity, sizeof(*identity));
	}''')
replace('''		.frame = header != NULL ? header->seq : UINT64_MAX,
		.port''', '''		.frame = header != NULL ? header->seq : UINT64_MAX,
		.sequence = identity != NULL ? identity->sequence : 0,
		.generation = identity != NULL ? identity->generation : 0,
		.pts = header != NULL ? header->pts : -1,
		.port''')
replace("""		.direction = port->direction == SPA_DIRECTION_OUTPUT ? 'O' : 'I',
	};
}""", """		.direction = port->direction == SPA_DIRECTION_OUTPUT ? 'O' : 'I',
	};
	if (identity != NULL)
		memcpy(record->domain, identity->domain, sizeof(record->domain));
}""")
replace('native_slot,frame,offset,result\\n', 'native_slot,frame,offset,result,sequence,generation,pts,domain\\n')
replace('''		fprintf(output, "%c,%c,%llu,%llu,%u,%u,%llu,%u,%d\\n",''', '''		fprintf(output, "%c,%c,%llu,%llu,%u,%u,%llu,%u,%d,%llu,%llu,%lld,",''')
replace('''				record->offset, record->result);
''', '''				record->offset, record->result,
				(unsigned long long)record->sequence,
				(unsigned long long)record->generation,
				(long long)record->pts);
		for (uint32_t byte = 0; byte < sizeof(record->domain); byte++)
			fprintf(output, "%02x", (unsigned int)record->domain[byte]);
		fputc('\\n', output);
''')
replace('''				buffer = next;
				available = !((filter->flags &''','''				buffer = next;
				ingress_trace_add(filter, 'D', port, buffer, 0);
				available = !((filter->flags &''')
replace('''	if (fifo_inputs)
		for (i = 0; i < filter->n_data_inputs; i++)
			if (filter->input_available[i])
				ingress_trace_add(filter, 'G', filter->data_inputs[i],
						filter->input_buffers[i], 0);''', '''	for (i = 0; i < filter->n_data_inputs; i++)
		if (filter->input_available[i])
			ingress_trace_add(filter, 'G', filter->data_inputs[i],
					filter->input_buffers[i], 0);''')
replace('''	if (fifo_inputs)
		for (i = 0; i < filter->n_data_inputs; i++)
			if (filter->input_available[i])
				ingress_trace_add(filter, 'E', filter->data_inputs[i],
						filter->input_buffers[i], res);''', '''	for (i = 0; i < filter->n_data_inputs; i++)
		if (filter->input_available[i])
			ingress_trace_add(filter, 'E', filter->data_inputs[i],
					filter->input_buffers[i], res);''')
replace('''		if (fifo_inputs)
			ingress_trace_add(filter, 'O', filter->outputs[i],
					filter->output_buffers[i], 0);
		res = pw_filter_queue_buffer(filter->outputs[i]->filter_port,
				filter->output_buffers[i]);
		if (fifo_inputs && res < 0)
			ingress_trace_add(filter, 'F', filter->outputs[i],
					filter->output_buffers[i], res);''', '''		ingress_trace_add(filter, 'O', filter->outputs[i],
				filter->output_buffers[i], 0);
		res = pw_filter_queue_buffer(filter->outputs[i]->filter_port,
				filter->output_buffers[i]);
		ingress_trace_add(filter, res < 0 ? 'F' : 'Q', filter->outputs[i],
				filter->output_buffers[i], res);''')
path.write_text(before + code)
