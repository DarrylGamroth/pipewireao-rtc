"""Join each observer node's native Link to its scheduler driver assignment."""
import argparse
import json
from pathlib import Path
import re

DRIVER = "PipeWireAO-Telemetry-Driver"
PREFIX = "cal2-llowfs-"
BRANCHES = ("modal-residual", "physical-offset")
driver_assignment = re.compile(r"move_to_driver\(\)\].*driver: (\S+) (\S+) runnable:1")
follower = re.compile(r"move_to_driver\(\)\].*follower: \S+ (\S+) runnable:1 driver-runnable:1")
clock = re.compile(r"context_recalc_graph\(\)\].*driver (\S+) running:1 runnable:1 quantum:(\d+) rate:(\d+).*'([^']+)'")

def clause(line, number):
    return {"line": number, "message": line.rstrip()}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("core_log", type=Path)
    parser.add_argument("trials", type=Path)
    args = parser.parse_args()
    wanted = {}
    for run in sorted(args.trials.iterdir()):
        native = run / "ready-native.json"
        if not native.is_file():
            continue
        objects = json.loads(native.read_text())
        names = {obj["id"]: obj["info"]["props"].get("node.name", "") for obj in objects
                 if obj["type"].endswith(":Node")}
        wanted[run.name] = {}
        for output in BRANCHES:
            playback = PREFIX + output + "-queue-output"
            links = [obj for obj in objects if obj["type"].endswith(":Link")
                     and names.get(obj["info"]["output-node-id"]) == playback
                     and names.get(obj["info"]["input-node-id"], "").startswith("classic-integration-observer-")]
            if len(links) != 1:
                continue
            link = links[0]
            receipt = wanted[run.name][output] = {"playback": playback,
                "observer": names[link["info"]["input-node-id"]], "link": link["id"]}
            if link["info"].get("props"):
                receipt["link_serial"] = link["info"]["props"].get("object.serial")
    matches = [(receipt, {receipt["playback"], receipt["observer"]}) for terms in wanted.values()
               for receipt in terms.values()]
    current = None
    followers = {}
    driver_clocks = {}
    with args.core_log.open() as stream:
        for index, line in enumerate(stream, 1):
            if "move_to_driver" in line:
                if found := driver_assignment.search(line):
                    current, name = found.groups()
                    if name != DRIVER:
                        current = None
                    driver_line = clause(line, index)
                    followers = {}
                    continue
                if "driver:" in line and "follower" not in line:
                    current = None
                if current and (found := follower.search(line)):
                    name = found.group(1)
                    followers[name] = clause(line, index)
                    for receipt, nodes in matches:
                        if "assignment" not in receipt and nodes.issubset(followers):
                            receipt["assignment"] = {"driver_address": current, "driver": driver_line,
                                **{node: followers[node] for node in sorted(nodes)}}
            elif DRIVER in line and (found := clock.search(line)):
                address, quantum, rate, _ = found.groups()
                driver_clocks.setdefault(address, {"quantum": int(quantum), "rate": int(rate),
                    "period_ms": int(quantum) * 1000 / int(rate), **clause(line, index)})
    for receipt, _ in matches:
        if assignment := receipt.get("assignment"):
            receipt["running_driver_cadence"] = driver_clocks.get(assignment["driver_address"])
    print(json.dumps(wanted, indent=2))

if __name__ == "__main__":
    main()
