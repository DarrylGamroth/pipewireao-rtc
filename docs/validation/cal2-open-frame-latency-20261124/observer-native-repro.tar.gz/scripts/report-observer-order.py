"""Correlate the first two CAL2 LLOWFS callbacks on one independent observer loop."""
import argparse
import csv
import json
from pathlib import Path
import struct

WIRE = struct.Struct("<QQ16sQQqQ")
EVENTS = {1: "receive", 2: "before-listener", 3: "julia-wrapper-entry",
    4: "julia-selected-callback", 5: "dequeue", 6: "before-callback-lock",
    7: "callback-lock-acquired", 8: "after-listener"}

def load(path):
    return json.loads(path.read_text())

def delta(timing, begin, end):
    a, b = timing.get(begin), timing.get(end)
    return (b-a) / 1e6 if a is not None and b is not None else None

def analyze(stage, runs, table):
    listed = list(csv.DictReader(table.open(), delimiter="\t"))
    output = {}
    for run in sorted(runs.glob("cuda-attach-*")):
        receipt_file = run / "lifecycle.json"
        if not receipt_file.exists():
            continue
        receipt = load(receipt_file)
        started = receipt.get("running", {}).get("started")
        if not started:
            continue
        pid = receipt["observer"]["pid"]
        initial = {row["lane"]: row for row in listed
            if row["trial"] == run.name and row["frame_in_trial"] == "1"}
        if not initial:
            continue
        sequence = int(initial["complete-open"]["sequence"])
        domain = initial["complete-open"]["domain"]
        generation = int(initial["complete-open"]["generation"])
        model_ns = int(initial["complete-open"]["model_ns"])
        source_identity = (domain, generation, sequence, model_ns)
        marks = []
        streams = []
        for index in range(1, 6):
            raw = stage / "observer-native-boundary" / f"observer-native.{pid}.{index}.bin"
            if not raw.exists():
                continue
            streams.append(index)
            for event, ns, raw_domain, gen, seq, pts, header in WIRE.iter_unpack(raw.read_bytes()):
                if not event:
                    continue
                marks.append(dict(stream=index, event=EVENTS[event], ns=ns, domain=raw_domain.hex(),
                    generation=gen, sequence=seq, model_ns=pts, header=header))
        path = run / "output-trace.jsonl"
        observations = [json.loads(line) for line in path.read_text().splitlines()]
        first_submit = min(int(initial[lane]["queue_submit_end_ns"])
            for lane in ("modal-residual", "physical-offset"))
        ordered = sorted(marks, key=lambda row: row["ns"])
        selected = [mark for mark in ordered if
            (mark["domain"], mark["generation"], mark["sequence"], mark["model_ns"]) == source_identity]
        times = {(event["stream"], event["event"]): event["ns"] for event in selected}
        residual_leave = times.get((2, "after-listener"))
        offset_receive = times.get((1, "receive"))
        remainder_events = None
        if residual_leave is not None and offset_receive is not None:
            remainder_events = [mark for mark in ordered
                if residual_leave < mark["ns"] < offset_receive]
        first_window = {lane: {key: float(value) if value else None for key, value in initial[lane].items()
            if key in ("queue_playback_to_observer_native_receive_ms",
                "observer_native_receive_to_dispatch_ms", "observer_native_dispatch_to_julia_wrapper_ms",
                "observer_callback_lock_ms", "observer_native_listener_wall_ms",
                "observer_capture_after_observed_ms")}
            for lane in ("modal-residual", "physical-offset")}
        output[run.name] = {"observer_pid": pid, "native_probe_streams": streams,
            "identity": source_identity, "first_window": first_window,
            "first_mark_order": selected,
            "native_receipts_before_Start": [mark for mark in ordered
                if mark["event"] == "receive" and mark["ns"] < started["sent_ns"]],
            "earlier_payload_observations": [dict(name=row["name"], ns=row["observed_ns"],
                sequence=row["acquired_sequence"]) for row in observations if row["observed_ns"] < first_submit],
            "residual_listener_enter_to_offset_receive_ms": delta(times, (2, "before-listener"), (1, "receive")),
            "residual_listener_leave_to_offset_receive_ms": delta(times, (2, "after-listener"), (1, "receive")),
            "other_records_between_residual_listener_return_and_offset_receipt": remainder_events,
            "first_submission_skew_ms": (int(initial["physical-offset"]["queue_submit_end_ns"]) -
                int(initial["modal-residual"]["queue_submit_end_ns"])) / 1e6}
    return output

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", type=Path)
    parser.add_argument("runs", type=Path)
    parser.add_argument("table", type=Path)
    args = parser.parse_args()
    print(json.dumps(analyze(args.stage, args.runs, args.table), indent=2))
