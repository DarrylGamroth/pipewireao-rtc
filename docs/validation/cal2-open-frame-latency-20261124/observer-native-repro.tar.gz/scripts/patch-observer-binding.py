from pathlib import Path
import sys

path = Path(sys.argv[1])
s = path.read_text()

original = """    unlock(stream.callback_lock)
    callback === nothing && return nothing
    try
        callback(stream, args...)"""
replacement = """    unlock(stream.callback_lock)
    if Field === :on_process
        unlocked_ns = time_ns()
        _trace_cal2_observer(stream, UInt64(6), lock_begin_ns)
        _trace_cal2_observer(stream, UInt64(7), lock_acquired_ns)
        _trace_cal2_observer(stream, UInt64(4), unlocked_ns)
    end
    callback === nothing && return nothing
    try
        callback(stream, args...)"""
assert s.count(original) == 1
s = s.replace(original, replacement)
original = """function _stream_process(stream::Stream)::Cvoid
    _invoke_stream_callback(stream, Val(:on_process))"""
replacement = """@inline function _trace_cal2_observer(stream::Stream, event::UInt64, timestamp::UInt64)
    ccall((:pw_stream_cal2_observer_trace, LibPipeWire.libpipewire_ao), Cvoid,
        (Ptr{LibPipeWire.pw_stream}, UInt64, UInt64), stream.handle, event, timestamp)
    return nothing
end

function _stream_process(stream::Stream)::Cvoid
    _trace_cal2_observer(stream, UInt64(3), time_ns())
    _invoke_stream_callback(stream, Val(:on_process))"""
assert s.count(original) == 1
s = s.replace(original, replacement)
begin = """    lock(stream.callback_lock)
    if !stream.callbacks_active"""
after = """    lock_begin_ns = Field === :on_process ? time_ns() : UInt64(0)
    lock(stream.callback_lock)
    lock_acquired_ns = Field === :on_process ? time_ns() : UInt64(0)
    if !stream.callbacks_active"""
assert s.count(begin) == 1
path.write_text(s.replace(begin, after))
