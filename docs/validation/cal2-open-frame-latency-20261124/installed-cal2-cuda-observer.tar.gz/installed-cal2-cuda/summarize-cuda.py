"""Summarize held-ready, first usable and exact native stop boundaries per attachment."""
import json
from pathlib import Path
import sys

trial_dir = Path(sys.argv[1])
trials = json.loads((trial_dir / "trials.json").read_text())


def seconds(end, start):
    return (end - start) / 1e9


def format_range(values):
    return f"{values[0]}-{values[-1]}"


summary = []
for trial in trials:
    name = trial["directory"]
    life = json.loads((trial_dir / name / "lifecycle.json").read_text())
    command = json.loads((trial_dir / name / "response-1.json").read_text())
    held = command["held"]
    rejected = command["rejected"]
    first = trial["first_usable"]
    row = dict(attachment=trial["attachment"], stage=name, rtc_pid=trial["rtc"]["pid"],
               observer_pid=trial["observer"]["pid"], observed_llowfs=len(trial["llowfs_acquisitions"]),
               llowfs_range=format_range(trial["llowfs_acquisitions"]),
               request_to_systemd_ready_s=seconds(trial["ready_ns"], trial["request_ns"]),
               request_to_native_ready_s=seconds(trial["native_ready"]["received_ns"], trial["request_ns"]),
               start_request_to_ack_s=seconds(trial["start"]["received_ns"], trial["start"]["sent_ns"]),
               systemctl_stop_to_completion_s=trial["stop"]["systemctl_to_completion_s"],
               quit_to_offline_s=trial["stop"]["quit_to_offline_s"],
               quit_to_process_exit_s=trial["stop"]["quit_to_process_exit_s"],
               graphs={name: owner["unit_identity"]["pid"] for name, owner in life["graph_owners"].items()},
               closes_refused=[item["reply"]["error"]["message"] for item in rejected],
               held_camera=life["held_camera"]["sequence"],
               absent_camera=trial["tap_during_rtc_absence"])
    for branch, sample in first.items():
        residual_ns = sample["residual"]["observed_ns"]
        complete_ns = max(residual_ns, sample["offset"]["observed_ns"],
                          sample["pair"]["observed_ns"] if sample["pair"] else 0)
        row[branch] = dict(first_camera_sequence=sample["camera"]["sequence"],
                           first_residual_ns=residual_ns, first_complete_open_ns=complete_ns,
                           start_to_first_residual_s=seconds(residual_ns, trial["start"]["sent_ns"]),
                           start_to_first_complete_open_s=seconds(complete_ns, trial["start"]["sent_ns"]),
                           start_ack_to_first_complete_open_s=seconds(complete_ns, trial["start"]["received_ns"]),
                           camera_native_queue_to_first_complete_open_s=seconds(
                               complete_ns, sample["camera"]["observed_ns"]))
    assert len(held) == len(rejected) == 2
    summary.append(row)
print(json.dumps(summary, indent=2, sort_keys=True))
