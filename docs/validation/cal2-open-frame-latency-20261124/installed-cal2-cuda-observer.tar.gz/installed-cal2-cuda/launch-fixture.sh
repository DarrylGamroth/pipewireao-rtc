#!/usr/bin/env bash
# Launch only the CAL2 retained source fixture in this private scratch directory.
set -eu
cal2_cuda_stage=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$cal2_cuda_stage/session-env.sh"
export CAL2_VALIDATION_QUEUE_MODULE="$cal2_cuda_stage/traced-queue/libpipewire-module-queue.so"
export CAL2_QUEUE_TRACE_DIR="$cal2_cuda_stage"
export CAL2_CUDA_VISIBLE_DEVICES=GPU-ace438b4-a57b-9194-d519-bdcbe42cb770
export CAL2_HIL_PROJECT="$cal2_cuda_stage/continuity/event-driven-provider-env"
export CAL2_PUPIL_WALL_NS=500000000
export CAL2_VALIDATION_HIL_ENTRYPOINT="$cal2_cuda_stage/continuity/event-driven-hil/src/independent.jl"
export CAL2_CORE_DEBUG='4,pw.link:4,pw.port:4,pw.stream:4,mod.scheduler-v1:4'
exec python3 -u "$cal2_cuda_stage/driver.py"
