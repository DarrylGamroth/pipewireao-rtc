using PipeWireAORTC, PipeWireAO, PipeWireAO_jll
const RTC = PipeWireAORTC
include(joinpath(ARGS[4], "classic_observation.jl"))

function queue_specs(app)
    prefix = PipeWireAO_jll.artifact_dir
    deployment = RTC.Common.read_json(joinpath(app, "deployment.conf"))
    session = RTC.DeploymentConfiguration.decode(joinpath(app, deployment["session"]), prefix)
    core = RTC.DeploymentConfiguration.decode(joinpath(app, deployment["core"]), prefix)
    names = ("llowfs-physical-offset", "llowfs-modal-residual",
        "scc-physical-offset", "scc-modal-residual", "scc-pair-status")
    return map(names) do name
        stem = "cal2-"*name
        sink = only(row for row in session["sinks"] if row["node.name"] == stem*"-queue-input")
        port = only(sink["ports"])
        node = stem*"-queue-output"
        module_entry = only(
            row["args"] for row in core["context.modules"] if
            get(row, "name", "") == "libpipewire-module-queue" &&
                get(get(row["args"], "playback.props", Dict()), "node.name", "") == node
        )
        @assert get(port,"layout","ROW_MAJOR") == "ROW_MAJOR"
        wire = getproperty(NdArray, Symbol(port["element-type"]))
        type = wire == NdArray.F32_LE ? Float32 : wire == NdArray.U8 ? UInt8 :
            error("Unexpected queue element type $wire")
        rate = SPA.Fraction(parse.(Int, split(port["rate"],'/'))...)
        (; name, node, media=module_entry["playback.props"]["media.name"], type, wire,
            shape=Tuple(Int.(port["shape"])), schema=port["schema"], rate)
    end
end

function run(app, remote, directory)
    specs = queue_specs(app)
    rows = Vector{NamedTuple}(undef, 4096)
    ready_rows = Threads.Atomic{Int}(0)
    running = Threads.Atomic{Bool}(true)
    observer_ready = Ref{Task}()
    function spawn_writer()
        observer_ready[] = @async open(joinpath(directory, "output-trace.jsonl"),"w") do io
            written = 0
            while running[] || written < ready_rows[]
                while written < ready_rows[]
                    written+=1
                    println(io, RTC.Common.metadata_json(rows[written]))
                end
                flush(io)
                sleep(0.005)
            end
        end
        touch(joinpath(directory,"observer-ready"))
    end
    function record(capture, spec)
        last_header_sequence = Ref{Union{UInt64,Nothing}}(nothing)
        on_timed_metadata = function(cap, metadata, entered_ns, dequeued_ns, metadata_ns)
            observed = time_ns()
            cap.finite || error("Nonfinite $(spec.name)")
            header = cap.header
            header.sequence == last_header_sequence[] && return nothing
            last_header_sequence[] = header.sequence
            id = something(cap.identity)
            index = ready_rows[]+1
            index <= length(rows) || error("Bounded CAL2 observation filled")
            rows[index] = (; name=spec.name, acquired_sequence=id.sequence,
                domain=bytes2hex(collect(id.domain.bytes)), generation=id.generation,
                model_ns=header.pts, header_sequence=header.sequence, observed_ns=observed,
                observer_process_entry_ns=entered_ns, observer_dequeued_ns=dequeued_ns,
                observer_metadata_ns=metadata_ns,
                max_abs=maximum(abs, cap.values), payload=copy(cap.values))
            ready_rows[] = index
            return nothing
        end
        return stream -> capture(stream; on_timed_metadata)
    end
    try
        observe = observe_classic(remote; timeout=1500.0, stream_specs=specs, drive_interval=0.002,
            process_capture=record, on_ready=spawn_writer,
            finished = _ -> false,
            cancelled = () -> isfile(joinpath(directory, "observer-stop")))
        RTC.Common.write_json(joinpath(directory,"observer-completed.json"), observe; atomic=true)
    finally
        running[] = false
        if isassigned(observer_ready)
            wait(observer_ready[])
        end
    end
end
run(ARGS[1:3]...)
