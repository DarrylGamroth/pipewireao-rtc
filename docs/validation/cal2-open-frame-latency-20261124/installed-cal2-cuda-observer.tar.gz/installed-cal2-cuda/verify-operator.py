"""Verify the exact operator helper on the still-publishing installed CAL2 fixture."""
import fcntl
import hashlib
from pathlib import Path
import subprocess
import time

import matched
import measure as m
import replacement as retained

directory = m.stage / "operator-check"
operators = m.stage / "cal2-ops.sh"
source = m.load(m.stage / "persistent.json")
graphs = m.load(m.stage / "replacement-cuda-a/prestarted-graph-owners.json")


def operation(argument):
    command = [str(operators), argument]
    sent = time.monotonic_ns()
    completed = m.run(*command, text=True, capture_output=True, timeout=150)
    received = time.monotonic_ns()
    (directory / (argument + ".stdout")).write_text(completed.stdout)
    (directory / (argument + ".stderr")).write_text(completed.stderr)
    return dict(command=command, sent_ns=sent, received_ns=received, stdout=completed.stdout.strip())


def run():
    directory.mkdir()
    assert m.status(m.unit)["ActiveState"] == "inactive"
    before = operation("status")
    output_observer = m.launch(retained.stock, "12", "live-observe.jl", directory / "observer.log",
                               retained.stock, m.socket, directory, m.stage / "observer-reference")
    m.wait(lambda: retained.ready_file(directory / "observer-ready"), 180, "operator output observer")
    attached = operation("attach")
    rtc = m.owner(m.unit)
    process = Path(f"/proc/{rtc['pid']}")
    command_line = process.joinpath("cmdline").read_bytes().decode().rstrip("\0").split("\0")
    assert all(not arg.startswith(("-J", "--sysimage")) for arg in command_line)
    native_maps = [line for line in process.joinpath("maps").read_text().splitlines()
                   if "libpipewire-ao-0.3" in line or "/lib/julia/sys.so" in line or
                   "PipeWireAORTC/" in line]
    frozen = m.load(m.stage / "replacement-cuda-a/frozen-inputs.json")
    for name, digest in frozen["files"].items():
        with Path(name).open("rb") as contents:
            assert hashlib.file_digest(contents, "sha256").hexdigest() == digest, name
    tested_artifacts = dict(command_line=command_line, native_maps=native_maps, sealed=frozen)
    ledger = m.rtc_runtime / rtc["invocation"] / "launch.json"
    m.save(directory / "operator-ready-ledger.json", m.load(ledger))
    ready = m.native_dump(directory / "operator-ready-native.json")
    retained.fixture(source, ready)
    assert retained.graph_still_live(ready, graphs)
    assert len(retained.native_links(ready)) == 10
    m.launch(retained.stock, "13", "operator-open-control.jl", directory / "control.log",
             ledger, directory, m.socket, "held-only")
    m.wait(lambda: retained.ready_file(directory / "control-online.json"), 140, "native Held Status")
    held = m.load(directory / "control-online.json")
    assert held["ready"]["reply"]["state"] == "Ready"
    started = operation("start")
    assert started["stdout"] == "running", started
    running = m.acknowledge(directory, 1, "observe")
    assert running["observed"]["reply"]["state"] == "Running"
    def fresh():
        matches = {branch: m.output_matches(directory, branch, started["sent_ns"], False)
                   for branch in m.branches}
        if not all(matches.values()):
            return None
        result = {}
        for branch, (offset, residual, camera) in matches.items():
            assert offset["max_abs"] == 0 and residual["max_abs"] > 0
            pair = None
            if branch == "scc":
                pair = next((row for row in m.read_capture(directory) if
                             row["name"] == "scc-pair-status" and row["payload"] == [1] and
                             m.same_camera(row, branch, [camera])), None)
                if pair is None:
                    return None
            result[branch] = dict(camera=camera, residual=m.without_payload(residual),
                                  zero_offset=m.without_payload(offset), pair=pair)
        return result
    frames = m.wait(fresh, 60, "fresh Open output through the exact operator Start")
    confirmed = m.acknowledge(directory, 2, "observe")
    assert confirmed["observed"]["reply"]["state"] == "Running"
    (directory / "workers-stopped").touch()
    (directory / "control-stop").touch()
    detached = operation("detach")
    stopped = m.load(ledger)
    m.save(directory / "operator-stopped-ledger.json", stopped)
    assert stopped["phase"] == "stopped" and stopped["cleanup_complete"]
    assert stopped["systemd_quit"] == {"attempted": True, "accepted": True}
    assert m.status(m.unit)["ActiveState"] == "inactive"
    retained.stop_observers(directory)
    after = m.native_dump(directory / "operator-after-native.json")
    retained.fixture(source, after)
    assert retained.graph_still_live(after, graphs) and not retained.native_links(after)
    while_off = m.wait(lambda: retained.advancing_source(detached["received_ns"]), 30,
                       "same independent camera identities after operator detach")
    final = operation("status")
    m.save(directory / "receipt.json", dict(status_before=before, status_after=final,
        attach=attached, start=started, detach=detached, rtc=rtc, observer_pid=output_observer.pid,
        held=held, running_open=confirmed, first_usable=frames, camera_after=while_off,
        persistent=source, graph_owners=graphs, tested_artifacts=tested_artifacts, stopped=stopped))
    print("Verified exact cal2-ops.sh status, attach, native Open Start and normal detach", flush=True)


if __name__ == "__main__":
    with (m.runtime.parent / "rtc-devel-benchmark.lock").open("a") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX)
        try:
            run()
        finally:
            for child, _ in m.children:
                if child.poll() is None:
                    child.terminate()
                    try:
                        child.wait(timeout=8)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait(timeout=8)
            if m.status(m.unit)["MainPID"] != "0":
                m.run(operators, "detach", timeout=180)
