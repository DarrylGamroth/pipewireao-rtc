"""Keep persistent demonstration logs bounded without reopening their writers."""
import csv
import json
import os
from pathlib import Path
import stat
import subprocess
import time

stage = Path(__file__).resolve().parent
receipt_path = stage / "live-continuity.json"
camera_path = stage / "camera-trace.tsv"
log_names = ["fixture.log", "core-native.log", "hil-native.log", "feed.log", "pupil-pacing.tsv"]
retention_bytes = 16 * 1024 * 1024
reclaim_bytes = 4 * 1024 * 1024
offsets = {}


def load_cursor():
    if receipt_path.exists():
        return json.loads(receipt_path.read_text())
    return {"cursor_bytes": 0, "cameras": {}}


def count_cameras(state):
    with camera_path.open("rb") as file:
        header = file.readline().decode().strip().split("\t")
        file.seek(max(file.tell(), state["cursor_bytes"]))
        while True:
            line = file.readline()
            if not line.endswith(b"\n"):
                break
            row = dict(zip(header, next(csv.reader([line.decode()], delimiter="\t")), strict=True))
            sequence = int(row["sequence"])
            observed_ns = int(row["observed_ns"])
            model_ns = int(row["model_ns"])
            identity = [row["domain"], int(row["generation"])]
            camera = state["cameras"].setdefault(row["camera"], {
                "frames": 0, "sequence_gaps": 0, "epochs": 0})
            if identity == camera.get("epoch"):
                last = camera["sequence"]
                camera["sequence_gaps"] += max(0, sequence - last - 1)
            else:
                camera["epochs"] += 1
            camera.update(epoch=identity, sequence=sequence, model_ns=model_ns,
                          tap_monotonic_ns=observed_ns, frames=camera["frames"] + 1)
            state["cursor_bytes"] = file.tell()
    state["updated_monotonic_ns"] = time.monotonic_ns()
    temporary = receipt_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n")
    temporary.replace(receipt_path)


def bound_log(path, before=None):
    try:
        fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
    except FileNotFoundError:
        return
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid():
            return
        block = info.st_blksize
        begin = offsets.get((info.st_dev, info.st_ino), block)
        end = max(0, info.st_size - retention_bytes)
        if before is not None:
            end = min(end, before)
        end -= end % block
        if end - begin >= reclaim_bytes:
            subprocess.run(["fallocate", "--punch-hole", "--keep-size",
                            "--offset", str(begin), "--length", str(end - begin),
                            f"/proc/self/fd/{fd}"],
                           check=True, pass_fds=(fd,), timeout=20)
            offsets[(info.st_dev, info.st_ino)] = end
    finally:
        os.close(fd)


def main():
    state = load_cursor()
    while True:
        count_cameras(state)
        for name in log_names:
            bound_log(stage / name)
        bound_log(camera_path, state["cursor_bytes"])
        time.sleep(30)


if __name__ == "__main__":
    main()
