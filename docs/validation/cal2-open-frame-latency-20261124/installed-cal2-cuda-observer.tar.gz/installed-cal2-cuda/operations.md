# Retained CUDA CAL2 fixture

The private CAL2 source publishes through `/run/user/1000/c2l-cuda-jhjhtFE9/c`. The source, pupil feeder, independent camera receiver, private core and both retained graph services can run while the RTC is detached. The RTC session starts Held with both integrators Open. Native Start releases the graphs for open-loop measurements. The service and its normal Quit use the installed standard Julia 1.13.3 launcher.

## Operate the current fixture

```bash
cal2_ops=/var/tmp/rtc-cal2-cuda.jhjhtFE9/cal2-ops.sh
"$cal2_ops" status      # Check the retained units and independent receiver counters.
"$cal2_ops" attach      # Start a new installed RTC session and wait for Held Ready.
"$cal2_ops" start       # Use native SessionRuntime Start for open-loop operation.
"$cal2_ops" detach      # Execute systemd's normal native RTC Quit.
```

The RTC service is `pipewireao-session@c2l-cuda-jhjhtfe9-measure.service`. The attach and detach commands call `systemctl --user start` and `systemctl --user stop` for that service. Native Start verifies the installed service’s runtime binding at `/run/user/1000/pipewireao-session-c2l-cuda-jhjhtfe9-measure`.

Run the full shutdown command when the private fixture is no longer needed.

```bash
/var/tmp/rtc-cal2-cuda.jhjhtFE9/cal2-ops.sh shutdown
```

Shutdown detaches the RTC, stops the two private graph units and asks the feeder supervisor to stop the independent source and core. It then stops the rolling log guard. The command leaves archived results and the application files on disk.

## Services and files

The user systemd manager owns the simulator, private core and feeder supervisor. The graph unit aliases and RTC instance drop-in are in `/run/user/1000/systemd/user`. Keep the current user manager and these absolute paths available during this demonstration. The fixture has no test-time deadline and the services are transient across a reboot. The supervisor treats an unexpected feeder exit as a fixture failure and retires its private core and source.

Keep this scratch directory, the standard Julia installation, the released PipeWireAO 4.0.8 artifact and the existing dependency depots referenced by `session-env.sh`. The original fixture environment is read from `/var/tmp/cal2-independent.UcNIRN/environment.sh`. The installed app pins graph artifacts in `candidate-app`. The running simulator uses the separate `source-app` calibration and the event-driven HIL dependency under `continuity`. Do not edit or remove these live dependencies.

`live-continuity.json` records cumulative tap observations and acquisition sequence gaps per camera. The log guard preserves the latest 16 MiB per fixture log and reclaims older data in aligned increments. The underlying logs may be sparse. Use the cumulative file and recent tail for ongoing monitoring. The private core was returned to warning-level logging. The archive preserves the complete bounded measurement windows. Diagnostic binary rings have fixed capacity, and their exhaustion stops recording without imposing a lifetime on the source.
