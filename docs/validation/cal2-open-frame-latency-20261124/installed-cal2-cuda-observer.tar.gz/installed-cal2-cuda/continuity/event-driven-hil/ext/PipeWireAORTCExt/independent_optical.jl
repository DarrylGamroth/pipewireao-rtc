function independent_arguments(args)
    allowed = ("--config", "--remote", "--pipewire-cpu")
    values = Dict{String,String}()
    iseven(length(args)) || throw(ArgumentError("each independent simulator option requires a value"))
    for index in 1:2:length(args)
        key, value = args[index], args[index + 1]
        key in allowed || throw(ArgumentError("unknown independent simulator option $key"))
        haskey(values, key) && throw(ArgumentError("duplicate $key"))
        values[key] = Configuration.text(value, key)
    end
    all(key -> haskey(values, key), allowed[1:2]) ||
        throw(ArgumentError("independent simulator requires --config and --remote"))
    remote = values["--remote"]
    isabspath(remote) && issocket(remote) ||
        throw(ArgumentError("independent simulator requires an existing absolute PipeWire socket"))
    pipewire_cpu = nothing
    if haskey(values, "--pipewire-cpu")
        pipewire_cpu = tryparse(Int, values["--pipewire-cpu"])
        pipewire_cpu !== nothing && pipewire_cpu >= 2 ||
            throw(ArgumentError("PipeWire loop CPU must be an integer excluding CPUs 0 and 1"))
    end
    return (; config = abspath(values["--config"]), remote, pipewire_cpu)
end

function Simulation.independent_main(args::AbstractVector)
    invocation = independent_arguments(args)
    config = Configuration.configuration(invocation.config)
    mode = Val(config.version)
    mode isa OpticalMode ||
        throw(ArgumentError("independent simulator requires a sealed optical configuration (version 4 or 6)"))
    load_backend(Val(config.backend))
    load_proper(config, nothing)
    clocked = mode === Val(6)
    input_node = clocked ? config.command_node : config.pupil_node
    warmup = !(clocked && config.backend === :cpu && iszero(config.pacing_period_ns))
    owner_check = Returns(nothing)
    execution = Base.invokelatest(
        prepare_optical_startup, config, mode, owner_check; warmup, owner = input_node
    )
    options = merge(config, invocation, (; owner_check))
    return Base.invokelatest(run_independent_optical!, execution, options, input_node)
end

function run_independent_optical!(execution, options, input_node)
    science = execution.science
    clocked = execution.clocked
    if options.backend === :cuda
        cuda = Configuration.load_instrument(:CUDA)
        @info "CUDA optical context" device=cuda.device() context=cuda.context() process=getpid()
        for name in keys(science.sensors)
            graph = ExternalPupil.optical_execution_graph(science.plant, name)
            device = Backends.compute_device(graph)
            device isa Backends.AcceleratorComputeDevice{Backends.CUDABackend} ||
                error("prepared detector $name does not use CUDA")
            prepared = ExternalPupil.execution_properties(science.plant, name)
            prepared["optics.execution"] == "CapturedGraphExecution" &&
                parse(Int, prepared["optics.captured-node-count"]) > 0 ||
                error("prepared detector $name has no captured CUDA execution")
            @info "CUDA optical detector" detector=name device prepared
        end
    end
    streams = ExternalPupil.stream_options(
        science, options.pupil_node, options.sensor_nodes;
        sensor_buffers = options.sensor_buffers,
        input_option = clocked ? clocked_command_option(options) : nothing,
        reference_clock = Common.prepare_reference_clock(options),
    )
    input = (true, map(_ -> false, keys(science.sensors))...)
    with_array_streams(streams; remote = options.remote, input, active = false,
            synchronous_command = clocked) do transport
        with_clocked_applied_command(transport, options) do applied
            pin_transport!(transport, options)
            ExternalPupil.prepare_transport!(execution, transport)
            observe_applied = applied === nothing ? nothing :
                (command, sequence, pts) -> observe_applied!(applied, transport, command, sequence, pts)
            for index in eachindex(streams)
                with_array_stream(transport, index) do stream
                    set_active!(stream, true)
                end
            end
            if applied !== nothing
                with_thread_loop_lock(transport.loop) do _
                    set_active!(applied.stream, true)
                end
            end
            @info "Independent optical streams active" input_node remote=options.remote
            ExternalPupil.run!(execution, transport; observe_applied) do execution, _, _
                ExternalPupil.Run(ExternalPupil.snapshot(execution).deadline_ns)
            end
        end
    end
    return nothing
end
