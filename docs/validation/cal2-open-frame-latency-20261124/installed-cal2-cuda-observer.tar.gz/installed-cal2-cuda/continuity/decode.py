import argparse
import csv
import struct
from pathlib import Path
import sys

EVENTS = {
    1: "stage-attempt", 2: "staged", 3: "native-queued", 4: "native-received",
    5: "receive-accepted", 6: "receive-busy", 7: "invalid-identity",
    8: "no-output-buffer", 9: "drained", 10: "trigger-driver",
    11: "output-overwritten", 12: "invalid-input-buffer", 13: "stage-busy",
    14: "callback-failed", 15: "graph-ingress", 16: "publication-retry",
    17: "graph-execute-begin", 18: "graph-execute-end", 19: "graph-output-staged",
}
ROW = struct.Struct("<8Q")

def events(path):
    for kind, channel, lo, hi, gen, seq, pts, timestamp in ROW.iter_unpack(path.read_bytes()):
        if timestamp:
            if pts >= 2**63:
                pts -= 2**64
            flags = channel >> 32
            yield (path.name, EVENTS[kind], channel & (2**32 - 1),
                struct.pack("<QQ", lo, hi).hex(), gen, seq, pts, timestamp, flags)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("files", type=Path, nargs="+")
    parser.add_argument("--triggers", action="store_true")
    args = parser.parse_args()
    rows = (row for path in args.files for row in events(path) if args.triggers or row[1] != "trigger-driver")
    writer = csv.writer(sys.stdout, delimiter="\t", lineterminator="\n")
    writer.writerow(("process", "event", "stream", "domain", "generation", "sequence", "model_ns", "monotonic_ns", "flags"))
    writer.writerows(sorted(rows, key=lambda row: row[7]))

if __name__ == "__main__":
    main()
