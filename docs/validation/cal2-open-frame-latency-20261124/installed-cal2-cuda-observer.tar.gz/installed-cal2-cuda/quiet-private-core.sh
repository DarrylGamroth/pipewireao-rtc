#!/usr/bin/env bash
# Reduce log verbosity of this exact private PipeWire core after the timed block.
set -eu
cal2_quiet_stage=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$cal2_quiet_stage/session-env.sh"
test -S "$PIPEWIREAORTC_CORE_SOCKET"
cal2_expected_pid=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["core"]["pid"])' "$cal2_quiet_stage/persistent.json")
cal2_current_pid=$(systemctl --user show -p MainPID --value "$PIPEWIREAORTC_CORE_UNIT")
test "$cal2_current_pid" = "$cal2_expected_pid"
export PIPEWIREAO_RUNTIME_DIR="${PIPEWIREAORTC_CORE_SOCKET%/*}"
export PIPEWIRE_RUNTIME_DIR="$PIPEWIREAO_RUNTIME_DIR"
export PIPEWIREAO_CONFIG_DIR="$PIPEWIREAO_PREFIX/share/pipewire-ao"
export PIPEWIREAO_MODULE_DIR="$PIPEWIREAO_PREFIX/lib/pipewire-ao-0.3"
export PIPEWIREAO_SPA_PLUGIN_DIR="$PIPEWIREAO_PREFIX/lib/spa-ao-0.2"
export LD_LIBRARY_PATH="$PIPEWIREAO_PREFIX/lib"
ulimit -c 0
timeout 10 "$PIPEWIREAO_PREFIX/bin/pwao-metadata" -r "$PIPEWIREAORTC_CORE_SOCKET" \
    -n settings 0 log.level 2 "Spa:String"
cal2_level_after=$(timeout 10 "$PIPEWIREAO_PREFIX/bin/pwao-metadata" -r "$PIPEWIREAORTC_CORE_SOCKET" -n settings 0 log.level)
printf '%s\n' "$cal2_level_after"
[[ $cal2_level_after == *"key:'log.level' value:'2'"* ]]
