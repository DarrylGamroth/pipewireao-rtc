from pathlib import Path
import sys

stage = Path(sys.argv[1])
graph = stage / "continuity-depot/packages/FilterGraphPipeWire/2cAf1/src"

def edit(path, changes):
    source = path.read_text()
    for original, replacement in changes:
        assert source.count(original) == 1, (path, original[:80], source.count(original))
        source = source.replace(original, replacement)
    path.write_text(source)

edit(graph / "continuity_trace.jl", [
    ("function _trace_continuity!(event, stream, identity, pts, flags=0)",
     "function _trace_continuity!(event, stream, identity, pts, flags=0, timestamp::UInt64=UInt64(0))"),
    ("unsafe_store!(rows, time_ns(), offset + 8)", "unsafe_store!(rows, iszero(timestamp) ? time_ns() : timestamp, offset + 8)"),
])
with (graph / "continuity_trace.jl").open("a") as output:
    output.write("""
@inline function _trace_boundary_buffer!(event, port, buffer, timestamp::UInt64)
    _continuity_rows[] == C_NULL && return nothing
    header = PipeWireAO.buffer_header(buffer)
    header === nothing && return nothing
    metadata = PipeWireAO.metadata_records(buffer)
    metadata === nothing && return nothing
    identity = PipeWireAO.acquisition_identity(metadata)
    identity === nothing && return nothing
    # In boundary records the high half of the channel contains Header.seq.
    sequence = UInt32(header.sequence & UInt64(typemax(UInt32)))
    return _trace_continuity!(event, port, identity, header.pts, sequence, timestamp)
end
""")

edit(graph / "graph_node.jl", [
    ("""    PipeWireAO.set_output_available!(buffers[index],available)
    return _finalize_outputs!""",
     """    PipeWireAO.set_output_available!(buffers[index],available)
    available && _trace_boundary_buffer!(19, index, buffers[index], UInt64(0))
    return _finalize_outputs!"""),
    ("""    result = GC.@preserve owner FilterGraphs._process_candidate_admitted!(
        output_arrays, owner.graph, input_arrays, input_metadata,
    )
    return _finish_ordinary_graph_candidate!""",
     """    begin_ns = _continuity_rows[] == C_NULL ? UInt64(0) : time_ns()
    result = GC.@preserve owner FilterGraphs._process_candidate_admitted!(
        output_arrays, owner.graph, input_arrays, input_metadata,
    )
    if !iszero(begin_ns)
        end_ns = time_ns()
        _trace_boundary_buffer!(17, 1, inputs[1], begin_ns)
        _trace_boundary_buffer!(18, 1, inputs[1], end_ns)
    end
    return _finish_ordinary_graph_candidate!"""),
    ("""        result = GC.@preserve owner FilterGraphs._process_candidate_admitted!(
            output_arrays, owner.graph, input_arrays, metadata,
        )
        return _finish_feedback_candidate!""",
     """        begin_ns = _continuity_rows[] == C_NULL ? UInt64(0) : time_ns()
        result = GC.@preserve owner FilterGraphs._process_candidate_admitted!(
            output_arrays, owner.graph, input_arrays, metadata,
        )
        if !iszero(begin_ns)
            end_ns = time_ns()
            _trace_boundary_buffer!(17, 1, inputs[1], begin_ns)
            _trace_boundary_buffer!(18, 1, inputs[1], end_ns)
        end
        return _finish_feedback_candidate!"""),
    ("""        result = FilterGraphs._process_primary_candidate_admitted!(
            output_arrays,
            join,
            primary,
            primary_metadata,
        )
        return _finish_graph_candidate!""",
     """        begin_ns = _continuity_rows[] == C_NULL ? UInt64(0) : time_ns()
        result = FilterGraphs._process_primary_candidate_admitted!(
            output_arrays,
            join,
            primary,
            primary_metadata,
        )
        if !iszero(begin_ns)
            end_ns = time_ns()
            _trace_boundary_buffer!(17, PrimaryIndex, primary_buffer, begin_ns)
            _trace_boundary_buffer!(18, PrimaryIndex, primary_buffer, end_ns)
        end
        return _finish_graph_candidate!"""),
])

observer = stage / "observer-reference/classic_observation.jl"
edit(observer, [
    ("""function (capture::ClassicObservationCapture{T})(stream; on_metadata = nothing) where {T}
    capture.error === nothing || return nothing
    dequeue_buffer!(capture.buffer, stream) || return nothing""",
     """function (capture::ClassicObservationCapture{T})(stream;
    on_metadata = nothing, on_timed_metadata = nothing) where {T}
    capture.error === nothing || return nothing
    entered_ns = on_timed_metadata === nothing ? UInt64(0) : time_ns()
    dequeue_buffer!(capture.buffer, stream) || return nothing
    dequeued_ns = on_timed_metadata === nothing ? UInt64(0) : time_ns()"""),
    ("""        identity = metadata === nothing ? nothing : acquisition_identity(metadata)
        # A newly attached""",
     """        identity = metadata === nothing ? nothing : acquisition_identity(metadata)
        metadata_ns = on_timed_metadata === nothing ? UInt64(0) : time_ns()
        # A newly attached"""),
    ("""        on_metadata === nothing || on_metadata(capture, metadata)
    catch err""",
     """        on_metadata === nothing || on_metadata(capture, metadata)
        on_timed_metadata === nothing ||
            on_timed_metadata(capture, metadata, entered_ns, dequeued_ns, metadata_ns)
    catch err"""),
])

edit(stage / "live-observe.jl", [
    ("on_metadata = function(cap, metadata)",
     "on_timed_metadata = function(cap, metadata, entered_ns, dequeued_ns, metadata_ns)"),
    ("model_ns=header.pts, header_sequence=header.sequence, observed_ns=observed,",
     """model_ns=header.pts, header_sequence=header.sequence, observed_ns=observed,
                observer_process_entry_ns=entered_ns, observer_dequeued_ns=dequeued_ns,
                observer_metadata_ns=metadata_ns,"""),
    ("return stream -> capture(stream; on_metadata)", "return stream -> capture(stream; on_timed_metadata)"),
])

decoder = stage / "continuity/decode.py"
edit(decoder, [
    ('14: "callback-failed", 15: "graph-ingress", 16: "publication-retry",',
     '14: "callback-failed", 15: "graph-ingress", 16: "publication-retry",\n    17: "graph-execute-begin", 18: "graph-execute-end", 19: "graph-output-staged",'),
])
