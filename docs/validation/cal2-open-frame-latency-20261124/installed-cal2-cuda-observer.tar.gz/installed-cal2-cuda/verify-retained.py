"""Verify the already-publishing private owners with the installed RTC detached."""
from pathlib import Path
import subprocess
import sys
import time

import measure as m
import replacement as retained

trial = m.stage / sys.argv[1]
source = m.load(m.stage / "persistent.json")
graphs = m.load(trial / "prestarted-graph-owners.json")
persistent = m.native_dump(trial / "operating-native.json")
retained.fixture(source, persistent)
assert retained.graph_still_live(persistent, graphs)
assert not retained.native_links(persistent)
assert m.status(m.unit)["ActiveState"] == "inactive"
assert m.status(m.unit)["MainPID"] == "0"
summaries = m.load(trial / "measurement-summary.json")
last_camera_cutoff = summaries[-1]["absent_camera"]
fresh = m.cameras()
newest = {camera: next(row for row in reversed(fresh) if row["camera"] == camera)
          for camera in last_camera_cutoff}
assert all(newest[camera]["sequence"] > max(last_camera_cutoff[camera]) for camera in newest)
compute = m.run("nvidia-smi", "--query-compute-apps=pid,gpu_uuid,used_gpu_memory",
                "--format=csv,noheader,nounits", capture_output=True, text=True).stdout
assert source["hil"]["pid"] in {int(row.split(",", 1)[0]) for row in compute.splitlines()}
lease = subprocess.run(
    ["flock", "--nonblock", str(m.runtime.parent / "rtc-devel-benchmark.lock"), "true"],
    check=False)
status = {name: m.status(name) for name in (m.unit, m.core_name, m.hil_name,
    *(g["unit"] for g in graphs.values()), f"c2l-{m.tag}-feeder-supervisor.service",
    f"c2l-{m.tag}-log-retention.service")}
assert all(values["ActiveState"] == "active" for name, values in status.items() if name != m.unit)
m.save(m.stage / "retained-live-verification.json", dict(
    observed_monotonic_ns=time.monotonic_ns(), simulator_compute=compute, unit_status=status,
    latest_independent_tap=newest, persistent=source, graphs=graphs, benchmark_free_when_checked=not lease.returncode,
    log_guard=m.load(m.stage / "live-continuity.json")))
