"""Exercise the installed CAL2 service against an independently publishing HIL."""
import argparse
import fcntl
import os
from pathlib import Path
import shutil
import time

import matched
import measure as m
import replacement as retained

stage, scratch, app = matched.stage, matched.scratch, matched.app
reference = Path("/var/tmp/rtc-owned-admission-evidence/cal2/trial-391742671609147-final")


def profile_start(observer, directory, perf):
    command = ["taskset", "-c", "12", "python3", observer, m.unit, directory / "cpu-observer"]
    if perf:
        command.append("--perf")
    with (directory / "cpu-observer.log").open("w") as output:
        m.run(*command, stdout=output, stderr=output, timeout=120)
    profile = m.load(directory / "cpu-observer/observer.json")
    sent, acknowledged = profile["requested_ns"], profile["returned_ns"]
    m.save(directory / "systemd-ready.json", dict(request_ns=sent, ready_ns=acknowledged,
        request_to_systemd_ready_s=m.seconds(acknowledged, sent), service=m.status(m.unit)))
    return sent, acknowledged


def observation_end(stop, source, minimum_llowfs, minimum_post_quit=6):
    """Wait for staged exposures so a producer gap cannot block the observation gate."""
    after = stop["completed_ns"]
    pid = source["hil"]["pid"]

    def observed():
        rows = matched.events("hil-array-trace.tsv", pid)
        cameras = [row for row in rows if row["event"] == "staged" and row["stream"] in (2, 3)]
        sequences = {index: [row for row in cameras if row["stream"] == index and
                              row["observed_ns"] > after] for index in (2, 3)}
        llowfs, scc = sequences.values()
        if len(llowfs) <= minimum_post_quit or not scc or llowfs[-1]["sequence"] <= minimum_llowfs:
            return None
        past_previous = next(row for row in llowfs if row["sequence"] >= minimum_llowfs)
        cutoff = max(llowfs[minimum_post_quit - 1]["observed_ns"],
                     scc[0]["observed_ns"], past_previous["observed_ns"])
        if time.monotonic_ns() < cutoff + 200_000_000:
            return None
        return dict(cutoff_ns=cutoff, after_stop_ns=after, llowfs_seen=llowfs, scc_seen=scc)

    return m.wait(observed, 650, "several real staged LLOWFS exposures and SCC after final Quit")


def capture_publication_result(source, cutoff=None):
    rows = matched.events("hil-array-trace.tsv", source["hil"]["pid"])
    result = {}
    for branch in m.branches:
        camera = "cal2-" + branch
        index = next(index for index, data in matched.camera_streams.items() if data["camera"] == camera)
        observed = [row for row in rows if row["stream"] == index and
                    (cutoff is None or row["observed_ns"] <= cutoff)]
        stage_calls = [row for row in observed if row["event"] == "stage-attempt"]
        staged = [row for row in observed if row["event"] == "staged"]
        staged_ids = {matched.identity(row) for row in staged}
        queued = {matched.identity(row): row for row in rows if row["stream"] == index and row["event"] == "native-queued"}
        overwritten = {matched.identity(row) for row in rows if row["stream"] == index and row["event"] == "output-overwritten"}
        missing = [row for row in staged if matched.identity(row) not in queued]
        tapped = {matched.identity(row) for row in matched.tap_receipts() if row["camera"] == camera}
        result[camera] = dict(attempts=len(staged), stage_calls=len(stage_calls),
            not_staged=[row for row in stage_calls if matched.identity(row) not in staged_ids],
            queued=sum(matched.identity(row) in queued for row in staged),
            last_staged=staged[-1], overwritten=[row for row in missing if matched.identity(row) in overwritten],
            still_pending=[row for row in missing if matched.identity(row) not in overwritten],
            queued_without_tap=[row for row in staged if matched.identity(row) in queued and matched.identity(row) not in tapped])
    m.save(scratch / "publication-result.json", result)
    if cutoff is not None:
        missing = {camera: {reason: [row["sequence"] for row in result[camera][reason]]
                            for reason in ("not_staged", "overwritten", "still_pending", "queued_without_tap")}
                   for camera in result}
        gaps = any(sequences for counts in missing.values() for sequences in counts.values())
        m.save(scratch / "detector-continuity.json", dict(cutoff_ns=cutoff, passed=not gaps, missing=missing))
    return result


def finish_ready_trial(directory, launch, ledger, receipt, source, graphs, *,
                       running=False, optical=False, observe_off_camera=True):
    if running:
        command = 2 + len(retained.optical_branches) if optical else 2
        receipt["native_stop"] = m.acknowledge(directory, command, "stop")
    (directory / "workers-stopped").touch()
    (directory / "control-stop").touch()
    retained.session_gap(directory, launch, ledger, receipt, source, graphs, "graceful",
                         observe_off_camera=observe_off_camera)
    matched.evidence(directory, source, graphs, receipt)


def capture_queue(directory, phase):
    before = time.monotonic_ns()
    nodes = m.native_dump(directory / (phase + "-queue-native.json"))
    items = [m.properties(node) for node in nodes if node["type"].endswith(":Module") and
             m.properties(node).get("node.name") == "cal2-llowfs-image-queue"]
    assert len(items) == 1, items
    return dict(request_ns=before, captured_ns=time.monotonic_ns(), counters=items[0])


def transport_trial(source, graphs, units, edges):
    directory, launch, ledger, receipt = matched.start("direct", "ordinary-transport", source, graphs, units, edges)
    counters = {"ready": capture_queue(directory, "ready")}
    started = retained.start_open(directory, receipt)

    def camera_arrivals():
        rows = [row for row in m.cameras() if row["camera"] == "cal2-llowfs" and
                row["observed_ns"] >= started["received_ns"]]
        return rows if len(rows) >= 3 else None

    arrivals = m.wait(camera_arrivals, 160, "three ordinary running LLOWFS publications")
    opened = m.wait(lambda: m.output_matches(directory, "llowfs", started["received_ns"], False),
                    10, "fresh LLOWFS graph measurement on the live companion")
    counters["pre_quit"] = capture_queue(directory, "pre-quit")
    m.save(directory / "ordinary-running.json", dict(camera_publications=arrivals, first_usable=opened,
                                                   queue=counters))
    finish_ready_trial(directory, launch, ledger, receipt, source, graphs, running=True)
    counters["post_quit"] = capture_queue(directory, "post-quit")
    m.save(directory / "queue-counters.json", counters)
    window = observation_end(receipt["stop"], source, 0)
    m.save(scratch / "post-quit-observation.json", window)
    capture_publication_result(source, window["cutoff_ns"])


def start_with_overlay(overlay, name, source, graphs, units, edges, *, trace=False):
    dropin = m.dropin / "zz-startup-attribution.conf"
    diagnostic_depot = overlay.parent / "depot"
    environment = f'Environment="JULIA_LOAD_PATH={overlay}:@:@stdlib"\n'
    environment += f'Environment="JULIA_DEPOT_PATH={diagnostic_depot}:{os.environ["JULIA_DEPOT_PATH"]}"\n'
    if trace:
        environment += 'Environment="RTC_STARTUP_ATTRIBUTION=trace"\n'
    dropin.write_text("[Service]\n" + environment)
    try:
        m.system("daemon-reload")
        result = matched.start("direct", name, source, graphs, units, edges)
        shutil.copyfile(dropin, result[0] / "activation-overlay.conf")
        return result
    finally:
        # ExecStop and cleanup use the sealed application, even for a
        # diagnostic main process that loaded an alternate Julia source.
        dropin.unlink(missing_ok=True)
        m.system("daemon-reload")


def run(args):
    scratch.mkdir()
    source = m.load(stage / "persistent.json")
    matched.camera_map(source)
    files = retained.fixture_inputs()
    units = {role: path.name for role, path in files.items()}
    claimed = []
    m.first_after_adoption = matched.first_correction
    try:
        matched.install_units(files, claimed)
        template = app / "systemd/pipewireao-session@.service"
        matched.input_receipts(scratch, source, files, {"direct": template})
        edge_records = retained.native_links(m.load(reference / "ready-native.json"))
        edges = {edge: data["format"] for edge, data in edge_records.items()}
        graphs = retained.prestart_graphs(units, source)
        for graph in graphs.values():
            matched.events("graph-ingress", graph["unit_identity"]["pid"])
        print("Both persistent graph services prestarted", flush=True)
        if args.observer:
            for name, perf in (("profile-passive", False), ("profile-perf", True)):
                m.start_service = lambda directory: profile_start(args.observer, directory, perf)
                directory, launch, ledger, receipt = matched.start("direct", name, source, graphs, units, edges)
                finish_ready_trial(directory, launch, ledger, receipt, source, graphs)
        if args.diagnostic:
            m.start_service = lambda directory: profile_start(args.observer, directory, False)
            directory, launch, ledger, receipt = start_with_overlay(
                args.diagnostic, "profile-diagnostic", source, graphs, units, edges, trace=True
            )
            finish_ready_trial(directory, launch, ledger, receipt, source, graphs)
            with (directory / "invocation.journal").open("w") as output:
                m.run("journalctl", "--user", "--no-pager", "-o", "short-monotonic",
                      "_SYSTEMD_INVOCATION_ID=" + receipt["rtc"]["invocation"], stdout=output)
        if args.ab_overlay:
            m.start_service = matched.timed_service_start
            for name, optimized in (("01-baseline", False), ("02-precompile", True),
                                    ("03-precompile", True), ("04-baseline", False)):
                if optimized:
                    result = start_with_overlay(args.ab_overlay, name, source, graphs, units, edges)
                else:
                    result = matched.start("direct", name, source, graphs, units, edges)
                finish_ready_trial(*result, source, graphs, observe_off_camera=False)
        for index in range(args.ready_passes):
            m.start_service = matched.timed_service_start
            directory, launch, ledger, receipt = matched.start(
                "direct", f"ready-{index + 1}", source, graphs, units, edges
            )
            finish_ready_trial(directory, launch, ledger, receipt, source, graphs)
        if args.transport:
            m.start_service = matched.timed_service_start
            transport_trial(source, graphs, units, edges)
        if args.optical:
            m.start_service = matched.timed_service_start
            stop = None
            for name in ["ordinary-optical", "graceful-restart"]:
                directory, launch, ledger, receipt = matched.start("direct", name, source, graphs, units, edges)
                signed = name == "graceful-restart"
                if signed:
                    held_since = receipt["native_ready"]["ready"]["received_ns"]
                    m.wait(lambda: m.cameras_after(held_since), 205, "both cameras advance while Held")
                    receipt["both_cameras_held"] = True
                started = retained.start_open(directory, receipt)
                retained.optical_open(directory, receipt, started)
                if signed:
                    retained.optical_close(directory, receipt)
                finish_ready_trial(directory, launch, ledger, receipt, source, graphs, running=True, optical=signed)
                stop = receipt["stop"]
            window = observation_end(stop, source, args.minimum_llowfs)
            m.save(scratch / "post-quit-observation.json", window)
            capture_publication_result(source, window["cutoff_ns"])
        retained.full_shutdown(source, units, wait_for_camera=False)
        m.save(scratch / "lifecycle-passed.json", {"profile": bool(args.observer),
                                                "transport": args.transport, "optical": args.optical})
    finally:
        try:
            if (args.optical or args.transport) and not (scratch / "publication-result.json").exists():
                capture_publication_result(source)
        finally:
            for child, _ in m.children:
                if child.poll() is None:
                    child.terminate()
                    child.wait(timeout=20)
            m.children.clear()
            try:
                retained.remove_runtime_units(claimed)
            finally:
                retained.capture_journal(claimed)
                if m.rtc_runtime.is_dir():
                    shutil.rmtree(m.rtc_runtime)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--observer", type=Path)
    parser.add_argument("--diagnostic", type=Path)
    parser.add_argument("--ab-overlay", type=Path)
    parser.add_argument("--ready-passes", type=int, default=0)
    parser.add_argument("--transport", action="store_true")
    parser.add_argument("--optical", action="store_true")
    parser.add_argument("--minimum-llowfs", type=int, default=45)
    args = parser.parse_args()
    if not (args.observer or args.transport or args.optical or args.ab_overlay):
        parser.error("select at least one validation lane")
    if args.diagnostic and not args.observer:
        parser.error("the diagnostic lane also requires the passive observer")
    if args.transport or args.ab_overlay:
        benchmark_lock = m.runtime.parent / "rtc-devel-benchmark.lock"
        with benchmark_lock.open("a") as lease:
            print("Waiting for the benchmark lease", flush=True)
            fcntl.flock(lease, fcntl.LOCK_EX)
            run(args)
    else:
        run(args)
