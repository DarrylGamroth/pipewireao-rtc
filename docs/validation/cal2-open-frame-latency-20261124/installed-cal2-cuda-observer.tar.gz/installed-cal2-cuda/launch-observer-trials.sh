#!/usr/bin/env bash
# Rerun ordinary installed attaches with only the independent observer traced.
set -eu
cal2_observer_stage=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$cal2_observer_stage/session-env.sh"
export CAL2_VALIDATION_ATTEMPT=${CAL2_VALIDATION_ATTEMPT:-cuda-observer}
export CAL2_FIRST_ATTACHMENT=${CAL2_FIRST_ATTACHMENT:-4}
export CAL2_ATTACHMENTS=${CAL2_ATTACHMENTS:-2}
export CAL2_OBSERVER_NATIVE_PREFIX=${CAL2_OBSERVER_NATIVE_PREFIX:-/var/tmp/cal2-boundary-native.hnOS2vzm/observer-sdk}
export CAL2_OBSERVER_NATIVE_DEPOT=${CAL2_OBSERVER_NATIVE_DEPOT:-/var/tmp/cal2-boundary-native.hnOS2vzm/observer-depot}
export CAL2_OBSERVER_EXPECTED_NATIVE="$CAL2_OBSERVER_NATIVE_PREFIX/lib/libpipewire-ao-0.3.so"
export PW_CAL2_OBSERVER_TRACE_DIRECTORY="$cal2_observer_stage/observer-native-boundary"
mkdir -p "$PW_CAL2_OBSERVER_TRACE_DIRECTORY"
test -f "$CAL2_OBSERVER_EXPECTED_NATIVE"
test -d "$CAL2_OBSERVER_NATIVE_DEPOT"
exec taskset -c 12,13 python3 -u "$cal2_observer_stage/cuda-trials.py"
