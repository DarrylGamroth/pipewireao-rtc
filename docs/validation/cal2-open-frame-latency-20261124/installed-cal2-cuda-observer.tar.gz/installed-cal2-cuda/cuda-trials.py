"""Time ordinary installed CAL2 RTC attachments while independent CUDA optics keep publishing."""
import fcntl
import json
import os
from pathlib import Path
import subprocess
import time

import matched
import measure as m
import ordinary
import replacement as retained

stage, scratch, app = matched.stage, matched.scratch, matched.app
usage_count = 12
first_arm = int(os.environ.get("CAL2_FIRST_ATTACHMENT", "1"))
arm_count = int(os.environ.get("CAL2_ATTACHMENTS", "3"))
reference = Path("/var/tmp/rtc-cal2-sysimage.l4jpe9MR/replacement-sysimage/01-default/ready-native.json")


def recent_taps(after, llowfs=3):
    rows = matched.tap_receipts()
    selected = {role: [row for row in rows if row["camera"] == role and
                      row["observed_ns"] > after] for role in retained.roles}
    if len(selected["cal2-llowfs"]) >= llowfs and selected["cal2-scc"]:
        return selected
    return None


def capture_gpu(destination, source):
    command = ["nvidia-smi", "--query-compute-apps=pid,gpu_uuid,process_name,used_gpu_memory",
               "--format=csv,noheader,nounits"]
    lines = m.run(*command, text=True, capture_output=True).stdout
    pids = [int(line.split(",", 1)[0]) for line in lines.splitlines() if line.strip()]
    assert source["hil"]["pid"] in pids, lines
    destination.write_text(lines)
    return dict(observed_ns=time.monotonic_ns(), simulator=source["hil"], process_gpu_rows=lines)


def camera_graph_props(objects):
    result = {}
    for role in retained.roles:
        candidates = retained.by_name(objects, role)
        assert len(candidates) == 1, (role, candidates)
        properties = m.properties(candidates[0])
        assert properties["optics.execution"] == "CapturedGraphExecution", properties
        assert int(properties["optics.captured-node-count"]) > 0, properties
        result[role] = {key: val for key, val in properties.items() if key.startswith("optics.")}
    return result


def consecutive_outputs(directory, started):
    rows = m.read_capture(directory)
    cameras = m.cameras()
    offsets = [row for row in rows if row["name"] == "llowfs-physical-offset" and
               row["observed_ns"] >= started["sent_ns"]]
    assert all(row["max_abs"] == 0 for row in offsets), offsets
    matched_rows = []
    for offset in offsets:
        camera = m.same_camera(offset, "llowfs", cameras)
        residual = m.modal_match(offset, "llowfs", rows)
        if camera is None or residual is None or camera["observed_ns"] <= started["sent_ns"]:
            continue
        assert residual["max_abs"] > 0, residual
        matched_rows.append(dict(camera=camera, offset=m.without_payload(offset),
                                 residual=m.without_payload(residual)))
    if len(matched_rows) < usage_count:
        return None
    frames = [sample["camera"]["sequence"] for sample in matched_rows]
    assert frames[:usage_count] == list(range(frames[0], frames[0] + usage_count)), frames
    return matched_rows


def stop_phases(directory, receipt):
    lines = m.run("journalctl", "--user", "--no-pager", "-o", "cat",
                  "_SYSTEMD_INVOCATION_ID=" + receipt["rtc"]["invocation"],
                  text=True, capture_output=True).stdout
    (directory / "invocation.journal").write_text(lines)
    text = "RTC systemd stop timing "
    messages = [json.loads(line[len(text):]) for line in lines.splitlines() if line.startswith(text)]
    assert len(messages) == 1, messages
    native = messages[0]
    assert native["invocation"] == receipt["rtc"]["invocation"]
    deadline = native["deadline_ns"]
    absolute = {phase: deadline - native[phase + "_remaining_ns"] for phase in
                ("quit_submission", "offline", "process_exit")}
    started = receipt["stop"]["request_ns"]
    completed = receipt["stop"]["completed_ns"]
    ordered = [started, *absolute.values(), completed]
    assert ordered == sorted(ordered), ordered
    timing = dict(systemctl_request_ns=started, **absolute, systemctl_completion_ns=completed,
                  systemctl_to_completion_s=m.seconds(completed, started),
                  quit_to_offline_s=m.seconds(absolute["offline"], absolute["quit_submission"]),
                  quit_to_process_exit_s=m.seconds(absolute["process_exit"], absolute["quit_submission"]),
                  systemctl_to_quit_s=m.seconds(absolute["quit_submission"], started),
                  native_stop_record=native)
    m.save(directory / "stop-timing.json", timing)
    return timing


def final_snapshot(source, graphs, units):
    objects = m.native_dump(scratch / "retained-final-native.json")
    retained.fixture(source, objects)
    assert retained.graph_still_live(objects, graphs)
    assert not retained.native_links(objects)
    unit_states = {unit: m.status(unit) for unit in (m.unit, m.core_name, m.hil_name, *units.values())}
    assert unit_states[m.unit]["ActiveState"] == "inactive"
    assert all(unit_states[unit]["ActiveState"] == "active" for unit in
               (m.core_name, m.hil_name, *units.values()))
    return unit_states


def run():
    scratch.mkdir()
    m.wait(lambda: (stage / "warm-lease-released").exists(), 1200, "publishing CUDA source")
    source = m.load(stage / "persistent.json")
    matched.camera_map(source)
    m.save(scratch / "gpu-initial.json", capture_gpu(scratch / "gpu-initial.csv", source))
    files = retained.fixture_inputs()
    units = {role: path.name for role, path in files.items()}
    installed = [m.unit_dir / unit for unit in (m.unit, *units.values())]
    if not any(path.exists() for path in installed):
        matched.install_units(files, [])
    else:
        assert all(path.exists() for path in installed), installed
    template = app / "systemd/pipewireao-session@.service"
    matched.input_receipts(scratch, source, files, {"direct": template})
    edge_records = retained.native_links(m.load(reference))
    edges = {edge: data["format"] for edge, data in edge_records.items()}
    graphs = retained.prestart_graphs(units, source)
    for graph in graphs.values():
        matched.events("graph-ingress", graph["unit_identity"]["pid"])
    owners_before = m.native_dump(scratch / "pre-attach-native.json")
    m.save(scratch / "cuda-camera-props.json", camera_graph_props(owners_before))
    graph_birth_us = {role: int(m.status(unit)["ExecMainStartTimestampMonotonic"])
                      for role, unit in units.items()}
    held_since = time.monotonic_ns()
    m.save(scratch / "publishing-prior-to-attachments.json",
           m.wait(lambda: recent_taps(held_since, 6), 65, "publishing CUDA camera prelude"))
    m.start_service = matched.timed_service_start
    trial_records = []
    observed = None
    for arm in range(first_arm, first_arm + arm_count):
        name = f"cuda-attach-{arm:02}"
        last = arm == first_arm + arm_count - 1
        directory, launch, ledger, receipt = matched.start("direct", name, source, graphs, units, edges)
        assert not any(arg.startswith(("-J", "--sysimage")) for arg in receipt["effective_argv"])
        receipt.update(attachment_generation=arm, retained_graph_birth_us=graph_birth_us,
                       observer_fresh_since_graph_birth=True)
        started = retained.start_open(directory, receipt)
        retained.optical_open(directory, receipt, started)
        consecutive = m.wait(lambda: consecutive_outputs(directory, started), 180,
                             f"{usage_count} consecutive open-loop LLOWFS outputs")
        m.save(directory / "consecutive-open-llowfs.json", consecutive)
        receipt["pre_quit_queue"] = ordinary.capture_queue(directory, "pre-quit")
        (directory / "workers-stopped").touch()
        (directory / "control-stop").touch()
        retained.session_gap(directory, launch, ledger, receipt, source, graphs, "graceful",
                             observe_off_camera=False)
        timing = stop_phases(directory, receipt)
        receipt["post_quit_queue"] = ordinary.capture_queue(directory, "post-quit")
        after = receipt["stop"]["completed_ns"]
        observed = m.wait(lambda: recent_taps(after, 8 if last else 3), 80,
                          "independent camera publications after ordinary Quit")
        m.save(directory / "tap-during-rtc-absence.json", observed)
        matched.evidence(directory, source, graphs, receipt)
        m.save(directory / "lifecycle.json", receipt)
        trial_records.append(dict(attachment=arm, directory=name, rtc=receipt["rtc"],
            observer=receipt["observer"], request_ns=receipt["request_ns"], ready_ns=receipt["ready_ns"],
            native_ready=receipt["native_ready"]["ready"], start=started,
            first_usable=receipt["fresh_open_priming"], open_output_count_for_llowfs=len(consecutive),
            llowfs_acquisitions=[row["camera"]["sequence"] for row in consecutive],
            stop=timing, tap_during_rtc_absence={camera: [row["sequence"] for row in rows]
                                               for camera, rows in observed.items()}))
        m.save(scratch / "trials.json", trial_records)
        print(f"{name}: {len(consecutive)} usable LLOWFS, normal Quit "
              f"{timing['quit_to_offline_s']:.3f} s to Offline", flush=True)
    assert len({trial["rtc"]["pid"] for trial in trial_records}) == len(trial_records)
    assert len({trial["observer"]["pid"] for trial in trial_records}) == len(trial_records)
    assert observed is not None
    cutoff = max(observed["cal2-llowfs"][7]["observed_ns"], observed["cal2-scc"][0]["observed_ns"])
    publication = ordinary.capture_publication_result(source, cutoff)
    assert m.load(scratch / "detector-continuity.json")["passed"], publication
    final = final_snapshot(source, graphs, units)
    m.save(scratch / "gpu-final.json", capture_gpu(scratch / "gpu-final.csv", source))
    m.save(scratch / "retained-final-owners.json", final)
    print("RTC detached. Graph services, CUDA simulator, private core and camera receiver retained.", flush=True)


if __name__ == "__main__":
    lease_path = m.runtime.parent / "rtc-devel-benchmark.lock"
    m.wait(lambda: (stage / "warm-lease-released").exists(), 1200, "CUDA fixture warmup")
    with lease_path.open("a") as benchmark:
        fcntl.flock(benchmark, fcntl.LOCK_EX)
        try:
            run()
        finally:
            for child, log in m.children.copy():
                if child.poll() is None:
                    child.terminate()
                    try:
                        child.wait(timeout=8)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait(timeout=8)
            if m.status(m.unit)["MainPID"] != "0":
                m.system("stop", m.unit, timeout=180)
            fcntl.flock(benchmark, fcntl.LOCK_UN)
