using PipeWireAORTC, PipeWireAO
const RTC = PipeWireAORTC
const C = RTC.ControlClient
const S = RTC.SessionCodec
const R = RTC.RunnerCodec
const CLI = RTC.SessionCLI
const GRAPHS = ("cal2-llowfs-controller", "cal2-scc-controller")
const CLOSE_FIELD = "correction:closed"
const STATE_PREFIX = "pipewireao.correction-control.correction:closed"
const OBSERVER_STATE = "pipewireao.frame-observer.state"

function request(client, op, args...; timeout=75)
    sent = time_ns()
    completion = C.request!(client, S.RunnerCommand(op, args...); deadline=C.monotonic()+timeout)
    received = time_ns()
    rendered = RTC.RunnerCommands.render(completion)
    return (; sent_ns=sent, received_ns=received, reply=rendered), completion
end

function snapshot(client, graph, closed)
    properties, _ = request(client, :properties, graph)
    generation, _ = request(client, :property_generation, graph, "correction")
    @assert properties.reply["ok"] && generation.reply["ok"]
    result = properties.reply["result"]
    values = result["properties"]
    @assert result["graph"] == graph
    @assert values[CLOSE_FIELD]["value"] === closed
    @assert values[STATE_PREFIX*".state"]["value"] == (closed ? "Closed" : "Open")
    @assert values[STATE_PREFIX*".requested"]["value"] === closed
    @assert isempty(values[STATE_PREFIX*".fault"]["value"])
    @assert generation.reply["result"]["graph"] == graph
    @assert generation.reply["result"]["requested"] == generation.reply["result"]["active"]
    return (; graph, properties, generation)
end

function command(client, operation, graph, guarded)
    if operation == "start"
        reply, completion = request(client, :status)
        CLI.confirm_ready(completion)
        held = [snapshot(client, name, false) for name in GRAPHS]
        @assert all(held) do entry
            !entry.properties.reply["result"]["properties"][STATE_PREFIX*".primed"]["value"]
        end
        rejected = [first(request(client, :properties_set, name,
            Dict(CLOSE_FIELD => R.RunnerScalar(:bool, true)))) for name in GRAPHS]
        for close_in_hold in rejected
            @assert close_in_hold.reply["ok"] === false
            @assert close_in_hold.reply["state"] == "Ready"
            @assert occursin("running session", close_in_hold.reply["error"]["message"])
        end
        started, _ = request(client, :session_start)
        @assert started.reply["ok"] && started.reply["state"] == "Running"
        early = if guarded
            # Issue both requests before the diagnostic snapshots.
            failures = [first(request(client, :properties_set, name,
                Dict(CLOSE_FIELD => R.RunnerScalar(:bool, true)))) for name in reverse(GRAPHS)]
            for premature in failures
                @assert premature.reply["ok"] === false premature
                @assert premature.reply["state"] == "Running"
                @assert occursin("correction closure requires a valid live open-loop measurement",
                    premature.reply["error"]["message"])
            end
            [begin
                still_open = snapshot(client, GRAPHS[i], false)
                properties = still_open.properties.reply["result"]["properties"]
                @assert properties[STATE_PREFIX*".primed"]["value"] === false
                @assert properties[OBSERVER_STATE]["value"] == "active"
                @assert still_open.generation.reply["result"]["active"] ==
                    held[i].generation.reply["result"]["active"] == 0
                (; graph=GRAPHS[i], premature, still_open)
            end for (i, premature) in zip(reverse(eachindex(GRAPHS)), failures)]
        else
            nothing
        end
        return (; held, rejected, started, early)
    elseif operation == "close"
        opened = snapshot(client, graph, false)
        if guarded
            properties = opened.properties.reply["result"]["properties"]
            @assert properties[STATE_PREFIX*".primed"]["value"] === true
            @assert properties[OBSERVER_STATE]["value"] == "active"
        end
        closed, _ = request(client, :properties_set, graph,
            Dict(CLOSE_FIELD => R.RunnerScalar(:bool, true)); timeout=480)
        @assert closed.reply["ok"] && closed.reply["state"] == "Running" closed
        result = closed.reply["result"]
        @assert result["active_adoption_observed"]
        generations = only(result["property_generations"])
        @assert generations["node"] == "correction"
        @assert generations["active"] == generations["requested"] >
            opened.generation.reply["result"]["active"]
        after = snapshot(client, graph, true)
        @assert after.generation.reply["result"]["active"] == generations["active"]
        return (; opened, closed, after)
    elseif operation == "reopen"
        closed = snapshot(client, graph, true)
        reopened, _ = request(client, :properties_set, graph,
            Dict(CLOSE_FIELD => R.RunnerScalar(:bool, false)); timeout=480)
        @assert reopened.reply["ok"] && reopened.reply["state"] == "Running" reopened
        result = reopened.reply["result"]
        @assert result["active_adoption_observed"]
        generations = only(result["property_generations"])
        @assert generations["node"] == "correction"
        @assert generations["active"] == generations["requested"] >
            closed.generation.reply["result"]["active"]
        after = snapshot(client, graph, false)
        @assert after.generation.reply["result"]["active"] == generations["active"]
        return (; closed, reopened, after)
    elseif operation == "observe"
        observed, _ = request(client, :status)
        return (; observed)
    elseif operation == "observe_fault"
        expires = C.monotonic() + 50
        while C.monotonic() < expires
            observed, _ = request(client, :status; timeout = 5)
            observed.reply["state"] == "Fault" && return (; observed)
            sleep(0.05)
        end
        error("No native Fault observed after replacement of a required graph owner")
    elseif operation == "stop"
        stopped, _ = request(client, :session_stop)
        @assert stopped.reply["ok"] && stopped.reply["state"] == "Ready"
        health, completion = request(client, :status)
        CLI.confirm_ready(completion)
        return (; stopped, health)
    end
    error("Unknown operation $operation")
end

function run(ledger, directory, remote, mode)
    d = RTC.Common.read_json(ledger)
    @assert d["remote"] == remote
    client = C.connect(RTC.SessionProfile.Profile(), remote, "pipewireao.rtc.session." * d["name"],
        d["session_pid"], d["session_control_instance"]; deadline=C.monotonic()+60)
    watch_arm = joinpath(directory, "watch-old-authority")
    try
        with_thread_loop_lock(client.loop) do _
            C.healthy(client)
            @assert client.observation.node_identity == d["session_uuid"]
            @assert client.observation.owner_pid == d["session_pid"]
            @assert client.observation.instance == d["session_control_instance"]
        end
        ready, completion = request(client, :status)
        CLI.confirm_ready(completion)
        held = [snapshot(client, name, false) for name in GRAPHS]
        @assert all(held) do entry
            state = entry.properties.reply["result"]["properties"]
            !state[STATE_PREFIX*".primed"]["value"]
        end
        started = if mode=="restart"
            outcome, _ = request(client, :session_start)
            @assert outcome.reply["ok"] && outcome.reply["state"] == "Running"
            outcome
        else
            nothing
        end
        RTC.Common.write_json(joinpath(directory, "control-online.json"),
            (; ready, held, started, uuid=d["session_uuid"], instance=client.observation.instance,
                pid=d["session_pid"], endpoint=client.global_id, serial=client.serial);
            atomic=true)
        mode=="restart" && return
        for idx in 1:16
            path = joinpath(directory, "command-$idx.json")
            while !isfile(path)
                if isfile(watch_arm)
                    retired = joinpath(directory, "old-authority-withdrawn.json")
                    try
                        snapshot, _ = request(client, :status; timeout = 5)
                        if snapshot.reply["ok"]
                            sleep(0.05)
                            continue
                        end
                        outcome = (; snapshot)
                        RTC.Common.write_json(retired, outcome; atomic = true)
                    catch err
                        outcome = (; error = sprint(showerror, err))
                        RTC.Common.write_json(retired, outcome; atomic = true)
                    end
                    return
                end
                isfile(joinpath(directory,"control-stop")) && return
                sleep(0.01)
            end
            instruction = RTC.Common.read_json(path)
            mode == "held-only" && instruction["operation"] in ("close", "open") &&
                error("correction settings remain Open in the sysimage comparison")
            result = command(client, instruction["operation"], get(instruction, "graph", ""), mode=="guarded")
            RTC.Common.write_json(joinpath(directory, "response-$idx.json"), result; atomic=true)
        end
    finally
        close(client)
    end
end
run(ARGS...)
