"""Qualify a sealed CAL2 replacement against the same independent CPU simulator."""
from pathlib import Path
import shutil
import time

import matched
import measure as m
import replacement as lifecycle


stage, scratch, app = matched.stage, matched.scratch, matched.app
cameras = ('cal2-llowfs', 'cal2-scc')


def observed(start, end=None):
    return {name: [row for row in m.cameras() if row['camera'] == name
                   and start <= row['observed_ns'] and (end is None or row['observed_ns'] < end)]
            for name in cameras}


def wait_for_cameras(since, count, label):
    def sufficient():
        rows = observed(since)
        return rows if all(len(samples) >= count for samples in rows.values()) else None
    return m.wait(sufficient, 360, label)


def queue_snapshot(directory, label):
    objects = m.native_dump(directory / f'{label}-native.json')
    properties = {}
    for name in cameras:
        matches = [m.properties(obj) for obj in objects if obj['type'].endswith(':Module')
                   and m.properties(obj).get('node.name') == f'{name}-image-queue']
        assert len(matches) == 1, (name, matches)
        properties[name] = {key: value for key, value in matches[0].items() if key.startswith('queue.')}
    return objects, properties


def trial(name, source, graphs, units, expected_edges, detached_count):
    directory = scratch / name
    launch, ledger, receipt, _, edges = lifecycle.start(directory, source, graphs, units, expected_edges)
    args = Path(f'/proc/{receipt["rtc"]["pid"]}/cmdline').read_bytes().decode().strip('\0').split('\0')
    assert all(arg != '-J' and not arg.startswith(('-J', '--sysimage')) for arg in args), args
    receipt['effective_argv'] = args
    ready = receipt['native_ready']['ready']['received_ns']
    started = lifecycle.start_open(directory, receipt)
    lifecycle.optical_open(directory, receipt, started)
    receipt['confirmed_primed_open'] = m.acknowledge(directory, 2, 'confirm-primed-open')
    _, pre = queue_snapshot(directory, 'queue-pre-quit')
    receipt['before_quit_queue'] = pre
    m.save(directory / 'lifecycle.json', receipt)
    receipt['native_stop'] = m.acknowledge(directory, 3, 'stop')
    lifecycle.session_gap(directory, launch, ledger, receipt, source, graphs, 'graceful', observe_off_camera=False)
    def closed_capture_pools():
        objects, counters = queue_snapshot(directory, 'queue-post-quit')
        return (objects, counters) if all(sample['queue.state.capture-buffers'] == 0
                                          for sample in counters.values()) else None
    post_objects, post = m.wait(closed_capture_pools, 10, 'retired native capture-pool statistics')
    lifecycle.fixture(source, post_objects)
    assert not lifecycle.native_links(post_objects)
    assert lifecycle.graph_still_live(post_objects, graphs)
    for name in cameras:
        before, after = pre[name], post[name]
        assert before['queue.state.pending-depth'] == 1, (name, before)
        assert before['queue.state.playback-buffers'] == 0, (name, before)
        assert before['queue.state.capture-buffers'] > 0, (name, before)
        assert after['queue.state.pending-depth'] == 0, (name, after)
        assert after['queue.state.capture-buffers'] == 0, (name, after)
        assert after['queue.stats.protocol-errors'] == before['queue.stats.protocol-errors'] == 0, (name, after)
        assert after['queue.stats.withdrawal-returns'] == before['queue.stats.withdrawal-returns'] + 1, (name, before, after)
        assert after['queue.stats.deliveries'] == after['queue.stats.completions'] == 0, (name, after)
        assert after['queue.stats.publications'] == (after['queue.stats.replacements'] +
                                                    after['queue.stats.withdrawal-returns']), (name, after)
    stop = receipt['stop']
    receipt['after_quit_queue'] = post
    receipt['detached'] = wait_for_cameras(stop['completed_ns'], detached_count,
                                           'both cameras advance with no RTC attached')
    final = m.native_dump(directory / 'detached-native.json')
    lifecycle.fixture(source, final)
    assert lifecycle.graph_still_live(final, graphs)
    assert not lifecycle.native_links(final)
    receipt['camera_windows'] = {
        'held': observed(ready, started['sent_ns']),
        'running': observed(started['received_ns'], stop['request_ns']),
        'quitting': observed(stop['request_ns'], stop['completed_ns']),
        'detached': receipt['detached'],
    }
    m.save(directory / 'lifecycle.json', receipt)
    print(f'{directory.name}: both independent cameras advanced with the RTC detached', flush=True)
    return receipt, edges


def run():
    scratch.mkdir()
    def service_start(_directory):
        requested = time.monotonic_ns()
        m.system('start', m.unit, timeout=500)
        return requested, time.monotonic_ns()
    m.start_service = service_start
    source = m.load(stage / 'persistent.json')
    files = lifecycle.fixture_inputs()
    units = {role: path.name for role, path in files.items()}
    claimed = []
    try:
        matched.install_units(files, claimed)
        matched.input_receipts(scratch, source, files, {'direct': app / 'systemd/pipewireao-session@.service'})
        graphs = lifecycle.prestart_graphs(units, source)
        a, expected_edges = trial('initial', source, graphs, units, None, 2)
        b, _ = trial('replacement', source, graphs, units, expected_edges, 1)
        assert a['rtc']['pid'] != b['rtc']['pid'], (a['rtc'], b['rtc'])
        assert a['rtc']['invocation'] != b['rtc']['invocation']
        observed_final = observed(0)
        for name, rows in observed_final.items():
            assert (b['before_quit_queue'][name]['queue.state.capture-generation'] >
                    a['before_quit_queue'][name]['queue.state.capture-generation']), name
            assert len({(row['domain'], row['generation']) for row in rows}) == 1, name
            assert all(right['model_ns'] > left['model_ns'] and right['sequence'] == left['sequence'] + 1
                       for left, right in zip(rows, rows[1:])), (name, rows)
            replaced = b['fresh_open_priming'][name.removeprefix('cal2-')]['camera']
            assert max(row['sequence'] for row in a['detached'][name]) < replaced['sequence'], (name, replaced)
        m.save(scratch / 'camera-continuity.json', observed_final)
        lifecycle.full_shutdown(source, units, wait_for_camera=False)
        m.save(scratch / 'lifecycle-passed.json', {'passed': True, 'rtc_initial': a['rtc'],
            'rtc_replacement': b['rtc'], 'simulator': source['hil'], 'core': source['core'], 'graph_owners': graphs})
    finally:
        for child, _ in m.children:
            if child.poll() is None:
                child.terminate()
                child.wait(timeout=20)
        try:
            lifecycle.remove_runtime_units(claimed)
        finally:
            lifecycle.capture_journal(claimed)
            if m.rtc_runtime.is_dir():
                shutil.rmtree(m.rtc_runtime)


if __name__ == '__main__':
    run()
