"""Summarize installed CAL2 qualification timestamps and transport evidence."""
import json
from pathlib import Path


stage = Path(__file__).resolve().parent
receipt_dir = stage / 'replacement-qualification'


def read(path):
    return json.loads(path.read_text())


def seconds(end, start):
    return round((end - start) / 1_000_000_000, 6)


def summarize_trial(trial, continuity):
    start = trial['running']['started']
    quit_time = trial['stop']
    ready = trial['native_ready']['ready']['received_ns']
    streams = {}
    for name, camera_rows in continuity.items():
        branch = name.removeprefix('cal2-')
        sample = trial['fresh_open_priming'][branch]
        initial = trial['before_quit_queue'][name]
        final = trial['after_quit_queue'][name]
        before = [row for row in camera_rows if row['observed_ns'] < quit_time['request_ns']]
        after = trial['detached'][name]
        streams[name] = {
            'acquisition_domain': sample['camera']['domain'], 'acquisition_generation': sample['camera']['generation'],
            'first_usable_sequence': sample['camera']['sequence'], 'first_usable_model_ns': sample['camera']['model_ns'],
            'first_usable_s_after_start': seconds(sample['residual']['observed_ns'], start['received_ns']),
            'residual_peak': sample['residual']['max_abs'], 'physical_offset_peak': sample['offset']['max_abs'],
            'last_before_quit_sequence': before[-1]['sequence'], 'observed_during_quit': [
                row['sequence'] for row in trial['camera_windows']['quitting'][name]],
            'detached_sequences': [row['sequence'] for row in after],
            'first_detached_s_after_quit': seconds(after[0]['observed_ns'], quit_time['completed_ns']),
            'queue_capture_generation': initial['queue.state.capture-generation'],
            'queue_pending_count': [initial['queue.state.pending-depth'], final['queue.state.pending-depth']],
            'queue_capture_buffer_count': [initial['queue.state.capture-buffers'], final['queue.state.capture-buffers']],
            'queue_capture_loan_returns': final['queue.stats.withdrawal-returns'] - initial['queue.stats.withdrawal-returns'],
        }
    return {'rtc': trial['rtc'], 'service_ready_s': trial['request_to_systemd_ready_s'],
            'status_ready_receipt_s': seconds(ready, trial['request_ns']),
            'native_quit_s_including_service_cleanup': seconds(quit_time['completed_ns'], quit_time['request_ns']),
            'stream_receipts': streams}


def main():
    continuity = read(receipt_dir / 'camera-continuity.json')
    report = read(receipt_dir / 'lifecycle-passed.json')
    report['trials'] = {name: summarize_trial(read(receipt_dir / name / 'lifecycle.json'), continuity)
                        for name in ('initial', 'replacement')}
    report['tap_continuity'] = {name: {'first': rows[0]['sequence'], 'last': rows[-1]['sequence'], 'count': len(rows)}
                                for name, rows in continuity.items()}
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
