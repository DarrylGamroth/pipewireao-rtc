#!/usr/bin/env bash
set -euo pipefail
scratch=$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$scratch/session-env.sh"
export TMPDIR=/var/tmp
export CAL2_VALIDATION_JLL_VERSION=${CAL2_VALIDATION_JLL_VERSION:-4.0.10+0}
export CUDA_VISIBLE_DEVICES= HIP_VISIBLE_DEVICES= ROCR_VISIBLE_DEVICES=
repo=/home/dgamroth/workspaces/codex/worktrees/rtc-native-queue-release
retained_export=/var/tmp/rtc-ndarray-integration.beRGH1/cal2/candidate-combined-gated-export

case "${1:?select install or run}" in
  install)
    release="${2:?RTC Git revision}"
    if [[ -f "$scratch/candidate-source.json" ]]; then
      export_dir="$scratch/cal2-export"
      [[ $(jq -r .commit "$scratch/candidate-source.json") == "$release" ]]
      [[ $(jq -r .native.version "$scratch/candidate-source.json") == "$CAL2_VALIDATION_JLL_VERSION" ]]
    else
      export_dir=$(python3 "$scratch/stage.py" "$repo" "$retained_export" "$release" "$CAL2_VALIDATION_JLL_VERSION")
    fi
    expected_source=$(jq -r .source "$scratch/candidate-source.json")
    exec taskset -c 10,11 "$julia" --startup-file=no --threads=1,0 --project="$export_dir" \
      "$scratch/install.jl" "$export_dir" "$scratch/candidate-app" "$expected_source"
    ;;
  source|qualify|run)
    export CAL2_NATIVE_PREFIX
    CAL2_NATIVE_PREFIX=$("$julia" --startup-file=no --project="$scratch/candidate-app" -e \
      'using PipeWireAO_jll; @assert pkgversion(PipeWireAO_jll) == VersionNumber(ENV["CAL2_VALIDATION_JLL_VERSION"]); print(PipeWireAO_jll.artifact_dir)')
    source "$scratch/session-env.sh"
    export TMPDIR=/var/tmp
    discard="$prefix/lib/spa-ao-0.2/discard/libspa-pipewireao-discard.so"
    LD_LIBRARY_PATH="$prefix/lib" "$prefix/bin/pwao-spa-inspect" "$discard" > "$scratch/discard-factory.txt"
    rg -q "factory name:[[:space:]]+'api.pipewireao.discard'" "$scratch/discard-factory.txt"
    rg -q '^factory instance:' "$scratch/discard-factory.txt"
    if rg -qi '^[[:space:]]*(error|can.t|failed)' "$scratch/discard-factory.txt"; then exit 1; fi
    export CAL2_VALIDATION_HIL_ENTRYPOINT
    CAL2_VALIDATION_HIL_ENTRYPOINT=$("$julia" --startup-file=no --project="$scratch/candidate-app" -e \
      'print(joinpath(dirname(Base.find_package("AdaptiveOpticsSimPipeWireHIL")), "independent.jl"))')
    export CAL2_VALIDATION_VARIANT=candidate CAL2_VALIDATION_ATTEMPT=qualification
    [[ -f "$CAL2_VALIDATION_HIL_ENTRYPOINT" ]]
    if [[ $1 == source ]]; then
      printf '%s\n' "$$" > "$scratch/fixture.pid"
      exec taskset -c 14,15 python3 -u "$scratch/driver.py" > "$scratch/fixture.log" 2>&1
    elif [[ $1 == qualify ]]; then
      read -r fixture_pid < "$scratch/fixture.pid"
    else
      taskset -c 14,15 python3 -u "$scratch/driver.py" > "$scratch/fixture.log" 2>&1 &
      fixture_pid=$!
      trap 'touch "$scratch/finish"; wait "$fixture_pid"' EXIT
    fi
    until [[ -f "$scratch/warm-lease-released" ]]; do
      kill -0 "$fixture_pid"
      sleep 0.5
    done
    taskset -c 14,15 python3 -u "$scratch/qualify.py"
    ;;
  *) exit 2 ;;
esac
