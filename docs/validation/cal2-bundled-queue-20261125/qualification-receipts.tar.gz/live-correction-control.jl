using PipeWireAORTC, PipeWireAO

const RTC = PipeWireAORTC
const ControlClient = RTC.ControlClient
const GRAPHS = ("cal2-llowfs-controller", "cal2-scc-controller")
const CLOSED = "correction:closed"
const CORRECTION = "pipewireao.correction-control." * CLOSED
const FRAME_OBSERVER_STATE = "pipewireao.frame-observer.state"

function request(client, operation, arguments...)
    sent_ns = time_ns()
    command = RTC.SessionCodec.RunnerCommand(operation, arguments...)
    completion = ControlClient.request!(client, command; deadline = ControlClient.monotonic() + 75)
    received_ns = time_ns()
    reply = RTC.RunnerCommands.render(completion)
    @assert reply["ok"] reply
    return (; sent_ns, received_ns, reply)
end

function require_state(result, state)
    @assert result.reply["state"] == state result
    return result
end

function held_ready(client)
    result = require_state(request(client, :status), "Ready")
    @assert result.reply["result"]["running"] === false result
    return result
end

function open_state(client, graph, primed)
    properties = request(client, :properties, graph)
    generation = request(client, :property_generation, graph, "correction")
    @assert properties.reply["result"]["graph"] == graph properties
    @assert generation.reply["result"]["graph"] == graph generation
    @assert generation.reply["result"]["requested"] == generation.reply["result"]["active"] generation
    values = properties.reply["result"]["properties"]
    @assert values[CLOSED]["value"] === false values
    @assert values[CORRECTION * ".state"]["value"] == "Open" values
    @assert values[CORRECTION * ".requested"]["value"] === false values
    @assert isempty(values[CORRECTION * ".fault"]["value"]) values
    @assert values[CORRECTION * ".primed"]["value"] === primed values
    if primed
        @assert values[FRAME_OBSERVER_STATE]["value"] == "active" values
    end
    return (; graph, properties, generation)
end

function run(ledger, directory, remote, mode)
    @assert mode == "held-only" mode
    record = RTC.Common.read_json(ledger)
    @assert record["direct_attach"] === true record
    @assert record["remote"] == remote record
    client = ControlClient.connect(RTC.SessionProfile.Profile(), remote,
        "pipewireao.rtc.session." * record["name"], record["session_pid"],
        record["session_control_instance"]; deadline = ControlClient.monotonic() + 60)
    try
        with_thread_loop_lock(client.loop) do _
            ControlClient.healthy(client)
            @assert client.observation.node_identity == record["session_uuid"]
            @assert client.observation.owner_pid == record["session_pid"]
            @assert client.observation.instance == record["session_control_instance"]
        end
        ready = held_ready(client)
        held = [open_state(client, graph, false) for graph in GRAPHS]
        RTC.Common.write_json(joinpath(directory, "control-online.json"),
            (; ready, held, uuid = record["session_uuid"], instance = client.observation.instance,
                pid = record["session_pid"], endpoint = client.global_id, serial = client.serial); atomic = true)
        for (index, operation) in enumerate(("start", "confirm-primed-open", "stop"))
            path = joinpath(directory, "command-$index.json")
            while !isfile(path)
                isfile(joinpath(directory, "control-stop")) && return nothing
                sleep(0.01)
            end
            @assert RTC.Common.read_json(path)["operation"] == operation path
            result = if operation == "start"
                held_ready(client)
                (; started = require_state(request(client, :session_start), "Running"))
            elseif operation == "confirm-primed-open"
                (; opened = [open_state(client, graph, true) for graph in GRAPHS])
            else
                (; stopped = require_state(request(client, :session_stop), "Ready"),
                    health = held_ready(client))
            end
            RTC.Common.write_json(joinpath(directory, "response-$index.json"), result; atomic = true)
        end
        while !isfile(joinpath(directory, "control-stop"))
            sleep(0.01)
        end
    finally
        close(client)
    end
    return nothing
end

abspath(PROGRAM_FILE) == (@__FILE__) && run(ARGS...)
