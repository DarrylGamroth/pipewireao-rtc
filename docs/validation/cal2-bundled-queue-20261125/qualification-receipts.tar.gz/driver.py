import fcntl, json, os, pathlib, shutil, subprocess, time, signal
from hashlib import file_digest
P = pathlib.Path
stage = P(__file__).resolve().parent
app = stage / "candidate-app"
runtime = P(os.environ["PIPEWIREAORTC_CORE_SOCKET"]).parent
socket = runtime / "c"
prefix = P(os.environ["PIPEWIREAO_PREFIX"])
julia = os.environ["CAL2_VALIDATION_JULIA"]
reference = stage / "observer-reference"
tag = os.environ["CAL2_VALIDATION_TAG"]
core_name, hil_name = (os.environ[key] for key in ("PIPEWIREAORTC_CORE_UNIT", "PIPEWIREAORTC_SOURCE_UNIT"))
services = (hil_name, core_name)
depots = os.environ["JULIA_DEPOT_PATH"]
sdk_modules = str(prefix / "lib/pipewire-ao-0.3")
queue = os.environ["CAL2_VALIDATION_QUEUE_MODULE"]
hil_project = os.environ.get("CAL2_HIL_PROJECT", str(app))
julia_command = [julia,"--startup-file=no","--threads=2,0","--project="+hil_project]
helper_julia = ["taskset","-c","12,13",julia,"--startup-file=no","--threads=2,1","-O0","--project="+str(app)]
native = dict(PIPEWIREAO_RUNTIME_DIR=str(runtime), PIPEWIRE_RUNTIME_DIR=str(runtime),
    PIPEWIREAO_CONFIG_DIR=str(stage / "core-config"),
    PIPEWIREAO_MODULE_DIR=sdk_modules,
    PIPEWIREAO_SPA_PLUGIN_DIR=str(prefix / "lib/spa-ao-0.2"),
    LD_LIBRARY_PATH=str(prefix / "lib"))
environment = dict(os.environ, **native)
client_native = dict(native, PIPEWIREAO_MODULE_DIR=sdk_modules)
child_env = dict(os.environ, **client_native)
keep = {key:os.environ[key] for key in (
    "JULIA_DEPOT_PATH","JULIA_LOAD_PATH","JULIA_PKG_PRECOMPILE_AUTO","JULIA_NUM_PRECOMPILE_TASKS",
    "JULIA_IMAGE_THREADS","OPENBLAS_NUM_THREADS","TMPDIR","XDG_CACHE_HOME","POCL_CACHE_DIR")}
children = []
claimed = False

def run(*args,timeout=30,env=None,**kwargs):
    return subprocess.run([str(arg) for arg in args],check=True,timeout=timeout,env=env,**kwargs)
def system(*args,**kwargs):
    return run("systemctl","--user",*args,**kwargs)
def service_status(name):
    p=system("show",name,"-p","ActiveState,SubState,MainPID,InvocationID,Result,FragmentPath,ExecMainStartTimestampMonotonic,ActiveEnterTimestampMonotonic,ControlGroup",
        text=True,capture_output=True)
    return dict(line.split("=",1) for line in p.stdout.splitlines() if "=" in line)
def now():
    return time.monotonic_ns()
def wait(predicate,seconds,label):
    stop=now()+int(seconds*1e9)
    while now()<stop:
        value=predicate()
        if value:
            return value
        time.sleep(.15)
    raise RuntimeError(f"Timed out awaiting {label}")
def persist(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
def core_transport(core, hil):
    paths = sorted({line.split(maxsplit=5)[5] for line in
                    P(f"/proc/{core['pid']}/maps").read_text().splitlines()
                    if "libpipewire-module-queue.so" in line or "libpipewire-ao-0.3.so." in line})
    expected = {str(P(queue).resolve()), str((prefix / "lib/libpipewire-ao-0.3.so").resolve())}
    assert set(paths) == expected, (paths, expected)
    native_library = str((prefix / "lib/libpipewire-ao-0.3.so").resolve())
    hil_libraries = sorted({line.split(maxsplit=5)[5] for line in
                            P(f"/proc/{hil['pid']}/maps").read_text().splitlines()
                            if "libpipewire-ao-0.3.so." in line})
    assert hil_libraries == [native_library], (hil_libraries, native_library)
    digests = {}
    for path in paths:
        with open(path,"rb") as file:
            digests[path] = file_digest(file,"sha256").hexdigest()
    discard = (prefix / "lib/spa-ao-0.2/discard/libspa-pipewireao-discard.so").resolve(strict=True)
    with discard.open("rb") as file:
        discard_digest = file_digest(file, "sha256").hexdigest()
    return dict(mappings=digests, simulator_native_library=hil_libraries[0],
                discard_package_file={str(discard): discard_digest},
                monotonic_ns=now(), wall_ns=time.time_ns())
def start_owner(unit,cpu,env,command,log=None):
    args=["systemd-run","--user",f"--unit={unit}","--property=Type=exec",
          f"--property=CPUAffinity={cpu}","--property=KillSignal=SIGINT","--property=TimeoutStopSec=45",
          "--property=UMask=0077"]
    if log is not None:
        args.extend([f"--property=StandardOutput=append:{log}",f"--property=StandardError=append:{log}"])
    args.extend(f"--setenv={key}={value}" for key,value in env.items())
    run(*args,*command)
def launch(args,log,env=child_env):
    with open(log,"w") as output:
        child=subprocess.Popen([str(arg) for arg in args],env=env,stdout=output,stderr=subprocess.STDOUT)
    children.append(child)
    return child
def check_child(child,file):
    if child.poll() is not None:
        raise RuntimeError(f"Fixture exited {child.returncode}: {file}")
def stat_ticks(pid):
    return int(P(f"/proc/{pid}/stat").read_text().rsplit(')',1)[1].split()[19])
def live_service(unit):
    status=service_status(unit)
    assert status["ActiveState"]=="active",status
    pid=int(status["MainPID"])
    return {"pid":pid,"ticks":stat_ticks(pid),"invocation":status["InvocationID"]}
def dump(path):
    with open(path,"w") as sink:
        run(prefix/"bin/pwao-dump","-r",socket,env=child_env,stdout=sink)
    return json.loads(path.read_text())
def persistent_nodes(objects):
    result = {}
    by_id = {int(o["id"]):o for o in objects}
    roles={"cal2-pupil-input","cal2-llowfs","cal2-scc","independent-cal2-observe-cal2-llowfs","independent-cal2-observe-cal2-scc"}
    for o in objects:
        props=o.get("info",{}).get("props",{})
        name=props.get("node.name")
        if name in roles and o["type"].endswith(":Node"):
            client=by_id[int(props["client.id"])]["info"]["props"]
            result[name]={"id":o["id"],"serial":props["object.serial"],"client_serial":client["object.serial"],
                "client_pid":client["pipewire.sec.pid"]}
        if o["type"].endswith(":Link") and str(props.get("object.path","")).startswith("independent-cal2/"):
            result[props["object.path"]]={"id":o["id"],"serial":props["object.serial"]}
    assert len(result)==8,result
    return result
def feeder_recent():
    lines=(stage/"camera-trace.tsv").read_text().splitlines()
    return {name:next((line.split("\t") for line in reversed(lines) if line.startswith(name+"\t")),None)
        for name in ("cal2-llowfs","cal2-scc")}
def after(old):
    recent=feeder_recent()
    return recent if all(recent[k] and int(recent[k][1])>int(old[k][1]) for k in old) else None
def write_control(ledger,phase,path):
    with open(path,"w") as output:
        run(*helper_julia,stage/"control.jl",ledger,phase,socket,timeout=160,env=child_env,stdout=output)
    return json.loads(path.read_text())
def exercise(lease):
    global claimed
    retained_core = os.environ.get("CAL2_RETAIN_CORE")
    if retained_core:
        old_service = json.loads(P(retained_core).read_text())
        core = live_service(core_name)
        assert core == old_service["core"] and socket.stat().st_ino == old_service["inode"], core
    else:
        assert not os.path.lexists(runtime),runtime
    for name in (hil_name,) if retained_core else services:
        p=system("show",name,"-p","LoadState","--value",text=True,capture_output=True)
        assert p.stdout.strip()=="not-found", (name,p.stdout)
    claimed = True
    if not retained_core:
        runtime.mkdir(mode=0o700)
        cfg=stage/"core-config"
        cfg.mkdir(exist_ok=True)
        rel=json.loads((app/"deployment.conf").read_text())["core"]
        (cfg/"daemon.conf").write_text((app/rel).read_text().replace("@REMOTE@","c"))
        shutil.copyfile(app/"shared-runtime/client-simulator.conf.in",cfg/"client.conf")
        start_owner(core_name,3,native | {"PIPEWIREAO_DEBUG":os.environ["CAL2_CORE_DEBUG"]},
                    [prefix/"bin/pipewire-ao","-c","daemon.conf"],stage/"core-native.log")
        wait(socket.is_socket,30,"private core socket")
        core=live_service(core_name)
    hil_source=os.environ["CAL2_VALIDATION_HIL_ENTRYPOINT"]
    stream_debug = {"PIPEWIREAO_DEBUG":os.environ["CAL2_STREAM_DEBUG"]}
    start_owner(hil_name,6,dict(client_native, **keep, **stream_debug),[*julia_command,hil_source,
        "--config",app/"simulation.conf","--remote",socket,"--pipewire-cpu","7"],stage/"hil-native.log")
    feed=launch([*helper_julia,stage/"feed.jl",app,socket,stage,reference],stage/"feed.log",
                child_env | stream_debug)
    def optics_ready():
        check_child(feed,stage/"feed.log")
        assert service_status(hil_name)["ActiveState"]=="active"
        return (stage/"feed-ready").exists()
    wait(optics_ready,420,"independent CAL2 HIL plus real LLOWFS/SCC frames")
    hil=live_service(hil_name)
    observed=dump(stage/"before-first-native.json")
    retained=persistent_nodes(observed)
    assert all(int(v["client_pid"])==hil["pid"] for k,v in retained.items() if k in
        {"cal2-pupil-input","cal2-llowfs","cal2-scc"})
    inode=socket.stat().st_ino
    persist(stage/"persistent.json",dict(core=core,hil=hil,inode=inode,native=retained,
        hil_project=hil_project,core_retained=bool(retained_core),transport=core_transport(core, hil)))
    print("CAL2 independent HIL initial publication", feeder_recent(), flush=True)
    fcntl.flock(lease,fcntl.LOCK_UN)
    (stage/"warm-lease-released").touch()
    print("CAL2 pupil feeder remains active and startup lease released",flush=True)
    stop=stage/"finish"
    while not stop.exists():
        check_child(feed,stage/"feed.log")
        time.sleep(1)

def interrupt(signum, _frame):
    raise InterruptedError(f"Fixture interrupted by signal {signum}")

signal.signal(signal.SIGTERM, interrupt)
signal.signal(signal.SIGINT, interrupt)

def cleanup():
    if not claimed:
        return
    (stage/"stop-feed").touch()
    for child in children:
        if child.poll() is None:
            try: child.wait(timeout=10)
            except subprocess.TimeoutExpired: child.terminate()
    try: system("stop",hil_name,core_name,timeout=120)
    except Exception: pass
    with open(stage/"journal.txt","w") as output:
        subprocess.run(["journalctl","--user","--no-pager","-o","short-monotonic","--all",*[v for name in services for v in ("-u",name)]],
            stdout=output,stderr=subprocess.STDOUT,timeout=90,check=False)
    if runtime.is_dir(): shutil.rmtree(runtime)

lock=runtime.parent/"rtc-devel-benchmark.lock"
with open(lock,"a") as acquired:
    print("CAL2 independent ready to queue for benchmark lock",lock,flush=True)
    fcntl.flock(acquired,fcntl.LOCK_EX)
    print("CAL2 independent has benchmark lock",flush=True)
    try: exercise(acquired)
    finally: cleanup()
