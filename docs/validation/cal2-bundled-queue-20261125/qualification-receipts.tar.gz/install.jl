using Pkg
using PipeWireAORTC, PipeWireAO_jll

export_path, destination, expected_source = ARGS
project = joinpath(export_path, "Project.toml")
@assert realpath(Base.active_project()) == realpath(project)
@assert realpath(pkgdir(PipeWireAORTC)) == realpath(expected_source)
@assert pkgversion(PipeWireAO_jll) == VersionNumber(ENV["CAL2_VALIDATION_JLL_VERSION"])
ENV["PIPEWIREAO_PREFIX"] = PipeWireAO_jll.artifact_dir
@show pkgdir(PipeWireAORTC) pkgversion(PipeWireAORTC) pkgversion(PipeWireAO_jll) PipeWireAO_jll.artifact_dir
manifest = joinpath(export_path, "Manifest.toml")
project_hash = Pkg.Types.project_resolve_hash(Pkg.Types.EnvCache(project), VERSION)
write(manifest, replace(read(manifest, String), r"(?m)^project_hash = \"[^\"]+\"$" =>
    "project_hash = \"$project_hash\""))
repository = export_path * ".git"
if !isdir(repository)
    PipeWireAORTC.InstrumentExport.seal!(export_path)
    @assert PipeWireAORTC.GitExport.snapshot!(export_path) == repository
end
commit = readchomp(`git --git-dir=$repository rev-parse HEAD`)
PipeWireAORTC.SessionInstall.install((;
    package = export_path, destination, pipewire_prefix = PipeWireAO_jll.artifact_dir,
    git_repository = repository, git_commit = commit, persistent_graph_owners = true,
))
