"""Stage the retained calibrated CAL2 export with the exact RTC and JLL trees."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import tomllib


stage = Path(__file__).resolve().parent


def git(repository, *args):
    return subprocess.check_output(["git", "-C", repository, *args], text=True).strip()


def package_section(manifest, name):
    return re.search(rf"(?m)^\[\[deps\.{name}\]\]\n.*?(?=^\[\[deps\.|\Z)", manifest, re.S)


def stage_application(repo, original, revision, version):
    commit = git(repo, "rev-parse", f"{revision}^{{commit}}")
    tree = git(repo, "rev-parse", f"{commit}^{{tree}}")
    metadata = tomllib.loads(git(repo, "show", f"{commit}:Project.toml"))
    resolved = git(repo, "show", f"{commit}:Manifest.toml")
    native = tomllib.loads(resolved)["deps"]["PipeWireAO_jll"][0]
    assert native["version"] == version, native
    slug = subprocess.check_output([
        os.environ["CAL2_VALIDATION_JULIA"], "--startup-file=no", "-e",
        'using UUIDs; print(Base.version_slug(UUID(ARGS[1]), Base.SHA1(hex2bytes(ARGS[2]))))',
        metadata["uuid"], tree,
    ], text=True)
    package = stage / "depot/packages/PipeWireAORTC" / slug
    package.mkdir(parents=True, exist_ok=True)
    with subprocess.Popen(["git", "-C", repo, "archive", commit], stdout=subprocess.PIPE) as archive:
        subprocess.run(["tar", "-x", "-C", package], stdin=archive.stdout, check=True)
        assert archive.wait() == 0
    export = stage / "cal2-export"
    export.mkdir()
    subprocess.run(["cp", "-aL", "--reflink=auto", f"{original}/.", export], check=True)
    deployment = export / "deployment.conf"
    spec = json.loads(deployment.read_text())
    spec["name"] = "cal2-" + os.environ["CAL2_VALIDATION_TAG"].lower()
    deployment.write_text(json.dumps(spec, sort_keys=True, separators=(",", ":")) + "\n")

    project = export / "Project.toml"
    text = project.read_text()
    declarations, compat_header, bounds = text.partition("[compat]\n")
    assert compat_header
    for name, bound in (("PipeWireAORTC", metadata["version"]), ("PipeWireAO_jll", version.split("+")[0])):
        bounds, count = re.subn(rf'(?m)^{name} = "[^"]+"$', f'{name} = "={bound}"', bounds)
        assert count == 1, (name, count)
    project.write_text(declarations + compat_header + bounds)

    path = export / "Manifest.toml"
    manifest = path.read_text()
    for name in ("PipeWireAO", "PipeWireAO_jll"):
        manifest = manifest.replace(package_section(manifest, name)[0], package_section(resolved, name)[0])
    rtc = package_section(manifest, "PipeWireAORTC")[0]
    record = re.sub(r'(?m)^deps = .+$', "deps = " + json.dumps(sorted(metadata["deps"])), rtc, count=1)
    record = re.sub(r'(?m)^git-tree-sha1 = .+$', f'git-tree-sha1 = "{tree}"', record, count=1)
    record = re.sub(r'(?m)^version = .+$', f'version = "{metadata["version"]}"', record, count=1)
    manifest = manifest.replace(rtc, record)
    obsolete = package_section(manifest, "PipeWireAOQueue_jll")
    if obsolete is not None:
        assert "PipeWireAOQueue_jll" not in metadata["deps"]
        manifest = manifest.replace(obsolete[0], "")
    packages = tomllib.loads(manifest)["deps"]
    assert packages["PipeWireAORTC"][0]["git-tree-sha1"] == tree
    assert packages["PipeWireAO_jll"][0] == native
    assert "PipeWireAOQueue_jll" not in packages
    path.write_text(manifest)
    receipt = {"commit": commit, "tree": tree, "source": str(package), "app": str(stage / "candidate-app"),
               "source_export": str(original), "source_export_revision": git(f"{original}.git", "rev-parse", "HEAD"),
               "native": native}
    (stage / "candidate-source.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(export)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path)
    parser.add_argument("original", type=Path)
    parser.add_argument("revision")
    parser.add_argument("version")
    options = parser.parse_args()
    stage_application(options.repo, options.original, options.revision, options.version)
