include(joinpath(@__DIR__, "live-correction-control.jl"))

for (owner, name) in ((RTC.Common, :read_json), (RTC.Common, :write_json),
        (RTC.SessionProfile, :Profile), (RTC.SessionCodec, :RunnerCommand),
        (RTC.RunnerCommands, :render), (ControlClient, :connect), (ControlClient, :request!),
        (ControlClient, :healthy), (ControlClient, :monotonic), (PipeWireAO, :with_thread_loop_lock))
    @assert isdefined(owner, name) (owner, name)
end
for (operation, arguments) in ((:status, ()), (:session_start, ()), (:session_stop, ()),
        (:properties, (GRAPHS[1],)), (:property_generation, (GRAPHS[2], "correction")))
    @assert RTC.SessionCodec.RunnerCommand(operation, arguments...) isa RTC.SessionCodec.RunnerCommand
end
ready = (; reply = Dict("ok" => true, "state" => "Ready", "result" => Dict("running" => false)))
@assert require_state(ready, "Ready") === ready
record = RTC.Common.read_json(only(ARGS))
@assert record["direct_attach"] === true
@assert all(haskey(record, key) for key in ("name", "runtime", "invocation", "session_pid",
    "session_control_instance", "session_uuid", "discovery_locator", "owners", "remote"))
@assert all(haskey(record["owners"], role) for role in ("core", "simulator", "cal2-llowfs", "cal2-scc"))
println("Pinned control API, operation arguments, held Ready and direct launch receipt checks passed")
