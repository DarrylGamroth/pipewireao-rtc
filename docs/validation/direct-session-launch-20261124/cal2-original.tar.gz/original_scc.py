"""Preserve the unaffected SCC optical gate if the original source stalls."""
import json
import os
from pathlib import Path
import signal
import sys

import matched
import measure as m
import replacement as retained

original = retained.scratch / "03-direct"
receipt = m.load(original / "lifecycle.json")
started = receipt["running"]["started"]
source = m.load(m.stage / "persistent.json")
matched.camera_map(source)
m.first_after_adoption = matched.first_correction
retain = m.load(retained.scratch / "prestarted-graph-owners.json")
expected_pid = int(sys.argv[1])
proc = Path(f"/proc/{expected_pid}")
assert (proc / "cmdline").read_bytes().split(b"\0")[:3] == [b"python3", b"-u", b"matched.py"]
start_ticks = (proc / "stat").read_text().rsplit(")", 1)[1].split()[19]
assert m.owner(m.unit) == receipt["rtc"]
assert not (original / "command-2.json").exists()

def usable_scc():
    if m.output_matches(original, "llowfs", started["sent_ns"], False):
        raise RuntimeError("LLOWFS has resumed; the original pair can proceed")
    matched_output = m.output_matches(original, "scc", started["sent_ns"], False)
    if matched_output is None:
        return None
    _, _, camera = matched_output
    if any(row["name"] == "scc-pair-status" and row["payload"] == [1] and
           m.same_camera(row, "scc", [camera]) for row in m.read_capture(original)):
        return camera
    return None

m.wait(usable_scc, 330, "an unaffected SCC pair open-loop sample")
assert m.owner(m.unit) == receipt["rtc"]
assert (proc / "stat").read_text().rsplit(")", 1)[1].split()[19] == start_ticks
os.kill(expected_pid, signal.SIGSTOP)
try:
    assert not (original / "command-2.json").exists()
    directory = retained.scratch / "03-direct-scc-only"
    directory.mkdir()
    (directory / "output-trace.jsonl").symlink_to("../03-direct/output-trace.jsonl")
    retained.optical_branches = ("scc",)
    acknowledge = m.acknowledge
    m.acknowledge = lambda _, *args, **kwargs: acknowledge(original, *args, **kwargs)
    retained.optical_open(directory, receipt, started)
    retained.optical_close(directory, receipt)
    assert retained.graph_still_live(m.native_dump(directory / "closed-native.json"), retain)
    signature = m.load(directory / "oracle-input.json")["scc"]
    owner_pid = retain["cal2-scc"]["unit_identity"]["pid"]
    rows = matched.events("graph-ingress", owner_pid)
    def boundaries(camera):
        key = matched.identity(camera)
        ingress = next(row for row in rows if row["event"] == "graph-ingress" and matched.identity(row) == key)
        tap = [row for row in matched.tap_receipts() if matched.identity(row) == key]
        return dict(camera=camera, graph_ingress=ingress, tap=tap)
    m.save(directory / "signed-ingress.json", dict(
        open=boundaries(receipt["fresh_open_priming"]["scc"]["camera"]),
        corrected=boundaries(signature["camera"])))
    print(json.dumps(receipt["first_signed_correction"], indent=2), flush=True)
finally:
    # The campaign owns all session teardown and the retained graph unit cleanup.
    os.kill(expected_pid, signal.SIGCONT)
