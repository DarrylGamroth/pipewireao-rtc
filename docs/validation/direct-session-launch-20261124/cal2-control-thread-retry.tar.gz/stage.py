import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tomllib

stage = Path(__file__).resolve().parent
repo = Path(os.environ.get("CAL2_STAGE_REPOSITORY",
    "/home/dgamroth/workspaces/codex/worktrees/rtc-independent-graph-owners"))
stock = Path("/var/tmp/rtc-ndarray-integration.beRGH1/cal2/candidate-combined-gated-install")
julia = os.environ["CAL2_VALIDATION_JULIA"]
variant, commit, *flags = sys.argv[1:]
assert flags in ([], ["--project-only"])
commit = subprocess.check_output(["git", "-C", repo, "rev-parse", f"{commit}^{{commit}}"], text=True).strip()
tree = subprocess.check_output(["git", "-C", repo, "rev-parse", f"{commit}^{{tree}}"], text=True).strip()
slug = subprocess.check_output(
    [julia, "--startup-file=no", "-e", 'using UUIDs; print(Base.version_slug(UUID("a3e2c7da-f73f-4284-8482-36ac422b34e6"), Base.SHA1(hex2bytes(only(ARGS)))))', tree],
    text=True)
package = stage / "depot/packages/PipeWireAORTC" / slug
if not package.is_dir():
    package.mkdir(parents=True)
    archive = subprocess.Popen(["git", "-C", repo, "archive", commit], stdout=subprocess.PIPE)
    subprocess.run(["tar", "-x", "-C", package], stdin=archive.stdout, check=True)
    assert archive.wait() == 0
app = stage / f"{variant}-app"
metadata = tomllib.loads((package / "Project.toml").read_text())
def ignore(directory, entries):
    return {name for name in entries
            if name in (".rtc-export.git", "depot") or (directory == str(stock) and name in ("bin", "systemd"))}
if not app.is_dir() and flags:
    app.mkdir()
    for file in ("Project.toml", "Manifest.toml"):
        shutil.copy2(stock / file, app / file)
    manifest = app / "Manifest.toml"
elif not app.is_dir():
    # The calibration mismatch selector mutates only a private copy.
    calibration = Path("generated/chopped-calibration-cred2-roi-f32/llowfs/artifacts/command-projection.fits")
    def copy_asset(source, destination):
        if Path(source).relative_to(stock) == calibration:
            return shutil.copy2(source, destination)
        return os.link(source, destination)
    shutil.copytree(stock, app, copy_function=copy_asset, ignore=ignore)
    deployment = app / "deployment.conf"
    spec = json.loads(deployment.read_text())
    assert spec["name"] == "cal2"
    spec["name"] = "cal2-" + os.environ["CAL2_VALIDATION_TAG"].lower()
    graph_roles = {"cal2-llowfs", "cal2-scc"}
    for owner in spec["owners"]:
        if owner["role"] in graph_roles:
            owner["environment"]["CAL2_GRAPH_TRACE"] = str(stage / "graph-ingress")
    deployment.unlink()
    deployment.write_text(json.dumps(spec, sort_keys=True, separators=(",", ":")) + "\n")
    manifest = app / "Manifest.toml"
if not app.with_suffix(".patched").is_file():
    manifest = app / "Manifest.toml"
    original = manifest.read_text()
    metadata = tomllib.loads((package / "Project.toml").read_text())
    pattern = r"(\[\[deps\.PipeWireAORTC\]\]\n)(.*?)(?=\n\[\[deps\.)"
    match = re.search(pattern, original, flags=re.S)
    new = re.sub(r'^deps = .*$', "deps = " + json.dumps(sorted(metadata["deps"])), match[2], count=1, flags=re.M)
    new = re.sub(r'^git-tree-sha1 = .*$', "git-tree-sha1 = " + json.dumps(tree), new, count=1, flags=re.M)
    new = re.sub(r'^version = .*$', "version = " + json.dumps(metadata["version"]), new, count=1, flags=re.M)
    manifest.unlink()
    manifest.write_text(original[:match.start(2)] + new + original[match.end(2):])
    app.with_suffix(".patched").touch()
readback = tomllib.loads((app / "Manifest.toml").read_text())["deps"]["PipeWireAORTC"][0]
assert readback["git-tree-sha1"] == tree and readback["version"] == metadata["version"]
(stage / f"{variant}-source.json").write_text(json.dumps({"commit": commit, "tree": tree, "source": str(package), "app": str(app)}, indent=2)+"\n")
print(app)
