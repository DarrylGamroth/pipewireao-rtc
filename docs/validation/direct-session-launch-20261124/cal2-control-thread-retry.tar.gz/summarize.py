"""Summarize completed CAL2 activations without replacing partial evidence."""
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])

def load(path):
    return json.loads(path.read_text())

for trial in sorted(root.iterdir()):
    if not trial.is_dir():
        continue
    ready = trial / "systemd-ready.json"
    if not ready.exists():
        continue
    properties = trial / "lifecycle.json"
    ready = load(ready)
    print(trial.name, f"{ready['request_to_systemd_ready_s']:.3f} s to systemd Ready",
          ready["service"]["InvocationID"], ready["service"]["MainPID"])
    if not properties.exists():
        continue
    lifecycle = load(properties)
    print("   ", "shutdown mode", lifecycle.get("stop", {}).get("mode", "pending"))
    detector = trial / "detector-paths.json"
    if not detector.exists():
        continue
    for camera, results in load(detector).items():
        if "open_sample" in results:
            oracle = lifecycle["first_signed_correction"][camera.split("-", 1)[1]]
            open_sequence = results["open_sample"]["publication"]["sequence"]
            closed_sequence = results["closed_sample"]["publication"]["sequence"]
            timings = results["timings_s"]
            print("   ", camera, f"open {open_sequence}, closed {closed_sequence}",
                  f"Start ack to usable {timings['start_ack_to_first_usable']:.3f} s",
                  f"Close request to correct {timings['close_request_to_first_corrected']:.3f} s",
                  f"all {oracle['channels_compared']} channels, maximum error {oracle['maximum_abs_error_m']:.3e} m")
