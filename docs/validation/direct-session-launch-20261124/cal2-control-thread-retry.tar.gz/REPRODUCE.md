# Installed CAL2 direct startup comparison

The private core and the independently supervised fixed-pupil optical
simulator use the retained CAL2 source application, profile and PipeWireAO
artifact. The fixture stages a deterministic pupil at a fixed 2 ms model
interval and a 32 s wall interval. The simulated LLOWFS and SCC exposures
respectively span 2 ms and 10 ms of model time. The simulator receives all
pupils through the native application Link.

The test installs immutable RTC source by Git tree in a local Julia depot.
The retained CAL2 application supplies the instrument declaration, scientific
graphs, FITS calibration and all dependency selections except the RTC tree.
The instrumented HIL and FilterGraphPipeWire sources retain their original
versions and add bounded stage, native queue, receive and graph callback
records. Their instrumentation is restricted to this fixture. Before
installation, the two graph declarations include their trace destination.
The installer seals the graph services with that destination.

Use one service instance and application for the legacy and direct lanes.
The direct lane uses the generated unit. The legacy lane restores
`ExecStartPre`, the prepared environment file and the historical `ExecStart`
from the previous cohort, and unsets the direct activation digest. Both
lanes use the same Julia, launcher, calibration, graph service definitions,
CPU placement, core, simulator and independently linked camera receiver.
The native graph owners are prestarted once per cohort and retain their
PIDs, process start ticks, invocation IDs and bootstrap instances across
RTC replacements.

The RTC main thread and core main loop use logical CPU 3. The core data loop
uses CPU 2. The source uses 6/7, LLOWFS 8/9 and SCC 10/11. Fixture Julia clients
use 12/13 and the coordinators use 14/15. The operating system CPU counters
cover the startup interval and the service scheduler samples record the RTC
main process and the legacy preparation process. Other host work can share
the CPUs.

The fixture starts a fresh native capture before each activation. It records
the synchronous systemd startup request and acknowledgement and separately
queries native Ready. It matches the 10 declared Links and verifies
held-open unprimed controllers and refused premature correction. It pairs
an actual camera publication, independent receive, graph ingress and output
against the complete acquisition identity. For each optical arm, a fresh
open-loop measurement and zero offsets precede explicit Close. The oracle
checks the first observed signed physical correction against the fitted
projection for all 2,304 output channels on each selected branch.

Graceful shutdown checks the native Stop and Quit acknowledgements. Forced
replacement sends SIGKILL only to the exact RTC MainPID, confirms that the
old native client withdrew, and checks that the session control, graph
endpoint, managed Links and prior bootstrap serials retired. A later RTC
receives new serials and starts Open and unprimed.

`build.sh SOURCE_COMMIT` stages and installs the retained calibrated
application once. `session-env.sh` defines paths to the retained local
applications and the private core. `driver.py` starts only this fixture's
core, simulator and camera receiver. Leave that process active while running
`matched.py` against the installed build. The `--smoke` selector performs
only the two Ready and graceful shutdown checks. The full selector precedes
the legacy/direct/direct/legacy series with one warmup per lane and follows
it with a direct recovery. `summarize.py` reads the completed receipts.
`continuity/decode.py` decodes the bounded binary trace for independently
checking exact sequences, domain, generation and model time.

These are software and optical simulation observations on one workstation.
The wall delays include the simulator's independently paced exposures, and
the comparison uses the same paced source in both startup lanes.
