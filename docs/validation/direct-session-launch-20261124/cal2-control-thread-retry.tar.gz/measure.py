import argparse
import csv
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import threading
import time

P = Path
stage = P(__file__).resolve().parent
reference = P("/var/tmp/cal2-services.6DdlJUDp")
socket = P(os.environ["PIPEWIREAORTC_CORE_SOCKET"])
runtime = socket.parent
prefix = P(os.environ["PIPEWIREAO_PREFIX"])
julia = os.environ["CAL2_VALIDATION_JULIA"]
tag = os.environ["CAL2_VALIDATION_TAG"]
instance = os.environ.get("CAL2_VALIDATION_SESSION_INSTANCE", f"c2l-{tag.lower()}-measure")
unit = f"pipewireao-session@{instance}.service"
unit_dir = runtime.parent / "systemd/user"
unit_file = unit_dir / unit
dropin = unit_dir / (unit+".d")
rtc_runtime = runtime.parent / f"pipewireao-session-{instance}"
core_name, hil_name = map(os.environ.__getitem__, ("PIPEWIREAORTC_CORE_UNIT", "PIPEWIREAORTC_SOURCE_UNIT"))
child_env = os.environ | {
    "PIPEWIREAO_RUNTIME_DIR": str(runtime),
    "PIPEWIRE_RUNTIME_DIR": str(runtime),
    "PIPEWIREAO_CONFIG_DIR": str(stage / "core-config"),
    "PIPEWIREAO_MODULE_DIR": str(prefix / "lib/pipewire-ao-0.3"),
    "PIPEWIREAO_SPA_PLUGIN_DIR": str(prefix / "lib/spa-ao-0.2"),
    "LD_LIBRARY_PATH": str(prefix / "lib"),
}
julia_flags = ["--startup-file=no", "--threads=2,1", "-O0"]
keep = ("JULIA_DEPOT_PATH", "JULIA_LOAD_PATH", "JULIA_PKG_PRECOMPILE_AUTO",
        "JULIA_NUM_PRECOMPILE_TASKS", "JULIA_IMAGE_THREADS", "OPENBLAS_NUM_THREADS",
        "TMPDIR", "XDG_CACHE_HOME", "POCL_CACHE_DIR")
branches = ("llowfs", "scc")
children = []

def run(*args, timeout=40, **kwargs):
    return subprocess.run([str(x) for x in args], check=True, timeout=timeout, **kwargs)

def system(*args, **kwargs):
    return run("systemctl", "--user", *args, **kwargs)

def status(service):
    props = ("ActiveState,SubState,MainPID,InvocationID,Result,FragmentPath,"
             "ExecMainStartTimestampMonotonic,ActiveEnterTimestampMonotonic")
    out = system("show", service, "-p", props, text=True, capture_output=True).stdout
    return dict(line.split("=", 1) for line in out.splitlines() if "=" in line)

def owner(service):
    s = status(service)
    assert s["ActiveState"] == "active", s
    pid = int(s["MainPID"])
    ticks = int(P(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[19])
    return {"pid": pid, "ticks": ticks, "invocation": s["InvocationID"]}

def wait(predicate, seconds, label):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if result := predicate():
            return result
        time.sleep(0.05)
    raise TimeoutError(f"Timed out awaiting {label}")

def load(file):
    return json.loads(file.read_text())

def save(file, value):
    temp = file.with_suffix(file.suffix + f".{os.getpid()}.tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True)+"\n")
    temp.replace(file)

def launch(app, cpu, script, log, *args):
    command = ["taskset", "-c", cpu, julia, *julia_flags, "--project="+str(app), stage/script, *args]
    with log.open("w") as sink:
        child = subprocess.Popen([str(x) for x in command], env=child_env, stdout=sink, stderr=subprocess.STDOUT)
    children.append((child,log))
    return child

def check_children():
    for child, log in children:
        if child.poll() is not None and not (log.parent/"workers-stopped").exists():
            raise RuntimeError(f"Observer/control exited {child.returncode}: {log}")

def read_capture(directory):
    check_children()
    file=directory/"output-trace.jsonl"
    if not file.exists():
        return []
    lines = file.read_text().splitlines(keepends=True)
    return [json.loads(line) for line in lines if line.endswith("\n")]

def cameras():
    result = []
    with (stage/"camera-trace.tsv").open() as io:
        for row in csv.DictReader(io, delimiter="\t"):
            if any(value is None for value in row.values()):
                continue
            for key in ("sequence", "model_ns", "generation", "observed_ns", "exposure_ns"):
                row[key] = int(row[key])
            row["max_abs"] = float(row["max_abs"])
            result.append(row)
    return result

def graph_startup_phases(directory, ledger):
    evidence = {}
    for branch in branches:
        name = "cal2-"+branch
        owner_record = ledger["owners"][name]
        graph_unit = owner_record["unit"]
        output = run("journalctl", "--user", "--no-pager", "-u", graph_unit, "-o", "cat",
                     text=True, capture_output=True).stdout
        (directory/(name+"-startup.log")).write_text(output)
        events = []
        event = None
        for line in output.splitlines():
            header = re.fullmatch(r". Info: Startup phase (started|completed|interrupted|skipped)", line)
            field = re.fullmatch(r"[│└] +([a-z_]+) = (.+)", line)
            if header:
                event = {"status":header[1]}
                events.append(event)
            elif field and event is not None:
                value = field[2]
                event[field[1]] = None if value == "nothing" else json.loads(value)
            elif line and line[0] not in "│└":
                event = None
        evidence[name] = {"pid":owner_record["pid"], "unit":graph_unit, "events":events}
    save(directory/"graph-startup-phases.json",evidence)

def native_dump(file):
    with file.open("w") as sink:
        run(prefix/"bin/pwao-dump", "-r", socket, env=child_env, stdout=sink)
    return load(file)

def properties(obj):
    return obj.get("info",{}).get("props",{})

def session_links(objects):
    return [properties(obj)["object.serial"] for obj in objects if obj["type"].endswith(":Link")
        and str(properties(obj).get("object.path","")).startswith("pipewireao/session/")]

def permanent(objects):
    b = {int(obj["id"]): obj for obj in objects}
    result = {}
    nodes={"cal2-pupil-input","cal2-llowfs","cal2-scc","independent-cal2-observe-cal2-llowfs",
        "independent-cal2-observe-cal2-scc"}
    for obj in objects:
        p = properties(obj)
        name = p.get("node.name")
        if name in nodes and obj["type"].endswith(":Node"):
            client = properties(b[int(p["client.id"])])
            result[name] = {"id": obj["id"], "serial": p["object.serial"],
                "client_serial": client["object.serial"], "client_pid": client["pipewire.sec.pid"]}
        path = str(p.get("object.path",""))
        if path.startswith("independent-cal2/") and obj["type"].endswith(":Link"):
            result[path] = {"id": obj["id"], "serial": p["object.serial"]}
    return result

def rates(objects):
    return {
       properties(o)["node.name"]: {k:v for k,v in properties(o).items() if k.startswith("queue.stats.")}
       for o in objects if o["type"].endswith(":Module") and all(v in properties(o) for v in
           ("queue.stats.publications","node.name"))
    }

def same_camera(sample, branch, cc):
    identity = (sample["acquired_sequence"],sample["model_ns"],sample["generation"],sample["domain"])
    matches = [row for row in cc if row["camera"] == "cal2-"+branch and
        (row["sequence"],row["model_ns"],row["generation"],row["domain"]) == identity]
    if not matches:
        return None
    assert len(matches)==1, identity
    return matches[0]

def modal_match(output, branch, rows):
    modal = [row for row in rows if row["name"] == branch+"-modal-residual" and
        all(row[k] == output[k] for k in ("acquired_sequence","model_ns","generation","domain"))]
    if not modal:
        return None
    assert len(modal)==1
    return modal[0]

def acknowledge(directory, i, operation, graph=None, seconds=105):
    request = {"operation":operation}
    if graph is not None:
        request["graph"] = graph
    save(directory/f"command-{i}.json", request)
    reply = directory/f"response-{i}.json"
    def available():
        check_children()
        return load(reply) if reply.exists() else None
    return wait(available, seconds, operation+" completion")

def without_payload(row):
    return {k:v for k,v in row.items() if k != "payload"}

def seconds(end, start):
    return (end-start)/1e9

def start_service(directory):
    # Sample only this private service cgroup. Keep timing on the synchronous
    # systemctl completion, independent of the sampler's observation interval.
    done=threading.Event()
    started_ns=time.monotonic_ns()
    process=subprocess.Popen(["systemctl","--user","start",unit])
    def sample():
        base=P("/sys/fs/cgroup/user.slice")/f"user-{os.getuid()}.slice"/f"user@{os.getuid()}.service"/"app.slice"
        with (directory/"startup-schedstat.jsonl").open("w",buffering=1) as output:
            while not done.is_set():
                try:
                    file=next(base.glob(f"*/{unit}/cgroup.procs"))
                    pids=file.read_text().splitlines()
                except (StopIteration, FileNotFoundError):
                    pids=[]
                for pid in pids:
                    proc=P("/proc")/pid
                    try:
                        args=proc.joinpath("cmdline").read_bytes().decode(errors="replace").split("\0")
                        ns=list(map(int,proc.joinpath("schedstat").read_text().split()))
                    except (FileNotFoundError,ProcessLookupError,ValueError):
                        continue
                    role=next((arg for arg in args if arg in ("prepare","publish")),None)
                    if any("MediaSession.main" in arg for arg in args):
                        role="rtc"
                    if "--output-o" in args or "--output-ji" in args:
                        role="package-precompile"
                    if role:
                        print(json.dumps(dict(monotonic_ns=time.monotonic_ns(),pid=int(pid),role=role,
                            runtime_ns=ns[0],runnable_wait_ns=ns[1])),file=output)
                done.wait(0.2)
    observer=threading.Thread(target=sample,daemon=True)
    observer.start()
    try:
        code=process.wait(timeout=500)
        ready_ns=time.monotonic_ns()
        if code:
            raise subprocess.CalledProcessError(code,process.args)
        return started_ns,ready_ns
    finally:
        done.set()
        observer.join(2)
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=10)

def cameras_after(timestamp):
    rows = cameras()
    latest = {branch: next((row for row in rows if row["camera"] == "cal2-"+branch and
                              row["observed_ns"] > timestamp), None) for branch in branches}
    return latest if all(latest.values()) else None

def first_after_adoption(directory, branch, close):
    ack = close["received_ns"]
    current = [r for r in cameras() if r["camera"]=="cal2-"+branch and r["observed_ns"] >= ack]
    if not current:
        return None
    camera = current[0]
    assert camera["observed_ns"] >= ack+100_000_000, (branch,camera,close)
    rows=read_capture(directory)
    # The camera tap is asynchronous. A camera observed near the transaction
    # may already have a frame-matched zero offset observed before the send.
    # This identifies a completed open frame without a camera tap margin.
    near = [r for r in cameras() if r["camera"]=="cal2-"+branch and
        close["sent_ns"]-100_000_000 <= r["observed_ns"] <= ack+100_000_000]
    for exposure in near:
        assert any(row["name"]==branch+"-physical-offset" and row["max_abs"]==0 and
            row["observed_ns"] < close["sent_ns"] and same_camera(row,branch,[exposure])
            for row in rows), (branch, exposure, close)
    if branch=="scc":
        status=[r for r in rows if r["name"]=="scc-pair-status" and same_camera(r,branch,[camera])]
        if not status:
            return None
        assert len(status)==1 and status[0]["payload"]==[1], (camera,status)
    candidate=[r for r in rows if r["name"]==branch+"-physical-offset" and same_camera(r,branch,[camera])]
    if not candidate:
        return None
    assert len(candidate)==1
    row=candidate[0]
    modal=modal_match(row,branch,rows)
    if not modal:
        return None
    assert row["max_abs"] > 0
    return row, modal, camera

def output_matches(directory, branch, since, closed):
    rows = read_capture(directory)
    for row in rows:
        if row["name"] != branch+"-physical-offset" or row["observed_ns"] < since:
            continue
        if bool(row["max_abs"]) != closed:
            continue
        modal = modal_match(row, branch, rows)
        camera = same_camera(row, branch, cameras())
        if modal and camera:
            return row, modal, camera
    return None

def capture_open(directory, started):
    result = {branch: output_matches(directory, branch, started["sent_ns"], False) for branch in branches}
    return result if all(result.values()) else None

def activation(variant, directory, app, persistent):
    assert owner(core_name) == persistent["core"] and owner(hil_name) == persistent["hil"]
    assert socket.stat().st_ino == persistent["inode"]
    before = native_dump(directory/"before-native.json")
    assert permanent(before) == persistent["native"] and not session_links(before)
    shutil.copyfile(app/"systemd/pipewireao-session@.service",unit_file)
    system("daemon-reload")
    launch(app, "12", "live-observe.jl", directory/"observer.log", app, socket, directory, reference)
    def await_observer():
        check_children()
        return (directory/"observer-ready").is_file()
    wait(await_observer, 130, "pre-start observer queue negotiation")
    initial_queue = rates(native_dump(directory/"observer-native.json"))
    assert len(initial_queue) == 8, initial_queue
    # Systemd startup timing begins after output taps have negotiated.
    before_start = cameras()
    assert all(any(row["camera"] == "cal2-"+branch for row in before_start) for branch in branches)
    started_ns, ready_ns = start_service(directory)
    rtc = owner(unit)
    unit_state = status(unit)
    receipt = {"variant":variant, "service_request_ns":started_ns, "service_ready_ns":ready_ns,
        "service_to_ready_s":seconds(ready_ns,started_ns), "service":unit_state, "rtc":rtc,
        "core":persistent["core"], "hil":persistent["hil"], "private_socket_inode":persistent["inode"]}
    save(directory/"timing.json",receipt)
    print(f"{variant}: Ready in {receipt['service_to_ready_s']:.3f} s; RTC PID {rtc['pid']}", flush=True)
    ledger_file = rtc_runtime/rtc["invocation"]/"launch.json"
    ledger = load(ledger_file)
    shutil.copyfile(ledger_file,directory/"ready-ledger.json")
    shutil.copyfile(ledger["config"],directory/"rtc.conf")
    assert ledger["remote"] == str(socket) and ledger["phase"] == "prepared"
    assert ledger["session_pid"] == rtc["pid"]
    assert ledger["owners"]["core"]["pid"] == persistent["core"]["pid"] and ledger["owners"]["core"]["external"]
    assert ledger["owners"]["simulator"]["pid"] == persistent["hil"]["pid"] and ledger["owners"]["simulator"]["external"]
    assert ledger["owners"]["simulator"]["control-protocol"] == "external-stream"
    n = native_dump(directory/"ready-native.json")
    links = session_links(n)
    assert permanent(n) == persistent["native"] and len(links) == 10 and len(set(links)) == 10
    receipt["rtc_links"] = links
    maps = {}
    for role, value in ledger["owners"].items():
        path = P(f"/proc/{value['pid']}/maps")
        maps[role] = [line for line in path.read_text().splitlines() if "ExportedGraphWarmup" in line]
    save(directory/"graph-package-images.json", maps)
    assert all(maps["cal2-"+branch] for branch in branches), maps
    graph_startup_phases(directory, ledger)
    def camera_while_held():
        check_children()
        return next((row for row in cameras() if row["observed_ns"] >= ready_ns), None)
    in_hold = wait(camera_while_held, 205, "camera traffic while Ready-held")
    held_rows = read_capture(directory)
    # Restarts may leave a queue's previous generation cached. Only this
    # RTC's cutover is supplied by the service timestamp and live camera.
    new_held = [r for r in held_rows if any(
        c["observed_ns"] >= started_ns and
        (c["sequence"], c["generation"], c["domain"]) ==
        (r["acquired_sequence"], r["generation"], r["domain"])
        for c in cameras())]
    assert not new_held, new_held
    receipt["ready_held_camera"] = in_hold
    save(directory/"timing.json",receipt)
    launch(app, "13", "live-control.jl", directory/"control.log", ledger_file, directory, socket, "guarded" if variant.endswith("-gated") else "ordinary")
    def await_control():
        check_children()
        return (directory/"control-online.json").exists()
    wait(await_control, 120, "native control client")
    if variant.endswith("-gated"):
        control_online_ns = time.monotonic_ns()
        receipt["last_held_llowfs_camera"] = wait(lambda: next((row for row in cameras()
            if row["camera"] == "cal2-llowfs" and row["observed_ns"] > control_online_ns), None),
            210, "LLOWFS exposure while held before early-close checks")
    start = acknowledge(directory, 1, "start")
    finish_activation(variant,directory,app,persistent,ledger_file,ledger,receipt,initial_queue,start)

def finish_activation(variant,directory,app,persistent,ledger_file,ledger,receipt,initial_queue,start):
    started = start["started"]
    first = wait(lambda: capture_open(directory, started), 600, "both first usable open-loop outputs")
    rows = read_capture(directory)
    usable = {}
    for branch, (physical, modal, camera) in first.items():
        assert modal["max_abs"] > 0 and physical["max_abs"] == 0
        assert camera["observed_ns"] >= started["sent_ns"], (camera, started)
        assert all(row["max_abs"] == 0 for row in rows if
            row["name"] == branch+"-physical-offset" and row["observed_ns"] >= started["sent_ns"])
        usable[branch] = {
            "physical": without_payload(physical), "modal": without_payload(modal), "camera": camera,
            "start_request_to_residual_s": seconds(modal["observed_ns"], started["sent_ns"]),
            "start_ack_to_residual_s": seconds(modal["observed_ns"], started["received_ns"]),
            "camera_observation_to_residual_s": seconds(modal["observed_ns"], camera["observed_ns"]),
            "camera_observation_to_offset_s": seconds(physical["observed_ns"], camera["observed_ns"]),
            "earlier_camera_sequences_after_start_ack": [frame["sequence"] for frame in cameras()
                if frame["camera"] == "cal2-"+branch and
                    started["received_ns"] <= frame["observed_ns"] and frame["sequence"] < camera["sequence"]],
        }
    pair = [r for r in rows if r["name"] == "scc-pair-status" and r["observed_ns"] >= started["sent_ns"]]
    complete = usable["scc"]["camera"]
    priming = [frame for frame in cameras() if frame["camera"]=="cal2-scc" and
        started["received_ns"] <= frame["observed_ns"] and frame["sequence"] < complete["sequence"]]
    assert len(priming)==1 and priming[0]["sequence"]+1 == complete["sequence"], priming
    completed=[r for r in pair if r["payload"] == [1] and same_camera(r,"scc",[complete])]
    assert len(completed)==1, pair[:3]
    assert all(r["acquired_sequence"] != priming[0]["sequence"] for r in rows
        if r["name"] in ("scc-physical-offset","scc-modal-residual") and r["observed_ns"] >= started["sent_ns"])
    receipt["first_scc_pair"] = {"priming_camera": priming[0], "complete": completed[0]}
    receipt["start"] = started
    receipt["first_usable"] = usable
    save(directory/"timing.json",receipt)
    print(f"{variant}: first usable residuals LLOWFS {usable['llowfs']['start_ack_to_residual_s']:.3f} s, SCC {usable['scc']['start_ack_to_residual_s']:.3f} s after Start acknowledgement",flush=True)
    # Both graphs are primed. There is no simulated actuator sink, so their
    # independent native closures can be acknowledged before either observation.
    closures = {branch:acknowledge(directory, index, "close", f"cal2-{branch}-controller",
                                  seconds=505)["closed"]
                for index, branch in enumerate(("scc","llowfs"), 2)}
    corrections = {}
    for branch, close in closures.items():
        observed = wait(lambda: first_after_adoption(directory, branch, close),
            440, branch+" first eligible post-adoption correction")
        physical, modal, camera = observed
        assert physical["acquired_sequence"] > usable[branch]["camera"]["sequence"]
        assert camera["observed_ns"] >= close["sent_ns"]
        earlier_offsets = [row for row in read_capture(directory)
            if row["name"] == branch+"-physical-offset" and
                row["observed_ns"] >= started["sent_ns"] and
                row["acquired_sequence"] < physical["acquired_sequence"]]
        assert earlier_offsets and all(row["max_abs"] == 0 for row in earlier_offsets), earlier_offsets
        usable[branch]["zero_open_offsets_observed"] = len(earlier_offsets)
        corrections[branch] = {"physical":physical, "modal":modal, "camera":camera, "close":close,
            "close_request_to_offset_s":seconds(physical["observed_ns"],close["sent_ns"]),
            "close_ack_to_offset_s":seconds(physical["observed_ns"],close["received_ns"])}
        print(f"{variant}: first {branch} correction at sequence {physical['acquired_sequence']} with peak {physical['max_abs']:.9g} m",flush=True)
    save(directory/"oracle-input.json",corrections)
    final_queue = rates(native_dump(directory/"before-stop-native.json"))
    queue_delta = {q: {k.removeprefix("queue.stats."): value-initial_queue[q][k] for k,value in values.items()}
        for q,values in final_queue.items()}
    for queue, values in queue_delta.items():
        if not any(name in queue for name in ("physical-offset","modal-residual","pair-status")):
            continue
        assert all(values[key] == 0 for key in ("replacements", "dropped-arrivals", "protocol-errors")), (queue,values)
        assert 0 <= values["publications"]-values["deliveries"] <= 1, (queue,values)
    receipt["observed_output_queue_deltas"] = queue_delta
    receipt["first_correction"] = {
        branch: item | {"physical":without_payload(item["physical"]), "modal":without_payload(item["modal"])}
        for branch,item in corrections.items()}
    stopped = acknowledge(directory,4,"stop")
    (directory/"workers-stopped").touch()
    (directory/"control-stop").touch()
    (directory/"observer-stop").touch()
    for child,log in children:
        assert child.wait(timeout=70) == 0, log
    children.clear()
    stop_ns = time.monotonic_ns()
    system("stop",unit,timeout=320)
    stopped_ns = time.monotonic_ns()
    final = load(ledger_file)
    shutil.copyfile(ledger_file,directory/"stopped-ledger.json")
    assert final["phase"] == "stopped" and final["systemd_quit"] == {"attempted":True,"accepted":True}
    inactive = status(unit)
    assert final["cleanup_complete"]
    assert inactive["ActiveState"] == "inactive" and inactive["Result"] == "success", inactive
    assert not P(ledger["discovery_locator"]).exists()
    assert owner(core_name) == persistent["core"] and owner(hil_name) == persistent["hil"]
    assert socket.stat().st_ino == persistent["inode"]
    n = native_dump(directory/"after-native.json")
    assert permanent(n) == persistent["native"] and not session_links(n)
    run("taskset", "-c", "15", julia, "--startup-file=no", "--project="+str(app),
        stage/"numerical-oracle.jl", app, directory, timeout=150, env=child_env)
    after = wait(lambda: cameras_after(stopped_ns), 310, "both cameras advancing after RTC exit")
    receipt.update({"stopped":stopped, "quit_s":seconds(stopped_ns,stop_ns), "post_quit_cameras":after,
                    "quit_requested_ns":stop_ns, "quit_completed_ns":stopped_ns,
                    "systemd_after_quit":inactive})
    save(directory/"timing.json",receipt)
    print(f"{variant}: native Quit, links gone, source still publishing, numerical corrections verified",flush=True)

def clean_trial(directory):
    for child,log in children:
        if child.poll() is None:
            child.terminate()
        try:
            child.wait(10)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(5)
    children.clear()
    try:
        system("stop",unit,timeout=130)
    finally:
        with (directory/"journal.log").open("w") as sink:
            run("journalctl","--user","--no-pager","-u",unit,"-o","short-monotonic",stdout=sink)

def exercise(variants):
    assert all(not os.path.lexists(p) for p in (unit_file, dropin, rtc_runtime))
    assert system("show",unit,"-p","LoadState","--value",text=True,capture_output=True).stdout.strip()=="not-found"
    persistent = load(stage/"persistent.json")
    dropin.mkdir(parents=True)
    try:
        (dropin/"fixture.conf").write_text("[Service]\n"+"".join(f'Environment="{k}={os.environ[k]}"\n' for k in keep))
        for variant in variants:
            app = stage/(variant+"-install")
            wait(lambda: (stage/(variant+".verified-install")).is_file() and
                (app/"systemd/pipewireao-session@.service").is_file(), 900, variant+" installation")
            directory = stage/f"{variant}-run-{time.monotonic_ns()}"
            directory.mkdir()
            (stage/(variant+"-latest")).write_text(str(directory)+"\n")
            try:
                activation(variant,directory,app,persistent)
            finally:
                clean_trial(directory)
    finally:
        unit_file.unlink(missing_ok=True)
        (dropin/"fixture.conf").unlink(missing_ok=True)
        dropin.rmdir()
        if rtc_runtime.is_dir():
            shutil.rmtree(rtc_runtime)
        system("daemon-reload")

def interrupted(signum, _frame):
    raise InterruptedError(f"Fixture interrupted by signal {signum}")
signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)
if __name__ == "__main__":
    args = argparse.ArgumentParser()
    args.add_argument("variants", nargs="+", choices=("candidate-combined-gated",))
    exercise(args.parse_args().variants)
