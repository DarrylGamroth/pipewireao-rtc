"""Join final detector receipts after late independent drains have settled."""
import json
from pathlib import Path
import sys

from continuity.decode import events
import measure as m

fixture = m.stage
source = m.load(fixture / "persistent.json")
tap_pid = source["native"]["independent-cal2-observe-cal2-llowfs"]["client_pid"]
tap_path = fixture / f"tap-array-trace.tsv.{tap_pid}.bin"

def key(row):
    return tuple(row[name] for name in ("domain", "generation", "sequence", "model_ns"))

def trace_rows(path):
    for _, event, stream, domain, generation, sequence, model, timestamp, flags in events(path):
        yield dict(event=event, stream=stream, domain=domain, generation=generation, sequence=sequence,
                   model_ns=model, observed_ns=timestamp, flags=flags)

received = {key(row): row for row in trace_rows(tap_path) if row["event"] == "native-received"}
accepted = {key(row): row for row in trace_rows(tap_path) if row["event"] == "receive-accepted"}
drained = {key(row): row for row in m.cameras()}

def enrich(boundaries):
    identity = key(boundaries["publication"])
    boundaries.update(tap_callback=received.get(identity), tap_accepted=accepted.get(identity),
                      tap_drained=drained.get(identity))

for receipt in Path(sys.argv[1]).glob("*/detector-paths.json"):
    report = m.load(receipt)
    for branch in report.values():
        for phase in ("publications", "held", "after_stop"):
            for exposure in branch[phase]:
                enrich(exposure)
        for phase in ("open_sample", "closed_sample"):
            if phase in branch:
                enrich(branch[phase])
                assert branch[phase]["graph_ingress"], (receipt, phase)
        branch["missing_tap_drains"] = [
            row["publication"]["sequence"] for row in branch["publications"] if row["tap_drained"] is None
        ]
    m.save(receipt.with_name("detector-paths-settled.json"), report)
    print(receipt.parent.name, json.dumps({camera: branch["missing_tap_drains"] for camera, branch in report.items()}))
