from pathlib import Path
from shutil import copyfile
import sys

stage = Path(__file__).resolve().parents[1]
pkgs = stage / 'continuity-depot/packages'
hil = pkgs / 'AdaptiveOpticsSimPipeWireHIL/SuCGV/src'
fg = pkgs / 'FilterGraphPipeWire/2cAf1/src'
fixed = len(sys.argv) == 2
if fixed:
    hil = Path(sys.argv[1]).resolve() / 'src'

def replace(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)

modules = [(hil, 'AdaptiveOpticsSimPipeWireHIL', 'CAL2_ARRAY_TRACE')]
if not fixed:
    modules.append((fg, 'FilterGraphPipeWire', 'CAL2_GRAPH_TRACE'))
for folder, mod, env_name in modules:
    copyfile(stage / 'continuity/continuity_trace.jl', folder / 'continuity_trace.jl')
    path = folder / f'{mod}.jl'
    module_code = 'module ' + mod + '\n'
    init = f'''
include("continuity_trace.jl")
function __init__()
    path = get(ENV, "{env_name}", "")
    isempty(path) || _init_continuity_trace!(path * "." * string(getpid()) * ".bin")
    return nothing
end
'''
    path.write_text(replace(path.read_text(), module_code, module_code + init))

path = hil / 'array_streams.jl'
source = path.read_text()
source = replace(source, '    busy::Atomic{Bool}\n', '    busy::Atomic{Bool}\n    trace_index::Int\n')
parameters = 'count::Int, ::Type{T}' + (', buffer_count::Int=2' if fixed else '')
source = replace(source, f'function ArrayStreamState({parameters}) where {{T}}',
    f'function ArrayStreamState({parameters}, trace_index::Int=0) where {{T}}')
source = replace(source, 'zeros(T, count), Atomic{Bool}(false), false,',
    'zeros(T, count), Atomic{Bool}(false), trace_index, false,')
constructor = 'ArrayStreamState(prod(Int.(option.format.shape)), element' + (', option.buffers' if fixed else '')
source = replace(source, constructor + ')', constructor + ', index)')
a,b = source.index('function _accept_array!'),source.index('function _pack_array!')
part = source[a:b]
part = replace(part, '    _array_identity_valid', '    _trace_continuity!(4, state.trace_index, identity, pts)\n    _array_identity_valid')
part = replace(part, '        Base.Threads.atomic_add!(state.rejected', '        _trace_continuity!(7, state.trace_index, identity, pts)\n        Base.Threads.atomic_add!(state.rejected')
part = replace(part, '        Base.Threads.atomic_add!(state.dropped, UInt64(1))\n        return false', '        _trace_continuity!(6, state.trace_index, identity, pts)\n        Base.Threads.atomic_add!(state.dropped, UInt64(1))\n        return false')
part = replace(part, '        state.pending = true', '        _trace_continuity!(5, state.trace_index, identity, pts)\n        state.pending = true')
source = source[:a]+part+source[b:]
source = replace(source, '    if !dequeue_buffer!(process.buffer, stream)\n', '''    if !dequeue_buffer!(process.buffer, stream)
        locked && _trace_continuity!(8, state.trace_index, state.receipt.identity,
            state.receipt.pts, Base.Libc.errno())
''')
source = replace(source, '        queued = true\n', '''        queued = true
        locked && _trace_continuity!(3, state.trace_index, state.receipt.identity, state.receipt.pts)
''')
source = replace(source, '    catch\n        state.failed[] = true\n', '''    catch
        _trace_continuity!(14, state.trace_index, state.receipt.identity, state.receipt.pts)
        state.failed[] = true
''')
if fixed:
    source = replace(source, '    item.input || (item.state.publication_retry[] = false)', '''    if !item.input
        state = item.state
        state.publication_retry[] && _trace_continuity!(16, state.trace_index,
            state.receipt.identity, state.receipt.pts, state.publication_retries)
        state.publication_retry[] = false
    end''')
source = replace(source, '    if header === nothing || properties === nothing ||', '''    if header === nothing || properties === nothing ||''')
source = replace(source, '            chunk.stride ∉ (0, sizeof(element), process.stride)\n        Base', '''            chunk.stride ∉ (0, sizeof(element), process.stride)
        identity = _continuity_rows[] == C_NULL || properties === nothing ? nothing : acquisition_identity(properties)
        _trace_continuity!(12, state.trace_index, identity, header === nothing ? -1 : header.pts,
            header === nothing ? 0 : header.flags)
        Base''')
source = replace(source, '''    stream_state(stream) == PipeWireAO.LibPipeWire.PW_STREAM_STATE_STREAMING &&
        is_driving(stream) && trigger_process!(stream)''', '''    if stream_state(stream) == PipeWireAO.LibPipeWire.PW_STREAM_STATE_STREAMING
        driving = is_driving(stream)
        driving && prepared.state.pending && _trace_continuity!(10, prepared.state.trace_index, nothing, 0)
        driving && trigger_process!(stream)
    end''')
a,b = source.index('function _stage_array!'),source.index('"Copy the latest input')
part = source[a:b]
part = replace(part, '    state.failed[] && return false', '    _trace_continuity!(1, state.trace_index, identity, pts)\n    state.failed[] && return false')
part = replace(part, '        Base.Threads.atomic_add!(state.dropped, UInt64(1))\n        return false', '        _trace_continuity!(13, state.trace_index, identity, pts)\n        Base.Threads.atomic_add!(state.dropped, UInt64(1))\n        return false')
part = replace(part, '        state.pending && Base.Threads.atomic_add!(state.dropped, UInt64(1))', '''        if state.pending
            _trace_continuity!(11, state.trace_index, state.receipt.identity, state.receipt.pts)
            Base.Threads.atomic_add!(state.dropped, UInt64(1))
        end''')
part = replace(part, '        state.pending = true', '        _trace_continuity!(2, state.trace_index, identity, pts)\n        state.pending = true')
source = source[:a]+part+source[b:]
source = replace(source, '        return PipeWireArrayReceipt(receipt.pts,receipt.sequence,receipt.duration,receipt.identity,', '''        _trace_continuity!(9, state.trace_index, receipt.identity, receipt.pts)
        return PipeWireArrayReceipt(receipt.pts,receipt.sequence,receipt.duration,receipt.identity,''')
path.write_text(source)

if fixed:
    sys.exit()

path = fg / 'graph_node.jl'
source = path.read_text()
source = replace(source, '''
        _preflight_input_facts!(owner,inputs)
''', '''
        if _continuity_rows[] != C_NULL
            for index in 1:length(inputs)
                input = inputs[index]
                PipeWireAO.input_available(input) || continue
                header = PipeWireAO.buffer_header(input)
                metadata = PipeWireAO.metadata_records(input)
                identity = metadata === nothing ? nothing : PipeWireAO.acquisition_identity(metadata)
                _trace_continuity!(15, index, identity, header === nothing ? -1 : header.pts,
                    header === nothing ? 0 : header.flags)
            end
        end
        _preflight_input_facts!(owner,inputs)
''')
path.write_text(source)
