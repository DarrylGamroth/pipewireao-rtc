# Diagnostic use only. One bounded prefaulted mmap per process, with no IO on
# the data loop. A row is committed by its final nonzero timestamp.
const _continuity_rows = Ref(Ptr{UInt64}(C_NULL))
const _continuity_index = Base.Threads.Atomic{Int}(0)
const _continuity_capacity = 32768
const _continuity_fields = 8

function _init_continuity_trace!(path)
    isempty(path) && return nothing
    open(path, "w+") do output
        bytes = _continuity_capacity * _continuity_fields * sizeof(UInt64)
        truncate(output, bytes)
        mapping = ccall(:mmap, Ptr{UInt64}, (Ptr{Cvoid}, Csize_t, Cint, Cint, Cint, Int64),
            C_NULL, bytes, 3, 1, fd(output), 0)
        mapping == Ptr{UInt64}(typemax(UInt)) && error("Could not mmap continuity trace " * path)
        ccall(:memset, Ptr{Cvoid}, (Ptr{Cvoid}, Cint, Csize_t), mapping, 0, bytes)
        _continuity_rows[] = mapping
    end
    return nothing
end

@inline function _trace_continuity!(event, stream, identity, pts, flags=0)
    rows = _continuity_rows[]
    rows == C_NULL && return nothing
    n = Base.Threads.atomic_add!(_continuity_index, 1)
    n < _continuity_capacity || return nothing
    offset = n * _continuity_fields
    if identity !== nothing
        low, high = reinterpret(NTuple{2,UInt64}, identity.domain.bytes)
        unsafe_store!(rows, low, offset + 3)
        unsafe_store!(rows, high, offset + 4)
        unsafe_store!(rows, identity.generation, offset + 5)
        unsafe_store!(rows, identity.sequence, offset + 6)
    end
    unsafe_store!(rows, UInt64(event), offset + 1)
    unsafe_store!(rows, UInt64(stream) | (UInt64(flags) << 32), offset + 2)
    unsafe_store!(rows, reinterpret(UInt64, Int64(pts)), offset + 7)
    unsafe_store!(rows, time_ns(), offset + 8)
    return nothing
end
