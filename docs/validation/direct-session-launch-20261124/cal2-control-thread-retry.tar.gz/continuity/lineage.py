import argparse
import collections
import csv
from pathlib import Path
import sys

from decode import events

parser = argparse.ArgumentParser()
parser.add_argument("--hil", type=Path, required=True)
parser.add_argument("--tap", type=Path, required=True)
parser.add_argument("--graph", type=Path, nargs="*", default=[])
args = parser.parse_args()

lineage = collections.defaultdict(dict)
for origin, paths in (("hil", [args.hil]), ("tap", [args.tap]), ("graph", args.graph)):
    for path in paths:
        for process, event, stream, domain, gen, seq, pts, timestamp, _ in events(path):
            if not seq:
                continue
            key = (domain, gen, seq, pts)
            lineage[key].setdefault((origin, event), []).append((process, stream, timestamp))

writer = csv.writer(sys.stdout, delimiter="\t", lineterminator="\n")
writer.writerow(("camera", "domain", "generation", "sequence", "model_ns", "stage_ns",
    "native_queue_ns", "tap_arrival_ns", "tap_drain_ns", "graph_ingress_ns", "diagnosis"))
for key, points in sorted(lineage.items(), key=lambda x: x[0]):
    if ("hil", "stage-attempt") not in points:
        continue
    camera = {2: "llowfs", 3: "scc"}[points["hil", "stage-attempt"][0][1]]
    def ts(origin, event):
        return ",".join(str(row[2]) for row in points.get((origin, event), []))
    diagnosis = ""
    if not ts("hil", "staged"):
        diagnosis = "stage-busy" if ts("hil", "stage-busy") else "stage-rejected"
    elif not ts("hil", "native-queued"):
        diagnosis = "stage-overwritten" if ts("hil", "output-overwritten") else "stage-still-unpublished"
    elif not ts("tap", "native-received"):
        diagnosis = "invalid-tap-buffer" if ts("tap", "invalid-input-buffer") else "no-tap-arrival"
    elif not ts("tap", "drained"):
        diagnosis = "tap-slot-contention" if ts("tap", "receive-busy") else "no-tap-drain"
    writer.writerow((camera, *key, ts("hil", "staged"), ts("hil", "native-queued"),
        ts("tap", "native-received"), ts("tap", "drained"), ts("graph", "graph-ingress"), diagnosis))
