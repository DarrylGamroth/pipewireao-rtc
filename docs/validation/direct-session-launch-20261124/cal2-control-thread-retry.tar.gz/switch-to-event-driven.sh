#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
cd "$cal2_fixture"

driver_pid="$1"
hil_project="$2"
test -f replacement-fixed47/source-publication-continuity.json
test -f "$hil_project/Manifest.toml"

for name in pipewireao-session@c2l-direct-dyzffcwb-measure.service \
    pipewireao-graph-cal2-direct-dyzffcwb-cal2-llowfs.service \
    pipewireao-graph-cal2-direct-dyzffcwb-cal2-scc.service; do
    test "$(systemctl --user show "$name" -p MainPID --value)" = 0
done
mapfile -d '' -t driver_args < "/proc/$driver_pid/cmdline"
test "${driver_args[0]}" = python3
test "${driver_args[1]}" = -u
test "${driver_args[2]}" = "$cal2_fixture/driver.py"
feed_pid=$(jq -r '.native["independent-cal2-observe-cal2-llowfs"].client_pid' persistent.json)
test "$(jq -r .core.pid persistent.json)" = "$(systemctl --user show "$PIPEWIREAORTC_CORE_UNIT" -p MainPID --value)"

# The Python supervisor owns both units by default. Reassign the live core
# to the next supervisor without running the old core teardown.
kill -KILL "$driver_pid"
touch stop-feed
deadline=$((SECONDS+20))
while kill -0 "$feed_pid" 2>/dev/null; do
    feeder_state=$(ps -o stat= -p "$feed_pid" || true)
    case "$feeder_state" in Z*|"") break ;; esac
    test "$SECONDS" -le "$deadline"
    sleep 1
done
systemctl --user stop "$PIPEWIREAORTC_SOURCE_UNIT"
deadline=$((SECONDS+20))
until test "$(systemctl --user show "$PIPEWIREAORTC_SOURCE_UNIT" -p LoadState --value)" = not-found; do
    test "$SECONDS" -le "$deadline"
    sleep 1
done
test "$(jq -r .core.pid persistent.json)" = "$(systemctl --user show "$PIPEWIREAORTC_CORE_UNIT" -p MainPID --value)"

mkdir fixed-source
journalctl --user --no-pager -o short-monotonic --all -u "$PIPEWIREAORTC_CORE_UNIT" \
    -u "$PIPEWIREAORTC_SOURCE_UNIT" > fixed-source/journal.txt
mv before-first-native.json persistent.json pupil-pacing.tsv camera-trace.tsv \
    first-llowfs.f32 first-llowfs.json feed.log fixture.log fixed-source/
mv hil-array-trace.tsv.*.bin tap-array-trace.tsv.*.bin graph-ingress.*.bin fixed-source/
rm stop-feed feed-ready warm-lease-released
export CAL2_HIL_PROJECT="$hil_project"
export CAL2_RETAIN_CORE="$cal2_fixture/fixed-source/persistent.json"
touch event-driven-started
PYTHONDONTWRITEBYTECODE=1 exec taskset -c 14,15 python3 -u "$cal2_fixture/driver.py" > fixture.log 2>&1
