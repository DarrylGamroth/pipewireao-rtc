#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
cd "$cal2_fixture"

coordinator_pid="$1"
old_driver_pid="$2"
test -s replacement-matched47/03-direct-scc-only/signed-ingress.json
if test -r "/proc/$coordinator_pid/cmdline"; then
    mapfile -d '' -t coordinator_args < "/proc/$coordinator_pid/cmdline"
    test "${coordinator_args[0]}" = python3
    test "${coordinator_args[1]}" = -u
    test "${coordinator_args[2]}" = matched.py
    kill -INT "$coordinator_pid"
fi
deadline=$((SECONDS+330))
while test -r "/proc/$coordinator_pid/cmdline"; do
    test "$SECONDS" -le "$deadline"
    sleep 1
done
for name in pipewireao-session@c2l-direct-dyzffcwb-measure.service \
    pipewireao-graph-cal2-direct-dyzffcwb-cal2-llowfs.service \
    pipewireao-graph-cal2-direct-dyzffcwb-cal2-scc.service; do
    test "$(systemctl --user show "$name" -p MainPID --value)" = 0
done

mapfile -d '' -t old_driver_args < "/proc/$old_driver_pid/cmdline"
test "${old_driver_args[0]}" = python3
test "${old_driver_args[2]}" = "$cal2_fixture/driver.py"
touch finish
deadline=$((SECONDS+150))
while test -r "/proc/$old_driver_pid/cmdline"; do
    test "$SECONDS" -le "$deadline"
    sleep 1
done

mkdir original-source
mv before-first-native.json persistent.json pupil-pacing.tsv camera-trace.tsv \
    first-llowfs.f32 first-llowfs.json feed.log fixture.log journal.txt original-source/
mv hil-array-trace.tsv.*.bin tap-array-trace.tsv.*.bin graph-ingress.*.bin original-source/
rm finish stop-feed feed-ready warm-lease-released
export CAL2_HIL_PROJECT="$cal2_fixture/continuity/fixed-provider-env"
touch fixed-started
PYTHONDONTWRITEBYTECODE=1 exec taskset -c 14,15 python3 -u "$cal2_fixture/driver.py" > fixture.log 2>&1
