"""Join final detector receipts after late independent drains have settled."""
import json
from pathlib import Path
import sys

from continuity.decode import events
import measure as m

fixture = m.stage
source = m.load(fixture / "persistent.json")
root = Path(sys.argv[1])
tap_pid = source["native"]["independent-cal2-observe-cal2-llowfs"]["client_pid"]
tap_path = fixture / f"tap-array-trace.tsv.{tap_pid}.bin"
hil_path = fixture / f'hil-array-trace.tsv.{source["hil"]["pid"]}.bin'

def key(row):
    return tuple(row[name] for name in ("domain", "generation", "sequence", "model_ns"))

def trace_rows(path):
    for _, event, stream, domain, generation, sequence, model, timestamp, flags in events(path):
        yield dict(event=event, stream=stream, domain=domain, generation=generation, sequence=sequence,
                   model_ns=model, observed_ns=timestamp, flags=flags)

received = {key(row): row for row in trace_rows(tap_path) if row["event"] == "native-received"}
accepted = {key(row): row for row in trace_rows(tap_path) if row["event"] == "receive-accepted"}
drained = {key(row): row for row in m.cameras()}
streams = {int(index): properties for index, properties in m.load(root / "source-camera-streams.json").items()}
published = [dict(row, **streams[row["stream"]]) for row in trace_rows(hil_path)
             if row["event"] == "native-queued" and row["stream"] in streams]
graphs = m.load(root / "prestarted-graph-owners.json")
graph_inputs = {camera: list(trace_rows(
    fixture / f'graph-ingress.{owner["unit_identity"]["pid"]}.bin'))
    for camera, owner in graphs.items()}
activations = sorted(((m.load(path), path.parent) for path in root.glob("*/lifecycle.json")),
                     key=lambda item: item[0]["request_ns"])

def enrich(boundaries):
    identity = key(boundaries["publication"])
    boundaries.update(tap_callback=received.get(identity), tap_accepted=accepted.get(identity),
                      tap_drained=drained.get(identity))

for index, (lifecycle, directory) in enumerate(activations):
    receipt = directory / "detector-paths.json"
    if not receipt.exists():
        continue
    report = m.load(receipt)
    until_ns = activations[index + 1][0]["request_ns"] if index + 1 < len(activations) else 2**64
    request_ns = lifecycle["request_ns"]
    ready_ns = lifecycle["native_ready"]["ready"]["received_ns"]
    started_ns = lifecycle.get("running", {}).get("started", {}).get("sent_ns", lifecycle["stop"]["request_ns"])
    for camera, branch in report.items():
        seen = {key(row): row for row in graph_inputs[camera]
                if row["event"] == "graph-ingress" and request_ns <= row["observed_ns"] < until_ns}
        branch["publications"] = [
            dict(publication=row, graph_ingress=seen.get(key(row))) for row in published
            if row["camera"] == camera and request_ns <= row["observed_ns"] < until_ns
        ]
        branch["held"] = [row for row in branch["publications"]
                          if ready_ns <= row["publication"]["observed_ns"] < started_ns]
        branch["after_stop"] = [row for row in branch["publications"]
                                if row["publication"]["observed_ns"] > lifecycle["stop"]["completed_ns"]]
        for phase in ("publications", "held", "after_stop"):
            for exposure in branch[phase]:
                enrich(exposure)
        for phase in ("open_sample", "closed_sample"):
            if phase in branch:
                enrich(branch[phase])
                assert branch[phase]["graph_ingress"], (receipt, phase)
        branch["missing_tap_drains"] = [
            row["publication"]["sequence"] for row in branch["publications"] if row["tap_drained"] is None
        ]
    m.save(receipt.with_name("detector-paths-settled.json"), report)
    print(receipt.parent.name, json.dumps({camera: branch["missing_tap_drains"] for camera, branch in report.items()}))
