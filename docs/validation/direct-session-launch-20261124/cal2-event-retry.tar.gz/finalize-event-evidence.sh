#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
cd "$cal2_fixture"
driver_pid="$1"
cohort=replacement-event-driven47
test -s "$cohort/source-publication-continuity.json"

names=(pipewireao-session@c2l-direct-dyzffcwb-measure.service
       pipewireao-graph-cal2-direct-dyzffcwb-cal2-llowfs.service
       pipewireao-graph-cal2-direct-dyzffcwb-cal2-scc.service)
for name in "${names[@]}"; do
    test "$(systemctl --user show "$name" -p MainPID --value)" = 0
done
mapfile -d '' -t driver_args < "/proc/$driver_pid/cmdline"
test "${driver_args[0]}" = python3
test "${driver_args[1]}" = -u
test "${driver_args[2]}" = "$cal2_fixture/driver.py"

touch finish
deadline=$((SECONDS+150))
while test -r "/proc/$driver_pid/cmdline"; do
    test "$SECONDS" -le "$deadline"
    sleep 1
done

names+=("$PIPEWIREAORTC_SOURCE_UNIT" "$PIPEWIREAORTC_CORE_UNIT")
for name in "${names[@]}"; do
    test "$(systemctl --user show "$name" -p MainPID --value)" = 0
done
test ! -e "$PIPEWIREAORTC_CORE_SOCKET"
systemctl --user show "${names[@]}" -p Id,LoadState,ActiveState,SubState,MainPID,Result > event-driven-final-services.txt

python3 settle_receipts.py "$cohort" > event-driven-settled-joins.log
python3 summarize.py "$cohort" > event-driven-summary.txt
hil_pid=$(jq -r '.hil.pid' persistent.json)
tap_pid=$(jq -r '.native["independent-cal2-observe-cal2-llowfs"].client_pid' persistent.json)
mapfile -t graphs < <(jq -r '.[]|.unit_identity.pid| "graph-ingress." + (. | tostring) + ".bin"' "$cohort/prestarted-graph-owners.json")
python3 continuity/lineage.py --hil "hil-array-trace.tsv.$hil_pid.bin" \
    --tap "tap-array-trace.tsv.$tap_pid.bin" --graph "${graphs[@]}" > event-driven-lineage.tsv
python3 continuity/decode.py "hil-array-trace.tsv.$hil_pid.bin" "tap-array-trace.tsv.$tap_pid.bin" "${graphs[@]}" > event-driven-transport.tsv
python3 reconcile-event-publication.py > event-driven-outcome.log
tar -czf event-source-030bed3-rtc-47ada5e.tar.gz \
    event-hil-provenance.json event-provider-prewarm.log event-driven-placement.json host-cpu-topology.csv \
    final-source.json final-build.log "$cohort" persistent.json before-first-native.json \
    camera-trace.tsv pupil-pacing.tsv event-driven-lineage.tsv event-driven-transport.tsv \
    event-driven-summary.txt event-driven-settled-joins.log event-driven-final-services.txt event-driven-outcome.log \
    event-driven-llowfs-retry-10.tsv event-driven-llowfs-retry-16.tsv \
    fixture.log feed.log journal.txt matched-event-driven47.log switch-to-event-driven.log \
    "hil-array-trace.tsv.$hil_pid.bin" "tap-array-trace.tsv.$tap_pid.bin" "${graphs[@]}" \
    REPRODUCE.md driver.py matched.py stage.py measure.py replacement.py summarize.py settle_receipts.py \
    stage-event-hil.py switch-to-event-driven.sh finalize-event-evidence.sh reconcile-event-publication.py live-correction-control.jl \
    live-observe.jl numerical-oracle.jl continuity/{decode.py,lineage.py,instrument.py,continuity_trace.jl} \
    continuity/event-driven-provider-env/{Project,Manifest}.toml \
    final-app/{Manifest.toml,Project.toml,deployment.conf} \
    final-app/systemd/{graph-owner-assets.json,graph-owners.json,session-activation.json,pipewireao-session@.service}
tar -tzf event-source-030bed3-rtc-47ada5e.tar.gz > event-source-030bed3-rtc-47ada5e.contents.txt
sha256sum event-source-030bed3-rtc-47ada5e.tar.gz
