"""Stage the committed EventSource HIL source and the fixture-only trace points."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tomllib

stage = Path(__file__).resolve().parent
repository = sys.argv[1]
reference = sys.argv[2]
base = Path("/var/tmp/cal2-independent.UcNIRN/final-install")
source = stage / "continuity/event-driven-hil"
environment = stage / "continuity/event-driven-provider-env"
commit = subprocess.check_output(["git", "-C", repository, "rev-parse", reference + "^{commit}"], text=True).strip()
tree = subprocess.check_output(["git", "-C", repository, "rev-parse", commit + "^{tree}"], text=True).strip()
source.mkdir()
with subprocess.Popen(["git", "-C", repository, "archive", commit], stdout=subprocess.PIPE) as archive:
    subprocess.run(["tar", "-x", "-C", source], stdin=archive.stdout, check=True)
    assert archive.wait() == 0
subprocess.run([sys.executable, stage / "continuity/instrument.py", source], check=True)
environment.mkdir()
shutil.copy2(base / "Project.toml", environment / "Project.toml")
original = (base / "Manifest.toml").read_text()
name = "AdaptiveOpticsSimPipeWireHIL"
pattern = r"(\[\[deps\." + name + r"\]\]\n)(.*?)(?=\n\[\[deps\.)"
match = re.search(pattern, original, flags=re.S)
assert match is not None
body = re.sub(r"^git-tree-sha1 = .*$", "path = " + json.dumps(str(source)), match[2], count=1, flags=re.M)
assert body != match[2]
manifest = original[:match.start(2)] + body + original[match.end(2):]
(environment / "Manifest.toml").write_text(manifest)
old, new = tomllib.loads(original), tomllib.loads(manifest)
original_hil, staged_hil = [spec["deps"].pop(name)[0] for spec in (old, new)]
assert old == new and original_hil["version"] == staged_hil["version"]
assert staged_hil["path"] == str(source)
files = [environment / "Manifest.toml", source / "src/array_streams.jl",
         source / "src/continuity_trace.jl", source / "src/external_pupil/ExternalPupil.jl",
         base / "simulation.conf"]
hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
(stage / "event-hil-provenance.json").write_text(json.dumps(dict(commit=commit, tree=tree,
    environment=str(environment), original_hil=original_hil, staged_hil=staged_hil,
    other_manifest_entries_identical=True, sha256=hashes), sort_keys=True, indent=2)+"\n")
print(environment)
