"""Separate the native lifecycle result from final staged publication losses."""
import csv
import json
from pathlib import Path

stage = Path(__file__).resolve().parent
cohort = stage / "replacement-event-driven47"

def load(path):
    return json.loads(path.read_text())

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

with (stage / "event-driven-lineage.tsv").open() as file:
    exposures = list(csv.DictReader(file, delimiter="\t"))
with (stage / "event-driven-transport.tsv").open() as file:
    transport = list(csv.DictReader(file, delimiter="\t"))

recovery = load(cohort / "recovery-direct/lifecycle.json")
gap_start = recovery["stop"]["completed_ns"]
stop_response = load(cohort / "recovery-direct/response-2.json")
reports = {}
first_failure = None
for camera in ("llowfs", "scc"):
    rows = [row for row in exposures if row["camera"] == camera]
    overwritten = [int(row["sequence"]) for row in rows if row["diagnosis"] == "stage-overwritten"]
    pending = [int(row["sequence"]) for row in rows if row["diagnosis"] == "stage-still-unpublished"]
    delivered = [row for row in rows if row["native_queue_ns"]]
    missing_receiver = [int(row["sequence"]) for row in delivered if not row["tap_drain_ns"]]
    reports[camera] = dict(staging_attempts=len(rows),
        native_publications=len(delivered), overwritten=overwritten,
        pending_at_shutdown=pending, native_publications_without_tap_drain=missing_receiver)
    if not overwritten:
        continue
    sequence = overwritten[0]
    exposure = next(row for row in rows if int(row["sequence"]) == sequence)
    exact = [row for row in transport if row["domain"] == exposure["domain"] and
             row["generation"] == exposure["generation"] and row["sequence"] == exposure["sequence"] and
             row["model_ns"] == exposure["model_ns"]]
    initial, *repeated = [int(row["monotonic_ns"]) for row in exact if row["event"] == "no-output-buffer"]
    all_tap = [row for row in exposures if row["tap_drain_ns"]]
    latest_tap = max((row for row in rows if row["tap_drain_ns"] and
                      int(row["tap_drain_ns"]) < initial), key=lambda row: int(row["tap_drain_ns"]))
    next_tap = min((row for row in all_tap if int(row["tap_drain_ns"]) > initial),
                   key=lambda row: int(row["tap_drain_ns"]), default=None)
    next_same = min((row for row in rows if row["tap_drain_ns"] and int(row["tap_drain_ns"]) > initial),
                    key=lambda row: int(row["tap_drain_ns"]), default=None)
    first_failure = dict(camera=camera, exposure=exposure, transport=exact,
        first_busy_ns=initial, final_busy_ns=repeated[-1],
        retry_exhaustion_ns=repeated[-1] - initial,
        systemd_stop_completion_to_first_miss_ns=initial - gap_start,
        last_same_camera_tap=latest_tap, next_tap=next_tap, next_same_camera_tap=next_same,
        next_tap_after_first_miss_ns=int(next_tap["tap_drain_ns"]) - initial if next_tap else None)

report = dict(gap_free=all(not row["overwritten"] for row in reports.values()), cameras=reports)
write(cohort / "staged-publication-result.json", report)
write(cohort / "recovery-publication-timing.json", dict(
    request_ns=recovery["request_ns"], systemd_ready_ns=recovery["ready_ns"],
    running_ack_ns=recovery["running"]["started"]["received_ns"],
    native_stop_ack_ns=stop_response["stopped"]["received_ns"],
    systemd_stop_completed_ns=gap_start,
    absence_snapshot="recovery-direct/after-native.json",
    note="The fixture records exact old Link serials and verifies their absence after systemd Stop. It has no timestamp for each individual Link removal.",
    first_failure=first_failure))
marker = cohort / "passed.json"
if marker.exists() and not report["gap_free"]:
    marker.rename(cohort / "lifecycle-passed.json")
print(json.dumps(report, indent=2))
