using PipeWireAO, PipeWireAORTC

const RTC = PipeWireAORTC
include("/home/dgamroth/workspaces/codex/worktrees/rtc-direct-session-launch/test/integration/classic_observation.jl")
include("queue-spec.jl")

const C = RTC.ControlClient
const S = RTC.SessionCodec
const R = RTC.RunnerCodec
const LOOPS = "pipewireao.correction-control."
const RECOVERY = "pipewireao-recovery:"
const SELECTIONS = Dict(
    "classic" => ("revolt-classic-jfg-frame-graph", ("closed-loop-correction:closed",)),
    "gpi2" => ("gpi2-jfg-frame-graph", ("closed-loop-correction:closed",)),
    "spiders" => ("spiders-controller", ("correction:closed", "llowfs-correction:closed")),
)

function command(client, operation, args...; timeout = 30)
    before = time_ns()
    completion = C.request!(client, S.RunnerCommand(operation, args...);
                            deadline = C.monotonic() + timeout)
    return Dict("sent_ns" => before, "received_ns" => time_ns(),
                "reply" => RTC.RunnerCommands.render(completion))
end
value(snapshot, key) = snapshot["reply"]["result"]["properties"][key]["value"]
properties(client, graph) = command(client, :properties, graph)
change(client, graph, key, scalar) = command(client, :properties_set, graph, Dict(key => scalar))

function observe_source(profile, app, remote, armed)
    prefix = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
    deployment = RTC.Common.read_json(joinpath(app, "deployment.conf"))
    decode(file) = RTC.DeploymentConfiguration.decode(joinpath(app, deployment[file]), prefix)
    core, session = decode("core"), decode("session")
    stems = if profile == "classic"
        (("detector", "simulator-detector", "detector-image"), ("slopes", "rtc-slopes", "shwfs-slopes"))
    elseif profile == "gpi2"
        (("detector", "simulator-detector", "detector-image"), ("pixels", "rtc-reconstruction-pixels", "reconstruction-pixels"))
    else
        (("scc", "spiders-scc-image", "spiders-scc-image"), ("llowfs", "spiders-llowfs-image", "spiders-llowfs-image"),
         ("scc-modal-residual", "spiders-scc-modal-residual", "spiders-scc-modal-residual"),
         ("llowfs-modal-residual", "spiders-llowfs-modal-residual", "spiders-llowfs-modal-residual"))
    end
    specs = map(fields -> queue_spec(session, core, fields...), stems)
    result = observe_classic(remote; stream_specs=specs, timeout=180, drive_interval=0.01,
        on_ready=() -> (armed[] = true))
    report = Dict{String,Any}()
    for (name, stream) in result["streams"]
        if name in ("detector","scc","llowfs")
            @assert stream["first_identity"] !== nothing
        end
        report[name] = Dict("acquisition" => stream["first_identity"],
                            "header_sequence" => stream["first_sequence"])
    end
    return report
end

function open!(record, role, destination, mode, stale_recovery_generation)
    graph, fields = SELECTIONS[role]
    client = C.connect(RTC.SessionProfile.Profile(), record["remote"], "pipewireao.rtc.session." * record["name"],
        record["session_pid"], record["session_control_instance"]; deadline=C.monotonic()+60)
    receipts = Dict{String,Any}()
    save() = RTC.Common.write_json(destination, receipts; atomic=true)
    try
        receipts["ready"] = command(client,:status)
        @assert receipts["ready"]["reply"]["state"] == "Ready" receipts["ready"]
        held = receipts["held"] = properties(client, graph)
        for field in fields
            @assert value(held,field) === false
            @assert value(held,LOOPS*field*".state") == "Open"
            @assert value(held,LOOPS*field*".primed") === false
            reply = receipts["held_close:"*field] = change(client,graph,field,R.RunnerScalar(:bool,true))
            @assert reply["reply"]["ok"] === false reply
        end
        if role != "classic"
            @assert value(held,RECOVERY*"state") == "idle"
            @assert value(held,RECOVERY*"request-token") == 0
            @assert value(held,RECOVERY*"recovery-generation") == 0
        end
        save()
        armed = Ref(false)
        observation = @async observe_source(role, dirname(Base.active_project()), record["remote"], armed)
        for _ in 1:1200
            armed[] && break
            istaskdone(observation) && fetch(observation)
            sleep(0.1)
        end
        @assert armed[]
        started = receipts["started"] = command(client,:session_start; timeout=90)
        @assert started["reply"]["ok"] && started["reply"]["state"] == "Running" started
        saved = Dict{String,Any}()
        receipts["first_live_priming"] = saved
        if role != "classic"
            receipts["probed_recovery_generation"] = stale_recovery_generation
            stale = receipts["stale_recovery_release"] = change(client, graph, RECOVERY*"release-token", R.RunnerScalar(:long,stale_recovery_generation))
            @assert !stale["reply"]["ok"] stale
        end
        expire = C.monotonic()+120
        while length(saved) != length(fields) && C.monotonic() < expire
            snapshot = properties(client,graph)
            @assert snapshot["reply"]["ok"] snapshot
            for field in fields
                @assert value(snapshot,field) === false
                @assert value(snapshot,LOOPS*field*".state") == "Open"
                if value(snapshot,LOOPS*field*".primed") === true && !haskey(saved, field)
                    saved[field] = snapshot
                    save()
                end
            end
            sleep(0.05)
        end
        @assert length(saved) == length(fields) receipts
        receipts["first_observed_acquisition"] = fetch(observation)
        if mode=="replacement"
            verified = receipts["replacement_write"] = change(client, graph, last(fields), R.RunnerScalar(:bool,false))
            @assert verified["reply"]["ok"] && verified["reply"]["state"]=="Running" verified
            save()
            directory=dirname(destination)
            touch(joinpath(directory,"running-qualified"))
            deadline=C.monotonic()+60
            while !isfile(joinpath(directory,"old-authority-checked"))
                C.monotonic()<deadline || error("old-authority proof was not completed")
                sleep(0.05)
            end
        end
        if role != "classic"
            intervention = receipts["fresh_recovery"] = change(client, graph, RECOVERY*"request-token", R.RunnerScalar(:long,Int64(15)))
            @assert intervention["reply"]["ok"] intervention
            deadline=C.monotonic()+45
            observed=properties(client,graph)
            while value(observed,RECOVERY*"recovery-generation")==0 && C.monotonic()<deadline
                sleep(0.05)
                observed=properties(client,graph)
            end
            receipts["recovery_after_request"] = observed
            @assert value(observed,RECOVERY*"request-token") == 15 observed
            generation=value(observed,RECOVERY*"recovery-generation")
            @assert generation>0 observed
            receipts["fresh_recovery_generation"]=generation
        end
        save()
        if mode=="leave"
            directory = dirname(destination)
            touch(joinpath(directory, "running-qualified"))
            deadline = C.monotonic() + 470
            while !isfile(joinpath(directory, "probe-old-authority"))
                C.monotonic() < deadline || error("replacement session did not request old-authority probe")
                sleep(0.05)
            end
            outcome = try
                command(client, :properties_set, graph, Dict(last(fields)=>R.RunnerScalar(:bool,false)); timeout = 6)
            catch error
                Dict("error"=>sprint(showerror,error))
            end
            @assert haskey(outcome,"error") || !outcome["reply"]["ok"] outcome
            receipts["old_authority_after_replacement"] = outcome
            save()
        else
            stopped = receipts["stopped"] = command(client,:session_stop; timeout=90)
            @assert stopped["reply"]["ok"] && stopped["reply"]["state"] == "Ready" stopped
            save()
        end
    finally
        save()
        close(client)
    end
end

ledger, role, destination, mode, generation = ARGS
record = RTC.Common.read_json(ledger)
@assert record["phase"] == "prepared"
open!(record,role,destination,mode,parse(Int64,generation))
