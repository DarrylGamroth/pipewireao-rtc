using PipeWireAO, PipeWireAORTC
const RTC = PipeWireAORTC
const B = RTC.OwnerBootstrapClient
const C = RTC.ControlClient
const BOOT = RTC.OwnerBootstrapCodec

function observe(client, owner, selection)
    records = Dict{String,Any}()
    expected = Dict{String,Any}()
    for property in split(selection,',')
        prefix = "pipewireao.correction-control." * property
        expected[property] = false
        expected[prefix*".state"] = "Open"
        expected[prefix*".primed"] = false
    end
    names = keys(expected)
    native = client.client
    global_node = only(find_globals(native.registry; properties=("node.name"=>owner,)))
    proxy = with_thread_loop_lock(native.loop) do _
        node = bind(native.registry,global_node,Node;
            on_param = function (_, sequence, id, index, next, pod)
                if id == SPA.PARAM_PROPS && pod !== nothing
                    for (key, value) in SPA.Props(pod).values
                        key in names || continue
                        records[key] = pod_value(typeof(expected[key]), value)
                    end
                end
                return nothing
            end)
        enum_params!(node, SPA.PARAM_PROPS; count=UInt32(16))
        return node
    end
    try
        C.poll(native, C._deadline_ns(C.monotonic()+10), Returns(nothing)) do _
            length(records) == length(expected)
        end
        @assert records == expected records
        return (; graph_serial=global_node.properties["object.serial"], properties=records)
    finally
        with_thread_loop_lock(_ -> close(proxy),native.loop)
    end
end

remote, bootstrap, process, owner, property, previous, receipt, mode = ARGS
pid = parse(Int,process)
if previous != "0"
    prefix = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
    expires = C.monotonic()+140
    while true
        info = RTC.Common.parse_json(read(`$(joinpath(prefix,"bin","pwao-dump")) -N -r $remote`,String))
        found = any(info) do item
            props = get(get(item,"info",Dict()),"props",Dict())
            get(props,"node.name",nothing) == bootstrap &&
                string(get(props,"object.serial",previous)) != previous
        end
        found && break
        C.monotonic()<expires || error("old bootstrap serial did not retire")
        sleep(0.2)
    end
end
client = B.connect(remote,bootstrap,pid,71; deadline=C.monotonic()+150)
@assert string(client.client.serial) != previous
try
    @assert B.connect_owner!(client;deadline=C.monotonic()+235).lifecycle == BOOT.Connected
    observed = observe(client,owner,property)
    RTC.Common.write_json(receipt,(; claimant_pid=getpid(),owner_pid=pid,
        bootstrap_serial=client.client.serial, observed...);atomic=true)
    if mode=="linger"
        while true
            sleep(0.2)
        end
    end
    @assert B.quit!(client;deadline=C.monotonic()+20).lifecycle == BOOT.Stopped
finally
    close(client)
end
