import json, os, pathlib, shutil, subprocess as sp, sys
root=pathlib.Path(__file__).resolve().parent
profile, scope = sys.argv[1:]
record=json.loads((root/f"{profile}-{scope}.json").read_text())
app=pathlib.Path(record["app"])
variant=profile[0]+root.name[-5:].lower()+("p" if scope=="persistent" else "d")
unit=f"pipewireao-session@{variant}.service"
result=sp.run(["systemctl","--user","show",unit,"-p","MainPID,ActiveState"],text=True,capture_output=True)
assert "MainPID=0" in result.stdout and not any(x in result.stdout for x in ["ActiveState=active\n","ActiveState=activating\n","ActiveState=deactivating\n"]), result.stdout
deployment=app/"deployment.conf"
previous=app.with_name(app.name+"-default-optimization-deployment.conf")
assert not previous.exists() and deployment.is_file()
shutil.copy2(deployment,previous)
systemd=app/"systemd"
units_archive=app.with_name(app.name+"-default-optimization-systemd")
assert systemd.is_dir() and not units_archive.exists()
for service in systemd.glob("*.service"):
    if "@." not in service.name:
        linked=pathlib.Path(os.environ["XDG_RUNTIME_DIR"])/"systemd/user"/service.name
        assert not linked.is_symlink() or linked.resolve()!=service,service
systemd.rename(units_archive)
spec=json.loads(deployment.read_text())
for owner in spec["owners"]:
    if owner["role"]!=spec["source-owner"]:
        owner["argv"].insert(1,"-O0")
deployment.write_text(json.dumps(spec,sort_keys=True,separators=(",",":"))+"\n")
env=dict(os.environ,**record["env"],RTC_FUNCTIONAL_NO_HIL_IMAGE="1")
prefix=pathlib.Path.home()/".julia/artifacts/77da251765f3124df77322c562e67a7c7742ab1d"
if scope=="persistent":
    runtime_name = f"sx-{root.name[-5:].lower()}" if profile=="spiders" else f"iv3-{profile[0]}-{root.name[-5:].lower()}"
    runtime=pathlib.Path(os.environ["XDG_RUNTIME_DIR"])/runtime_name
    env.update(PIPEWIREAORTC_CORE_UNIT=runtime.name+"-core.service",PIPEWIREAORTC_SOURCE_UNIT=runtime.name+"-source.service",
               PIPEWIREAORTC_CORE_SOCKET=str(runtime/"c"))
sp.run(["nice","-n","6","taskset","-c","4,5",record["julia"],"--startup-file=no","-O0","--threads=2,0",
        "--project="+str(app),root/"install.jl",app,record["source"],scope],env=env,check=True,timeout=600)

record["owner_optimization"]="0"
(root/f"{profile}-{scope}.json").write_text(json.dumps(record,indent=2)+"\n")
