# Optional real CPU optical preparation; no core, service or device is opened.
using Proper
include("simulation_optical.jl")
OpticalSimulationTests.test_preparation()
