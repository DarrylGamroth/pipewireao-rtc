module OpticalObservation

import PipeWireAORTC
import Clocks

using AdaptiveOpticsSim
using AdaptiveOpticsSim.AlgorithmGraphs
using AdaptiveOpticsSim.AlgorithmGraphs:
    prepare_graph_output_snapshot,
    snapshot_values,
    poll_graph_output_snapshot!,
    snapshot_metadata,
    release_graph_output_snapshot!,
    try_snapshot_graph_output!,
    reset_graph_output_snapshot!
using AdaptiveOpticsSimPipeWireHIL
using PipeWireAO
using ThreadPinning
using Base.Threads: Atomic, atomic_add!, atomic_cas!

const Optics = AdaptiveOpticsSim.Optics
const FOCAL_IMAGE_SCHEMA = PipeWireAORTC.Schemas.identifier("focal_photon_rate")
# Piston-removed OPD in nm on the transmitting pupil; excluded pixels are NaN.
const WAVEFRONT_SCHEMA = PipeWireAORTC.Schemas.identifier("residual_pupil_opd_nm")
# One row: uncorrected atmosphere RMS, corrected pupil RMS; both in nm OPD.
const RMS_SCHEMA = PipeWireAORTC.Schemas.identifier("pupil_opd_rms_nm")
const RMS_CHANNELS = (
    (
        name = "uncorrected_atmosphere_rms",
        index = 0,
        title = "Uncorrected atmosphere RMS",
        units = "nm OPD",
    ),
    (
        name = "corrected_pupil_rms",
        index = 1,
        title = "Corrected pupil RMS",
        units = "nm OPD",
    ),
)
const PERIOD_NS = Int64(50_000_000)
const PREPARATION_TIMEOUT_NS = Int64(30_000_000_000)
const RMS_SHAPE = (1, 2)

mutable struct Observation{S,U,I,V,M}
    snapshot::S
    atmosphere_snapshot::U
    busy::Atomic{Bool}
    imaging::I
    values::V
    wavefront::V
    rms::V
    pupil::M
    stop::Atomic{Bool}
    failed::Atomic{Bool}
    completed::Atomic{UInt64}
    dropped::Atomic{UInt64}
    generation::UInt64
    next_sample_ns::Union{Nothing,Int64}
    host_ns::Union{Nothing,Int64}
    task::Any
end

prepare(::Nothing, graph; imaging = nothing) = nothing
reference_snapshots(::Nothing) = ()
reference_snapshots(snapshot) = (snapshot,)
snapshots(observation::Observation) =
    (observation.snapshot, reference_snapshots(observation.atmosphere_snapshot)...)

function contracts()
    optics = Base.get_extension(PipeWireAORTC, :PipeWireAORTCOpticsExt)
    if optics === nothing
        # RTC versions before 0.7.26 keep the contract in the AOS extension.
        optics = Base.get_extension(PipeWireAORTC, :PipeWireAORTCAOSExt)
    end
    return optics.OpticalObservation
end

function verify_product(values, contract)
    collect(size(values)) == contract["shape"] && eltype(values) === Float32 || throw(
        DimensionMismatch(
            "optical observation product differs from its cold port contract"
        ),
    )
    return nothing
end

function prepare(definition::AlgorithmGraphDefinition, graph; imaging = nothing)
    declarations = contracts()
    config = declarations.guide_sensor(definition.nodes)
    selected = imaging === nothing ? declarations.default_imaging() : imaging
    ports = declarations.port_contracts(definition; imaging = selected)
    # Use the plant aperture and the explicitly selected source photometry.
    # This product is ideal photon rate, without detector exposure or noise.
    telescope = Optics.prepare_telescope(
        config.telescope, AdaptiveOpticsSim.Backends.HostComputeDevice()
    )
    source = declarations.imaging_source(selected.source, config)
    zero_padding = selected.zero_padding
    snapshot = prepare_graph_output_snapshot(graph, Val(:pupil_opd))
    atmosphere_snapshot = nothing
    try
        if any(declarations.atmosphere_output, definition.outputs)
            atmosphere_snapshot = prepare_graph_output_snapshot(graph, Val(:atmosphere_opd))
            axes(snapshot_values(atmosphere_snapshot)) == axes(snapshot_values(snapshot)) ||
                throw(DimensionMismatch("atmosphere and pupil OPD axes must match"))
        end
        pupil = Optics.PupilFunction(telescope, snapshot_values(snapshot))
        imaging = Optics.prepare_direct_imaging(pupil, source; zero_padding)
        Optics.form_direct_image!(imaging)
        intensity = Optics.intensity_values(Optics.direct_imaging_output(imaging))
        focal = Matrix{Float32}(undef, reverse(size(intensity)))
        form_focal_image!(focal, intensity)
        pupil_mask = Matrix{Bool}(Optics.pupil_mask(telescope))
        any(pupil_mask) ||
            throw(ArgumentError("optical observation needs a transmitting pupil"))
        wavefront = Matrix{Float32}(undef, reverse(size(pupil_mask)))
        verify_product(focal, ports["focal-image"])
        verify_product(wavefront, ports["residual-wavefront"])
        return Observation(
            snapshot,
            atmosphere_snapshot,
            Atomic{Bool}(false),
            imaging,
            focal,
            wavefront,
            zeros(Float32, RMS_SHAPE),
            pupil_mask,
            Atomic{Bool}(false),
            Atomic{Bool}(false),
            Atomic{UInt64}(0),
            Atomic{UInt64}(0),
            UInt64(0),
            nothing,
            nothing,
            nothing,
        )
    catch error
        try
            finalize_snapshots!(
                close, (snapshot, reference_snapshots(atmosphere_snapshot)...)
            )
        catch cleanup
            throw(CompositeException([error, cleanup]))
        end
        rethrow()
    end
end

source_options(::Nothing; reference_clock = METADATA_CLOCK_REALTIME) = ()
function source_options(observation::Observation; reference_clock = METADATA_CLOCK_REALTIME)
    properties = Dict(
        "node.loop.name" => "telemetry-loop",
        "node.group" => "pipewireao-optical-observation",
        "node.sync-group" => "sync.pipewireao-optical-observation",
    )
    images = (
        PipeWireImageSourceOptions(
            node_name = "simulator-focal-image",
            media_name = "focal-image",
            schema = FOCAL_IMAGE_SCHEMA,
            shape = size(observation.values),
            rate = SPA.Fraction(UInt32(20), UInt32(1)),
            buffers = 3,
            properties = properties,
            reference_clock = reference_clock,
        ),
        PipeWireImageSourceOptions(
            node_name = "simulator-residual-wavefront",
            media_name = "residual-wavefront",
            schema = WAVEFRONT_SCHEMA,
            shape = size(observation.wavefront),
            rate = SPA.Fraction(UInt32(20), UInt32(1)),
            buffers = 3,
            properties = properties,
            reference_clock = reference_clock,
        ),
    )
    return (
        images...,
        rms_source_options(observation.atmosphere_snapshot, properties, reference_clock)...,
    )
end

rms_source_options(::Nothing, properties, reference_clock) = ()
rms_source_options(snapshot, properties, reference_clock) = (
    PipeWireImageSourceOptions(
        node_name = "simulator-wavefront-rms",
        media_name = "wavefront-rms",
        schema = RMS_SCHEMA,
        shape = RMS_SHAPE,
        rate = SPA.Fraction(UInt32(20), UInt32(1)),
        buffers = 3,
        properties = properties,
        channels = RMS_CHANNELS,
        reference_clock = reference_clock,
    ),
)

# One producer admits the complete cohort before advancing the graph. Its busy
# flag stays set until the consumer releases every transfer, so independent
# snapshot slots cannot pair different graph frames under observer backpressure.
function submit!(
    observation::Observation;
    generation = observation.generation,
    pts = Int64(0),
    model_time_ns = Int64(0),
)
    atomic_cas!(observation.busy, false, true) == false || return false
    for snapshot in snapshots(observation)
        try_snapshot_graph_output!(snapshot; generation, pts, model_time_ns) ||
            throw(ArgumentError("optical snapshot cohort was not free"))
    end
    return true
end

function poll!(observation::Observation)
    observation.busy[] || return false
    ready = true
    for snapshot in snapshots(observation)
        ready &= poll_graph_output_snapshot!(snapshot)
    end
    return ready
end

function release!(observation::Observation)
    for snapshot in snapshots(observation)
        release_graph_output_snapshot!(snapshot)
    end
    observation.busy[] = false
    return nothing
end

function process_sample!(observation::Observation, pipewire)
    poll!(observation) || return false
    try
        metadata = snapshot_metadata(observation.snapshot)
        for snapshot in reference_snapshots(observation.atmosphere_snapshot)
            snapshot_metadata(snapshot) == metadata ||
                throw(ArgumentError("optical snapshot cohort metadata differs"))
        end
        # Reset may have advanced the source generation during optional imaging.
        metadata.generation == observation.generation || return false
        form_products!(observation)
        stage_pipewire_image!(
            pipewire,
            1,
            observation.values,
            metadata.sequence,
            metadata.pts,
            metadata.generation,
        )
        stage_pipewire_image!(
            pipewire,
            2,
            observation.wavefront,
            metadata.sequence,
            metadata.pts,
            metadata.generation,
        )
        stage_rms!(observation.atmosphere_snapshot, observation, pipewire, metadata)
    finally
        release!(observation)
    end
    atomic_add!(observation.completed, UInt64(1))
    return true
end

stage_rms!(::Nothing, observation, pipewire, metadata) = nothing
stage_rms!(snapshot, observation, pipewire, metadata) = stage_pipewire_image!(
    pipewire, 3, observation.rms, metadata.sequence, metadata.pts, metadata.generation
)

function form_products!(observation::Observation)
    Optics.form_direct_image!(observation.imaging)
    form_focal_image!(
        observation.values,
        Optics.intensity_values(Optics.direct_imaging_output(observation.imaging)),
    )
    form_wavefront!(
        observation.wavefront, snapshot_values(observation.snapshot), observation.pupil
    )
    form_rms!(observation.atmosphere_snapshot, observation)
    return nothing
end

form_rms!(::Nothing, observation) = nothing
function form_rms!(atmosphere_snapshot, observation)
    observation.rms[1, 1] = pupil_rms_nm(
        snapshot_values(atmosphere_snapshot), observation.pupil
    )
    observation.rms[1, 2] = pupil_rms_nm(
        snapshot_values(observation.snapshot), observation.pupil
    )
    return nothing
end

# Spatial population RMS after removing pupil piston. Welford's update avoids
# subtracting two large moments and uses the same actual mask for both signals.
function pupil_rms_nm(opd, pupil)
    axes(opd) == axes(pupil) || throw(DimensionMismatch("OPD and pupil axes must match"))
    count = 0
    mean = 0.0
    variance_sum = 0.0
    for index in eachindex(opd, pupil)
        if pupil[index]
            value = Float64(opd[index])
            isfinite(value) ||
                throw(ArgumentError("nonfinite OPD on the transmitting pupil"))
            count += 1
            delta = value - mean
            mean += delta / count
            variance_sum += delta * (value - mean)
        end
    end
    count > 0 || throw(ArgumentError("wavefront observation needs a transmitting pupil"))
    return Float32(sqrt(max(0.0, variance_sum / count)) * 1e9)
end

# AOS optical arrays index increasing physical [x, y]. Image rows increase down,
# so both optical diagnostics transpose the axes and reverse physical y.
@inline image_source_index(source, row, column) =
    CartesianIndex(column, lastindex(source, 2) - (row - firstindex(source, 2)))

function form_focal_image!(destination, intensity)
    ndims(destination) == ndims(intensity) == 2 &&
    axes(destination) == reverse(axes(intensity)) || throw(
        DimensionMismatch("focal image axes must reverse the rank-two intensity axes")
    )
    Base.mightalias(destination, intensity) &&
        throw(ArgumentError("focal image must not alias the intensity"))
    for column in axes(destination, 2), row in axes(destination, 1)
        destination[row, column] = intensity[image_source_index(intensity, row, column)]
    end
    return destination
end

# Presentation of the same owned pupil snapshot used for ideal imaging. Uniform
# pupil-sample weighting matches the CPU replay metric; tip/tilt remain included.
# AOS indexes physical [x, y]; image [row, column] places +x right and +y up.
# The destination has reversed source axes and must not alias either input.
# No controller state, graph output or physical command is modified.
function form_wavefront!(destination, opd, pupil)
    ndims(destination) == ndims(opd) == ndims(pupil) == 2 &&
    axes(opd) == axes(pupil) &&
    axes(destination) == reverse(axes(opd)) || throw(
        DimensionMismatch(
            "wavefront image axes must reverse the matching rank-two OPD and pupil axes"
        ),
    )
    (Base.mightalias(destination, opd) || Base.mightalias(destination, pupil)) &&
        throw(ArgumentError("wavefront image must not alias the OPD or pupil"))
    total = 0.0
    count = 0
    for index in eachindex(opd, pupil)
        if pupil[index]
            value = opd[index]
            isfinite(value) ||
                throw(ArgumentError("nonfinite OPD on the transmitting pupil"))
            total += Float64(value)
            count += 1
        end
    end
    count > 0 || throw(ArgumentError("wavefront observation needs a transmitting pupil"))
    piston = total / count
    for column in axes(destination, 2), row in axes(destination, 1)
        index = image_source_index(opd, row, column)
        destination[row, column] =
            pupil[index] ? Float32((Float64(opd[index]) - piston) * 1e9) : NaN32
    end
    return destination
end

function worker!(observation::Observation, pipewire, cpu::Int)
    # The cold static initializer schedules this task on default thread two.
    # Its CPU is declared by deployment; the source remains on thread one.
    current_task().sticky = true
    try
        Threads.threadid() == 2 ||
            throw(ArgumentError("optical worker must run on Julia thread two"))
        ThreadPinning.pinthread(cpu)
        println(
            "OPTICAL_WORKER thread=$(Threads.threadid()) cpu=$(ThreadPinning.getcpuid())"
        )
        while !observation.stop[]
            process_sample!(observation, pipewire)
            GC.safepoint()
            yield()
        end
    catch
        # Optional observation faults stop observation only. The retained slot
        # is drained by close/reset; no exception crosses a native callback.
        observation.failed[] = true
    end
    return nothing
end

start!(::Nothing, pipewire, cpu) = nothing
function start!(observation::Observation, pipewire, cpu)
    observation.task === nothing || throw(ArgumentError("optical worker already started"))
    Threads.nthreads(:default) >= 2 &&
    Threads.nthreads(:interactive) == 0 &&
    Threads.threadid() == 1 || throw(
        ArgumentError(
            "optical observation requires two default Julia threads with the source on thread one",
        ),
    )
    cpu !== nothing && cpu > 1 && cpu != ThreadPinning.getcpuid() || throw(
        ArgumentError(
            "observation worker CPU must differ from the source CPU and exclude CPU0/1"
        ),
    )
    observation.stop[] = false
    # Thread two also serves cold bootstrap polling. Both tasks yield; science
    # stays on thread one and no observation work enters a native callback.
    observation.task = ThreadPinning.@spawnat 2 worker!(observation, pipewire, cpu)
    return nothing
end

warm!(
    ::Nothing,
    pipewire;
    check = () -> nothing,
    cpu = nothing,
    clock::Clocks.AbstractNanoClock = Clocks.SystemNanoClock(),
) = nothing
function pin_image_thread!(cpu::Integer)
    cpu > 1 || throw(ArgumentError("image thread CPU must exclude CPU0/1"))
    # pw_thread_loop_start passes only its name to the native thread creator.
    # Placement is deployment-owned and performed once before admission.
    root = "/proc/self/task"
    tids = filter(readdir(root)) do tid
        strip(read(joinpath(root, tid, "comm"), String)) == "AOS-HIL-images"
    end
    length(tids) == 1 || throw(ArgumentError("expected exactly one native image thread"))
    tid = only(tids)
    run(pipeline(`taskset -pc $cpu $tid`; stdout = devnull))
    status = read(joinpath(root, tid, "status"), String)
    affinity = match(r"(?m)^Cpus_allowed_list:\s*(.+)$", status)
    affinity !== nothing && strip(affinity.captures[1]) == string(cpu) ||
        throw(ArgumentError("native image thread CPU placement was not applied"))
    return nothing
end
function warm!(
    observation::Observation,
    pipewire;
    check = () -> nothing,
    cpu = nothing,
    clock::Clocks.AbstractNanoClock = Clocks.SystemNanoClock(),
)
    check()
    observation.generation = UInt64(frame_acquisition_generation(pipewire))
    cpu !== nothing && cpu > 1 ||
        throw(ArgumentError("observation worker CPU is not configured"))
    pin_image_thread!(cpu)
    start!(observation, pipewire, cpu)
    target = observation.completed[] + UInt64(1)
    submit!(observation; generation = observation.generation) ||
        throw(ArgumentError("cannot warm the optical snapshot"))
    previous = Clocks.time_nanos(clock)::Int64
    deadline = Base.checked_add(previous, PREPARATION_TIMEOUT_NS)
    while true
        now_ns = Clocks.time_nanos(clock)::Int64
        # Completed slot release is known even at expiry or a regressed clock.
        observation.completed[] >= target && break
        check()
        observation.failed[] &&
            throw(ArgumentError("optical worker failed during preparation"))
        now_ns >= previous ||
            throw(ArgumentError("optical worker monotonic clock regressed"))
        previous = now_ns
        now_ns < deadline || throw(ArgumentError("optical worker preparation timed out"))
        GC.safepoint()
        yield()
    end
    reset_pipewire_image_sources!(pipewire)
    # Keep the actual warmed task and its CUDA task-local state alive. The
    # completion counter publishes only after the slot has been released.
    return nothing
end

sample!(::Nothing, timing, model_ns, now) = false
function sample!(
    observation::Observation,
    timing::PipeWireFrameCommandTiming,
    model_ns::Int64,
    now::Int64,
)
    return sample!(observation, timing.source_published_nanoseconds, model_ns, now)
end

function sample!(observation::Observation, pts::Int64, model_ns::Int64, now::Int64)
    observation.failed[] && return false
    previous = observation.host_ns
    if previous !== nothing && now < previous
        observation.failed[] = true
        return false
    end
    observation.host_ns = now
    next = observation.next_sample_ns
    next !== nothing && now < next && return false
    observation.next_sample_ns = try
        Base.checked_add(now, PERIOD_NS)
    catch
        observation.failed[] = true
        return false
    end
    admitted = try
        submit!(observation; generation = observation.generation, pts, model_time_ns = model_ns)
    catch
        observation.failed[] = true
        false
    end
    admitted || atomic_add!(observation.dropped, UInt64(1))
    return admitted
end

stop_worker!(::Nothing) = nothing
function stop_worker!(observation::Observation)
    observation.stop[] = true
    task = observation.task
    task === nothing || wait(task)
    observation.task = nothing
    return nothing
end

reset!(
    ::Nothing,
    pipewire;
    check = () -> nothing,
    cpu = nothing,
    clock::Clocks.AbstractNanoClock = Clocks.SystemNanoClock(),
) = nothing
function reset!(
    observation::Observation,
    pipewire;
    check = () -> nothing,
    cpu = nothing,
    clock::Clocks.AbstractNanoClock = Clocks.SystemNanoClock(),
)
    observation.next_sample_ns = nothing
    observation.failed[] = false
    warm!(observation, pipewire; check, cpu, clock)
    return nothing
end

drain!(::Nothing) = nothing
function drain!(observation::Observation)
    stop_worker!(observation)
    finalize_snapshots!(reset_graph_output_snapshot!, observation)
    observation.busy[] = false
    return nothing
end

close!(::Nothing) = nothing
function close!(observation::Observation)
    stop_worker!(observation)
    finalize_snapshots!(close, observation)
    return nothing
end

finalize_snapshots!(operation, observation::Observation) =
    finalize_snapshots!(operation, snapshots(observation))
function finalize_snapshots!(operation, owned::Tuple)
    failures = Exception[]
    for snapshot in owned
        try
            operation(snapshot)
        catch error
            push!(failures, error)
        end
    end
    isempty(failures) ||
        throw(length(failures) == 1 ? only(failures) : CompositeException(failures))
    return nothing
end

function close!(observation, pipewire)
    failures = Exception[]
    try
        close!(observation)
    catch error
        push!(failures, error)
    end
    try
        pipewire === nothing || close(pipewire)
    catch error
        push!(failures, error)
    end
    isempty(failures) ||
        throw(length(failures) == 1 ? only(failures) : CompositeException(failures))
    return nothing
end

end
