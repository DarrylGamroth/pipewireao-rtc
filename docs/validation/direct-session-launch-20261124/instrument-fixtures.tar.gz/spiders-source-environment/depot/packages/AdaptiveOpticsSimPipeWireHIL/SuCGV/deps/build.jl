using PipeWireAO_jll

include("command_receiver_build.jl")
using .CommandReceiverBuild: FILENAME, build

build(joinpath(@__DIR__, FILENAME), PipeWireAO_jll.artifact_dir,
    dirname(PipeWireAO_jll.libpipewire_ao_path))
