# Deliver two optical input intervals over a private core and verify both camera windows.
function external_pupil_delivery(remote, options; reconnect = false)
    science = prepare_external_pupil_ports(options.plant.definition; settings = options.plant.settings)
    names = keys(science.sensors)
    formats = (
        science.pupil.shape, map(sensor -> size(sensor.image), values(science.sensors))...
    )
    schemas = (
        science.pupil.schema, map(sensor -> sensor.schema, values(science.sensors))...
    )
    peers = Tuple(
        PipeWireArrayStreamOptions(
            node_name = "test.optical.peer.$index",
            media_name = "test",
            # Fixed source and sink buffer pools must agree at link negotiation.
            buffers = index == 1 ? 2 : options.sensor_buffers,
            metadata = PipeWireAORTC.Common.ACQUISITION_METADATA,
            schema = schemas[index],
            format = NdArrayFormat(
                NdArray.F32_LE, formats[index]; layout = NdArray.ROW_MAJOR
            ),
        ) for index in 1:3
    )
    with_array_streams(peers; remote, input = (false, true, true)) do owner
        registry = with_array_stream(owner, 1) do _
            Registry(owner.core)
        end
        links = Link[]
        try
            function connect(output_name, input_name)
                ports = nothing
                _wait_for_hil_condition() do
                    roundtrip(registry)
                    output = find_globals(
                        registry;
                        interface = "PipeWire:Interface:Node",
                        properties = ("node.name" => output_name,),
                    )
                    input = find_globals(
                        registry;
                        interface = "PipeWire:Interface:Node",
                        properties = ("node.name" => input_name,),
                    )
                    length(output) == length(input) == 1 || return false
                    output_id, input_id = only(output).id, only(input).id
                    outputs = find_globals(
                        registry;
                        interface = "PipeWire:Interface:Port",
                        properties = (
                            "node.id" => string(output_id), "port.direction" => "out"
                        ),
                    )
                    inputs = find_globals(
                        registry;
                        interface = "PipeWire:Interface:Port",
                        properties = (
                            "node.id" => string(input_id), "port.direction" => "in"
                        ),
                    )
                    length(outputs) == length(inputs) == 1 || return false
                    ports = (output_id, only(outputs).id, input_id, only(inputs).id)
                    true
                end
                link = with_array_stream(owner, 1) do _
                    create_object(
                        owner.core,
                        "link-factory",
                        Link;
                        properties = Dict(
                            "link.output.node" => string(ports[1]),
                            "link.output.port" => string(ports[2]),
                            "link.input.node" => string(ports[3]),
                            "link.input.port" => string(ports[4]),
                            "object.linger" => "false",
                        ),
                    )
                end
                push!(links, link)
                return link
            end
            function disconnect(link)
                with_array_stream(owner, 1) do _
                    close(link)
                end
                filter!(candidate -> candidate !== link, links)
                return nothing
            end
            connect("test.optical.peer.1", options.pupil_node)
            function attach_camera(index)
                return connect(
                    getproperty(options.sensor_nodes, names[index]),
                    "test.optical.peer.$(index + 1)",
                )
            end
            llowfs = attach_camera(1)
            scc = attach_camera(2)
            packet = zeros(Float32, science.pupil.shape)
            packet[2, :, :] .= 1
            images = map(shape -> zeros(Float32, shape), formats[2:end])
            domain = AcquisitionDomain(ntuple(i -> UInt8(i), 16))
            pupil_duration = UInt64(2_000_000)
            function offer(sequence)
                @test stage_pipewire_array!(
                    owner,
                    1,
                    packet;
                    identity = AcquisitionIdentity(domain, UInt64(1), UInt64(sequence)),
                    pts = Int64((sequence - 1) * pupil_duration),
                    duration = pupil_duration,
                )
            end
            function observe(camera, sequence, duration)
                stream = camera + 1
                receipt = Ref{Any}(nothing)
                _wait_for_hil_condition(; timeout = 20) do
                    with_array_stream(trigger_process!, owner, 1)
                    array_stream_status(owner, stream).pending || return false
                    receipt[] = drain_pipewire_array!(images[camera], owner, stream)
                    receipt[].identity.sequence >= sequence
                end
                row = receipt[]
                @test row.identity.sequence == sequence && row.duration == duration
                @test row.pts == (sequence - 1) * duration
                @test all(isfinite, images[camera]) && sum(images[camera]) > 0
                return row.identity
            end

            offer(1)
            llowfs_identity = observe(1, 1, 2_000_000)
            @test !array_stream_status(owner, 3).pending
            offer(2)
            observe(1, 2, 2_000_000)
            scc_identity = observe(2, 1, 4_000_000)
            reconnect || return

            # The LLOWFS observer stays linked while the separate SCC consumer
            # leaves and reattaches. Both camera domains must remain stable.
            disconnect(scc)
            offer(3)
            @test observe(1, 3, 2_000_000).domain == llowfs_identity.domain
            scc = attach_camera(2)
            offer(4)
            @test observe(1, 4, 2_000_000).domain == llowfs_identity.domain
            @test observe(2, 2, 4_000_000).domain == scc_identity.domain

            # Leave only the independent input producer connected. Four
            # further intervals exceed the simulator's one retained input
            # and create two SCC exposures before either consumer returns.
            disconnect(llowfs)
            disconnect(scc)
            for sequence in 5:8
                offer(sequence)
                _wait_for_hil_condition(; timeout = 10) do
                    with_array_stream(trigger_process!, owner, 1)
                    !array_stream_status(owner, 1).pending
                end
                sleep(0.2)
            end
            attach_camera(1)
            attach_camera(2)
            offer(9)
            @test observe(1, 9, 2_000_000).domain == llowfs_identity.domain
            offer(10)
            @test observe(1, 10, 2_000_000).domain == llowfs_identity.domain
            @test observe(2, 5, 4_000_000).domain == scc_identity.domain
        finally
            with_array_stream(owner, 1) do _
                foreach(close, reverse(links))
                close(registry)
            end
        end
    end
end

