module CommandReceiverBuild

include("../src/command_receiver_library.jl")
using .CommandReceiverLibrary: FILENAME

function build(library, prefix, libdir; julia = first(Base.julia_cmd().exec))
    parent = mkpath(dirname(library))
    mktempdir(parent) do directory
        output = joinpath(directory, FILENAME)
        compiler = Cmd(Base.shell_split(get(ENV, "CC", "cc")))
        includes = joinpath(prefix, "include")
        run(`$compiler -std=gnu11 -O3 -fPIC -shared -Wl,-z,defs
            -I$(joinpath(includes, "pipewire-ao-0.3")) -I$(joinpath(includes, "spa-ao-0.2"))
            $(joinpath(@__DIR__, "command_receiver.c")) -L$libdir -lpipewire-ao-0.3 -o $output`)
        # Verify in a new process so a different libpipewire-ao already
        # loaded by the installer cannot satisfy the helper's dependency.
        code = """
            using Libdl: dllist
            include(ARGS[1])
            receiver = CommandReceiverLibrary.load(ARGS[2])
            loaded = filter(p -> startswith(basename(p), "libpipewire-ao-0.3.so"), dllist())
            length(loaded) == 1 && samefile(only(loaded), ARGS[3]) ||
                error("command receiver linked a different PipeWireAO library")
            close(receiver)
            """
        source = joinpath(@__DIR__, "..", "src", "command_receiver_library.jl")
        native = joinpath(libdir, "libpipewire-ao-0.3.so")
        verifier = `$julia --startup-file=no --compiled-modules=existing
            --pkgimages=existing -e $code $source $output $native`
        run(addenv(verifier, "LD_LIBRARY_PATH" => libdir, "JULIA_LOAD_PATH" => "@stdlib"))
        mv(output, library; force = true)
    end
    return nothing
end

end
