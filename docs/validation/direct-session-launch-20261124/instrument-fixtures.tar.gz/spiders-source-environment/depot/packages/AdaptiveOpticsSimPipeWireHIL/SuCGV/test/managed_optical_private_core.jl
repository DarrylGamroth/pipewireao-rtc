# Optional CPU selector with the managed source extension and a private core.
using Test,
    PipeWireAORTC, AdaptiveOpticsSim, AdaptiveOpticsSimPipeWireHIL, Proper, PipeWireAO
import PipeWireAO_jll
include(joinpath(pkgdir(PipeWireAORTC), "test", "external_pupil_owner_documents.jl"))
include("private_core_helpers.jl")
const Owner = PipeWireAORTC.AOSOwner
const Client = PipeWireAORTC.OwnerBootstrapClient
const Codec = PipeWireAORTC.OwnerBootstrapCodec
const Source = PipeWireAORTC.SourceControl
using PipeWireAORTC.InstrumentExport: prepare_external_pupil_ports
deadline() = time_ns() / 1e9 + 180

@testset "managed optical observation contract" begin
    extension = Base.get_extension(AdaptiveOpticsSimPipeWireHIL, :PipeWireAORTCExt)
    contracts = extension.OpticalObservation.contracts()
    @test isdefined(contracts, :imaging_configuration)
    @test isdefined(contracts, :port_contracts)
end

include("external_pupil_delivery.jl")

@testset "managed external-pupil shutdown by $termination" for termination in (:quit, :interrupt)
    mktempdir() do directory
        (; config) = external_pupil_owner_documents(directory)
        _with_private_core() do remote
            remote = joinpath(ENV["PIPEWIREAO_RUNTIME_DIR"], remote)
            control_node = "test.optical.control"
            bootstrap_node = "test.optical.bootstrap"
            options = merge(Owner.configuration(config), (; control_node))
            args = [
                "--config", config, "--remote", remote, "--control-node", control_node,
                "--bootstrap-node", bootstrap_node, "--bootstrap-instance", "51",
            ]
            launcher = joinpath(pkgdir(AdaptiveOpticsSimPipeWireHIL), "src", "managed.jl")
            project = dirname(Base.active_project())
            command = `$(Base.julia_cmd()) --project=$project --startup-file=no --threads=2,0 $launcher $args`
            startup_ready = joinpath(directory, "startup-ready")
            if termination === :interrupt
                # Julia wraps a signal delivered during a package initializer in InitError.
                source_dir = mkpath(joinpath(directory, "PipeWireAOOpticalStartup", "src"))
                write(joinpath(source_dir, "PipeWireAOOpticalStartup.jl"), """
                    module PipeWireAOOpticalStartup
                    function __init__()
                        touch(ENV["HIL_TEST_STARTUP_READY"])
                        sleep(120)
                    end
                    end
                    """)
                command = addenv(command,
                    "JULIA_LOAD_PATH" => join([directory; LOAD_PATH], ':'),
                    "PIPEWIREAO_OPTICAL_STARTUP" => "interrupt-test",
                    "HIL_TEST_STARTUP_READY" => startup_ready,
                )
            end
            log = joinpath(directory, "managed.log")
            process = run(pipeline(command; stdout = log, stderr = log); wait = false)
            client = source = nothing
            try
                client = Client.connect(
                    remote, bootstrap_node, getpid(process), 51; deadline = deadline()
                )
                @test Client.status(client; deadline = deadline()).lifecycle === Codec.Preparing
                if termination === :interrupt
                    _wait_for_hil_condition(; timeout = 30) do
                        process_exited(process) && error(read(log, String))
                        isfile(startup_ready)
                    end
                    kill(process, Base.SIGINT)
                    _wait_for_hil_condition(() -> process_exited(process); timeout = 15)
                    @test success(process)
                    @test !occursin("wrong context", read(log, String))
                    return
                end
                @test Client.connect_owner!(client; deadline = deadline()).lifecycle ===
                    Codec.Connected
                snapshot_codec = PropsBuffer(
                    Source.SNAPSHOT_NAMES,
                    Source.snapshot_values(
                        Int64(1),
                        Source.INITIAL,
                        Int64(0),
                        Int32(0),
                        Int64(1),
                        Int64(0),
                        false,
                        false,
                        Int64(1),
                        Int64(0),
                    ),
                )
                snapshot = Ref(snapshot_codec.prototype)
                # The public Node interface carries the same source PODs as a
                # camera Stream, with no invented detector or mirror port.
                source = with_thread_loop_lock(client.client.loop) do _
                    registry = something(client.client.registry)
                    object = only(
                        find_globals(
                            registry;
                            interface = "PipeWire:Interface:Node",
                            properties = ("node.name" => options.control_node,),
                        ),
                    )
                    node = bind(
                        registry,
                        object,
                        Node;
                        on_param = (node, seq, id, index, next, pod) -> begin
                            id == SPA.PARAM_PROPS &&
                                pod !== nothing &&
                                parse_props!(snapshot, snapshot_codec, pod)
                            nothing
                        end,
                    )
                    subscribe_params!(node, (SPA.PARAM_PROPS,))
                    node
                end
                function control(pod, kind, token)
                    with_thread_loop_lock(client.client.loop) do _
                        set_param!(source, SPA.PARAM_PROPS, pod)
                    end
                    _wait_for_hil_condition(; timeout = 10) do
                        process_exited(process) && error(read(log, String))
                        with_thread_loop_lock(client.client.loop) do _
                            snapshot[][3] == kind && snapshot[][4] == token
                        end
                    end
                    return with_thread_loop_lock(client.client.loop) do _
                        snapshot[]
                    end
                end
                running = control(run_control_request(1, :running), Source.RUN, 1)
                @test running[5] == 0 && running[8]
                external_pupil_delivery(remote, options)
                refused = control(reset_control_request(2), Source.RESET, 2)
                @test refused[5] < 0 && refused[6] == 1
                held = control(run_control_request(3, :stopped), Source.RUN, 3)
                @test held[5] == 0 && !held[8]
                reset = control(reset_control_request(4), Source.RESET, 4)
                @test reset[5] == 0 && reset[6] == 2 && reset[7] == 0 && !reset[8]
                with_thread_loop_lock(client.client.loop) do _
                    close(source)
                end
                source = nothing
                @test Client.quit!(client; deadline = deadline()).lifecycle ===
                    Codec.Stopped
                close(client)
                client = nothing
                _wait_for_hil_condition(() -> process_exited(process))
                @test success(process)
            finally
                client === nothing || with_thread_loop_lock(client.client.loop) do _
                    source === nothing || close(source)
                end
                client === nothing || close(client)
                _stop_hil_process(process)
                success(process) || println(stderr, read(log, String))
            end
        end
    end
end
