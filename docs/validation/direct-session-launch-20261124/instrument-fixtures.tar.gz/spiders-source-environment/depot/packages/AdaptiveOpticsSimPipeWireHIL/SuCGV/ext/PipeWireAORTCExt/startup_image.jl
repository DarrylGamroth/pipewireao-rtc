# Lightweight deployment entry point. Load this file without importing HIL or AOS.
module StartupImage

using TOML, UUIDs
import PipeWireAO: LibPipeWire
import PipeWireAORTC
import PipeWireAORTC: Common, InstrumentConfiguration
import PipeWireAORTC.DeploymentConfiguration as D

include("../../deps/command_receiver_build.jl")
const Receiver = CommandReceiverBuild.CommandReceiverLibrary

const NAME = "PipeWireAOOpticalStartup"
const PIPEWIREAO_JLL_UUID = "cde84cf6-9a21-5ce0-b5e3-1526e778c30b"
const MANAGED_ENTRY =
    "include(joinpath(dirname(Base.find_package(\"AdaptiveOpticsSimPipeWireHIL\")), \"managed.jl\"))"

directory(package, role) = joinpath(package, "optical-startup", role)
receiver_library(package, role) = joinpath(package, "command-receiver", role, Receiver.FILENAME)

# Only the installation's own cache and Julia's shipped caches participate in
# selection. A depot prepended to a shared cache does not take precedence over
# newer package images elsewhere in the stack.
function stage_source_depots(path, depots)
    sources = mkpath(joinpath(path, "sources"))
    for (index, depot) in enumerate(depots)
        for name in ("packages", "artifacts", "juliaup")
            input = joinpath(depot, name)
            isdir(input) || continue
            view = mkpath(joinpath(sources, string(index)))
            symlink(realpath(input), joinpath(view, name))
        end
    end
    return nothing
end

function image_depot_path(path; build_override = nothing)
    sources = joinpath(path, "sources")
    depots = sort!(readdir(sources; join = true); by = depot -> parse(Int, basename(depot)))
    build_override === nothing || pushfirst!(depots, build_override)
    # The trailing colon includes Julia's system depots without the user depot.
    return join([joinpath(path, "depot"); depots; ""], ':')
end

function stage_native_prefix(depot, prefix, library)
    sdk = LibPipeWire.PipeWireAO_jll.artifact_dir
    realpath(prefix) == realpath(sdk) && return nothing
    # A JLL wrapper expects lib/ even when the installed SDK uses a multiarch
    # library directory. Use the same filesystem layout as the RTC's override.
    native = mkpath(joinpath(depot, "native-prefix"))
    symlink(realpath(library), joinpath(native, "lib"))
    for name in ("bin", "share", "etc", "include")
        source = joinpath(prefix, name)
        ispath(source) && symlink(realpath(source), joinpath(native, name))
    end
    artifacts = mkpath(joinpath(depot, "artifacts"))
    open(joinpath(artifacts, "Overrides.toml"), "w") do io
        TOML.print(io, Dict(PIPEWIREAO_JLL_UUID => Dict("PipeWireAO" => native)))
    end
    return depot
end

function owner_depot_path(path, env, role)
    depots = image_depot_path(path)
    runtime = get(env, "PIPEWIREAO_RUNTIME_DIR", nothing)
    runtime === nothing && return depots
    # Preserve the RTC runtime SDK override without making its compiled files
    # candidates for this owner's installed startup image.
    override = joinpath(runtime, "julia-depot", "artifacts", "Overrides.toml")
    isfile(override) || return depots
    depot = joinpath(runtime, role, "julia-depot")
    artifacts = mkpath(joinpath(depot, "artifacts"))
    cp(override, joinpath(artifacts, basename(override)); force = true)
    return depot * ":" * depots
end

function configuration(package, owner; allow_missing = false)
    argv = owner["argv"]
    entry = findfirst(==(MANAGED_ENTRY), argv)
    entry === nothing && return nothing
    index = findfirst(==("--config"), argv)
    index !== nothing && index < length(argv) || return nothing
    config = argv[index + 1]
    startswith(config, "@PACKAGE@/") || return nothing
    relative = String(chopprefix(config, "@PACKAGE@/"))
    allow_missing && !ispath(joinpath(package, relative)) && return nothing
    path = D.relative_asset(package, relative)
    document = Common.read_json(path)
    version = get(document, "version", nothing)
    synchronous_command = version == 6
    workload = if get(document, "backend", nothing) != "cpu"
        nothing
    elseif version in (4, 6)
        :prepare_optical_startup
    elseif version == 3 && isdefined(InstrumentConfiguration, :SIMULATOR_PREPARATION) &&
            isfile(joinpath(dirname(path), InstrumentConfiguration.SIMULATOR_PREPARATION))
        :prepare_lockstep_startup
    else
        nothing
    end
    return (; path, workload, synchronous_command)
end

"""
    requested(package, owners)

Return whether a managed HIL owner needs an optical image or native command
receiver at installation.
"""
function requested(package, owners)
    return any(owners) do owner
        config = configuration(package, owner)
        return config !== nothing && (config.workload !== nothing || config.synchronous_command)
    end
end

"""
    install!(environment, package, owners, prefix)

Build the optical startup images and synchronous command receivers needed by
the managed HIL owners against the installed environment and PipeWire prefix.
"""
function install!(environment, package, owners, prefix)
    for owner in owners
        config = configuration(package, owner)
        config === nothing && continue
        if config.synchronous_command
            library = receiver_library(package, owner["role"])
            Common.startup_phase(owner["role"], "build synchronous command receiver") do
                julia = D.selected_julia_executable(first(owner["argv"]))
                CommandReceiverBuild.build(library, prefix, D.installed_paths(prefix)["library"]; julia)
            end
        end
        config.workload === nothing || build!(package, environment, owner, config, prefix)
    end
    return nothing
end

function build!(package, environment, owner, config, prefix)
    path = directory(package, owner["role"])
    manifest = joinpath(environment, "Manifest.toml")
    lockstep = config.workload === :prepare_lockstep_startup
    if !haskey(TOML.parsefile(manifest)["deps"], "PrecompileTools")
        @info "Optical startup image unavailable in the installed environment" owner=owner["role"]
        return nothing
    end
    !(ispath(path) || islink(path)) || throw(ArgumentError("optical startup directory must be new"))
    mkpath(joinpath(path, "src"))
    project = TOML.parsefile(joinpath(environment, "Project.toml"))
    project["name"] = NAME
    project["uuid"] = string(uuid4())
    project["version"] = "0.1.0"
    project["deps"]["PrecompileTools"] = "aea7be01-6a6a-4083-8856-8a6e6704d82a"
    open(io -> TOML.print(io, project; sorted = true), joinpath(path, "Project.toml"), "w")
    cp(manifest, joinpath(path, "Manifest.toml"))
    optics_import = !lockstep && haskey(project["deps"], "Proper") ? "using Proper" : ""
    dependencies = if lockstep
        join((
            "Base.include_dependency(" * repr(file) * "; track_content = true)"
            for file in (joinpath(package, "deployment.conf"),
                         joinpath(environment, "Project.toml"), manifest)
        ), '\n')
    else
        ""
    end
    write(
        joinpath(path, "src", NAME * ".jl"),
        """
        module $NAME
        using PipeWireAORTC, AdaptiveOpticsSimPipeWireHIL
        $optics_import
        $dependencies
        using PrecompileTools: @compile_workload
        const Simulation = AdaptiveOpticsSimPipeWireHIL.Simulation
        @compile_workload Simulation.$(config.workload)($(repr(config.path)))
        end
        """,
    )
    argv = owner["argv"]
    julia = D.selected_julia_executable(first(argv))
    flags = filter(arg -> startswith(arg, "--threads=") ||
                          (lockstep && startswith(arg, "-O")), argv)
    stage_source_depots(path, DEPOT_PATH)
    library = D.installed_paths(prefix)["library"]
    env = copy(ENV)
    merge!(env, owner["environment"])
    env["JULIA_LOAD_PATH"] = "@:@stdlib"
    env["PIPEWIREAO_PREFIX"] = prefix
    env["LD_LIBRARY_PATH"] = library
    code = "using PipeWireAOOpticalStartup; touch(only(ARGS))"
    build = Cmd([julia, "--startup-file=no", flags..., "--project=" * path,
        "-e", code, joinpath(path, "ready")])
    Common.startup_phase(owner["role"], "build optical startup image") do
        mktempdir(path) do depot
            build_override = stage_native_prefix(depot, prefix, library)
            env["JULIA_DEPOT_PATH"] = image_depot_path(path; build_override)
            run(setenv(build, env))
        end
    end
    return nothing
end

"""
    configure_owner!(argv, env, package, owner)

Set the managed owner's environment to load its installed native command
receiver and optical package cache when the profile uses them.
"""
function configure_owner!(argv, env, package, owner)
    entry = findfirst(==(MANAGED_ENTRY), argv)
    entry === nothing && return nothing
    config = configuration(package, owner; allow_missing = true)
    config === nothing && return nothing
    role = owner["role"]
    if config.synchronous_command
        library = receiver_library(package, role)
        isfile(library) || error("installed synchronous HIL command receiver is missing: $library")
        env[Receiver.ENVIRONMENT] = library
    end
    path = directory(package, role)
    config.workload !== nothing && isfile(joinpath(path, "ready")) || return nothing
    if config.workload === :prepare_optical_startup
        # Match the dependency import order of the optical workload.
        argv[entry] = "using $NAME; " * argv[entry]
    end
    insert!(argv, 2, "--compiled-modules=existing")
    insert!(argv, 3, "--pkgimages=existing")
    env["PIPEWIREAO_OPTICAL_STARTUP"] = path
    env["JULIA_LOAD_PATH"] = "@:" * path * ":@stdlib"
    env["JULIA_DEPOT_PATH"] = if isdir(joinpath(path, "sources"))
        owner_depot_path(path, env, role)
    else
        joinpath(path, "depot") * ":" * env["JULIA_DEPOT_PATH"]
    end
    return nothing
end

end
