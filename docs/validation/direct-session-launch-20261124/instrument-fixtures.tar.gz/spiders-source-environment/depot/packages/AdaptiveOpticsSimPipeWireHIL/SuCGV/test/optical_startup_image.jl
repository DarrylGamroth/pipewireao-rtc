using Test
using PipeWireAO

include(joinpath(@__DIR__, "..", "ext", "PipeWireAORTCExt", "startup_image.jl"))

@testset "load the optical image before the managed entry" begin
    optical = StartupImage
    owner = Dict(
        "role" => "simulator",
        "argv" => ["julia", "-e", optical.MANAGED_ENTRY, "--", "--config", "@PACKAGE@/simulation.conf"],
    )
    command = ["julia", "-e", optical.MANAGED_ENTRY, "--", "--config", "simulation.conf"]
    mktempdir() do package
        argv = copy(command)
        env = Dict("JULIA_DEPOT_PATH" => "/depot")
        optical.configure_owner!(argv, env, package, owner)
        @test argv == command
        @test !haskey(env, "PIPEWIREAO_OPTICAL_STARTUP")

        config = joinpath(package, "simulation.conf")
        write(config, """{"backend":"cpu","version":4}""")
        path = mkpath(optical.directory(package, owner["role"]))
        touch(joinpath(path, "ready"))
        optical.configure_owner!(argv, env, package, owner)
        @test argv[2:3] == ["--compiled-modules=existing", "--pkgimages=existing"]
        @test argv[5] == "using PipeWireAOOpticalStartup; " * optical.MANAGED_ENTRY
        @test argv[6:end] == command[4:end]
        @test env["PIPEWIREAO_OPTICAL_STARTUP"] == path

        receipt = joinpath(package, optical.InstrumentConfiguration.SIMULATOR_PREPARATION)
        mkpath(dirname(receipt))
        touch(receipt)
        write(config, """{"backend":"cpu","version":3}""")
        argv = copy(command)
        env = Dict("JULIA_DEPOT_PATH" => "/depot")
        optical.configure_owner!(argv, env, package, owner)
        @test argv[2:3] == ["--compiled-modules=existing", "--pkgimages=existing"]
        @test argv[4:end] == command[2:end]
        @test env["PIPEWIREAO_OPTICAL_STARTUP"] == path
    end
end

@testset "select the managed CPU optical workloads" begin
    mktempdir() do package
        config = joinpath(package, "simulation.conf")
        argv = ["julia", "-e", StartupImage.MANAGED_ENTRY, "--config", "@PACKAGE@/simulation.conf"]
        owner = Dict("argv" => argv)
        for (backend, version, selected) in (
            ("cpu", 3, false), ("cpu", 4, true), ("cpu", 6, true), ("cuda", 6, true),
        )
            write(config, """{"backend":"$backend","version":$version}""")
            @test StartupImage.requested(package, [owner]) === selected
        end
        receipt = joinpath(package, StartupImage.InstrumentConfiguration.SIMULATOR_PREPARATION)
        mkpath(dirname(receipt))
        touch(receipt)
        write(config, """{"backend":"cpu","version":3}""")
        @test StartupImage.requested(package, [owner])
        write(config, """{"backend":"cuda","version":3}""")
        @test !StartupImage.requested(package, [owner])
        @test !StartupImage.requested(package, [Dict("argv" => ["other"])])
    end
end

@testset "use the installed startup depot and native receiver" begin
    prefix = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
    mktempdir() do temporary
        package = mkpath(joinpath(temporary, "application"))
        shared = mkpath(joinpath(temporary, "shared"))
        keep = ("packages", "artifacts", "juliaup")
        foreach(name -> mkpath(joinpath(shared, name)), (keep..., "compiled"))
        owner = Dict(
            "role" => "simulator",
            "argv" => [first(Base.julia_cmd().exec), "-e", StartupImage.MANAGED_ENTRY, "--config", "@PACKAGE@/simulation.conf"],
        )
        config = joinpath(package, "simulation.conf")
        path = StartupImage.directory(package, owner["role"])
        StartupImage.stage_source_depots(path, [shared])
        sources = joinpath(path, "sources", "1")
        @test all(name -> samefile(joinpath(shared, name), joinpath(sources, name)), keep)
        @test !ispath(joinpath(sources, "compiled"))
        touch(joinpath(path, "ready"))
        write(config, """{"backend":"cpu","version":4}""")
        env = Dict("JULIA_DEPOT_PATH" => shared * ":")
        argv = copy(owner["argv"])
        StartupImage.configure_owner!(argv, env, package, owner)
        @test env["JULIA_DEPOT_PATH"] == join([joinpath(path, "depot"), sources, ""], ':')
        @test !haskey(env, StartupImage.Receiver.ENVIRONMENT)

        # Clocked optical owners need the receiver independently of their
        # accelerator choice and of the optional CPU optical startup image.
        write(config, """{"backend":"cuda","version":6}""")
        library = StartupImage.receiver_library(package, owner["role"])
        @test_throws ErrorException StartupImage.configure_owner!(
            copy(owner["argv"]), env, package, owner,
        )
        StartupImage.install!(package, package, [owner], prefix)
        @test isfile(library)
        @test isfile(joinpath(path, "ready"))
        argv = copy(owner["argv"])
        env = Dict("JULIA_DEPOT_PATH" => shared * ":")
        withenv("CC" => "/bin/false") do
            StartupImage.configure_owner!(argv, env, package, owner)
        end
        @test env[StartupImage.Receiver.ENVIRONMENT] == library
        @test argv == owner["argv"]
        @test env["JULIA_DEPOT_PATH"] == shared * ":"
        receiver = StartupImage.Receiver.load(library; command_size = 96)
        close(receiver)
        @test_throws ErrorException StartupImage.Receiver.load(library; command_size = 95)
    end
end

@testset "select the SDK override at build and launch" begin
    sdk = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
    sdk_paths = StartupImage.D.installed_paths(sdk)
    launch = StartupImage.PipeWireAORTC.SessionLaunch
    mktempdir() do temporary
        custom = mkpath(joinpath(temporary, "sdk"))
        library = mkpath(joinpath(custom, "lib", "multiarch"))
        soname = "libpipewire-ao-0.3.so.0"
        cp(realpath(joinpath(sdk_paths["library"], soname)), joinpath(library, soname))
        symlink(soname, joinpath(library, "libpipewire-ao-0.3.so"))
        for name in ("pipewire-ao-0.3", "spa-ao-0.2")
            symlink(joinpath(sdk_paths["library"], name), joinpath(library, name))
        end
        for name in ("bin", "share", "etc", "include")
            source = joinpath(sdk, name)
            ispath(source) && symlink(source, joinpath(custom, name))
        end
        @test realpath(custom) != realpath(sdk)
        paths = StartupImage.D.installed_paths(custom)
        @test paths["library"] == library
        @test !samefile(joinpath(library, soname), joinpath(sdk_paths["library"], soname))

        receiver = joinpath(temporary, StartupImage.Receiver.FILENAME)
        StartupImage.CommandReceiverBuild.build(receiver, custom, paths["library"])
        @test isfile(receiver)

        package = mkpath(joinpath(temporary, "application"))
        owner = Dict(
            "role" => "simulator",
            "argv" => ["julia", "-e", StartupImage.MANAGED_ENTRY, "--config", "@PACKAGE@/simulation.conf"],
        )
        write(joinpath(package, "simulation.conf"), """{"backend":"cpu","version":4}""")
        path = StartupImage.directory(package, owner["role"])
        StartupImage.stage_source_depots(path, String[])
        build_depot = mkpath(joinpath(temporary, "build-depot"))
        build_override = StartupImage.stage_native_prefix(build_depot, custom, paths["library"])
        @test build_override == build_depot
        @test isfile(joinpath(build_depot, "artifacts", "Overrides.toml"))
        @test samefile(joinpath(build_depot, "native-prefix", "lib"), library)

        runtime = mkpath(joinpath(temporary, "runtime"))
        launch.prepare_julia_overlay!((; prefix = custom), paths, Dict("owners" => [owner]), runtime)
        session_depot = joinpath(runtime, "julia-depot")
        mkpath(joinpath(session_depot, "compiled"))
        touch(joinpath(path, "ready"))
        argv = copy(owner["argv"])
        env = Dict("JULIA_DEPOT_PATH" => session_depot * ":", "PIPEWIREAO_RUNTIME_DIR" => runtime)
        StartupImage.configure_owner!(argv, env, package, owner)
        depots = split(env["JULIA_DEPOT_PATH"], ':')
        @test session_depot ∉ depots
        owner_override = joinpath(first(depots), "artifacts", "Overrides.toml")
        @test read(owner_override) == read(joinpath(session_depot, "artifacts", "Overrides.toml"))
        @test !ispath(joinpath(first(depots), "compiled"))

        # A later launch can select the unmodified JLL SDK. The temporary
        # installation override must not reappear when RTC provides no override.
        default_runtime = mkpath(joinpath(temporary, "default-runtime"))
        launch.prepare_julia_overlay!((; prefix = sdk), sdk_paths, Dict("owners" => [owner]),
            default_runtime)
        default_env = Dict("JULIA_DEPOT_PATH" => joinpath(default_runtime, "julia-depot") * ":",
            "PIPEWIREAO_RUNTIME_DIR" => default_runtime)
        StartupImage.configure_owner!(copy(owner["argv"]), default_env, package, owner)
        @test default_env["JULIA_DEPOT_PATH"] == StartupImage.image_depot_path(path)
        @test build_depot ∉ split(default_env["JULIA_DEPOT_PATH"], ':')

        code = """
            using Artifacts
            key = Base.UUID("$(StartupImage.PIPEWIREAO_JLL_UUID)")
            expected = isempty(only(ARGS)) ? nothing : only(ARGS)
            @assert Artifacts.query_override(key, "PipeWireAO") == expected
            """
        for (depot_path, native) in (
            (StartupImage.image_depot_path(path; build_override), joinpath(build_depot, "native-prefix")),
            (env["JULIA_DEPOT_PATH"], joinpath(runtime, "native-prefix")),
            (default_env["JULIA_DEPOT_PATH"], ""),
        )
            command = `$(Base.julia_cmd()) --startup-file=no -e $code $native`
            @test success(addenv(command, "JULIA_DEPOT_PATH" => depot_path, "JULIA_LOAD_PATH" => "@stdlib"))
        end
    end
end
