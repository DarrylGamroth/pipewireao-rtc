using AdaptiveOpticsSimPipeWireHIL
using Aqua
using PipeWireAO
using Test

@testset "AdaptiveOpticsSimPipeWireHIL" begin
    include("configuration.jl")
    include("simulation.jl")
    include("simulation_optical.jl")
    include("validation.jl")
    include("completion.jl")
    include("sim_runner.jl")

    include("acquisition.jl")
    include("exchange.jl")
    include("applied_command.jl")
    include("image_source.jl")
    include("array_streams.jl")
    include("source_channels.jl")
    include("exchange_wait.jl")
    include("driver_cycle.jl")
    include("transport.jl")
    include("lifecycle.jl")
    include("multi_command.jl")
    include("calibration.jl")
    include("optical_exposure_publication.jl")
    include("external_pupil_execution.jl")

    @testset "row-major frame transport" begin
        frame = reshape(Float32.(1:6), 2, 3)
        state = AdaptiveOpticsSimPipeWireHIL.ExchangeState(
            frame,
            zeros(Float32, 1),
            UInt64(1),
        )
        AdaptiveOpticsSimPipeWireHIL._stage_frame_transport!(state)
        @test state.frame_transport == Float32[1, 3, 5, 2, 4, 6]
    end

    Aqua.test_all(AdaptiveOpticsSimPipeWireHIL)
end

include("model_time.jl")
include("live_private_core.jl")
include("live_command_receiver.jl")

include("live_calibration_private_core.jl")
include("live_named_calibration_private_core.jl")
