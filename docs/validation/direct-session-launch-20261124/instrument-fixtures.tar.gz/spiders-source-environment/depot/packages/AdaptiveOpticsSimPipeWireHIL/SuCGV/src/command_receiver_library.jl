module CommandReceiverLibrary

using Libdl: dlopen, dlclose, dlsym, RTLD_LOCAL, RTLD_NOW

const FILENAME = "libhil_command_receiver.so"
const ENVIRONMENT = "PIPEWIREAO_HIL_COMMAND_RECEIVER"

struct Library
    handle::Ptr{Cvoid}
    create::Ptr{Cvoid}
    stream::Ptr{Cvoid}
    free::Ptr{Cvoid}
    status::Ptr{Cvoid}
    drain::Ptr{Cvoid}
    reset::Ptr{Cvoid}
end

function load(path; command_size = nothing)
    handle = dlopen(path, RTLD_LOCAL | RTLD_NOW)
    try
        abi = ccall(dlsym(handle, :hil_command_receiver_abi), UInt64, ())
        abi >> 32 == 1 || error("unsupported synchronous HIL command receiver ABI: $path")
        command_size === nothing || UInt32(abi & 0xffffffff) == command_size ||
            error("synchronous HIL command receiver record size differs: $path")
        return Library(
            handle,
            dlsym(handle, :hil_command_receiver_new),
            dlsym(handle, :hil_command_receiver_stream),
            dlsym(handle, :hil_command_receiver_free),
            dlsym(handle, :hil_command_receiver_status),
            dlsym(handle, :hil_command_receiver_drain),
            dlsym(handle, :hil_command_receiver_reset),
        )
    catch
        dlclose(handle)
        rethrow()
    end
end

Base.close(library::Library) = dlclose(library.handle)

end
