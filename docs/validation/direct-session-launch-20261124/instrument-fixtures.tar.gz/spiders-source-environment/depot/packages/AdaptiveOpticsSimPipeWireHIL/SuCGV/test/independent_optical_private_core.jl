# Optional CPU selector with the sealed instrument and the matching native SDK.
using Test, PipeWireAORTC, AdaptiveOpticsSimPipeWireHIL, Proper, PipeWireAO
import PipeWireAO_jll
using PipeWireAORTC.InstrumentExport: prepare_external_pupil_ports

include(joinpath(pkgdir(PipeWireAORTC), "test", "external_pupil_owner_documents.jl"))
include("private_core_helpers.jl")
include("external_pupil_delivery.jl")

const HIL = AdaptiveOpticsSimPipeWireHIL

@testset "independent optical service keeps data nodes across peer replacement" begin
    @test_throws ArgumentError HIL.Simulation.independent_main(["--config", "simulation.conf"])
    @test_throws ArgumentError HIL.Simulation.independent_main(
        ["--config", "simulation.conf", "--remote", "pipewire-0"]
    )
    mktempdir() do directory
        (; config) = external_pupil_owner_documents(directory)
        options = PipeWireAORTC.AOSOwner.configuration(config)
        _with_private_core() do core_name
            remote = joinpath(ENV["PIPEWIREAO_RUNTIME_DIR"], core_name)
            launcher = joinpath(pkgdir(HIL), "src", "independent.jl")
            project = dirname(Base.active_project())
            command = `$(Base.julia_cmd()) --project=$project --startup-file=no --threads=2,0 $launcher --config $config --remote $remote`
            log = joinpath(directory, "simulator.log")
            process = run(pipeline(command; stdout = log, stderr = log); wait = false)
            try
                started = timedwait(360; pollint = 0.05) do
                    process_exited(process) || occursin("Independent optical streams active", read(log, String))
                end
                started == :ok && !process_exited(process) ||
                    error("independent optical simulator did not open its streams:\n" * read(log, String))
                external_pupil_delivery(remote, options; reconnect = true)
                @test !process_exited(process)
                kill(process, Base.SIGINT)
                _wait_for_hil_condition(() -> process_exited(process); timeout = 30)
                @test success(process)
            finally
                _stop_hil_process(process)
            end
            @test issocket(remote)
        end
    end
end
