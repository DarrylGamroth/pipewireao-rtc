using PipeWireAO, PipeWireAORTC, FilterGraphPipeWire, FilterGraphs, FilterGraphAlgorithms, Test

const RTC = PipeWireAORTC
const G = RTC.GraphOwner
const E = Base.get_extension(RTC, :PipeWireAORTCGraphExt)
if haskey(ENV, "RTC_PROBE_GRAPH_SOURCE")
    source = read(ENV["RTC_PROBE_GRAPH_SOURCE"], String)
    preparation = first(split(last(split(source, "function prepare_persistent_graph", limit=2)),
        "\ncheck_persistent_corrections", limit=2))
    Base.include_string(E, "function prepare_persistent_graph" * preparation, ENV["RTC_PROBE_GRAPH_SOURCE"])
end
const P = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
const STOCK = "/var/tmp/rtc-ndarray-integration.beRGH1"
const VARIANTS = (
    "classic" => (joinpath(STOCK, "classic/export"), "julia", ("slopes,validity",)),
    "gpi2" => (joinpath(STOCK, "instruments/sources/gpi2-final"), "julia", ("reconstruction-pixels",)),
    "spiders" => (joinpath(STOCK, "instruments/sources/spiders"), "spiders-scc",
        ("correction:closed=modal-residual", "llowfs-correction:closed=llowfs-modal-residual,llowfs-validity")),
)

function probe(label, stock, role, primes)
    spec = RTC.Common.read_json(joinpath(stock, "deployment.conf"))
    owner = only(filter(owner -> owner["role"] == role, spec["owners"]))
    argv = replace.(Garg(owner), "@PACKAGE@" => stock)
    argv = replace.(argv, r"@BOOTSTRAP_INSTANCE_[A-Z_]+@" => "42")
    argv = replace.(argv, "@RUNTIME@/@REMOTE@" => "/tmp/not-connected-pipewire")
    for prime in primes
        append!(argv, ["--prime-on-output", prime])
    end
    binding, args, fits, properties, timeout, recovery, supervision, offsets, qualification, display =
        G.arguments([argv; "--persistent"])
    options = G.graph_options(FilterGraphPipeWire, args, properties, timeout, recovery,
        supervision, offsets, qualification, display; prime_on_output = binding.prime_on_output)
    config = RTC.DeploymentConfiguration.decode(options.graph, P)
    if !haskey(config, "filter.composition")
        controller = only(filter(node -> node["name"] == "closed-loop-correction", config["filter.graph"]["nodes"]))
        controller["props"]["closed"] = false
    end
    members = map(path -> RTC.DeploymentConfiguration.decode(path, P),
                  G.composition_files(config, options.graph))
    println(label, " ", options.graph, " ", properties, " ", options.prime_on_output)
    for epoch in 1:2
        graph = E.prepare_persistent_graph(config, members, FilterGraphAlgorithms.algorithms())
        try
            E.check_persistent_corrections(graph, properties)
            initial = G.prepare_bindings(G.bindings(fits), FilterGraphs.parameter_formats(graph))
            FilterGraphs.replace_parameters!(graph, initial...)
            priming = E.prepare_priming(options, graph)
            @test length(priming) == length(properties)
            @test all(observer -> !observer.ready[], priming)
            @test all(observer -> !FilterGraphAlgorithms.property_values(observer.controller.plan).closed, priming)
            if !isempty(recovery)
                controllers = Tuple(Symbol(first(split(property, ':'))) for property in properties)
                @test length(controllers) <= 2
            end
            println("  prepared fresh ", typeof(graph).name.name, " attachment ", epoch)
        finally
            FilterGraphPipeWire.close_execution(graph)
        end
    end
end
Garg(owner) = String.(RTC.GraphStartup.owner_arguments(owner))
for (label, (stock, role, primes)) in VARIANTS
    isempty(ARGS) || label in ARGS || continue
    @testset "$label" begin
        probe(label, stock, role, primes)
    end
end
