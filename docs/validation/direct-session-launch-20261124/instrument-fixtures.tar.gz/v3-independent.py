import json, os, pathlib, shutil, subprocess as sp, sys, time
root=pathlib.Path(__file__).resolve().parent
profile, commit = sys.argv[1:]
assert profile in {"classic","gpi2"}
stock=json.loads((root/(profile+"-direct.json")).read_text())
app_stock=pathlib.Path(stock["app"])
deployment=json.loads((app_stock/"deployment.conf").read_text())
source_role=deployment["source-owner"]
source=next(o for o in deployment["owners"] if o["role"]==source_role)
bootstrap=source["bootstrap-node"]
control=source["control-node"]
prefix=pathlib.Path.home()/".julia/artifacts/77da251765f3124df77322c562e67a7c7742ab1d"
queue=pathlib.Path.home()/".julia/artifacts/20afa07132938ae663c7cf4c10f00172ca40e70f/lib/pipewire-ao-0.3"
xdg=pathlib.Path(os.environ["XDG_RUNTIME_DIR"])
runtime=xdg/f"iv3-{profile[0]}-{root.name[-5:].lower()}"
socket=runtime/"c"
units=[runtime.name+"-core.service",runtime.name+"-source.service"]
result=root/(profile+"-independent-v3")
result.mkdir(exist_ok=True)
control_trace=result/"source-cursor.jsonl"
finish=result/"finish-source"
assert not control_trace.exists() and not finish.exists()
assert not runtime.exists()
runtime.mkdir(mode=0o700)

def system(command,*args,**kwargs):
    return sp.run([command,"--user",*map(str,args)],check=True,timeout=110,**kwargs)
def properties(unit):
    out=system("systemctl","show",unit,"-p","ActiveState,MainPID,InvocationID",text=True,capture_output=True)
    return dict(row.split("=",1) for row in out.stdout.splitlines())
def start_owner(unit,cpus,env,command):
    args=[f"--unit={unit}","--property=Type=exec",f"--property=CPUAffinity={cpus}",
          "--property=KillSignal=SIGINT","--property=TimeoutStopSec=45","--property=UMask=0077"]
    args.extend(f"--setenv={key}={value}" for key,value in env.items())
    system("systemd-run",*args,"--",*command)
def identities():
    result={}
    for unit in units:
        observed=properties(unit)
        assert observed["ActiveState"]=="active",observed
        start=pathlib.Path(f'/proc/{observed["MainPID"]}/stat').read_text().rsplit(")",1)[1].split()[19]
        result[unit]=[observed["MainPID"],observed["InvocationID"],start]
    return result
def wait(predicate,seconds,detail):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        if predicate(): return
        time.sleep(0.25)
    raise RuntimeError(detail)
def data():
    if not control_trace.is_file(): return []
    return [json.loads(line) for line in control_trace.read_text().splitlines() if line.endswith("}")]
def current():
    records=data()
    return records[-1] if records else None

external={"PIPEWIREAORTC_CORE_UNIT":units[0],"PIPEWIREAORTC_SOURCE_UNIT":units[1],
    "PIPEWIREAORTC_CORE_SOCKET":str(socket),"RTC_FUNCTIONAL_NO_HIL_IMAGE":"1"}
environment=dict(os.environ,**external)
native=dict(PIPEWIREAO_RUNTIME_DIR=str(runtime),PIPEWIRE_RUNTIME_DIR=str(runtime),
    PIPEWIREAO_MODULE_DIR=str(prefix/"lib/pipewire-ao-0.3")+":"+str(queue),
    PIPEWIREAO_SPA_PLUGIN_DIR=str(prefix/"lib/spa-ao-0.2"),LD_LIBRARY_PATH=str(prefix/"lib"),
    PIPEWIREAO_PREFIX=str(prefix))
controller=installing=None
try:
    if os.environ.get("RTC_REUSE_V3_APP")!="1":
        sp.run([sys.executable,root/"stage.py",profile,commit,"persistent"],
               env={**environment,"RTC_STAGE_ONLY":"1"},check=True,timeout=100)
        installing=sp.Popen([sys.executable,root/"stage.py",profile,commit,"persistent"],env=environment)
    record=json.loads((root/(profile+"-persistent.json")).read_text())
    app=pathlib.Path(record["app"])
    cfg=result/"configuration"
    cfg.mkdir(exist_ok=True)
    (cfg/"daemon.conf").write_text((app_stock/deployment["core"]).read_text().replace("@REMOTE@","c"))
    shutil.copy2(app_stock/deployment["client"][source_role],cfg/"client.conf")
    source_env=dict(native,**stock["env"],PIPEWIREAO_CONFIG_DIR=str(cfg))
    start_owner(units[0],13,{**native,"PIPEWIREAO_CONFIG_DIR":str(cfg)},
                [prefix/"bin/pipewire-ao","-c","daemon.conf"])
    wait(socket.is_socket,50,"private core did not start")
    option_args=source["argv"]
    index=option_args.index("--")
    command=option_args[:index+1]
    common=lambda value: value.replace("@PACKAGE@",str(app_stock)).replace("@RUNTIME@/@REMOTE@",str(socket)).replace("@BOOTSTRAP_INSTANCE_SIMULATOR@","72")
    command=list(map(common,command))
    command.insert(2,"--compiled-modules=existing")
    for key,value in zip(option_args[index+1::2],option_args[index+2::2]):
        if not key.startswith("--phase-timing"):
            command.extend([key,common(value)])
    command.extend(["--acquisition","free-running","--idle-strategy","yielding"])
    start_owner(units[1],deployment["placement"][source_role]["leader-cpu"],source_env,command)
    before=identities()
    pid=before[units[1]][0]
    with (result/"source-controller.log").open("w") as out:
        controller=sp.Popen(["nice","-n","8","taskset","-c","4,5",stock["julia"],"--startup-file=no",
           "--compiled-modules=existing","--threads=1,0","--project="+str(app_stock),
           root/"start-managed-source.jl",socket,bootstrap,"72",pid,control,control_trace,finish],
           stdout=out,stderr=sp.STDOUT,env=dict(os.environ,**source_env))
    def source_ready():
        if controller.poll() is not None:
            raise RuntimeError("HIL controller exited before source ran")
        return current() and current()["sequence"]>=2
    wait(source_ready,700,"v3 source did not publish successive model-time acquisitions before RTC")
    if installing:
        assert installing.wait(timeout=500)==0
    else:
        assert (app/"systemd/pipewireao-session@.service").is_file()
    graph_units=[path.name for path in (app/"systemd").glob("pipewireao-graph-*.service")]
    graph_paths=[app/"systemd"/name for name in graph_units]
    assert len(graph_paths)==1
    system("systemctl","link","--runtime",*graph_paths)
    system("systemctl","daemon-reload")
    pre=current()
    sp.run([sys.executable,root/"run.py",profile,"persistent"],env=environment,check=True,timeout=1500)
    post=current()
    assert identities()==before
    assert post["generation"]==pre["generation"] and post["sequence"]>pre["sequence"]
    (result/"source-continuity.json").write_text(json.dumps({"services":before,"before":pre,"after":post},indent=2)+"\n")
finally:
    finish.touch()
    if controller and controller.poll() is None:
        try:controller.wait(timeout=45)
        except sp.TimeoutExpired: controller.terminate()
    for name in (*locals().get("graph_units",[]),*reversed(units)):
        try: system("systemctl","stop",name)
        except (sp.CalledProcessError,sp.TimeoutExpired): pass
    for name in locals().get("graph_units",[]):
        link=xdg/"systemd/user"/name
        if link.is_symlink() and link.resolve()==app/"systemd"/name:
            link.unlink()
    system("systemctl","daemon-reload")
    with (result/"journal.log").open("w") as f:
        sp.run(["journalctl","--user","--no-pager","--all",*[arg for name in units for arg in ("-u",name)]],stdout=f,stderr=sp.STDOUT)
    if runtime.is_dir():
        shutil.rmtree(runtime)
