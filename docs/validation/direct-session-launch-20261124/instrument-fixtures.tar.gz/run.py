import fcntl, json, os, pathlib, shutil, subprocess as sp, sys, time, traceback
root=pathlib.Path(__file__).resolve().parent
profile,scope=sys.argv[1:3]
record=json.loads((root/f"{profile}-{scope}.json").read_text())
app=pathlib.Path(record["app"])
xdg=pathlib.Path(os.environ["XDG_RUNTIME_DIR"])
variant=profile[0]+root.name[-5:].lower()+("p" if scope=="persistent" else "d")
unit=f"pipewireao-session@{variant}.service"
runtime=xdg/f"pipewireao-session-{variant}"
unit_stub=app/"systemd"/unit
dest=xdg/"systemd/user"/unit
drop=dest.with_suffix(".service.d")
artifacts=root/f"{profile}-{scope}-run"
if artifacts.exists():
    artifacts=artifacts.with_name(artifacts.name+"-"+str(time.monotonic_ns()))
artifacts.mkdir()
result=artifacts/"series.json"
adopt_live = os.environ.get("RTC_ADOPT_LIVE_FIXTURE")=="1"
assert runtime.name == "pipewireao-session-"+variant
if adopt_live:
    assert dest.is_symlink() and dest.resolve()==unit_stub and drop.is_dir() and runtime.is_dir()
else:
    assert all(not path.exists() and not path.is_symlink() for path in (dest,drop,unit_stub))
env=dict(os.environ,**record["env"])
env["PIPEWIREAORTC_GRAPH_STARTUP_TIMING"]="1"
def system(*args, timeout=90, check=True):
    p=sp.run(["systemctl","--user",*map(str,args)],capture_output=True,text=True,timeout=timeout)
    if check and p.returncode: raise RuntimeError(f"systemctl {args}: {p.stderr} {p.stdout}")
    return p.stdout.strip()
def properties(name=unit):
    return dict(line.split("=",1) for line in system("show",name,
      "-p","ActiveState,InvocationID,MainPID,FragmentPath,ExecMainStatus,Result").splitlines())
def same_install(pid):
    arguments=pathlib.Path(f"/proc/{pid}/cmdline").read_bytes().rstrip(b"\0").decode().split("\0")
    assert arguments[0]==record["julia"] and "--project="+str(app) in arguments,arguments
    return arguments
def objects(remote, activated_runtime):
    prefix=pathlib.Path.home()/".julia/artifacts/77da251765f3124df77322c562e67a7c7742ab1d"
    data=sp.check_output([prefix/"bin/pwao-dump","-N","-r",remote],env=dict(env,LD_LIBRARY_PATH=str(prefix/"lib"),
             PIPEWIREAO_SPA_PLUGIN_DIR=str(prefix/"lib/spa-ao-0.2"),
             PIPEWIREAO_MODULE_DIR=str(prefix/"lib/pipewire-ao-0.3"),
             PIPEWIREAO_CONFIG_DIR=str(pathlib.Path(activated_runtime)/"session"),
             PIPEWIREAO_RUNTIME_DIR=str(pathlib.Path(remote).parent)),text=True,timeout=30)
    return [x for x in json.loads(data) if x["type"].endswith((":Node",":Port",":Link"))]
def clock():
    return time.monotonic_ns()
history=[]
functional_lock=open(root/"functional-run.lock","a")
fcntl.flock(functional_lock,fcntl.LOCK_EX)
try:
    if not adopt_live:
        template=pathlib.Path(os.environ.get("RTC_INSTRUMENT_UNIT_TEMPLATE", app/"systemd/pipewireao-session@.service"))
        shutil.copy2(template,unit_stub)
        drop.mkdir()
        (drop/"fixture.conf").write_text("[Service]\n"+"".join(f'Environment="{k}={env[k]}"\n' for k in
            [*record["env"],"PIPEWIREAORTC_GRAPH_STARTUP_TIMING"]))
        system("link","--runtime",unit_stub)
        system("daemon-reload")
    old_control=replacement_control=None
    def await_file(marker, process, timeout):
        bound=time.monotonic()+timeout
        while not marker.exists():
            if process.poll() is not None or time.monotonic()>=bound:
                raise RuntimeError(f"{marker} was not produced by the control client")
            time.sleep(.25)
    for trial in range(1,3):
        stage=artifacts/str(trial)
        stage.mkdir(exist_ok=True)
        item={"profile":profile,"scope":scope,"unit":unit,"requested_ns":clock()}
        history.append(item)
        print(profile,scope,trial,"starting",flush=True)
        system("start",unit,timeout=850)
        item["ready_ns"]=clock()
        props=item["session"]=properties()
        assert props["ActiveState"]=="active",props
        item["main_argv"]=same_install(props["MainPID"])
        ledger=runtime/props["InvocationID"]/"launch.json"
        d=item["prepared"]=json.loads(ledger.read_text())
        assert str(d["session_pid"])==props["MainPID"] and d["phase"]=="prepared",d
        items=objects(d["remote"],d["runtime"])
        (stage/"objects-ready.json").write_text(json.dumps(items,indent=2)+"\n")
        link_prefix=f'pipewireao/session/{d["session_control_instance"]}/'
        item["links"]=[x["info"]["props"]["object.serial"] for x in items
                       if x["type"].endswith(":Link") and
                          x["info"]["props"].get("object.path","").startswith(link_prefix)]
        assert item["links"]
        graph_names={"classic":"revolt-classic-jfg-frame-graph","gpi2":"gpi2-jfg-frame-graph","spiders":"spiders-controller"}
        [item["graph_serial"]]=[x["info"]["props"]["object.serial"] for x in items
                               if x["type"].endswith(":Node") and x["info"]["props"].get("node.name")==graph_names[profile]]
        if trial>1:
            before=history[0]
            assert item["session"]["InvocationID"]!=before["session"]["InvocationID"]
            assert item["prepared"]["session_uuid"]!=before["prepared"]["session_uuid"]
            if scope=="persistent":
                assert set(item["links"]).isdisjoint(before["links"])
                assert item["graph_serial"]!=before["graph_serial"]
                for role,owner in d["owners"].items():
                    if owner.get("persistent"):
                        old=before["prepared"]["owners"][role]
                        assert tuple(owner[k] for k in ("pid","start-ticks","invocation"))==tuple(old[k] for k in ("pid","start-ticks","invocation"))
            elif d["owners"]["core"].get("external",False):
                assert d["remote"]==before["prepared"]["remote"]
                assert set(item["links"]).isdisjoint(before["links"])
                for role,owner in d["owners"].items():
                    if not owner.get("external",False) and not owner.get("optional",False):
                        assert owner["pid"]!=before["prepared"]["owners"][role]["pid"]
            else:
                assert d["remote"]!=before["prepared"]["remote"]
        print(profile, scope, trial, "held Ready", d["session_pid"], flush=True)
        prefix=pathlib.Path.home()/".julia/artifacts/77da251765f3124df77322c562e67a7c7742ab1d"
        control_env=dict(env,PIPEWIREAO_PREFIX=str(prefix),LD_LIBRARY_PATH=str(prefix/"lib"),
            PIPEWIREAO_CONFIG_DIR=str(pathlib.Path(d["runtime"])/"session"),
            PIPEWIREAO_RUNTIME_DIR=str(pathlib.Path(d["remote"]).parent),
            PIPEWIRE_RUNTIME_DIR=str(pathlib.Path(d["remote"]).parent),
            PIPEWIREAO_MODULE_DIR=str(prefix/"lib/pipewire-ao-0.3"),
            PIPEWIREAO_SPA_PLUGIN_DIR=str(prefix/"lib/spa-ao-0.2"))
        with (stage/"controls.log").open("w") as control_log:
            control_mode = "leave" if scope=="persistent" and trial==1 else "replacement" if old_control else "stop"
            prior_generation=15
            if control_mode=="replacement" and profile!="classic":
                previous=json.loads((artifacts/"1/controls.json").read_text())
                prior_generation=previous["fresh_recovery_generation"]
            command=["nice","-n","6","taskset","-c","14,15",record["julia"],"--startup-file=no","--threads=2,0",
                     "--project="+str(app),root/"controls.jl",ledger,profile,stage/"controls.json",control_mode,str(prior_generation)]
            if control_mode=="leave":
                old_control=sp.Popen(command,env=control_env,stdout=control_log,stderr=sp.STDOUT)
                await_file(stage/"running-qualified",old_control,390)
            elif control_mode=="replacement":
                replacement_control=sp.Popen(command,env=control_env,stdout=control_log,stderr=sp.STDOUT)
                await_file(stage/"running-qualified",replacement_control,390)
                (artifacts/"1/probe-old-authority").touch()
                assert old_control.wait(timeout=20)==0
                old_control=None
                (stage/"old-authority-checked").touch()
                assert replacement_control.wait(timeout=90)==0
                replacement_control=None
            else:
                sp.run(command,env=control_env,stdout=control_log,stderr=sp.STDOUT,check=True,timeout=390)
        if scope=="persistent" and trial==2:
            old_checks=json.loads((artifacts/"1/controls.json").read_text())
            new_checks=json.loads((stage/"controls.json").read_text())
            before=old_checks["first_observed_acquisition"]
            after=new_checks["first_observed_acquisition"]
            for camera in {"classic":("detector",),"gpi2":("detector",),"spiders":("scc","llowfs")}[profile]:
                a,b=(stream[camera]["acquisition"] for stream in (before,after))
                assert a["domain"]==b["domain"] and a["generation"]==b["generation"] and a["sequence"]<b["sequence"], (camera,a,b)
        if scope=="persistent" and trial==1:
            system("kill","--kill-whom=main","--signal=SIGKILL",unit)
            expires=time.monotonic()+90
            while properties()["ActiveState"] not in ("failed","inactive") and time.monotonic()<expires:
                time.sleep(0.15)
            forced=properties()
            assert forced["ActiveState"] in ("failed","inactive")
            item["forced_stop"]={"signal":"SIGKILL","result":forced}
        else:
            system("stop",unit,timeout=300)
            final=properties()
            item["stopped"]=final
            assert final["MainPID"]=="0" and final["Result"]=="success",final
            if scope=="persistent":
                alive={}
                for role,owner in d["owners"].items():
                    if owner.get("external") or owner.get("persistent"):
                        observed=properties(owner["unit"])
                        assert observed["ActiveState"]=="active" and observed["MainPID"]==str(owner["pid"])
                        assert observed["InvocationID"]==owner["invocation"]
                        alive[role]=observed
                item["retained_after_graceful_stop"]=alive
        try:
            item["cleanup"]=json.loads(ledger.read_text())
        except FileNotFoundError:
            item["cleanup_absent"]=True
        result.write_text(json.dumps(history,indent=2)+"\n")
        print(profile,scope,trial,"cleaned",flush=True)
finally:
    try:
        for child in (locals().get("old_control"),locals().get("replacement_control")):
            if child and child.poll() is None:
                child.terminate()
                child.wait(timeout=10)
        system("stop",unit,check=False,timeout=90)
        for i,item in enumerate(history,1):
            prep=item.get("prepared",{})
            owner_units=[owner["unit"] for owner in prep.get("owners",{}).values() if "unit" in owner]
            with (artifacts/str(i)/"journal.log").open("w") as log:
                sp.run(["journalctl","--user","-u",unit,*sum([["-u",name] for name in owner_units],[]),"--no-pager","--all","-n","400"],stdout=log,stderr=sp.STDOUT)
    finally:
        result.write_text(json.dumps(history,indent=2)+"\n")
        if dest.is_symlink():
            dest.unlink()
        if drop.is_dir():
            shutil.rmtree(drop)
        unit_stub.unlink(missing_ok=True)
        system("daemon-reload",check=False)
