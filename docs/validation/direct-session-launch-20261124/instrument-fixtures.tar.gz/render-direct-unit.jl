using PipeWireAO, PipeWireAORTC
const RTC = PipeWireAORTC
const I = RTC.SessionInstall
const D = RTC.DeploymentConfiguration
const L = RTC.SessionLaunch
app, destination = ARGS
prefix=String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
spec=I.session_spec(app,prefix)
project=D.application_environment(spec,app)
executable=D.session_executable(spec,app,prefix)
launcher=joinpath(app,"bin","pipewireao-rtc-session")
julia=D.selected_julia_executable(Base.julia_cmd().exec[1])
activation=(; julia, project, digest=RTC.Common.sha256_file(joinpath(app,"systemd",L.ACTIVATION_FILE)))
external=L.external_services()
@assert external!==nothing
template=I.resolved_unit_template(project)
write(destination,I.installed_unit(template,spec;launcher,package=app,prefix,executable,external,activation))
