import json, os, pathlib, shutil, subprocess as sp, sys, time
root=pathlib.Path(__file__).resolve().parent
xdg=pathlib.Path(os.environ["XDG_RUNTIME_DIR"])
prefix=pathlib.Path.home()/".julia/artifacts/77da251765f3124df77322c562e67a7c7742ab1d"
queue=pathlib.Path.home()/".julia/artifacts/20afa07132938ae663c7cf4c10f00172ca40e70f/lib/pipewire-ao-0.3"
runtime=xdg/f"sx-{root.name[-5:].lower()}"
socket=runtime/"c"
units=[runtime.name+"-core.service",runtime.name+"-source.service"]
def system(command,*args,**kwargs):
    return sp.run([command,"--user",*map(str,args)],check=True,timeout=90,**kwargs)
def properties(unit):
    out=system("systemctl","show",unit,"-p","ActiveState,MainPID,InvocationID",text=True,capture_output=True)
    return dict(row.split("=",1) for row in out.stdout.splitlines())
def start_owner(unit,cpus,env,command):
    options=[f"--unit={unit}","--property=Type=exec",f"--property=CPUAffinity={cpus}",
             "--property=KillSignal=SIGINT","--property=TimeoutStopSec=45","--property=UMask=0077"]
    options.extend(f"--setenv={key}={value}" for key,value in env.items())
    system("systemd-run",*options,"--",*command)
def service_identities():
    ids={}
    for unit in units:
        values=properties(unit)
        assert values["ActiveState"]=="active",values
        stat=pathlib.Path(f'/proc/{values["MainPID"]}/stat').read_text()
        ids[unit]=[values["MainPID"],values["InvocationID"],stat.rsplit(")",1)[1].split()[19]]
    return ids
def wait(predicate,seconds,detail):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        if predicate(): return
        time.sleep(0.25)
    raise RuntimeError(detail)
def dump(native):
    cmd=[prefix/"bin/pwao-dump","-N","-r",socket]
    return json.loads(sp.check_output(cmd,env=native,text=True,timeout=10))
def source_ready(native):
    try:
        all_objects=dump(native)
    except (sp.SubprocessError, ValueError): return False
    names={obj.get("info",{}).get("props",{}).get("node.name") for obj in all_objects
           if obj["type"].endswith(":Node")}
    expected={"spiders-dm-command","simulator-dm-applied","spiders-scc","spiders-llowfs"}
    return expected<=names

reuse = os.environ.get("RTC_REUSE_SP_SOURCE") == "1"
if reuse:
    assert runtime.is_dir() and socket.is_socket()
    assert all(properties(unit)["ActiveState"]=="active" for unit in units)
else:
    assert not runtime.exists()
    runtime.mkdir(mode=0o700)
    for unit in units:
        assert properties(unit)["ActiveState"]=="inactive"
external={"PIPEWIREAORTC_CORE_UNIT":units[0],"PIPEWIREAORTC_SOURCE_UNIT":units[1],
    "PIPEWIREAORTC_CORE_SOCKET":str(socket)}
native=dict(PIPEWIREAO_RUNTIME_DIR=str(runtime),PIPEWIRE_RUNTIME_DIR=str(runtime),
    PIPEWIREAO_MODULE_DIR=str(prefix/"lib/pipewire-ao-0.3")+":"+str(queue),
    PIPEWIREAO_SPA_PLUGIN_DIR=str(prefix/"lib/spa-ao-0.2"),LD_LIBRARY_PATH=str(prefix/"lib"))
try:
    env=dict(os.environ,**external)
    installing = None
    if os.environ.get("RTC_REUSE_SP_APP")!="1":
        sp.run([sys.executable,root/"stage.py","spiders",sys.argv[1],"persistent"],
               env={**env,"RTC_STAGE_ONLY":"1"},check=True,timeout=90)
        installing=sp.Popen([sys.executable,root/"stage.py","spiders",sys.argv[1],"persistent"],env=env)
    record=json.loads((root/"spiders-persistent.json").read_text())
    app=pathlib.Path(record["app"])
    spec=json.loads((app/"deployment.conf").read_text())
    owner=next(owner for owner in spec["owners"] if owner["role"]=="simulator")
    cfg=root/"spiders-independent-core"
    cfg.mkdir(exist_ok=True)
    (cfg/"daemon.conf").write_text((app/spec["core"]).read_text().replace("@REMOTE@","c"))
    shutil.copy2(app/spec["client"]["simulator"],cfg/"client.conf")
    if not reuse:
        start_owner(units[0],13,{**native,"PIPEWIREAO_CONFIG_DIR":str(cfg)},[prefix/"bin/pipewire-ao","-c","daemon.conf"])
        wait(socket.is_socket,45,"SPIDERS private socket did not start")
        external_config=app/"simulation.conf"
        # Source-only environment supplies independent v6 support. Optical paths are
        # otherwise the absolute exported SPIDERS instrument paths relative to app.
        source_project="/var/tmp/cal2-independent.UcNIRN/final-install"
        entry="/var/tmp/cal2-independent.UcNIRN/private-depot/packages/AdaptiveOpticsSimPipeWireHIL/SuCGV/src/independent.jl"
        start_owner(units[1],14,dict(native,**record["env"],PIPEWIREAO_CONFIG_DIR=str(cfg),PIPEWIREAO_PREFIX=str(prefix), PIPEWIREAO_HIL_COMMAND_RECEIVER=str(root/"spiders-runtime-command-receiver.so")),
            [record["julia"].replace("1.13.4+0","1.13.3+0"),"--startup-file=no","--compiled-modules=existing",
             "--threads=2,0","--project="+source_project,entry,
             "--config",external_config,"--remote",socket,"--pipewire-cpu","15"])
    client_native=dict(os.environ,**native,PIPEWIREAO_CONFIG_DIR=str(cfg))
    wait(lambda: source_ready(client_native),650,"SPIDERS HIL did not publish its declared core endpoints")
    if installing:
        assert installing.wait(timeout=650)==0
    else:
        assert (app/"systemd/pipewireao-session@.service").is_file()
    graph_units=[path.name for path in (app/"systemd").glob("pipewireao-graph-*.service")]
    graph_paths=[app/"systemd"/name for name in graph_units]
    assert len(graph_paths)==2
    system("systemctl","link","--runtime",*graph_paths)
    system("systemctl","daemon-reload")
    before=service_identities()
    (root/"spiders-independent-before.json").write_text(json.dumps({"processes":before,"native":dump(client_native)},indent=2)+"\n")
    retained=sp.run([sys.executable,root/"run.py","spiders","persistent"],env=env,timeout=1450)
    if os.environ.get("RTC_TEST_SP_DIRECT")=="1":
        system("systemctl","stop",*graph_units)
        template=root/"spiders-session-owned.service.in"
        sp.run(["nice","-n","8","taskset","-c","4,5",record["julia"],"--startup-file=no","-O0",
            "--project="+str(app),root/"render-direct-unit.jl",app,template],
            env=dict(env,**record["env"]),check=True,timeout=125)
        (root/"spiders-direct.json").write_text(json.dumps(record,indent=2)+"\n")
        scoped=sp.run([sys.executable,root/"run.py","spiders","direct"],
                      env=dict(env,RTC_INSTRUMENT_UNIT_TEMPLATE=str(template)),timeout=1450)
        print("SPIDERS session-owned direct exit",scoped.returncode,flush=True)
    after=service_identities()
    assert after==before
    (root/"spiders-independent-after.json").write_text(json.dumps({"processes":after,"native":dump(client_native)},indent=2)+"\n")
    retained.check_returncode()
    if "scoped" in locals(): scoped.check_returncode()
finally:
    for name in (*locals().get("graph_units",[]),*reversed(units)):
        try: system("systemctl","stop",name)
        except (sp.SubprocessError,sp.TimeoutExpired): pass
    for name in locals().get("graph_units",[]):
        link=xdg/"systemd/user"/name
        if link.is_symlink() and link.resolve()==app/"systemd"/name:
            link.unlink()
    system("systemctl","daemon-reload")
    with (root/"spiders-independent-journal.log").open("w") as f:
        sp.run(["journalctl","--user","--no-pager","--all",*[arg for name in units for arg in ("-u",name)]],stdout=f,stderr=sp.STDOUT)
    if runtime.is_dir():
        shutil.rmtree(runtime)
