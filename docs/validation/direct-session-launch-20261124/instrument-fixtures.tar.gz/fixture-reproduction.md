# Instrument fixture inputs

The selectors use the calibrated workstation exports in
`/var/tmp/rtc-ndarray-integration.beRGH1` and the Julia and native prefixes in
`stage.py`. Keep these exports and the package histories available when
restaging. Run each profile serially so the temporary unit names and CPU
placements refer to one private core. These are functional simulation
checks. The selections use CPUs 12–15 for required owners and CPUs 4–5
for the auxiliary client where declared.

Set `RTC_FUNCTIONAL_GRAPH_OPTLEVEL=0` for the reduced-optimization graph
fixture. `RTC_FUNCTIONAL_NO_HIL_IMAGE=1` selects ordinary runtime HIL
construction. Leave graph optimization at its default for the Classic
session-owned scope. The installed trials retain the exact RTC source
and dependency identities listed in the live-session receipts.

- `stage.py` and `install.jl` stage the selected source revision and use the
  installed session generator. Each scope record is the input to `run.py`.
- `run.py`, `controls.jl` and `queue-spec.jl` check installed systemd activation,
  native declared Links, held corrections, real samples and stop. The retained
  scope checks a Running RTC SIGKILL followed by a replacement and a graceful
  stop.
- `v3-independent.py` and `start-managed-source.jl` start a separately managed
  source and use the native free-running source cursor. Use `3c964d3` for
  retained Classic and `61b77ca` for retained GPI2.
- `spiders-independent.py` supervises the independent .5.13 HIL simulation,
  its private core and the graph services. For a fresh stage, point
  `RTC_VALIDATION_FGPW` at a checkout of companion commit
  `8b1838554f7fef041cbfedd9e21d8d1bf0898bee` and select RTC `84fcd27`.
  The source environment is a separate pinned HIL Project and Manifest as
  recorded in the live-session receipt.
- Build `spiders-runtime-command-receiver.so` in the fixture directory using
  `CommandReceiverBuild.build(library, prefix, joinpath(prefix, "lib"))`
  from the pinned HIL source's `deps/command_receiver_build.jl`. Use the
  same PipeWireAO 4.0.8 native prefix as the private core.
- `exact-owner-attach.jl` and `exact-owner-claim.jl` exercise the calibrated
  graph rebind from a native claimant SIGKILL without camera Links.
- `prepare-graphs.jl` probes preparation of the retained calibrated documents
  and `record-live-session.py` extracts the compact installed receipts.

The selected logs preserve the fitted dual declaration test, native callback
test, the cold default-optimization timeout phases and corrected offline
composition preparation. This archive contains fixture sources and reports.
The input calibrations and application builds are kept by their owners.
