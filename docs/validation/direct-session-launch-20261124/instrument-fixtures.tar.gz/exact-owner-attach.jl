using Test, PipeWireAO, PipeWireAORTC
const RTC=PipeWireAORTC
const HERE=@__DIR__
include("/home/dgamroth/workspaces/codex/worktrees/rtc-direct-session-launch/test/control_private_core.jl")
profile, app, outcome = ARGS
spec = RTC.Common.read_json(joinpath(app,"deployment.conf"))
role=profile=="spiders" ? "spiders-scc" : "julia"
owner = only(filter(x->x["role"]==role,spec["owners"]))
args = String.(RTC.GraphStartup.owner_arguments(owner))
argument(name) = findfirst(==(name),args)+1
args[argument("--pin-cpus")]="5,4"
node = args[argument("--name")]
bootstrap = args[argument("--bootstrap-node")]
properties = join(args[findall(==("--correction-property"),args) .+ 1],",")

function exercise(remote,directory,daemon)
    chmod(dirname(remote),0o700)
    resolved = RTC.DeploymentConfiguration.substitute.(args,Ref(Dict(
        "PACKAGE"=>app,"RUNTIME"=>dirname(remote),"REMOTE"=>basename(remote),
        "BOOTSTRAP_INSTANCE_JULIA"=>"71","BOOTSTRAP_INSTANCE_SPIDERS_SCC"=>"71")))
    qualify = "using PipeWireAORTC; PipeWireAORTC.GraphOwner.main(ARGS)"
    julia = Base.julia_cmd()
    owner_cmd = `$julia --startup-file=no --compiled-modules=existing -O0 --threads=2,0 --project=$app -e $qualify -- --persistent $resolved`
    claimant_cmd = `$julia --startup-file=no --compiled-modules=existing -O0 --threads=1,0 --project=$app $(joinpath(HERE,"exact-owner-claim.jl"))`
    mkpath(outcome)
    tag1 = joinpath(outcome,"first.json")
    tag2 = joinpath(outcome,"second.json")
    open(joinpath(outcome,"graph-owner.log"),"w") do owner_log
        process = run(pipeline(owner_cmd; stdout=owner_log,stderr=owner_log);wait=false)
        claimant = nothing
        replacement = nothing
        try
            pid=getpid(process)
            function check()
                process_exited(process) && error("pilot owner exited")
                claimant !== nothing && process_exited(claimant) && !isfile(tag1) &&
                    error("first controller exited without connecting")
                replacement !== nothing && process_exited(replacement) && !isfile(tag2) &&
                    error("replacement controller exited without connecting")
                return nothing
            end
            open(joinpath(outcome,"claimants.log"),"w") do controller_log
                claimant = run(pipeline(`$claimant_cmd $remote $bootstrap $pid $node $properties 0 $tag1 linger`;stdout=controller_log,stderr=controller_log);wait=false)
                wait_proof(() -> isfile(tag1),270,"exact first attachment";check)
                before = RTC.Common.read_json(tag1)
                @test before["claimant_pid"] == getpid(claimant)
                @test before["owner_pid"] == pid
                kill(claimant,Base.SIGKILL)
                wait(claimant)
                @test claimant.termsignal == Base.SIGKILL
                claimant = nothing
                serial = before["bootstrap_serial"]
                replacement = run(pipeline(`$claimant_cmd $remote $bootstrap $pid $node $properties $serial $tag2 quit`;stdout=controller_log,stderr=controller_log);wait=false)
                wait_proof(() -> isfile(tag2),220,"fresh attachment after claimant death";check)
                after = RTC.Common.read_json(tag2)
                @test before["claimant_pid"] != after["claimant_pid"]
                @test before["bootstrap_serial"] != after["bootstrap_serial"]
                @test before["graph_serial"] != after["graph_serial"]
                @test after["owner_pid"] == pid == getpid(process)
                wait(replacement)
                @test success(replacement)
                @test !process_exited(process)
            end
        finally
            claimant === nothing || stop_proof_child!(claimant,"first native claimant")
            replacement === nothing || stop_proof_child!(replacement,"replacement native claimant")
            process_exited(process) || kill(process,Base.SIGKILL)
            wait(process)
        end
    end
end

@testset "exact $profile graph survives native claimant process loss" begin
    with_control_private_core(exercise;temporary_prefix="gra-",
        remote_name="core",telemetry_loop=true)
end
