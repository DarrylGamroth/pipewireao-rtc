import json, pathlib, sys
base=pathlib.Path(__file__).resolve().parent
profile, scope, directory, destination=sys.argv[1:]
directory=base/directory
record=json.loads((base/(profile+"-"+scope+".json")).read_text())
series=json.loads((directory/"series.json").read_text())
destination=pathlib.Path(destination)
report=json.loads(destination.read_text()) if destination.is_file() else {}
activated=[]
for i, row in enumerate(series,1):
    if "ready_ns" not in row:
        continue
    checks=json.loads((directory/str(i)/"controls.json").read_text())
    held=checks["held"]["reply"]["result"]["properties"]
    outcome={"session_main_pid":int(row["session"]["MainPID"]),
      "session_invocation":row["session"]["InvocationID"],
      "session_uuid":row["prepared"]["session_uuid"],
      "remote":row["prepared"]["remote"],
      "ready_seconds":(row["ready_ns"]-row["requested_ns"])/1e9,
      "ready_declared_links":row["links"],
      "ready_correction":{name:item["value"] for name,item in held.items()
                        if "correction-control." in name or name.endswith(":closed")},
      "held_close_refusals":{name.removeprefix("held_close:"):item["reply"]["error"] for name,item in checks.items()
                              if name.startswith("held_close:")},
      "source_acquisition":checks["first_observed_acquisition"],
      "first_priming":{field:{key:value["value"] for key,value in observation["reply"]["result"]["properties"].items()
                              if key == field or key.startswith("pipewireao.correction-control."+field+".")}
                       for field,observation in checks["first_live_priming"].items()},
      "stopped_state":checks.get("stopped",{}).get("reply",{}).get("state"),
      "systemd_stop_result":row.get("stopped",{}).get("Result")}
    if "graph_serial" in row:
        outcome["graph_serial"]=row["graph_serial"]
    if "forced_stop" in row:
        outcome["forced_stop"]=row["forced_stop"]
    if "retained_after_graceful_stop" in row:
        outcome["retained_after_graceful_stop"]=row["retained_after_graceful_stop"]
    outcome["persistent_services_at_ready"]={role:{"pid":owner["pid"],"invocation":owner["invocation"],
                                  "start_ticks":owner["start-ticks"],"unit":owner["unit"]}
        for role,owner in row["prepared"]["owners"].items() if owner.get("external") or owner.get("persistent")}
    if "replacement_write" in checks:
        outcome["replacement_write_accepted"]=checks["replacement_write"]["reply"]["ok"]
    if "probed_recovery_generation" in checks:
        outcome["probed_recovery_generation"]=checks["probed_recovery_generation"]
    if "fresh_recovery" in checks:
        outcome["fresh_recovery_ok"]=checks["fresh_recovery"]["reply"]["ok"]
        outcome["recovery_after_request"]={name:field["value"] for name,field in
            checks["recovery_after_request"]["reply"]["result"]["properties"].items()
            if name.startswith("pipewireao-recovery:")}
    if "stale_recovery_release" in checks:
        outcome["stale_recovery_release_error"]=checks["stale_recovery_release"]["reply"]["error"]
    if "old_authority_after_replacement" in checks:
        outcome["old_authority_after_replacement"]=checks["old_authority_after_replacement"]
    activated.append(outcome)
report[profile+"-"+scope]={"rtc_source":record["commit"],"rtc_tree":record["tree"],"native":"PipeWireAO 4.0.8+0",
                          "julia":"1.13.4","graph_optimization":record.get("owner_optimization"),"activations":activated}
if len(activated)!=len(series):
    report[profile+"-"+scope]["unqualified_later_attempts"]=len(series)-len(activated)
if "fgpw" in record:
    report[profile+"-"+scope]["fgpw_source"]=record["fgpw"]["commit"]
    report[profile+"-"+scope]["fgpw_tree"]=record["fgpw"]["tree"]
destination.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
