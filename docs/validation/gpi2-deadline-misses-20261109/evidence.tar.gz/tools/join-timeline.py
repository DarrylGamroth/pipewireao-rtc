from bisect import bisect_left
import csv
import sqlite3
from pathlib import Path
import sys

path = Path(sys.argv[1])
with sqlite3.connect(path / "timeline.sqlite") as db:
    origin, = db.execute("select systemClockNs from TARGET_INFO_SESSION_START_TIME").fetchone()
    graph = db.execute("""
        select r.start + ?, r.end + ?, g.start + ?, g.end + ?, r.correlationId
        from CUPTI_ACTIVITY_KIND_RUNTIME r
        join StringIds n on n.id = r.nameId
        join CUPTI_ACTIVITY_KIND_GRAPH_TRACE g on g.correlationId = r.correlationId
        where n.value = 'cuGraphLaunch' order by r.start
        """, (origin,) * 4).fetchall()
    dtoh = db.execute("""
        select r.start + ?, r.end + ?, m.start + ?, m.end + ?
        from CUPTI_ACTIVITY_KIND_RUNTIME r
        join StringIds n on n.id = r.nameId
        join CUPTI_ACTIVITY_KIND_MEMCPY m on m.correlationId = r.correlationId
        where n.value = 'cuMemcpyDtoHAsync_v2' order by r.start
        """, (origin,) * 4).fetchall()
    sync = db.execute("""
        select r.start + ?, r.end + ? from CUPTI_ACTIVITY_KIND_RUNTIME r
        join StringIds n on n.id = r.nameId
        where n.value = 'cuStreamSynchronize' order by r.start
        """, (origin,) * 2).fetchall()

def read(name):
    with (path / name).open() as source:
        return list(csv.DictReader(source))

def calls(rows, left, right, times):
    return rows[bisect_left(times, left):bisect_left(times, right)]

graph_times = [r[0] for r in graph]
dtoh_times = [r[0] for r in dtoh]
sync_times = [r[0] for r in sync]
callbacks = read("callbacks.csv")
stages = iter(read("stages.csv"))
stage = next(stages)
out = csv.writer(sys.stdout)
out.writerow(("sequence", "graph_submit", "graph_start", "graph_end", "first_device_copy_start", "last_device_copy_end",
              "driver_wait_start", "driver_wait_end", "driver_launch_end", "copies"))
for cb in callbacks:
    while int(stage["status_read"]) < int(cb["start_ns"]):
        stage = next(stages)
    t0, t1, t2, t3 = (int(stage[k]) for k in (
        "launch_start", "launch_return", "completion_wait_start", "completion_wait_return"))
    launches = calls(graph, t0, t1, graph_times)
    copies = calls(dtoh, t1, t2, dtoh_times)
    waits = calls(sync, t2, t3, sync_times)
    if len(launches) == len(waits) == 1 and len(copies) == 4:
        submitted, launch_end, device_start, device_end, _ = launches[0]
        wait_start, wait_end = waits[0]
        first_copy_start = min(copy[2] for copy in copies)
        last_copy_end = max(copy[3] for copy in copies)
        assert device_start < device_end <= last_copy_end <= wait_end <= t3
        assert wait_start <= wait_end and t0 <= submitted <= launch_end <= t1
        out.writerow((cb["sequence"], submitted, device_start, device_end, first_copy_start, last_copy_end,
                      wait_start, wait_end, launch_end, len(copies)))
    stage = next(stages, None)
assert stage is None
