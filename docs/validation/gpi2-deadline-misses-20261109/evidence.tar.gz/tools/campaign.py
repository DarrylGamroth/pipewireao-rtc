from pathlib import Path
import os, re, subprocess as sp, sys, tempfile, time

root = Path(__file__).resolve().parents[1]
name, mode, samples, warmup = sys.argv[1:]
raw = root / name
raw.mkdir()
native = Path(os.environ["PIPEWIREAO_PREFIX"])
env = os.environ.copy()
env.update(PIPEWIREAO_CONFIG_DIR=str(root),
           PIPEWIREAO_MODULE_DIR=str(native/"lib/pipewire-ao-0.3"),
           PIPEWIREAO_SPA_PLUGIN_DIR=str(native/"lib/spa-ao-0.2"),
           PIPEWIREAO_REMOTE="pipewire-ao-0",
           PIPEWIREAO_DEBUG=os.environ.get("GPI2_PW_DEBUG","0"))
quit_request = raw / "quit"
procs = []
def start(label, command, stdin=None, additions=None):
    with (raw / (label+".log")).open("wb") as log:
        process=sp.Popen(command, env=env | (additions or {}), stdout=log, stderr=sp.STDOUT, stdin=stdin, cwd=root)
    procs.append((process,label))
    return process
def check(proc):
    if proc.poll() is not None:
        raise RuntimeError(f"premature exit {proc.args}: {proc.returncode}")
def wait(predicate, proc, timeout=300):
    until = time.monotonic() + timeout
    while not predicate():
        check(proc)
        if time.monotonic() > until:
            raise TimeoutError(proc.args)
        time.sleep(0.04)
def contains(label, needle):
    return needle in (raw / (label+".log")).read_text(errors="replace")
with tempfile.TemporaryDirectory(prefix="gpi2-",dir=env["XDG_RUNTIME_DIR"]) as runtime:
    env.update(XDG_RUNTIME_DIR=runtime,PIPEWIREAO_RUNTIME_DIR=runtime)
    remote = Path(runtime) / env["PIPEWIREAO_REMOTE"]
    fifo = name.endswith("-rt")
    try:
        core = start("core", ["taskset","-c","2",native/"bin/pipewire-ao","-c","core.conf"])
        wait(remote.is_socket, core, 10)
        julia = ["julia", "--startup-file=no", "--threads=2,0",
                 "--project="+str(root/"env"), root/"tools/owner.jl", mode, remote, quit_request, raw]
        if mode == "nsys":
            julia = ["nsys", "profile", "--trace=cuda", "--sample=none",
                     "--cpuctxsw=process-tree", "--capture-range=cudaProfilerApi",
                     "--capture-range-end=stop", "--cuda-graph-trace=graph",
                     "--output="+str(raw/"timeline")] + julia
        owner = start("graph", ["taskset","-c","4,6",*julia],
            additions={"PIPEWIREAO_CONFIG_NAME":"client-rt.conf"} if fifo else None)
        wait(lambda: contains("graph","CONNECTED "), owner, 360)
        owner_pid = int(re.search(r"CONNECTED (\d+)", (raw/"graph.log").read_text()).group(1))
        replay = start("replay",["taskset","-c","8,10,12",root/"replay",
               "--frame-rate","2000","--sample-frames",samples,"--warmup-frames",warmup,
               "--csv",raw/"completed.csv","--arrival-csv",raw/"arrivals.csv"],stdin=sp.PIPE,
            additions={"PIPEWIREAO_CONFIG_NAME":"replay-rt.conf","GPI2_FIFO":"1"} if fifo else None)
        wait(lambda: contains("replay","CONNECT_ACCEPTED"), replay, 15)
        def tool(name,*args,check=True):
            return sp.run([native/"bin"/name,"-r",str(remote),*args],env=env,
                          capture_output=True,text=True,timeout=8,check=check)
        until = time.monotonic()+15
        while True:
            ports_out = tool("pwao-link","-o").stdout
            ports_in = tool("pwao-link","-i").stdout
            if all(n in ports_out for n in ("rtc-row-source:", "gpi2-captured:tiptilt")) and all(n in ports_in for n in ("gpi2-woofer:","gpi2-tweeter:","gpi2-tiptilt:","gpi2-captured:raw")):
                break
            check(owner); check(replay)
            if time.monotonic()>until: raise TimeoutError((ports_out,ports_in))
            time.sleep(.1)
        with (raw/"ports.txt").open("w") as f:
            f.write(ports_out+ports_in)
        tool("pwao-link","-w","rtc-row-source:output_1","gpi2-captured:raw")
        for port in ("woofer","tweeter","tiptilt"):
            tool("pwao-link","-w","gpi2-captured:"+port,"gpi2-"+port+":input_1")
        wait(lambda: contains("replay","READY"), replay, 15)
        if fifo:
            for pid, names in ((owner_pid, {"julia-data-loop"}), (replay.pid, {"rtc-source","rtc-command"})):
                tids = [(task.name,(task/"comm").read_text().strip())
                        for task in Path(f"/proc/{pid}/task").iterdir()]
                selected = [(tid, name) for tid,name in tids if name in names]
                assert {name for _,name in selected} == names
                for tid,_ in selected:
                    policy = sp.check_output(["chrt","-p",tid], text=True)
                    assert "SCHED_FIFO" in policy and "priority: 15" in policy, policy
        with (raw/"threads.txt").open("w") as f:
            sp.run(["ps","-L","-p",f"{core.pid},{owner_pid},{replay.pid}","-o","pid,tid,psr,cls,rtprio,comm"],stdout=f,check=True)
            for pid in (core.pid, owner_pid, replay.pid):
                for task in Path(f"/proc/{pid}/task").iterdir():
                    try:
                        affinity = next(x.strip() for x in (task/"status").read_text().splitlines() if x.startswith("Cpus_allowed_list:"))
                        print(task.name,affinity,file=f)
                    except FileNotFoundError: pass
        replay.stdin.write(b"s")
        replay.stdin.flush()
        if os.environ.get("GPI2_CPU_CONTENTION"):
            wait(lambda: contains("replay","STREAMING"), replay, 5)
            start_ns = int(re.search(r"first_deadline_ns=(\d+)", (raw/"replay.log").read_text()).group(1))
            workers = []
            for seconds, cpu in ((4, 5), (8, 15), (12, 5), (16, 15)):
                deadline = start_ns + (1 + int(warmup)) * 500000 + seconds * 1000000000
                workers.append(start(f"contend-{seconds}-cpu{cpu}",
                    ["taskset","-c",str(cpu),root/"contend",str(deadline)]))
            for worker in workers:
                if worker.wait(25):
                    raise RuntimeError("contention worker failed")
        if replay.wait(int(samples)//2000 + 20): raise RuntimeError("replay failed")
        quit_request.touch()
        if owner.wait(45): raise RuntimeError("graph shutdown failed")
    finally:
        quit_request.touch()
        for proc,label in reversed(procs):
            if proc.poll() is None:
                if label=="graph":
                    try: proc.wait(8)
                    except sp.TimeoutExpired: pass
                if proc.poll() is None:
                    proc.terminate()
                    try: proc.wait(5)
                    except sp.TimeoutExpired:
                        proc.kill()
                        proc.wait()
        (raw/"exits.txt").write_text("".join(f"{label} pid={proc.pid} status={proc.returncode}\n" for proc,label in procs))
