import csv
from collections import Counter
import json
import math
import struct
import sys
from pathlib import Path

path = Path(sys.argv[1])
def read_csv(name):
    with (path / name).open() as f:
        return [{k: int(v) if v.lstrip("-").isdigit() else v for k, v in row.items()}
                for row in csv.DictReader(f)]

def stats(items):
    samples = sorted(items)
    if not samples:
        return {"count": 0}
    return {"count": len(samples), "min": samples[0], "max": samples[-1],
            **{f"p{p:g}": samples[math.ceil(p*len(samples)/100)-1] for p in (50, 95, 99, 99.9)}}

offered = [r for r in read_csv("arrivals.csv") if r["phase"] == "measured"]
assert offered and all(r["nominal_deadline_ns"] for r in offered), "missing scheduled releases"
period = offered[1]["nominal_deadline_ns"] - offered[0]["nominal_deadline_ns"]
assert period == 500_000
assert all(b["nominal_deadline_ns"] - a["nominal_deadline_ns"] == period
           for a,b in zip(offered,offered[1:])), "omitted or rescheduled release"
received = [r for r in offered if r["command_receipt_ns"]]
published = [r for r in offered if r["publication_ns"]]
assert all(r["nominal_deadline_ns"] <= r["offered_ns"] for r in offered)
assert all(r["offered_ns"] <= r["publication_ns"] for r in published)
for r in received:
    times = [r[k] for k in ("woofer_ns", "tweeter_ns", "tiptilt_ns")]
    assert r["publication_ns"] <= min(times) and max(times) == r["command_receipt_ns"]
late = sum(r["command_receipt_ns"] - r["nominal_deadline_ns"] > period for r in received)
summary = {
    "offered": len(offered),
    "published": len(published),
    "all_commands": len(received),
    "partial_commands": sum(r["command_receipt_ns"] == 0 and any(r[k] for k in ("woofer_ns","tweeter_ns","tiptilt_ns")) for r in offered),
    "source_rejected": sum(r["source_rejected"] for r in offered),
    "states": Counter(r["state"] for r in offered),
    "completed_late": late,
    "slots_without_on_time_command": len(offered)-len(received)+late,
    "nominal_to_offer_ns": stats(r["offered_ns"]-r["nominal_deadline_ns"] for r in offered),
    "nominal_to_publication_ns": stats(r["publication_ns"]-r["nominal_deadline_ns"] for r in published),
    "publication_cadence_error_ns": stats(abs(b["publication_ns"]-a["publication_ns"]-period)
          for a,b in zip(published,published[1:]) if b["sequence"] == a["sequence"]+1),
    "nominal_to_command_ns": stats(r["command_receipt_ns"]-r["nominal_deadline_ns"] for r in received),
    "publication_to_command_ns": stats(r["command_receipt_ns"]-r["publication_ns"] for r in received),
    "publication_to_sink_ns": {k:stats(r[k]-r["publication_ns"] for r in received) for k in ("woofer_ns","tweeter_ns","tiptilt_ns")},
}
if (path/"callbacks.csv").exists():
    callbacks = read_csv("callbacks.csv")
    seq = {r["sequence"]:r for r in offered}
    traced = [r for r in callbacks if r["sequence"] in seq]
    assert len({r["sequence"] for r in traced}) == len(traced)
    assert all(r["succeeded"] == "true" and r["end_ns"] >= r["start_ns"] for r in traced)
    assert all(seq[r["sequence"]]["publication_ns"] > 0 for r in traced)
    graw=(path/"gc.bin").read_bytes()
    begun, finished, tid = struct.unpack_from("<QQi",graw)
    records=list(struct.iter_unpack("<QQQ",graw[24:]))
    assert begun == finished < len(records)
    assert all(0 < b <= e for b,e,_ in records[:begun])
    begin=offered[0]["nominal_deadline_ns"]
    end=max(offered[-1]["nominal_deadline_ns"]+period, *(r["end_ns"] for r in traced))
    events=[(b,e) for b,e,_ in records[:begun] if b < end and e > begin]
    summary["trace"]={
        "all_callback_records": len(callbacks),
        "measured_callback_records":len(traced),
        "allocation_valid": sum(r["allocation_valid"]=="true" for r in traced),
        "allocated_bytes_histogram": Counter(r["allocated_bytes"] for r in traced if r["allocation_valid"]=="true"),
        "gc_epoch_crossings":sum(r["gc_epoch_start"]!=r["gc_epoch_end"] for r in traced),
        "gc_hook_spans_ns":stats(e-b for b,e in events),
        "gc_hook_spans_all_ns":stats(e-b for b,e,_ in records[:begun]),
        "gc_overlapping_callbacks":sum(any(b<r["end_ns"] and e>r["start_ns"] for b,e in events) for r in traced),
        "callback_service_ns":stats(r["end_ns"]-r["start_ns"] for r in traced),
        "callback_service_over_period":sum(r["end_ns"]-r["start_ns"]>period for r in traced),
        "publication_to_callback_start_ns":stats(r["start_ns"]-seq[r["sequence"]]["publication_ns"] for r in traced),
        "callback_end_to_last_command_ns":stats(seq[r["sequence"]]["command_receipt_ns"]-r["end_ns"] for r in traced if seq[r["sequence"]]["command_receipt_ns"]),
        "callback_thread_ids": Counter(r["thread_id"] for r in traced),
        "callback_linux_tid":tid,
    }
print(json.dumps(summary, indent=2,sort_keys=True))
