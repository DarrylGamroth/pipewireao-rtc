import csv
import json
import statistics
import sys

with open(sys.argv[1]) as source:
    rows = [{key: int(value) for key, value in row.items() if key != "phase"}
            for row in csv.DictReader(source) if row["phase"] == "measured"]
first = rows[0]["nominal_deadline_ns"]
ports = ("woofer_ns", "tweeter_ns", "tiptilt_ns")

def duration(row):
    return row["command_receipt_ns"] - row["nominal_deadline_ns"]

def relative(row):
    return row["nominal_deadline_ns"] - first

misses = [row for row in rows if duration(row) > 500_000]
burst = misses[1:]
start, end = relative(burst[0]), relative(burst[-1])
window = [row for row in rows if start <= relative(row) <= end]
same_detector = {row["sequence"] % 1062 for row in burst}
outside = [row for row in rows if not start <= relative(row) <= end
           and row["sequence"] % 1062 in same_detector]
output = {
    "measured_frames": len(rows),
    "misses": len(misses),
    "cluster_count": len(burst),
    "cluster_start_relative_ns": start,
    "cluster_end_relative_ns": end,
    "cluster_offers": len(window),
    "distinct_cluster_detector_frames": len(same_detector),
    "same_detector_outside_cluster_offers": len(outside),
    "same_detector_outside_cluster_misses": sum(duration(row) > 500_000 for row in outside),
    "publish_to_receipt_exceeded_500us": sum(
        row["command_receipt_ns"] - row["publication_ns"] > 500_000 for row in misses),
    "median_late_release_to_publication_ns": statistics.median(
        row["publication_ns"] - row["nominal_deadline_ns"] for row in misses),
    "median_late_publication_to_first_receipt_ns": statistics.median(
        min(row[port] for port in ports) - row["publication_ns"] for row in misses),
    "median_late_first_to_last_receipt_ns": statistics.median(
        row["command_receipt_ns"] - min(row[port] for port in ports) for row in misses),
    "max_late_first_to_last_receipt_ns": max(
        row["command_receipt_ns"] - min(row[port] for port in ports) for row in misses),
}
print(json.dumps(output, indent=2))
