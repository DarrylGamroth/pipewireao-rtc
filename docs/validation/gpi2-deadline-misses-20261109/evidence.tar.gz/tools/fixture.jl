module GPI2Fixture
using FilterGraphs,FilterGraphAlgorithms,FITSIO,YAML,JSON,SHA,TOML
const FG=FilterGraphs
const FGA=FilterGraphAlgorithms
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const APPLICATION=get(ENV,"GPI2_APPLICATION","/home/dgamroth/workspaces/codex/adaptive-optics-simulations/gpi2")
const INPUTS=get(ENV,"GPI2_INPUTS","/home/dgamroth/workspaces/codex/pipewire/JuliaFilterGraph.jl/benchmark/results/gpi2-scaling-20261104/fp16-graph-frames")
const FB=Symbol("constraint-feedback")
const OUTFB=Symbol("controller-constraint-feedback")
sha(p)=bytes2hex(open(sha256,p))
function load_fixture()
    metadata=TOML.parsefile(joinpath(INPUTS,"results.toml"))
    for name in ("rtc/graph.conf","rtc/parameters.yaml","calibration/result.yaml")
        sha(joinpath(APPLICATION,name))==metadata["configuration_sha256"][name] || error("fixture changed: $name")
    end
    document=FG._parse_spa_json(read(joinpath(APPLICATION,"rtc/graph.conf"),String))
    graph=FG._prepare_graph(FG._graph_spec(document);algorithms=FGA.algorithms())
    formats=FG.parameter_formats(graph)
    receipt=YAML.load_file(joinpath(APPLICATION,"calibration/result.yaml"))
    bindings=YAML.load_file(joinpath(APPLICATION,"rtc/parameters.yaml"))["parameters"]
    params=Dict{Symbol,Array}();identities=Dict{String,String}()
    for binding in bindings
        key=Symbol(binding["port"]);path=normpath(joinpath(APPLICATION,"rtc",binding["path"]))
        identities[string(key)]=sha(path)
        identities[string(key)]==receipt["artifact_sha256"][basename(path)] || error("calibration changed: $key")
        value=FITS(path,"r") do f;read(f[binding["hdu"]]);end
        axes=get(binding,"axes",nothing)
        axes===nothing || (value=permutedims(value,Tuple(axes)))
        format=getproperty(formats,key)
        size(value)==format.shape || error("parameter shape: $key")
        params[key]=convert(Array{format.element_type},value)
    end
    Set(keys(params))==Set(keys(formats)) || error("parameter coverage")
    meta=metadata["arrays"]["raw_frames_U16"];path=joinpath(INPUTS,meta["file"])
    sha(path)==meta["sha256"] || error("raw corpus changed")
    frames=Array{UInt16}(undef,Tuple(meta["shape"]));read!(path,frames)
    (;document,params,frames,identities,metadata)
end
function cpu_graph(fixture;profile=:authored)
    document=deepcopy(fixture.document)
    if profile===:commands
        filter!(x->Symbol(x["name"]) in (:woofer,:tweeter,:tiptilt,OUTFB),document["filter.graph"]["outputs"])
    end
    graph=FG._prepare_graph(FG._graph_spec(document);algorithms=FGA.algorithms())
    for item in pairs(fixture.params);FG.replace_parameters!(graph,item);end
    graph
end
arrays(formats)=map(f->zeros(f.element_type,f.shape),formats)
struct Case{G,I,O}
    name::String
    graph::G
    inputs::I
    outputs::O
    resident::Bool
end
function step!(c::Case,frames,index,sequence)
    copyto!(c.inputs.raw,view(frames,:,:,index))
    metadata=map(_->FGA.SampleMetadata(sequence;terminal=true,discontinuity=sequence==1),c.inputs)
    result=FG.process!(c.outputs,c.graph,c.inputs,metadata)
    all(values(result)) || error("$(c.name) rejected $sequence: $result")
    c.resident || copyto!(getproperty(c.inputs,FB),getproperty(c.outputs,OUTFB))
    nothing
end
function reset_case!(c)
    FG.reset!(c.graph)
    foreach(x->fill!(x,0),values(c.inputs));foreach(x->fill!(x,0),values(c.outputs))
end
function loop!(c,frames,n;offset=0)
    for i in 1:n;step!(c,frames,mod1(offset+i,size(frames,3)),offset+i);end
end
end
