import csv
import json
from pathlib import Path
import statistics
import sys

path = Path(sys.argv[1])

def read(name):
    with (path / name).open() as source:
        return [{k: int(v) if v.lstrip("-").isdigit() else v for k, v in row.items()}
                for row in csv.DictReader(source)]

measurements = {r["sequence"]: r for r in read("arrivals.csv") if r["phase"] == "measured"}
gpu = [r for r in read("gpu.csv") if r["sequence"] in measurements]
assert len(gpu) == len(measurements) == 40000
overhead = read("profiler-overhead.csv")
late = [r for r in gpu if measurements[r["sequence"]]["command_receipt_ns"]
        - measurements[r["sequence"]]["nominal_deadline_ns"] > 500000]
graph_time = lambda row: row["graph_end"] - row["graph_start"]
dispatch = lambda row: row["first_device_copy_start"] - row["graph_end"]
readback = lambda row: row["last_device_copy_end"] - row["first_device_copy_start"]
wait_exit = lambda row: row["driver_wait_end"] - row["last_device_copy_end"]

def overlapping(row):
    start, stop = row["graph_end"], row["first_device_copy_start"]
    return [record for record in overhead if record["start_ns"] < stop and record["end_ns"] > start]

slow = [row for row in late if dispatch(row) > 100000]
print(json.dumps({
    "matched_device_frames": len(gpu),
    "late": len(late),
    "median_graph_ns": statistics.median(map(graph_time, gpu)),
    "max_late_graph_ns": max(map(graph_time, late)),
    "median_copy_dispatch_ns": statistics.median(map(dispatch, gpu)),
    "median_copy_sequence_ns": statistics.median(map(readback, gpu)),
    "median_driver_wake_ns": statistics.median(map(wait_exit, gpu)),
    "slow_copy_dispatch": [
        {"sequence": r["sequence"], "dispatch_ns": dispatch(r), "copies_ns": readback(r),
         "driver_wake_ns": wait_exit(r), "overlap": overlapping(r)}
        for r in slow
    ],
}, indent=2))
