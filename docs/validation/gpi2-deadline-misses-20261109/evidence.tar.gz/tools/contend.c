#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static uint64_t now_ns(void)
{
    struct timespec stamp;
    if (clock_gettime(CLOCK_MONOTONIC, &stamp) != 0)
        abort();
    return (uint64_t)stamp.tv_sec * 1000000000 + stamp.tv_nsec;
}

int main(int argc, char **argv)
{
    if (argc != 2)
        return 2;
    uint64_t start = strtoull(argv[1], NULL, 10);
    const uint64_t duration = 352000000;
    const size_t count = 4 * 1024 * 1024;
    uint64_t *data = aligned_alloc(64, count * sizeof(*data));
    if (data == NULL)
        return 2;
    for (size_t i = 0; i < count; ++i)
        data[i] = i;
    struct timespec ts = { start / 1000000000, start % 1000000000 };
    int result;
    while ((result = clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &ts, NULL)) == EINTR) {}
    if (result)
        return 2;
    uint64_t actual = now_ns();
    do {
        for (size_t i = 0; i < count; ++i)
            data[i] = (data[i] << 1) ^ (i * 19);
    } while (now_ns() < actual + duration);
    printf("%llu,%llu,%llu\n", (unsigned long long)actual, (unsigned long long)now_ns(),
        (unsigned long long)data[5000]);
    free(data);
    return 0;
}
