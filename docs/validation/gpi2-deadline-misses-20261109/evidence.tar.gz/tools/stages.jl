const FGCUDA = Base.get_extension(G, :FilterGraphsCUDAExt)
const STAGES = Vector{NTuple{6, UInt64}}(undef, 65536)
const STAGE_COUNT = Ref(0)

@noinline function G._launch_and_complete_captured_frame!(
    context::FGCUDA.CUDACapturedContext,
    executable,
    host_outputs,
    device_outputs,
)
    t0 = time_ns()
    G._launch_captured_graph!(context, executable)
    t1 = time_ns()
    G._enqueue_captured_frame_status_copy!(context, executable.frame_status)
    G._transfer_captured_outputs!(context, host_outputs, device_outputs)
    t2 = time_ns()
    G._synchronize_captured_graph!(context)
    t3 = time_ns()
    status = G._read_captured_frame_status(executable.frame_status)
    t4 = time_ns()
    index = STAGE_COUNT[] + 1
    if index <= length(STAGES)
        @inbounds STAGES[index] = (t0, t1, t2, t3, t4, UInt64(Threads.threadid()))
        STAGE_COUNT[] = index
    end
    return status
end

function write_stages(path)
    open(path, "w") do io
        println(io, "launch_start,launch_return,completion_wait_start,completion_wait_return,status_read,thread")
        for i in 1:STAGE_COUNT[]
            println(io, join(STAGES[i], ','))
        end
    end
end
