import csv
import json
import math
from pathlib import Path
import sys

path = Path(sys.argv[1])

def read(name):
    with (path / name).open() as source:
        return [{key: int(value) if value.lstrip("-").isdigit() else value
                 for key, value in row.items()} for row in csv.DictReader(source)]

def quantiles(values):
    ordered = sorted(values)
    if not ordered:
        return {}
    return {name: ordered[math.ceil(fraction * len(ordered)) - 1]
            for name, fraction in (("p50", .50), ("p99", .99), ("max", 1.0))}

names = ("release_to_publication", "publication_to_callback", "callback_to_launch",
         "launch_api", "enqueue_output", "completion_wait", "wait_return_to_callback_end",
         "callback_end_to_last_receipt")
arrivals = read("arrivals.csv")
source = [row for row in arrivals if row["publication_ns"]]
missing = [row for row in arrivals if not row["publication_ns"] and row["phase"] == "measured"]
assert all(row["source_rejected"] == 1 and row["command_receipt_ns"] == 0 for row in missing)
callback = read("callbacks.csv")
stages = iter(read("stages.csv"))
stage = next(stages)
assert len(source) == len(callback)
rows = []
for arrival, metrics in zip(source, callback, strict=True):
    assert arrival["sequence"] == metrics["sequence"]
    while stage["status_read"] < metrics["start_ns"]:
        stage = next(stages)
    assert metrics["thread_id"] + 1 == stage["thread"]
    assert metrics["succeeded"] == "true"
    times = [arrival["nominal_deadline_ns"], arrival["publication_ns"], metrics["start_ns"],
             stage["launch_start"], stage["launch_return"], stage["completion_wait_start"],
             stage["completion_wait_return"], metrics["end_ns"], arrival["command_receipt_ns"]]
    assert times == sorted(times), (arrival["sequence"], times)
    assert stage["completion_wait_return"] <= stage["status_read"] <= metrics["end_ns"]
    intervals = {name: b - a for name, a, b in zip(names, times, times[1:])}
    if arrival["phase"] == "measured":
        rows.append({"sequence": arrival["sequence"], "total_ns": times[-1] - times[0],
                     "publication_ns": times[1], "release_ns": times[0],
                     "allocated": metrics["allocated_bytes"], **intervals})
    stage = next(stages, None)
assert stage is None and next(stages, None) is None

def report(rows, absent=0):
    return {"frames": len(rows), "source_rejected": absent,
            "misses": absent + sum(row["total_ns"] > 500_000 for row in rows),
            **{key: quantiles(r[key] for r in rows) for key in (*names, "total_ns")}}

late = [row for row in rows if row["total_ns"] > 500_000]
output = {"measured": report(rows, len(missing)), "late": report(late),
          "worst": max(rows, key=lambda row: row["total_ns"])}
for file in sorted(path.glob("contend-*.log")):
    start, stop, _ = (int(x) for x in file.read_text().strip().split(","))
    subset = [row for row in rows if start <= row["release_ns"] < stop]
    output[file.stem] = report(subset, sum(start <= row["nominal_deadline_ns"] < stop for row in missing))
if late:
    output["late_examples"] = sorted(late, key=lambda row: -row["total_ns"])[:8]
print(json.dumps(output, indent=2))
