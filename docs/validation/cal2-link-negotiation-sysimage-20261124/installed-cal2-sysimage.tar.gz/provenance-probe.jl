using PipeWireAORTC

julia, project, image = ARGS
PipeWireAORTC.SessionInstall.validate_sysimage(julia, project, image)
println("Julia sysimage provenance accepted for ", project)
