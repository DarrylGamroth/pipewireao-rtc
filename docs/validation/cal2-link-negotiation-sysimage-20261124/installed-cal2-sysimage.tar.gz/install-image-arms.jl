using PipeWireAO, PipeWireAORTC

const RTC = PipeWireAORTC
const I = RTC.SessionInstall
const C = RTC.Common
const D = RTC.DeploymentConfiguration
const L = RTC.SessionLaunch

app, prefix, expected, image, results = ARGS
julia = D.selected_julia_executable(first(Base.julia_cmd().exec))
@assert pkgdir(RTC) == expected
@assert realpath(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir) == realpath(prefix)

I.finish_install(app, prefix, julia, nothing;
                 persistent_graph_owners = true, sysimage = I.selected_sysimage(image))
systemd = joinpath(app, "systemd")
record = joinpath(systemd, L.ACTIVATION_FILE)
unit = joinpath(systemd, "pipewireao-session@.service")
mkpath(results)
mv(record, joinpath(results, "sysimage.json"))
cp(unit, joinpath(results, "sysimage.service"))

# Produce the default selection with the same installed paths, inventory and owners.
spec = I.session_spec(app, prefix)
launcher = joinpath(app, "bin", "pipewireao-rtc-session")
project = D.application_environment(spec, app)
activation = I.install_activation!(app, prefix, julia, project, launcher, spec, nothing)
manifest = joinpath(systemd, "graph-owners.json")
managed = C.read_json(manifest)
units = [managed["owners"][owner["role"]]["unit"] for owner in spec["owners"]
         if haskey(managed["owners"], owner["role"])]
persistent = (; units, digest = C.sha256_file(manifest))
template = I.resolved_unit_template(project)
normal = I.installed_unit(
    template, spec; launcher, package = app, prefix,
    executable = D.session_executable(spec, app, prefix),
    external = L.external_services(), persistent, activation,
)
write(unit, normal)
cp(unit, joinpath(results, "default.service"))
cp(record, joinpath(results, "default.json"))
