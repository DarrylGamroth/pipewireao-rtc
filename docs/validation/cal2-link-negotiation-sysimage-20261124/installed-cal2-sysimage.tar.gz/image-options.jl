using SHA

const RTC_ID = Base.PkgId(Base.UUID("a3e2c7da-f73f-4284-8482-36ac422b34e6"), "PipeWireAORTC")
@show VERSION Base.active_project() unsafe_string(Base.JLOptions().image_file)
@show Threads.nthreads() Threads.nthreads(:interactive) Sys.sysimage_target()
@show Base.in_sysimage(RTC_ID)
for (id, mod) in sort!(collect(Base.loaded_modules); by = entry -> string(first(entry)))
    Base.in_sysimage(id) || continue
    id.uuid === nothing && continue
    println(id, '\t', pathof(mod))
end
using PipeWireAORTC, PipeWireAO
@show pkgversion(PipeWireAORTC) pathof(PipeWireAORTC)
@show pkgversion(PipeWireAO) PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir
manifest = joinpath(dirname(Base.active_project()), "Manifest.toml")
@show open(io -> bytes2hex(sha256(io)), manifest)

if !isempty(ARGS)
    document = PipeWireAORTC.Common.read_json(only(ARGS))
    deployment = PipeWireAORTC.DeploymentConfiguration
    binding = deployment.session_process_binding(document, "/validation/unused.conf")
    image = binding["sysimage"]
    mappings = [line for line in eachline("/proc/self/maps") if occursin(image, line)]
    @assert Base.in_sysimage(RTC_ID) && unsafe_string(Base.JLOptions().image_file) == image
    @assert !isempty(mappings) && all(line -> deployment.matches_sysimage_mapping(line, binding), mappings)
    @show binding["device"] binding["inode"] length(mappings)
    println("Exact installed pathname, device and inode match the live image mappings.")
end
