"""Record activity of the other benchmark holder without interacting with it."""
import json
from pathlib import Path
import time

parent = Path("/proc/2027767")
operator = Path("/var/tmp/gpi2-shadow-20261124")
try:
    fields = (parent / "stat").read_text().rsplit(")", 1)[1].split()
    children = (parent / "task/2027767/children").read_text().split()
    activity = dict(state=fields[0], cpu_ticks=int(fields[11]) + int(fields[12]),
                    last_cpu=int(fields[36]), children=list(map(int, children)))
except FileNotFoundError:
    activity = None
log = operator / "fixture-repl.log"
print(json.dumps(dict(
    observed_ns=time.monotonic_ns(), wall_ns=time.time_ns(), other_repl=activity,
    request_pending=(operator / "fixture-request.jl").exists(),
    log_last_write_ns=log.stat().st_mtime_ns if log.exists() else None,
)))
