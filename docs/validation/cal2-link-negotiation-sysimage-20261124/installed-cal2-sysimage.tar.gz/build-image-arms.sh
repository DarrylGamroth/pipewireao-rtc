#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
export JULIA_PKG_OFFLINE=true
app=$(python3 "$cal2_fixture/stage.py" candidate "$1")
source_path=$(jq -r '.source' "$cal2_fixture/candidate-source.json")
image="$cal2_fixture/rtc-application.so"
build_depots="$JULIA_DEPOT_PATH:/home/dgamroth/.julia:"
launcher=( taskset -c 4,5 "$julia" --startup-file=no --threads=1,0 )
compiler=( "--project=$cal2_fixture/pc-tool" "$cal2_fixture/build-sysimage.jl" "$app" "$image" )
JULIA_DEPOT_PATH="$build_depots" JULIA_IMAGE_THREADS=2 "${launcher[@]}" "${compiler[@]}"
installer=(
    "--project=$app" "$cal2_fixture/install-image-arms.jl"
    "$app" "$PIPEWIREAO_PREFIX" "$source_path" "$image" "$cal2_fixture/image-arms"
)
"${launcher[@]}" "${installer[@]}"
files=(
    "$app"/{Project.toml,Manifest.toml,systemd/*.json,systemd/*.service}
    "$cal2_fixture"/image-arms/{default,sysimage}.{json,service} "$image"
)
sha256sum "${files[@]}"
touch "$cal2_fixture/candidate-ready"
