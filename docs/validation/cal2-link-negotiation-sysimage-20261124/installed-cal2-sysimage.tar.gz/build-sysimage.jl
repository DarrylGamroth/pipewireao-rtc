using PackageCompiler, SHA

project, image = ARGS
manifest = joinpath(project, "Manifest.toml")
digest(path) = open(io -> bytes2hex(sha256(io)), path)
lock = digest(manifest)
@show VERSION pkgversion(PackageCompiler) project lock Sys.CPU_NAME Sys.sysimage_target()
@time PackageCompiler.create_sysimage(
    [:PipeWireAORTC]; project, sysimage_path = image, cpu_target = "native",
)
@assert digest(manifest) == lock
@show filesize(image) digest(image)
