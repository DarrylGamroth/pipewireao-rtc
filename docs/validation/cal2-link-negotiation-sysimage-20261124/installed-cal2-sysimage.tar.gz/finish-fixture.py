"""Retire only the verified private CAL2 fixture after its final observation."""
import os
from pathlib import Path
import time

import matched
import measure as m

stage, run = matched.stage, matched.scratch
assert m.load(run / "lifecycle-passed.json")["ready_open_quit_trials"] == 4
assert m.load(run / "detector-continuity.json")["passed"]
source = m.load(stage / "persistent.json")
graphs = m.load(run / "prestarted-graph-owners.json")
transient = (m.core_name, m.hil_name)
installed = (m.unit, *(graph["unit"] for graph in graphs.values()))
runtime_paths = (m.unit_file, m.dropin, m.rtc_runtime, *(m.unit_dir / unit for unit in installed[1:]))


def installed_gone():
    states = {unit: m.status(unit) for unit in installed}
    if all(state["MainPID"] == "0" for state in states.values()) and all(
        not os.path.lexists(path) for path in runtime_paths
    ):
        return states
    return None


prior = m.wait(installed_gone, 45, "fixture RTC and graph units to retire")
assert m.owner(m.hil_name) == source["hil"] and m.owner(m.core_name) == source["core"]
assert m.socket.stat().st_ino == source["inode"]
shutdown = time.monotonic_ns()
(stage / "finish").touch(exist_ok=False)


def private_gone():
    states = {unit: m.status(unit) for unit in transient}
    pids = (source["core"]["pid"], source["hil"]["pid"],
            source["native"]["independent-cal2-observe-cal2-llowfs"]["client_pid"])
    if all(state["MainPID"] == "0" for state in states.values()) and not m.runtime.exists() and all(
        not Path(f"/proc/{pid}").exists() for pid in pids
    ):
        return states
    return None


retired = m.wait(private_gone, 150, "private core, HIL and independent tap retirement")
m.save(stage / "fixture-shutdown.json", dict(
    requested_ns=shutdown, verified_ns=time.monotonic_ns(),
    rtc_and_graph_units=prior, stopped_private_units=retired, source_before_shutdown=source,
    absent_runtime_artifacts=[str(path) for path in (m.runtime, *runtime_paths)],
))
