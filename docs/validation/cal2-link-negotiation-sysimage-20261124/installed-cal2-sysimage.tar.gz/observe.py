#!/usr/bin/env python3
"""Measure the systemd start of an installed RTC. The caller owns stop and native assertions."""
import argparse
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time

SYSTEMCTL = ["systemctl", "--user"]
STAT = {
    "state": 3,
    "minflt": 10,
    "majflt": 12,
    "user_ticks": 14,
    "system_ticks": 15,
    "child_user_ticks": 16,
    "child_system_ticks": 17,
    "threads": 20,
    "start_ticks": 22,
    "processor": 39,
    "blkio_delay_ticks": 42,
}


def properties(unit):
    names = "ActiveState,MainPID,InvocationID,ExecMainStartTimestampMonotonic,ActiveEnterTimestampMonotonic"
    command = [*SYSTEMCTL, "show", "--property", names, unit]
    lines = subprocess.check_output(command, text=True).splitlines()
    return dict(line.split("=", 1) for line in lines)


def procstat(path):
    fields = path.read_text().rsplit(") ", 1)[1].split()
    return {name: int(fields[field - 3]) if field != 3 else fields[0]
            for name, field in STAT.items()}


def sample(pid):
    proc = Path("/proc") / str(pid)
    try:
        before = time.monotonic_ns()
        cpu, rq, slices = map(int, (proc / "schedstat").read_text().split())
        details = procstat(proc / "stat")
        frequencies = {}
        for logical_cpu in {2, details["processor"]}:
            entry = Path(f"/sys/devices/system/cpu/cpu{logical_cpu}/cpufreq/scaling_cur_freq")
            try:
                frequencies[str(logical_cpu)] = int(entry.read_text())
            except OSError:
                pass
        io = None
        try:
            io = {name: int(value) for name, value in
                  (line.split(": ") for line in (proc / "io").read_text().splitlines())}
        except PermissionError:
            pass
        return {
            "time_ns": before,
            "main_thread_cpu_ns": cpu,
            "main_thread_runqueue_ns": rq,
            "main_thread_slices": slices,
            "wchan": (proc / "wchan").read_text().strip(),
            "proc": details,
            "scaling_cur_freq_khz": frequencies,
            "proc_io": io,
            "sample_duration_ns": time.monotonic_ns() - before,
        }
    except (FileNotFoundError, ProcessLookupError):
        return None


def start_unit(args):
    perf = None
    perf_counts = None
    pid = 0
    observed_at = None
    calls = 0
    start_properties = properties(args.unit)
    if start_properties["ActiveState"] not in ("inactive", "failed"):
        raise RuntimeError(f"expected inactive unit, found {start_properties}")
    starting = None
    observer_started = time.process_time_ns()
    observer_children = resource.getrusage(resource.RUSAGE_CHILDREN)
    marks = []
    with (args.output / "start.log").open("w") as log, (args.output / "perf.log").open("w") as perf_log:
        requested = time.monotonic_ns()
        started = subprocess.Popen([*SYSTEMCTL, "start", args.unit], stdout=log, stderr=log)
        try:
            while True:
                if pid == 0 and started.poll() is None:
                    current = properties(args.unit)
                    calls += 1
                    pid = int(current["MainPID"])
                    if pid:
                        observed_at = time.monotonic_ns()
                        starting = current
                        if args.perf:
                            perf = subprocess.Popen([
                                "perf", "record", "-q", "-T", "--clockid", "mono",
                                "-e", "cpu-clock:u", "-F", "199", "--tid", str(pid),
                                "-o", str(args.output / "perf.data"),
                            ], stdout=perf_log, stderr=perf_log)
                            perf_counts = subprocess.Popen([
                                "perf", "stat", "-x,", "--tid", str(pid),
                                "-e", "cycles:u,instructions:u", "-o", str(args.output / "perf-counts.csv"),
                            ], stdout=perf_log, stderr=perf_log)
                if pid:
                    measured = sample(pid)
                    if measured:
                        marks.append(measured)
                code = started.poll()
                if code is not None:
                    returned = time.monotonic_ns()
                    break
                time.sleep(args.period)
        finally:
            recorders = [recorder for recorder in (perf, perf_counts)
                         if recorder is not None and recorder.poll() is None]
            for recorder in recorders:
                recorder.send_signal(signal.SIGINT)
            for recorder in recorders:
                recorder.wait(timeout=7)
    finish = properties(args.unit)
    observer_cpu = time.process_time_ns() - observer_started
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    receipt = {
        "unit": args.unit, "return_code": code, "requested_ns": requested,
        "returned_ns": returned, "main_pid_observed_ns": observed_at, "polled_properties": calls,
        "initial_properties": start_properties, "first_main_properties": starting,
        "after_start_properties": finish, "observer_process_cpu_ns": observer_cpu,
        "observer_children_cpu_seconds":
            children.ru_utime + children.ru_stime - observer_children.ru_utime - observer_children.ru_stime,
        "observer_affinity": sorted(os.sched_getaffinity(0)),
        "proc_stat_hz": os.sysconf("SC_CLK_TCK"), "period": args.period,
        "perf": args.perf, "perf_return_code": None if perf is None else perf.returncode,
        "perf_counts_return_code": None if perf_counts is None else perf_counts.returncode,
        "samples": marks,
    }
    (args.output / "observer.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: value for key, value in receipt.items() if key != "samples"}), flush=True)
    return code


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("unit")
    cli.add_argument("output", type=Path)
    cli.add_argument("--perf", action="store_true")
    cli.add_argument("--period", default=.02, type=float)
    args = cli.parse_args()
    args.output.mkdir()
    raise SystemExit(start_unit(args))
