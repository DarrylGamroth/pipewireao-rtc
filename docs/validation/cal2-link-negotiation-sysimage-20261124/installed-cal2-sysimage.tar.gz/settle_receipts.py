"""Join final detector receipts after late independent drains have settled."""
import collections
import json
from pathlib import Path
import sys

from continuity.decode import events
import measure as m

fixture = Path(sys.argv[2]) if len(sys.argv) > 2 else m.stage
m.stage = fixture
source = m.load(fixture / "persistent.json")
root = Path(sys.argv[1])
tap_pid = source["native"]["independent-cal2-observe-cal2-llowfs"]["client_pid"]
tap_path = fixture / f"tap-array-trace.tsv.{tap_pid}.bin"
hil_path = fixture / f'hil-array-trace.tsv.{source["hil"]["pid"]}.bin'

def key(row):
    return tuple(row[name] for name in ("domain", "generation", "sequence", "model_ns"))

def trace_rows(path):
    for _, event, stream, domain, generation, sequence, model, timestamp, flags in events(path):
        yield dict(event=event, stream=stream, domain=domain, generation=generation, sequence=sequence,
                   model_ns=model, observed_ns=timestamp, flags=flags)

received = {key(row): row for row in trace_rows(tap_path) if row["event"] == "native-received"}
accepted = {key(row): row for row in trace_rows(tap_path) if row["event"] == "receive-accepted"}
tap_drain = {key(row): row for row in trace_rows(tap_path) if row["event"] == "drained"}
drained = {key(row): row for row in m.cameras()}
streams = {int(index): properties for index, properties in m.load(root / "source-camera-streams.json").items()}
producer = [dict(row, **streams[row["stream"]]) for row in trace_rows(hil_path)
            if row["stream"] in streams]
published = [row for row in producer if row["event"] == "native-queued"]
graphs = m.load(root / "prestarted-graph-owners.json")
graph_inputs = {camera: list(trace_rows(
    fixture / f'graph-ingress.{owner["unit_identity"]["pid"]}.bin'))
    for camera, owner in graphs.items()}
activations = sorted(((m.load(path), path.parent) for path in root.glob("*/lifecycle.json")),
                     key=lambda item: item[0]["request_ns"])
window = root / "post-quit-observation.json"
settled_until_ns = m.load(window)["cutoff_ns"] + 200_000_000 if window.exists() else 2**64

def transport_summary(window):
    producer_events = collections.defaultdict(lambda: collections.defaultdict(list))
    cutoff = window["cutoff_ns"]
    for row in producer:
        producer_events[key(row)][row["event"]].append(row)
    summary = {}
    for info in streams.values():
        camera = info["camera"]
        stages = [row for row in producer if row["camera"] == camera and row["event"] == "staged" and
                  row["observed_ns"] <= cutoff]
        scopes = {"provider_epoch": stages,
                  "after_final_quit": [row for row in stages if row["observed_ns"] > window["after_stop_ns"]]}
        summary[camera] = {}
        for name, exposures in scopes.items():
            summary[camera][name] = {
                "sequences": [row["sequence"] for row in exposures],
                "native_queued": sum(bool(producer_events[key(row)]["native-queued"]) for row in exposures),
                "tap_callback": sum(key(row) in received for row in exposures),
                "tap_drain_trace": sum(key(row) in tap_drain for row in exposures),
                "tap_drain_receipt": sum(key(row) in drained for row in exposures),
            }
        retries = []
        for row in stages:
            grouped = producer_events[key(row)]
            misses = grouped["no-output-buffer"]
            if not misses:
                continue
            first_miss = misses[0]["observed_ns"]
            def ms_after_miss(events):
                return [(item["observed_ns"] - first_miss) / 1_000_000 for item in events]
            retries.append(dict(sequence=row["sequence"], domain=row["domain"], generation=row["generation"],
                                model_ns=row["model_ns"], first_miss_ns=first_miss,
                                errno=[miss["flags"] for miss in misses],
                                retry_ms=ms_after_miss(grouped["publication-retry"]),
                                native_queue_ms=ms_after_miss(grouped["native-queued"]),
                                tap_drain_ms=ms_after_miss([tap_drain[key(row)]] if key(row) in tap_drain else []),
                                tap_receipt_ms=ms_after_miss([drained[key(row)]] if key(row) in drained else [])))
        summary[camera]["retry_receipts"] = retries
    m.save(root / "settled-transport.json", summary)

if window.exists():
    transport_summary(m.load(window))

def enrich(boundaries):
    identity = key(boundaries["publication"])
    boundaries.update(tap_callback=received.get(identity), tap_accepted=accepted.get(identity),
                      tap_drained=drained.get(identity))

for index, (lifecycle, directory) in enumerate(activations):
    receipt = directory / "detector-paths.json"
    if not receipt.exists():
        continue
    report = m.load(receipt)
    until_ns = (activations[index + 1][0]["request_ns"]
                if index + 1 < len(activations) else settled_until_ns)
    request_ns = lifecycle["request_ns"]
    ready_ns = lifecycle["native_ready"]["ready"]["received_ns"]
    started_ns = lifecycle.get("running", {}).get("started", {}).get("sent_ns", lifecycle["stop"]["request_ns"])
    transport = directory / "ordinary-running.json"
    for camera, branch in report.items():
        seen = {key(row): row for row in graph_inputs[camera]
                if row["event"] == "graph-ingress" and request_ns <= row["observed_ns"] < until_ns}
        branch["publications"] = [
            dict(publication=row, graph_ingress=seen.get(key(row))) for row in published
            if row["camera"] == camera and request_ns <= row["observed_ns"] < until_ns
        ]
        branch["held"] = [row for row in branch["publications"]
                          if ready_ns <= row["publication"]["observed_ns"] < started_ns]
        branch["after_stop"] = [row for row in branch["publications"]
                                if row["publication"]["observed_ns"] > lifecycle["stop"]["completed_ns"]]
        for phase in ("publications", "held", "after_stop"):
            for exposure in branch[phase]:
                enrich(exposure)
        if transport.exists() and camera == "cal2-llowfs":
            _, residual, sample = m.load(transport)["first_usable"]
            identity = key(sample)
            branch["open_sample"] = next(row for row in branch["publications"]
                                         if key(row["publication"]) == identity)
            branch["timings_s"] = dict(
                request_to_ready=m.seconds(lifecycle["ready_ns"], request_ns),
                start_ack_to_first_usable=m.seconds(
                    residual["observed_ns"], lifecycle["running"]["started"]["received_ns"]),
            )
        for phase in ("open_sample", "closed_sample"):
            if phase in branch:
                enrich(branch[phase])
                assert branch[phase]["graph_ingress"], (receipt, phase)
        opened = lifecycle.get("fresh_open_priming", {}).get(camera.removeprefix("cal2-"))
        if opened:
            acknowledged = lifecycle["running"]["started"]["received_ns"]
            output_times = {name: opened[name]["observed_ns"] for name in ("residual", "offset", "pair")
                            if opened.get(name) is not None}
            branch["timings_s"].update(
                start_ack_to_first_residual=m.seconds(output_times["residual"], acknowledged),
                start_ack_to_first_zero_offset=m.seconds(output_times["offset"], acknowledged),
                start_ack_to_first_complete_open_sample=m.seconds(max(output_times.values()), acknowledged),
            )
            if "pair" in output_times:
                branch["timings_s"]["start_ack_to_first_pair_status"] = m.seconds(output_times["pair"], acknowledged)
        branch["missing_tap_drains"] = [
            row["publication"]["sequence"] for row in branch["publications"] if row["tap_drained"] is None
        ]
    m.save(receipt.with_name("detector-paths-settled.json"), report)
    print(receipt.parent.name, json.dumps({camera: branch["missing_tap_drains"] for camera, branch in report.items()}))
