"""Compare installed CAL2 with the distribution and pinned application images."""
import argparse
import fcntl
import hashlib
import os
from pathlib import Path
import shutil

import matched
import measure as m
import ordinary
import replacement as retained

stage, scratch, app = matched.stage, matched.scratch, matched.app
variants = {"default": stage / "image-arms/default", "sysimage": stage / "image-arms/sysimage"}
distribution_image = Path(m.julia).parent.parent / "lib/julia/sys.so"


def sha256(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def prove_same_inputs():
    default, custom = [m.load(variant.with_suffix(".json")) for variant in variants.values()]
    image = Path(custom.pop("julia-sysimage"))
    image_digest = custom.pop("julia-sysimage-sha256")
    identity = custom["files"].pop(str(image))
    assert default == custom
    assert image_digest == sha256(image)
    m.save(scratch / "image-comparison.json",
           dict(default=dict(path=str(distribution_image), sha256=sha256(distribution_image)),
                sysimage=dict(path=str(image), sha256=image_digest, identity=identity),
                equal_files=sorted(default["files"])))
    return image


def select(mode):
    assert m.status(m.unit)["MainPID"] == "0"
    document = variants[mode].with_suffix(".json")
    activation = app / "systemd/session-activation.json"
    pending = activation.with_suffix(".incoming")
    assert not pending.exists()
    shutil.copyfile(document, pending)
    pending.replace(activation)
    matched.set_mode(mode, {name: path.with_suffix(".service") for name, path in variants.items()})


def confirm_image(directory, receipt, ledger, expected_image, mode):
    pid = receipt["rtc"]["pid"]
    proc = Path(f"/proc/{pid}")
    maps = [fields for line in (proc / "maps").read_text().splitlines()
            if len(fields := line.split(maxsplit=5)) == 6]
    paths = {fields[5] for fields in maps}
    selected = [fields for fields in maps if fields[5] == str(expected_image)]
    assert selected
    identity = expected_image.stat()
    for line in selected:
        major, minor = (int(part, 16) for part in line[3].split(":"))
        assert (major, minor, int(line[4])) == (os.major(identity.st_dev), os.minor(identity.st_dev), identity.st_ino)
    assert (proc / "exe").resolve() == Path(m.julia).resolve()
    args = receipt["effective_argv"]
    assert args == ledger["session_process"]["argv"]
    assert [argument for argument in args if argument.startswith("--sysimage=")] == (
        [f"--sysimage={expected_image}"] if mode == "sysimage" else []
    )
    assert ledger["session_process"].get("sysimage") == (
        str(expected_image) if mode == "sysimage" else None
    )
    if mode == "sysimage":
        assert ledger["session_process"]["device"] == identity.st_dev
        assert ledger["session_process"]["inode"] == identity.st_ino
    assert "--threads=1,0" in args
    m.save(directory / "image-mapping.json", dict(image=str(expected_image),
           executable=str((proc / "exe").resolve()), argv=args, mapped=selected,
           package_images=sorted(path for path in paths if "PipeWireAORTC/" in path),
           pipewire_images=sorted(path for path in paths if "libpipewire-ao-0.3.so." in path)))


def first_llowfs(directory, receipt, started):
    offset, residual, camera = m.wait(
        lambda: m.output_matches(directory, "llowfs", started["sent_ns"], False),
        125, "first fresh open LLOWFS output",
    )
    assert residual["max_abs"] > 0 and offset["max_abs"] == 0
    assert camera["observed_ns"] > started["sent_ns"]
    receipt["fresh_open_priming"] = {
        "llowfs": dict(offset=m.without_payload(offset), residual=m.without_payload(residual),
                       camera=camera, pair=None),
    }
    m.save(directory / "lifecycle.json", receipt)


def observed_start(observer, directory):
    def host_state():
        processes = m.run("ps", "-eLo", "pid,tid,psr,comm,time", "--no-headers",
                          text=True, capture_output=True).stdout
        return dict(procstat=Path("/proc/stat").read_text(),
                    cpu_2_3=[line.strip() for line in processes.splitlines()
                             if line.split(maxsplit=4)[2] in ("2", "3")])

    before = host_state()
    result = ordinary.profile_start(observer, directory, False)
    m.save(directory / "host-startup-stat.json", dict(before=before, after=host_state()))
    return result


def run(observer, full_pair):
    scratch.mkdir()
    image = prove_same_inputs()
    source = m.load(stage / "persistent.json")
    matched.camera_map(source)
    files = retained.fixture_inputs()
    units = {role: path.name for role, path in files.items()}
    reference = retained.native_links(m.load(ordinary.reference / "ready-native.json"))
    edges = {key: data["format"] for key, data in reference.items()}
    claimed = []
    try:
        matched.install_units(files, claimed)
        matched.input_receipts(scratch, source, files,
                               {name: path.with_suffix(".service") for name, path in variants.items()})
        graphs = retained.prestart_graphs(units, source)
        print("Both graph services prestarted on the continuously publishing source", flush=True)
        m.start_service = lambda directory: observed_start(observer, directory)
        for index, mode in enumerate(("default", "sysimage", "sysimage", "default"), 1):
            select(mode)
            directory, launch, ledger, receipt = matched.start(
                mode, f"{index:02}-{mode}", source, graphs, units, edges
            )
            confirm_image(directory, receipt, ledger,
                          image if mode == "sysimage" else distribution_image, mode)
            started = retained.start_open(directory, receipt)
            if full_pair and index in (2, 4):
                retained.optical_open(directory, receipt, started)
            else:
                first_llowfs(directory, receipt, started)
            assert all(row["max_abs"] == 0 for row in m.read_capture(directory)
                       if row["name"].endswith("-physical-offset"))
            ordinary.finish_ready_trial(directory, launch, ledger, receipt, source, graphs, running=True)
        window = ordinary.observation_end(receipt["stop"], source, 0)
        m.save(scratch / "post-quit-observation.json", window)
        ordinary.capture_publication_result(source, window["cutoff_ns"])
        assert m.load(scratch / "detector-continuity.json")["passed"]
        retained.full_shutdown(source, units, wait_for_camera=False)
        m.save(scratch / "lifecycle-passed.json", {"ready_open_quit_trials": 4, "both_branches_open": full_pair})
    finally:
        for child, _ in m.children:
            if child.poll() is None:
                child.terminate()
                child.wait(timeout=20)
        try:
            retained.remove_runtime_units(claimed)
        finally:
            retained.capture_journal(claimed)
            if m.rtc_runtime.is_dir():
                shutil.rmtree(m.rtc_runtime)


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--observer", required=True, type=Path)
    cli.add_argument("--both-branches", action="store_true")
    args = cli.parse_args()
    with (m.runtime.parent / "rtc-devel-benchmark.lock").open("a") as lease:
        print("Waiting for the benchmark lease", flush=True)
        fcntl.flock(lease, fcntl.LOCK_EX)
        run(args.observer, args.both_branches)
