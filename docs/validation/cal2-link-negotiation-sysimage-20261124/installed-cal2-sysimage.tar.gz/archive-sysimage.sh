#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
cd "$cal2_fixture"
cohort=replacement-sysimage
source_pid=$(jq -r '.hil.pid' persistent.json)
tap_pid=$(jq -r '.native["independent-cal2-observe-cal2-llowfs"].client_pid' persistent.json)
mapfile -t graph_traces < <(jq -r '.[].unit_identity.pid| "graph-ingress." + tostring + ".bin"' "$cohort/prestarted-graph-owners.json")
hil_trace="hil-array-trace.tsv.$source_pid.bin"
tap_trace="tap-array-trace.tsv.$tap_pid.bin"
python3 continuity/lineage.py --hil "$hil_trace" --tap "$tap_trace" --graph "${graph_traces[@]}" > "$cohort/detector-lineage.tsv"
python3 settle_receipts.py "$cohort" . > "$cohort/settled-joins.log"
python3 summarize-image-trials.py "$cohort" > "$cohort/comparison.json"
rg -n 'recycled slot .* on withdrawal|pw_context_create_link.*\(cal2-(llowfs|scc)\)' core-native.log > "$cohort/queue-returns.log"
files=(
    "$cohort" image-arms candidate-source.json sysimage-build.log image-options.log preseal-image-maps.log
    fixture.log persistent.json camera-trace.tsv pupil-pacing.tsv fixture-shutdown.json host-kernel.txt
    "$hil_trace" "$tap_trace" "${graph_traces[@]}"
    candidate-app/{Project.toml,Manifest.toml,deployment.conf}
    candidate-app/systemd/{graph-owner-assets.json,graph-owners.json,pipewireao-graph-*.service}
    pc-tool/Project.toml packagecompiler-lock.toml packagecompiler-lock-origin.json
    core-config queue-provenance.json source-simulation.conf commands.txt
    build-image-arms.sh build-sysimage.jl install-image-arms.jl sysimage-trials.py image-options.jl
    provenance-probe.jl provenance-negative.sh provenance-compatible.log provenance-mismatch.log
    provenance-manifests.sha256 provenance-negative/{Project,Manifest}.toml
    summarize-image-trials.py archive-sysimage.sh finish-fixture.py
    lease-wait.jsonl observe-lease-wait.py
    session-env.sh stage.py driver.py feed.jl live-correction-control.jl live-observe.jl
    measure.py matched.py replacement.py ordinary.py observe.py settle_receipts.py
    continuity/{decode.py,lineage.py,continuity_trace.jl}
    continuity/event-driven-provider-env/{Project,Manifest}.toml
    continuity/event-driven-hil/src/{array_streams,independent,continuity_trace}.jl
    continuity-depot/packages/FilterGraphPipeWire/2cAf1/src/{FilterGraphPipeWire,continuity_trace}.jl
)
tar -czf installed-cal2-sysimage.tar.gz "${files[@]}"
gzip -t installed-cal2-sysimage.tar.gz
sha256sum installed-cal2-sysimage.tar.gz
