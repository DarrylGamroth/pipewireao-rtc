#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/session-env.sh"
cd "$cal2_fixture"
python3 - <<'PY'
import re,shutil,tomllib
from pathlib import Path
source=Path('candidate-app')
negative=Path('provenance-negative')
negative.mkdir()
shutil.copy2(source/'Project.toml',negative/'Project.toml')
manifest=(source/'Manifest.toml').read_text()
stanza=re.search(r'(?ms)^\[\[deps\.JSON\]\]\n.*?(?=^\[\[deps\.)',manifest)[0]
older=stanza.replace('version = "1.13.4"','version = "1.13.1"').replace(
    '06d90f699285d055e34f0b014636a75a17ff2252','69a876face3b7aa9ac03b8dbf0f27d71bc17cf05')
assert older!=stanza
changed=manifest.replace(stanza,older)
baseline=tomllib.loads(manifest)['deps']
candidate=tomllib.loads(changed)['deps']
assert set(baseline)==set(candidate)
assert [key for key in baseline if baseline[key]!=candidate[key]]==['JSON']
(negative/'Manifest.toml').write_text(changed)
PY
launcher=( taskset -c 14 "$julia" --startup-file=no --threads=1,0 --compiled-modules=existing )
probe=( "${launcher[@]}" "--project=$cal2_fixture/candidate-app" provenance-probe.jl )
"${probe[@]}" "$julia" "$cal2_fixture/candidate-app" "$cal2_fixture/rtc-application.so" > provenance-compatible.log 2>&1
result=0
"${probe[@]}" "$julia" "$cal2_fixture/provenance-negative" "$cal2_fixture/rtc-application.so" > provenance-mismatch.log 2>&1 || result=$?
test "$result" -ne 0
rg -q 'different JSON package source' provenance-mismatch.log
sha256sum candidate-app/{Project,Manifest}.toml provenance-negative/{Project,Manifest}.toml > provenance-manifests.sha256
