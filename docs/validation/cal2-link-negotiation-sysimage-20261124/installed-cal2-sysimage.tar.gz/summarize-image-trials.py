"""Summarize the four valid syscall timings and the correlated first outputs."""
import json
from pathlib import Path
import statistics
import sys

run = Path(sys.argv[1])
records = []
for directory in sorted(run.glob("0*")):
    life = json.loads((directory / "lifecycle.json").read_text())
    image = json.loads((directory / "image-mapping.json").read_text())
    observer = json.loads((directory / "cpu-observer/observer.json").read_text())
    paths = json.loads((directory / "detector-paths-settled.json").read_text())
    sample = observer["samples"][-1]
    stats = sample["proc"]
    hz = observer["proc_stat_hz"]
    assert life["stop"]["systemd"]["Result"] == "success"
    records.append(dict(
        arm=directory.name, mode=life["mode"], pid=life["rtc"]["pid"],
        invocation=life["rtc"]["invocation"], image=image["image"],
        ready_s=life["request_to_systemd_ready_s"],
        process_cpu_s=(stats["user_ticks"]+stats["system_ticks"])/hz,
        user_cpu_s=stats["user_ticks"]/hz, system_cpu_s=stats["system_ticks"]/hz,
        main_thread_cpu_s=sample["main_thread_cpu_ns"]/1e9,
        main_thread_runqueue_s=sample["main_thread_runqueue_ns"]/1e9,
        minor_page_faults=stats["minflt"], major_page_faults=stats["majflt"],
        sample_after_return_s=(sample["time_ns"]-observer["returned_ns"])/1e9,
        first_usable={
            camera: dict(sequence=branch["open_sample"]["publication"]["sequence"],
                         **branch["timings_s"])
            for camera, branch in paths.items() if "open_sample" in branch
        },
    ))

modes = ("default", "sysimage")
metrics = ("ready_s", "process_cpu_s", "main_thread_cpu_s", "main_thread_runqueue_s")
assert len(records) == 4
assert len({entry["pid"] for entry in records}) == 4
assert len({entry["invocation"] for entry in records}) == 4
means = {
    mode: {metric: statistics.mean(entry[metric] for entry in records if entry["mode"] == mode)
           for metric in metrics}
    for mode in modes
}
summary = dict(trials=records, means=means,
               mean_ready_saved_s=means["default"]["ready_s"]-means["sysimage"]["ready_s"])
print(json.dumps(summary, indent=2))
