#!/usr/bin/env bash
set -euo pipefail
rtc_image_scratch=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
rtc_image_fixture=/var/tmp/rtc-cal2-sysimage.l4jpe9MR
source "$rtc_image_fixture/session-env.sh"
export JULIA_DEPOT_PATH="/var/tmp/rtc-admission-precompile.0DcR5n13/depot:/var/tmp/rtc-startup-cpu.oNJi8aFe/depot:$JULIA_DEPOT_PATH" JULIA_LOAD_PATH="@:@stdlib" TMPDIR=/tmp
rtc_image="$rtc_image_fixture/rtc-application.so"
cmp "$rtc_image_scratch/image-build-env/Project.toml" "$rtc_image_fixture/candidate-app/Project.toml"
cmp "$rtc_image_scratch/image-build-env/Manifest.toml" "$rtc_image_fixture/candidate-app/Manifest.toml"
launcher=(taskset -c 12 "$julia" --startup-file=no --threads=1,0 --compiled-modules=existing)
installer=("${launcher[@]}" --project=/var/tmp/rtc-startup-cpu.oNJi8aFe/optimized-env "$rtc_image_scratch/installer-probe.jl")
"${installer[@]}" "$julia" "$rtc_image_scratch/image-build-env" "$rtc_image" >"$rtc_image_scratch/final-image-compatible.log" 2>&1
"${launcher[@]}" --project="$rtc_image_scratch/mismatched-env" --sysimage="$rtc_image" \
    "$rtc_image_scratch/legacy-probe.jl" "$rtc_image" > "$rtc_image_scratch/final-image-legacy-accepted.log" 2>&1
result=0
"${installer[@]}" "$julia" "$rtc_image_scratch/mismatched-env" "$rtc_image" > "$rtc_image_scratch/final-image-mismatch-rejected.log" 2>&1 || result=$?
test "$result" -ne 0
rg 'different JSON package source' "$rtc_image_scratch/final-image-mismatch-rejected.log"
cat "$rtc_image_scratch/final-image-legacy-accepted.log"
