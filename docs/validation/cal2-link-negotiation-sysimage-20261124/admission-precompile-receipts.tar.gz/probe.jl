using PipeWireAORTC
const RTC = PipeWireAORTC
const PipeWireAO = RTC.MediaSession.PipeWireAO
const Clocks = RTC.MediaSession.Clocks

function compile_targets(targets)
    GC.gc()
    return @timed begin
        count(precompile, targets)
    end
end

function measure(path, traced)
    grouped = Dict{String,Vector{Type}}()
    for line in eachline(path)
        label, text = split(line, '\t'; limit = 2)
        push!(get!(grouped, label, Type[]), Core.eval(Main, Meta.parse(text)))
    end
    compile_targets(Type[])
    for label in ("registry", "proof", "close", "status")
        haskey(grouped, label) || continue
        targets = grouped[label]
        trace = traced == "trace"
        trace && ccall(:jl_force_trace_compile_timing_enable, Cvoid, ())
        cold = try
            compile_targets(targets)
        finally
            trace && ccall(:jl_force_trace_compile_timing_disable, Cvoid, ())
        end
        warm = compile_targets(targets)
        cold.value == warm.value == length(targets) || error("precompile signature not found for " * label)
        println(label, " roots=", cold.value, " elapsed_s=", cold.time, " compiler_s=", cold.compile_time,
                " warm_elapsed_s=", warm.time, " warm_compiler_s=", warm.compile_time)
    end
    println("source=", pkgdir(RTC))
end

measure(ARGS...)
