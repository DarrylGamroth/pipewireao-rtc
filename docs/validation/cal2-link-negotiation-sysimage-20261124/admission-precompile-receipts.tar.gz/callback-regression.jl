using Test, PipeWireAORTC

const RTC = PipeWireAORTC
const PW = RTC.MediaSession.PipeWireAO
const Client = RTC.ControlClient
const Clock = RTC.MediaSession.Clocks

struct BindingCallbacks end
function Base.bind(::BindingCallbacks, _, ::Type{PW.Node}; callbacks...)
    return (; callbacks...)
end

struct SourceObservation
    seen::Vector{Tuple{PW.Pod,Int64}}
end
function Client.observe!(observation::SourceObservation, pod::PW.Pod; at)
    push!(observation.seen, (pod, at))
    return nothing
end

mutable struct AdmissionClient
    clock::Clock.CachedNanoClock
    wakeups::Int
end
Client.wake!(client::AdmissionClient) = (client.wakeups += 1; nothing)

@testset "owner parameter callback argument order" begin
    observation = SourceObservation(Tuple{PW.Pod,Int64}[])
    client = AdmissionClient(Clock.CachedNanoClock(Int64(42)), 0)
    callbacks = Client.bind_owner(BindingCallbacks(), nothing, client, observation)
    pod = PW.Pod(Int32(17))
    callback = callbacks.on_param

    callback(nothing, Cint(7), PW.SPA.PARAM_PROPS, UInt32(19), UInt32(23), pod)
    @test observation.seen == [(pod, Int64(42))]
    @test client.wakeups == 1

    callback(nothing, Cint(8), PW.SPA.PARAM_FORMAT, UInt32(19), UInt32(23), pod)
    callback(nothing, Cint(9), PW.SPA.PARAM_PROPS, UInt32(19), UInt32(23), nothing)
    @test observation.seen == [(pod, Int64(42))]
    @test client.wakeups == 3
end
