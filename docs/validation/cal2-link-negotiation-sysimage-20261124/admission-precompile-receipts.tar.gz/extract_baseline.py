from pathlib import Path
import re
import sys

journal = Path(sys.argv[1]).read_text().splitlines()
roots = set()
for label, first, last in (("registry",357,401), ("proof",499,530), ("close",593,615)):
    for line in journal[first-1:last]:
        match = re.search(r"ms =# precompile\((Tuple\{.*\})\)(?: # recompile)?$", line)
        if not match:
            continue
        signature = match[1]
        if label == "registry":
            chosen = (
                ("MediaSession._bind_object!" in signature and
                 signature.endswith(("Type{PipeWireAO.ClientInfo}}", "Type{PipeWireAO.NodeInfo}}"))) or
                "typeof(PipeWireAORTC.MediaSession._bind_object)," in signature and "Type{PipeWireAO.Node" in signature or
                "typeof(PipeWireAORTC.MediaSession._enumerate_object!)" in signature or
                "typeof(PipeWireAORTC.MediaSession.controller_fact)" in signature or
                "typeof(PipeWireAORTC.MediaSession.update!)" in signature and "MediaSession.ParamReceived" in signature
            )
        elif label == "proof":
            chosen = (
                ("typeof(Core.kwcall)" in signature and "typeof(PipeWireAORTC.ControlClient.connect)" in signature) or
                "typeof(PipeWireAO._core_events)" in signature or
                signature.startswith("Tuple{Type{PipeWireAO.Registry") or
                ("typeof(Core.kwcall)" in signature and (
                    "typeof(PipeWireAO.add_listener!)" in signature or
                    "typeof(Base.bind)" in signature and "ControlClient." in signature or
                    "Type{PipeWireAO.Filter" in signature or
                    "typeof(PipeWireAO.connect!)" in signature
                )) or
                "typeof(PipeWireAO.subscribe_params!)" in signature or
                "typeof(PipeWireAO.enum_params!)" in signature
            )
        else:
            chosen = "typeof(Base.close)" in signature and (("ControlClient.Client{" in signature and "TimerSource{" not in signature) or "param_callback##" in signature)
        if chosen and signature not in roots:
            roots.add(signature)
            print(label + "\t" + signature)
