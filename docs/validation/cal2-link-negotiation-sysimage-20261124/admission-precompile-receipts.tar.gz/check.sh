#!/usr/bin/env bash
set -euo pipefail
rtc_corrected=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/rtc-cal2-sysimage.l4jpe9MR/session-env.sh
export JULIA_DEPOT_PATH="$rtc_corrected/depot:/var/tmp/rtc-admission-precompile.0DcR5n13/depot:/var/tmp/rtc-startup-cpu.oNJi8aFe/depot:$JULIA_DEPOT_PATH" JULIA_LOAD_PATH="@:@stdlib" TMPDIR=/tmp

candidate="$rtc_corrected/env"
base=/var/tmp/rtc-startup-cpu.oNJi8aFe/optimized-env
launch=(taskset -c 12 "$julia" --startup-file=no --threads=1,0 --compiled-modules=existing)
"${launch[@]}" --project="$candidate" "$rtc_corrected/callback-regression.jl" > "$rtc_corrected/callback-test.log" 2>&1
"${launch[@]}" --project="$candidate" "$rtc_corrected/candidate_targets.jl" \
  > "$rtc_corrected/candidate-targets.tsv" 2> "$rtc_corrected/target-generation.log"
for sample in 01-baseline 02-candidate 03-candidate 04-baseline 05-baseline 06-candidate; do
    variant="${sample#*-}"
    environment="$candidate"
    if [[ "$variant" == baseline ]]; then environment="$base"; fi
    "${launch[@]}" --project="$environment" "$rtc_corrected/probe.jl" \
      "$rtc_corrected/$variant-targets.tsv" quiet > "$rtc_corrected/probe-$sample.log" 2>&1
    "${launch[@]}" --project="$environment" -e '
        started = time_ns()
        Base.@time_imports using PipeWireAORTC
        println("import_wall_s=", (time_ns() - started) / 1e9)
        println("source=", pkgdir(PipeWireAORTC))
        for line in eachline("/proc/self/maps")
            if occursin("/compiled/", line) && occursin("/PipeWireAORTC/", line)
                println("rtc_image_map=", line)
                break
            end
        end' > "$rtc_corrected/import-$sample.log" 2>&1
done
"${launch[@]}" --project="$base" "$rtc_corrected/probe.jl" \
  "$rtc_corrected/baseline-targets.tsv" trace > "$rtc_corrected/baseline-trace.log" 2>&1
"${launch[@]}" --project="$candidate" "$rtc_corrected/probe.jl" \
  "$rtc_corrected/candidate-targets.tsv" trace > "$rtc_corrected/candidate-trace.log" 2>&1
