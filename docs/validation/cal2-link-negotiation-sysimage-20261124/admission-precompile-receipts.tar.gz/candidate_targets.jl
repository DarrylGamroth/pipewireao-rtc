using PipeWireAORTC
const RTC = PipeWireAORTC
const M = RTC.MediaSession
const C = RTC.ControlClient
const PW = M.PipeWireAO
const Clock = M.Clocks.SystemNanoClock
const RT = Core.Compiler.return_type

signature(f::Type, types...) = Tuple{Type{f},types...}
signature(f, types...) = Tuple{typeof(f),types...}
emit(group, f, types...) = println(group, '\t', signature(f, types...))

core = RT(M.session_core, Tuple{PW.Context{PW.MainLoop},String,M.EventQueue})
registry = RT(PW.Registry, Tuple{core})
endpoint = RT(M.session_endpoint, Tuple{core,Dict{String,String},M.EventQueue,Clock})
controller = RT(M.session_controller, Tuple{core,Dict{String,String}})
T = M.Session{core,registry,endpoint,controller,Clock}
@assert isconcretetype(T)
callbacks = RT(M.object_callbacks, Tuple{M.EventQueue,UInt32,UInt64})
emit("registry", M._bind_object!, T, PW.Global, Type{PW.Client}, Type{PW.ClientInfo})
emit("registry", M._bind_object!, T, PW.Global, Type{PW.Node}, Type{PW.NodeInfo})
arguments = (registry,PW.Global,Type{PW.Node},callbacks,M.EventQueue,UInt32)
emit("registry", M._bind_object, arguments...)
node_proxy = RT(M._bind_object, Tuple{arguments...})
@assert isconcretetype(node_proxy)
object = M.Object{node_proxy,PW.NodeInfo}
emit("registry", M._enumerate_object!, T, M.Job, object, UInt32)
emit("registry", M.controller_fact, T, object, PW.NodeInfo)
emit("registry", M.update!, T, M.ParamReceived)

profile = RTC.SessionProfile.Profile()
obs = C.Observation{typeof(profile),C.lifecycle_type(profile),C.completion_type(profile),C.rejection_type(profile)}
client = C.Client{obs,Clock}
check = RT(M.admission_check, Tuple{T,M.Job})
emit("proof", Core.kwcall, NamedTuple{(:deadline,:clock,:controller_instance,:check),Tuple{Int64,Clock,Int64,check}},
     typeof(C.connect), typeof(profile), String, String, Int32, UInt64)
connection = (PW.Context{PW.ThreadLoop},String,client)
client_core = RT(C.client_core, Tuple{connection...})
@assert isconcretetype(client_core)
emit("proof", PW._core_events, client_core)
emit("proof", PW.Registry, client_core)
client_registry = RT(PW.Registry, Tuple{client_core})
@assert isconcretetype(client_registry)
emit("proof", C.listen_registry!, client_registry, client)
emit("proof", Core.kwcall, NamedTuple{(:properties,),Tuple{Dict{String,String}}},
    Type{PW.Filter}, client_core, String)
filter_type = RT(Core.kwcall,
    Tuple{NamedTuple{(:properties,),Tuple{Dict{String,String}}},Type{PW.Filter},client_core,String})
@assert isconcretetype(filter_type)
emit("proof", Core.kwcall, NamedTuple{(:flags,),Tuple{UInt32}},
    typeof(PW.connect!), filter_type)
emit("proof", C.bind_marker, client_registry, PW.Global, client)
emit("proof", C.bind_owner, client_registry, PW.Global, client, obs)
owner_proxy = RT(C.bind_owner, Tuple{client_registry,PW.Global,client,obs})
marker_proxy = RT(C.bind_marker, Tuple{client_registry,PW.Global,client})
listener = RT(C.listen_registry!, Tuple{client_registry,client})
@assert all(isconcretetype, (owner_proxy,marker_proxy,listener))
emit("proof", PW.subscribe_params!, owner_proxy, Tuple{UInt32})
emit("proof", Core.kwcall, NamedTuple{(:count,),Tuple{UInt32}},
    typeof(PW.enum_params!), owner_proxy, UInt32)
for resource in (owner_proxy,marker_proxy,listener,client_core)
    emit("close", close, resource)
end
emit("close", close, node_proxy)
status_check = RT(M.publication_check, Tuple{T,Int64})
emit("status", Core.kwcall, NamedTuple{(:deadline,:check),Tuple{Int64,status_check}},
    typeof(C.request!), client, typeof(RTC.SessionCodec.RunnerCommand(:status)))
