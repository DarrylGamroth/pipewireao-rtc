/* SPDX-License-Identifier: MIT */

#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <inttypes.h>
#include <math.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <spa/buffer/buffer.h>
#include <spa/buffer/meta.h>
#include <spa/node/command.h>
#include <spa/param/format.h>
#include <spa/param/buffers.h>
#include <spa/param/ndarray.h>
#include <spa/param/ndarray-utils.h>
#include <spa/pod/builder.h>
#include <spa/utils/result.h>

#include <pipewire/pipewire.h>

#define IMAGE_ROWS 242u
#define IMAGE_COLUMNS 240u
#ifndef ROW_BLOCK_ROWS
#define ROW_BLOCK_ROWS IMAGE_ROWS
#endif
#define BLOCKS_PER_FRAME (IMAGE_ROWS / ROW_BLOCK_ROWS)
#define ROW_BLOCK_ELEMENTS (ROW_BLOCK_ROWS * IMAGE_COLUMNS)
enum { SINK_COUNT = 3 };
static float *captured[SINK_COUNT];
static const char *sink_names[SINK_COUNT] = { "gpi2-woofer", "gpi2-tweeter", "gpi2-tiptilt" };
static const uint32_t sink_elements[SINK_COUNT] = { 97, 2304, 2 };
static const char *sink_schemas[SINK_COUNT] = {
    "org.heart.std-dm.actuator-command/1",
    "org.heart.std-dm.actuator-command/1",
    "org.heart.std-dm.actuator-command/1",
};
#define SOURCE_PENDING_FRAMES 2u
#define SOURCE_PENDING_ROWS (SOURCE_PENDING_FRAMES * BLOCKS_PER_FRAME)
#define PRIMING_FRAMES 1u
#define START_DELAY_NS UINT64_C(100000000)
#define DRAIN_NS UINT64_C(2000000000)

enum arrival_state {
	ARRIVAL_EMPTY = 0,
	ARRIVAL_PENDING,
	ARRIVAL_CLAIMED,
	ARRIVAL_PUBLISHED,
	ARRIVAL_MISSED,
};

struct arrival_record {
	atomic_int state;
	uint64_t nominal_deadline_ns;
	uint64_t offered_ns;
	atomic_uint_fast64_t publication_ns;
	atomic_int trigger_result;
	atomic_int state_after_trigger;
	atomic_uint publications_in_trigger;
	atomic_int dequeue_errno;
	atomic_uint available_at_failure;
};

struct frame_record {
	bool source_rejected;
	atomic_uint_fast64_t command_receipt_ns;
	atomic_uint_fast64_t sink_receipt_ns[SINK_COUNT];
	atomic_uint received;
    atomic_uint duplicates[SINK_COUNT];
};

struct rtc_client;
struct command_sink {
    struct rtc_client *data;
    struct pw_stream *stream;
    struct spa_hook listener;
    unsigned index;
    atomic_int state;
    atomic_bool format_verified;
};

struct rtc_client {
	struct pw_main_loop *loop;
	struct pw_context *context;
	struct pw_core *core;
	struct pw_stream *source;
	struct command_sink sinks[SINK_COUNT];
	uint16_t *input_frames;
	size_t input_count;
	struct spa_hook source_listener;
	struct pw_loop *schedule_loop;
	struct spa_source *schedule_timer;
	struct spa_source *retry_event;
	struct spa_source *finish_timer;
	struct spa_source *control;
	atomic_int source_state;
	atomic_bool source_format_verified;
	atomic_bool streaming_reported;
	atomic_bool ready_reported;
	atomic_bool start_requested;
	atomic_uint scheduled;
	atomic_uint accepted;
	atomic_uint claim_cursor;
	atomic_uint produced;
	atomic_uint source_buffer_count;
	atomic_uint max_source_buffers;
	atomic_uint source_buffer_maxsize;
	atomic_uint empty_arrival_callbacks;
	atomic_uint source_dequeue_failures;
	atomic_uint completed_triggers;
	atomic_uint trigger_accepted;
	atomic_uint trigger_busy;
	atomic_uint trigger_failures;
	uint32_t reserved_rows;
	uint32_t pending_rows;
	uint32_t max_reserved_rows;
	uint32_t max_pending_rows;
	uint32_t rejected_source_frames;
	atomic_uint_fast64_t request_process_commands;
	atomic_uint command_frames;
	atomic_uint zero_command_frames;
	atomic_uint_fast64_t timer_catchup_expirations;
	atomic_uint_fast64_t max_timer_expirations_per_callback;
	atomic_uint_fast64_t row_publications_after_next_deadline;
	atomic_uint_fast64_t max_row_publication_lateness_ns;
	atomic_int result;
	atomic_uintptr_t failure_message;
	uint32_t frame_rate;
	uint32_t warmup_frames;
	uint32_t sample_frames;
	uint32_t overload_frame_rate;
	uint32_t overload_frames;
	uint64_t overload_period_ns;
	uint32_t total_frames;
	uint32_t total_blocks;
	uint64_t block_interval_ns;
	uint64_t frame_period_ns;
	uint64_t readout_ns;
	uint64_t first_deadline_ns;
	struct spa_fraction negotiated_source_rate;
	struct spa_fraction negotiated_sink_rate;
	struct arrival_record *arrivals;
	struct frame_record *frames;
	const char *csv_path;
	const char *arrival_csv_path;
};

static void schedule_arrivals(void *userdata, uint64_t expirations);
static void service_source_retry(void *userdata, uint64_t count);

static uint64_t monotonic_ns(void)
{
	struct timespec value;

	if (clock_gettime(CLOCK_MONOTONIC, &value) != 0)
		return 0;
	return (uint64_t)value.tv_sec * UINT64_C(1000000000) +
		(uint64_t)value.tv_nsec;
}

static struct timespec ns_to_timespec(uint64_t value)
{
	return (struct timespec) {
		.tv_sec = (time_t)(value / UINT64_C(1000000000)),
		.tv_nsec = (long)(value % UINT64_C(1000000000)),
	};
}

static const char *frame_phase(const struct rtc_client *data, uint32_t frame)
{
	if (frame < PRIMING_FRAMES)
		return "priming";
	if (frame < PRIMING_FRAMES + data->warmup_frames)
		return "warmup";
	if (data->overload_frames == 0)
		return "measured";
	return frame < PRIMING_FRAMES + data->warmup_frames + data->overload_frames ?
		"overload" : "recovery";
}

static uint64_t frame_deadline_offset_ns(const struct rtc_client *data, uint32_t frame)
{
	uint32_t start = PRIMING_FRAMES + data->warmup_frames;
	uint32_t overloaded = frame > start ? SPA_MIN(frame - start, data->overload_frames) : 0;
	return (uint64_t)(frame - overloaded) * data->frame_period_ns +
		(uint64_t)overloaded * data->overload_period_ns;
}

static uint64_t nominal_block_deadline_ns(const struct rtc_client *data,
		uint32_t arrival)
{
	uint32_t frame = arrival / BLOCKS_PER_FRAME;
	uint32_t block = arrival % BLOCKS_PER_FRAME;

	if (data->readout_ns == 0)
		return data->first_deadline_ns +
			(uint64_t)arrival * data->block_interval_ns;
	return data->first_deadline_ns +
		frame_deadline_offset_ns(data, frame) +
		(uint64_t)block * data->readout_ns / BLOCKS_PER_FRAME;
}

static void update_max(atomic_uint_fast64_t *target, uint64_t value)
{
	uint64_t current = atomic_load_explicit(target, memory_order_relaxed);

	while (current < value && !atomic_compare_exchange_weak_explicit(target,
			&current, value, memory_order_relaxed, memory_order_relaxed))
		;
}

static void fail(struct rtc_client *data, const char *message)
{
	int expected = 0;

	if (atomic_compare_exchange_strong_explicit(&data->result, &expected, 1,
			memory_order_acq_rel, memory_order_relaxed)) {
		atomic_store_explicit(&data->failure_message, (uintptr_t)message,
				memory_order_release);
		pw_log_error("%s", message);
	}
	pw_main_loop_quit(data->loop);
}

static int create_schedule_timer(struct spa_loop *loop, bool async, uint32_t seq,
		const void *payload, size_t size, void *userdata)
{
	struct rtc_client *data = userdata;
	struct timespec first, interval;
	uint64_t now;

	(void)loop;
	(void)async;
	(void)seq;
	(void)payload;
	(void)size;
	data->schedule_timer = pw_loop_add_timer(data->schedule_loop,
			schedule_arrivals, data);
	if (data->schedule_timer == NULL)
		return -errno;
	now = monotonic_ns();
	if (now == 0)
		return -EIO;
	data->first_deadline_ns = now + START_DELAY_NS;
	if (data->readout_ns != 0) {
		first = ns_to_timespec(data->first_deadline_ns);
		interval = ns_to_timespec(0);
		return pw_loop_update_timer(data->schedule_loop, data->schedule_timer,
				&first, &interval, true);
	}
	first = ns_to_timespec(data->first_deadline_ns);
	interval = ns_to_timespec(data->block_interval_ns);
	return pw_loop_update_timer(data->schedule_loop, data->schedule_timer,
			&first, &interval, true);
}

static void arm_schedule(struct rtc_client *data)
{
	struct timespec finish_first, finish_interval;

	if (atomic_exchange_explicit(&data->streaming_reported, true,
			memory_order_acq_rel))
		return;
	if (data->schedule_loop == NULL || pw_loop_locked(data->schedule_loop,
			create_schedule_timer, 1, NULL, 0, data) < 0) {
		fail(data, "could not arm the RTC source data-loop timer");
		return;
	}
	finish_first = ns_to_timespec(UINT64_C(1000000));
	finish_interval = finish_first;
	if (pw_loop_update_timer(pw_main_loop_get_loop(data->loop),
			data->finish_timer, &finish_first, &finish_interval, false) < 0) {
		fail(data, "could not arm the RTC completion timer");
		return;
	}
	printf("STREAMING first_deadline_ns=%" PRIu64
		" block_interval_ns=%" PRIu64 "\n",
		data->first_deadline_ns, data->block_interval_ns);
	fflush(stdout);
}

static void maybe_start(struct rtc_client *data)
{
	bool ready = atomic_load_explicit(&data->source_format_verified,
			memory_order_acquire) &&
        atomic_load_explicit(&data->source_state, memory_order_acquire) == PW_STREAM_STATE_STREAMING;
    for (unsigned i = 0; i < SINK_COUNT; i++)
        ready = ready && atomic_load(&data->sinks[i].format_verified) &&
            atomic_load(&data->sinks[i].state) == PW_STREAM_STATE_STREAMING;

	if (!ready)
		return;
	if (!atomic_exchange_explicit(&data->ready_reported, true,
			memory_order_acq_rel)) {
		printf("READY source_rate=%u/%u command_rate=%u/%u\n",
			data->negotiated_source_rate.num,
			data->negotiated_source_rate.denom,
			data->negotiated_sink_rate.num,
			data->negotiated_sink_rate.denom);
		fflush(stdout);
	}
	if (atomic_load_explicit(&data->start_requested, memory_order_acquire))
		arm_schedule(data);
}

static void start_control(void *userdata, int fd, uint32_t mask)
{
	struct rtc_client *data = userdata;
	uint8_t command;

	if ((mask & SPA_IO_IN) == 0 || read(fd, &command, sizeof(command)) !=
			(ssize_t)sizeof(command) || command != 's') {
		fail(data, "RTC benchmark received an invalid start command");
		return;
	}
	atomic_store_explicit(&data->start_requested, true, memory_order_release);
	maybe_start(data);
}

static void source_param_changed(void *userdata, uint32_t id,
		const struct spa_pod *param)
{
	struct rtc_client *data = userdata;
	struct spa_ndarray_info info;
	uint32_t expected_rate = data->frame_rate * BLOCKS_PER_FRAME;

	if (id != SPA_PARAM_Format || param == NULL)
		return;
	if (spa_format_ndarray_parse(param, &info) < 0 ||
	    info.element_type != SPA_ELEMENT_TYPE_U16_LE ||
	    info.layout != SPA_NDARRAY_LAYOUT_ROW_MAJOR ||
	    info.n_dimensions != 2 || info.shape[0] != ROW_BLOCK_ROWS ||
	    info.shape[1] != IMAGE_COLUMNS || info.rate.num != expected_rate ||
	    info.rate.denom != 1u) {
		fail(data, "RTC source negotiated an unexpected format or rate");
		return;
	}
	data->negotiated_source_rate = info.rate;
	atomic_store_explicit(&data->source_format_verified, true,
			memory_order_release);
	maybe_start(data);
}

static void sink_param_changed(void *userdata, uint32_t id,
		const struct spa_pod *param)
{
	struct command_sink *sink = userdata;
	struct rtc_client *data = sink->data;
	struct spa_ndarray_info info;

	if (id != SPA_PARAM_Format || param == NULL)
		return;
	if (spa_format_ndarray_parse(param, &info) < 0 ||
	    info.element_type != SPA_ELEMENT_TYPE_F32_LE ||
	    info.layout != SPA_NDARRAY_LAYOUT_ROW_MAJOR ||
	    info.n_dimensions != 1 || info.shape[0] != sink_elements[sink->index] ||
	    info.rate.num != data->frame_rate || info.rate.denom != 1u) {
		fail(data, "RTC command sink negotiated an unexpected format or rate");
		return;
	}
	atomic_store_explicit(&sink->format_verified, true,
			memory_order_release);
	maybe_start(data);
}

static void source_state_changed(void *userdata, enum pw_stream_state old,
		enum pw_stream_state state, const char *error)
{
	struct rtc_client *data = userdata;

	(void)old;
	atomic_store_explicit(&data->source_state, state, memory_order_release);
	if (state == PW_STREAM_STATE_ERROR) {
		pw_log_error("source stream error: %s", error == NULL ? "unknown" : error);
		fail(data, "RTC source entered the error state");
		return;
	}
	maybe_start(data);
}

static void sink_state_changed(void *userdata, enum pw_stream_state old,
		enum pw_stream_state state, const char *error)
{
	struct command_sink *sink = userdata;
	struct rtc_client *data = sink->data;

	(void)old;
	atomic_store_explicit(&sink->state, state, memory_order_release);
	if (state == PW_STREAM_STATE_ERROR) {
		pw_log_error("command sink stream error: %s",
			error == NULL ? "unknown" : error);
		fail(data, "RTC command sink entered the error state");
		return;
	}
	maybe_start(data);
}

/* Only the source data loop advances this cursor or changes reservations. */
static bool claim_arrival(struct rtc_client *data, uint32_t *arrival)
{
	uint32_t cursor = atomic_load(&data->claim_cursor);
	uint32_t scheduled = atomic_load(&data->scheduled);
	while (cursor < scheduled) {
		if (atomic_load(&data->arrivals[cursor].state) == ARRIVAL_PENDING) {
			*arrival = cursor;
			return true;
		}
		atomic_store(&data->claim_cursor, ++cursor);
	}
	return false;
}

static void source_process(void *userdata)
{
	struct rtc_client *data = userdata;
	struct pw_buffer *buffer;
	struct spa_data *block;
	struct spa_meta_header *header;
	struct arrival_record *record;
	uint16_t *pixels;
	uint32_t arrival, frame, block_index, row_offset;
	uint64_t publication;
	uint64_t lateness;
	int result;

	if (!claim_arrival(data, &arrival)) {
		atomic_fetch_add(&data->empty_arrival_callbacks, 1);
		return;
	}
	record = &data->arrivals[arrival];
	buffer = pw_stream_dequeue_buffer(data->source);
	if (buffer == NULL) {
		int dequeue_error = errno;
		struct pw_time timing = { 0 };
		atomic_store(&record->dequeue_errno, dequeue_error);
		if (pw_stream_get_time_n(data->source, &timing, sizeof(timing)) == 0)
			atomic_store(&record->available_at_failure, timing.avail_buffers);
		atomic_fetch_add(&data->source_dequeue_failures, 1);
		if (dequeue_error != EAGAIN && dequeue_error != EBUSY && dequeue_error != EPIPE)
			fail(data, "RTC source dequeue failed unexpectedly");
		return;
	}
	atomic_store(&record->state, ARRIVAL_CLAIMED);
	block = &buffer->buffer->datas[0];
	if (block->data == NULL || block->chunk == NULL ||
	    block->maxsize < ROW_BLOCK_ELEMENTS * sizeof(*pixels)) {
		(void)pw_stream_queue_buffer(data->source, buffer);
		atomic_store_explicit(&record->state, ARRIVAL_MISSED,
				memory_order_release);
		fail(data, "RTC source received an invalid buffer");
		return;
	}
	header = spa_buffer_find_meta_data(buffer->buffer, SPA_META_Header,
			sizeof(*header));
	if (header == NULL) {
		(void)pw_stream_queue_buffer(data->source, buffer);
		atomic_store_explicit(&record->state, ARRIVAL_MISSED,
				memory_order_release);
		fail(data, "RTC source Header metadata is unavailable");
		return;
	}
	frame = arrival / BLOCKS_PER_FRAME;
	block_index = arrival % BLOCKS_PER_FRAME;
	row_offset = block_index * ROW_BLOCK_ROWS;
	pixels = block->data;
    memcpy(pixels, data->input_frames + ((size_t)frame % data->input_count) * ROW_BLOCK_ELEMENTS,
           ROW_BLOCK_ELEMENTS * sizeof(*pixels));
	block->chunk->offset = 0;
	block->chunk->size = ROW_BLOCK_ELEMENTS * sizeof(*pixels);
	block->chunk->stride = IMAGE_COLUMNS * sizeof(*pixels);
	*header = (struct spa_meta_header) {
		.flags = block_index + 1u == BLOCKS_PER_FRAME ?
			SPA_META_HEADER_FLAG_MARKER : 0,
		.offset = row_offset,
		.pts = (int64_t)record->nominal_deadline_ns,
		.dts_offset = 0,
		.seq = (uint64_t)frame + 1u,
	};
	publication = monotonic_ns();
	if (publication == 0) {
		(void)pw_stream_queue_buffer(data->source, buffer);
		atomic_store_explicit(&record->state, ARRIVAL_MISSED,
				memory_order_release);
		fail(data, "CLOCK_MONOTONIC failed during source publication");
		return;
	}
	atomic_store_explicit(&record->publication_ns, publication,
			memory_order_release);
	lateness = publication > record->nominal_deadline_ns ?
		publication - record->nominal_deadline_ns : 0;
	update_max(&data->max_row_publication_lateness_ns, lateness);
	if (lateness >= (data->readout_ns == 0 ? data->block_interval_ns :
			nominal_block_deadline_ns(data, arrival + 1u) -
			record->nominal_deadline_ns))
		atomic_fetch_add_explicit(&data->row_publications_after_next_deadline,
				1u, memory_order_relaxed);
	result = pw_stream_queue_buffer(data->source, buffer);
	if (result < 0) {
		atomic_store_explicit(&record->state, ARRIVAL_MISSED,
				memory_order_release);
		fail(data, "RTC source could not publish a queued buffer");
		return;
	}
	atomic_store_explicit(&record->state, ARRIVAL_PUBLISHED,
			memory_order_release);
	atomic_fetch_add_explicit(&data->produced, 1u, memory_order_release);
	atomic_store(&data->claim_cursor, arrival + 1u);
	data->pending_rows--;
	data->reserved_rows--;
}

static int drive_source(struct rtc_client *data)
{
	int result = pw_stream_trigger_process(data->source);
	if (result == 0)
		atomic_fetch_add(&data->trigger_accepted, 1);
	else if (result == -EBUSY)
		atomic_fetch_add(&data->trigger_busy, 1);
	else if (result < 0) {
		atomic_fetch_add(&data->trigger_failures, 1);
		fail(data, "RTC source trigger failed unexpectedly");
	}
	return result;
}

static void service_source_retry(void *userdata, uint64_t count SPA_UNUSED)
{
	struct rtc_client *data = userdata;
	(void)drive_source(data);
}

static int create_source_retry(struct spa_loop *loop SPA_UNUSED,
		bool async SPA_UNUSED, uint32_t seq SPA_UNUSED,
		const void *payload SPA_UNUSED, size_t size SPA_UNUSED, void *userdata)
{
	struct rtc_client *data = userdata;
	data->retry_event = pw_loop_add_event(data->schedule_loop, service_source_retry, data);
	return data->retry_event == NULL ? -errno : 0;
}

static void source_command(void *userdata, const struct spa_command *command)
{
	struct rtc_client *data = userdata;
	if (SPA_NODE_COMMAND_ID(command) != SPA_NODE_COMMAND_RequestProcess)
		return;
	atomic_fetch_add(&data->request_process_commands, 1);
	if (data->retry_event != NULL && pw_loop_signal_event(data->schedule_loop, data->retry_event) < 0)
		fail(data, "could not stage RTC native process request");
}

static void source_trigger_done(void *userdata)
{
	struct rtc_client *data = userdata;
	uint32_t produced, completed;
	bool completed_publication = false;

	produced = atomic_load_explicit(&data->produced, memory_order_acquire);
	completed = atomic_load_explicit(&data->completed_triggers,
			memory_order_relaxed);
	while (completed < produced) {
		if (atomic_compare_exchange_weak_explicit(&data->completed_triggers,
				&completed, completed + 1u, memory_order_acq_rel,
				memory_order_relaxed)) {
			completed_publication = true;
			break;
		}
	}
	if (completed_publication && data->pending_rows != 0 && data->retry_event != NULL &&
	    pw_loop_signal_event(data->schedule_loop, data->retry_event) < 0)
		fail(data, "could not stage RTC source completion retry");
}

static void command_process(void *userdata)
{
	struct command_sink *sink = userdata;
	struct rtc_client *data = sink->data;
	struct pw_buffer *buffer;
	struct spa_data *block;
	struct spa_meta_header *header;
	const float *command;
	uint64_t receipt, expected;
	uint32_t frame, index;

	buffer = pw_stream_dequeue_buffer(sink->stream);
	if (buffer == NULL)
		return;
	receipt = monotonic_ns();
	if (receipt == 0) {
		(void)pw_stream_queue_buffer(sink->stream, buffer);
		fail(data, "CLOCK_MONOTONIC failed during command receipt");
		return;
	}
	block = &buffer->buffer->datas[0];
	if (block->data == NULL || block->chunk == NULL ||
	    block->chunk->offset > block->maxsize ||
	    block->chunk->size != sink_elements[sink->index] * sizeof(*command) ||
	    block->maxsize - block->chunk->offset < block->chunk->size) {
		(void)pw_stream_queue_buffer(sink->stream, buffer);
		fail(data, "RTC command sink received an invalid buffer");
		return;
	}
	header = spa_buffer_find_meta_data(buffer->buffer, SPA_META_Header,
			sizeof(*header));
	if (header == NULL || header->seq == 0 || header->seq > data->total_frames ||
		    header->offset != 0) {
		(void)pw_stream_queue_buffer(sink->stream, buffer);
		fail(data, "RTC command sink received invalid Header metadata");
		return;
	}
	frame = (uint32_t)header->seq - 1u;
	if (header->pts != SPA_TIME_INVALID) {
		(void)pw_stream_queue_buffer(sink->stream, buffer);
		fail(data, "RTC command sink received unexpected HEART command PTS");
		return;
	}
	command = SPA_PTROFF(block->data, block->chunk->offset, const float);
	for (index = 0; index < sink_elements[sink->index]; index++) {
		if (!isfinite(command[index])) {
			(void)pw_stream_queue_buffer(sink->stream, buffer);
			fail(data, "RTC command sink received a non-finite command");
			return;
		}
	}
	expected = 0;
	if (!atomic_compare_exchange_strong_explicit(
			&data->frames[frame].sink_receipt_ns[sink->index], &expected, receipt,
			memory_order_acq_rel, memory_order_relaxed)) {
        atomic_fetch_add(&data->frames[frame].duplicates[sink->index], 1u);
        if (pw_stream_queue_buffer(sink->stream, buffer) < 0)
            fail(data, "RTC command sink could not recycle a duplicate buffer");
        return;
	}
    if (captured[sink->index] != NULL)
        memcpy(captured[sink->index] + (size_t)frame * sink_elements[sink->index], command, block->chunk->size);
    if (atomic_fetch_add(&data->frames[frame].received, 1) == SINK_COUNT - 1) {
        uint64_t last = 0;
        for (unsigned i = 0; i < SINK_COUNT; i++)
            last = SPA_MAX(last, atomic_load(&data->frames[frame].sink_receipt_ns[i]));
        atomic_store(&data->frames[frame].command_receipt_ns, last);
        atomic_fetch_add_explicit(&data->command_frames, 1u, memory_order_release);
    }
	if (pw_stream_queue_buffer(sink->stream, buffer) < 0)
		fail(data, "RTC command sink could not recycle a queued buffer");
}

static void admit_arrival(struct rtc_client *data, uint32_t arrival, uint64_t offered)
{
	struct arrival_record *record = &data->arrivals[arrival];
	struct frame_record *frame = &data->frames[arrival / BLOCKS_PER_FRAME];
	if (arrival % BLOCKS_PER_FRAME == 0) {
		frame->source_rejected = SOURCE_PENDING_ROWS - data->reserved_rows < BLOCKS_PER_FRAME;
		if (frame->source_rejected)
			data->rejected_source_frames++;
		else {
			data->reserved_rows += BLOCKS_PER_FRAME;
			if (data->reserved_rows > data->max_reserved_rows)
				data->max_reserved_rows = data->reserved_rows;
		}
	}
	record->nominal_deadline_ns = nominal_block_deadline_ns(data, arrival);
	record->offered_ns = offered;
	atomic_store(&record->state, frame->source_rejected ? ARRIVAL_MISSED : ARRIVAL_PENDING);
	if (!frame->source_rejected) {
		atomic_fetch_add(&data->accepted, 1);
		data->pending_rows++;
		if (data->pending_rows > data->max_pending_rows)
			data->max_pending_rows = data->pending_rows;
	}
	atomic_store(&data->scheduled, arrival + 1u);
}

static void drive_arrivals(struct rtc_client *data, uint32_t arrival)
{
	struct arrival_record *record = &data->arrivals[arrival];
	uint32_t before = atomic_load(&data->produced);
	int result = drive_source(data);
	atomic_store(&record->trigger_result, result);
	atomic_store(&record->state_after_trigger, atomic_load(&record->state));
	atomic_store(&record->publications_in_trigger, atomic_load(&data->produced) - before);
}

static void schedule_uniform_arrivals(struct rtc_client *data, uint64_t expirations)
{
	uint64_t batch = expirations;
	uint32_t arrival = atomic_load(&data->scheduled);
	if (arrival >= data->total_blocks)
		return;
	update_max(&data->max_timer_expirations_per_callback, batch);
	if (batch > 1)
		atomic_fetch_add(&data->timer_catchup_expirations, batch - 1);
	uint64_t offered = monotonic_ns();
	while (expirations-- > 0 && arrival < data->total_blocks)
		admit_arrival(data, arrival++, offered);
	if (batch != 0 && arrival != 0)
		drive_arrivals(data, arrival - 1u);
	if (arrival == data->total_blocks) {
		struct timespec zero = { 0 };
		if (pw_loop_update_timer(data->schedule_loop, data->schedule_timer,
				&zero, &zero, false) < 0)
			fail(data, "could not disarm completed RTC arrival timer");
	}
}

static void schedule_burst_arrivals(struct rtc_client *data)
{
	struct timespec next, interval;
	uint64_t now, batch = 0;
	uint32_t arrival;

	now = monotonic_ns();
	if (now == 0) {
		fail(data, "CLOCK_MONOTONIC failed during burst arrival scheduling");
		return;
	}
	for (;;) {
		arrival = atomic_load_explicit(&data->scheduled, memory_order_relaxed);
		if (arrival >= data->total_blocks ||
		    nominal_block_deadline_ns(data, arrival) > now)
			break;
		admit_arrival(data, arrival, now);
		batch++;
	}
	if (batch != 0) {
		drive_arrivals(data, arrival - 1u);
		update_max(&data->max_timer_expirations_per_callback, batch);
		if (batch > 1)
			atomic_fetch_add_explicit(&data->timer_catchup_expirations,
					batch - 1, memory_order_relaxed);
	}
	if (arrival >= data->total_blocks)
		return;
	next = ns_to_timespec(nominal_block_deadline_ns(data, arrival));
	interval = ns_to_timespec(0);
	if (pw_loop_update_timer(data->schedule_loop, data->schedule_timer,
			&next, &interval, true) < 0)
		fail(data, "could not rearm the RTC burst source timer");
}

static void schedule_arrivals(void *userdata, uint64_t expirations)
{
	struct rtc_client *data = userdata;

	if (data->readout_ns == 0)
		schedule_uniform_arrivals(data, expirations);
	else
		schedule_burst_arrivals(data);
}

static void check_finish(void *userdata, uint64_t expirations)
{
	struct rtc_client *data = userdata;
	uint32_t scheduled, commands, priming_commands, required_commands;
	uint32_t produced, completed;
	uint64_t now, final_deadline;

	(void)expirations;
	scheduled = atomic_load_explicit(&data->scheduled, memory_order_acquire);
	if (scheduled < data->total_blocks)
		return;
	commands = atomic_load_explicit(&data->command_frames, memory_order_acquire);
	priming_commands = atomic_load_explicit(
			&data->frames[0].command_receipt_ns, memory_order_acquire) != 0;
	required_commands = commands - priming_commands;
	produced = atomic_load_explicit(&data->produced, memory_order_acquire);
	completed = atomic_load_explicit(&data->completed_triggers,
			memory_order_acquire);
	if (required_commands >= data->total_frames - PRIMING_FRAMES &&
	    produced == data->total_blocks && completed >= produced) {
		pw_main_loop_quit(data->loop);
		return;
	}
	now = monotonic_ns();
	final_deadline = nominal_block_deadline_ns(data, data->total_blocks - 1u);
	if (now >= final_deadline + DRAIN_NS)
		pw_main_loop_quit(data->loop);
}

static void interrupted(void *userdata, int signal_number)
{
	struct rtc_client *data = userdata;

	(void)signal_number;
	fail(data, "RTC latency benchmark interrupted");
}

static struct spa_pod *build_format(struct spa_pod_builder *builder,
		uint32_t element_type, const uint32_t *shape, uint32_t dimensions,
		uint32_t rate, const char *schema)
{
	struct spa_pod_frame object;

	spa_pod_builder_push_object(builder, &object, SPA_TYPE_OBJECT_Format,
			SPA_PARAM_EnumFormat);
	spa_pod_builder_add(builder,
			SPA_FORMAT_mediaType, SPA_POD_Id(SPA_MEDIA_TYPE_application),
			SPA_FORMAT_mediaSubtype, SPA_POD_Id(SPA_MEDIA_SUBTYPE_ndarray),
			SPA_FORMAT_NDARRAY_elementType, SPA_POD_Id(element_type),
			SPA_FORMAT_NDARRAY_shape,
			SPA_POD_Array(sizeof(uint32_t), SPA_TYPE_Int, dimensions, shape),
			SPA_FORMAT_NDARRAY_layout,
			SPA_POD_Id(SPA_NDARRAY_LAYOUT_ROW_MAJOR),
			SPA_FORMAT_NDARRAY_rate, SPA_POD_Fraction(&SPA_FRACTION(rate, 1u)),
			SPA_FORMAT_NDARRAY_schema, SPA_POD_String(schema), 0);
	return spa_pod_builder_pop(builder, &object);
}

static struct spa_pod *build_header_meta(struct spa_pod_builder *builder)
{
	return spa_pod_builder_add_object(builder,
			SPA_TYPE_OBJECT_ParamMeta, SPA_PARAM_Meta,
			SPA_PARAM_META_type, SPA_POD_Id(SPA_META_Header),
			SPA_PARAM_META_size, SPA_POD_Int(sizeof(struct spa_meta_header)));
}

static struct spa_pod *build_row_buffers(struct spa_pod_builder *builder)
{
	return spa_pod_builder_add_object(builder,
			SPA_TYPE_OBJECT_ParamBuffers, SPA_PARAM_Buffers,
			SPA_PARAM_BUFFERS_buffers, SPA_POD_Int(32),
			SPA_PARAM_BUFFERS_blocks, SPA_POD_Int(1),
			SPA_PARAM_BUFFERS_size, SPA_POD_Int(ROW_BLOCK_ELEMENTS * sizeof(uint16_t)),
			SPA_PARAM_BUFFERS_stride, SPA_POD_Int(IMAGE_COLUMNS * sizeof(uint16_t)),
			SPA_PARAM_BUFFERS_align, SPA_POD_Int(16));
}

static int connect_stream(struct pw_stream *stream, enum pw_direction direction,
		const struct spa_pod **params, uint32_t count, bool driver)
{
	enum pw_stream_flags flags = PW_STREAM_FLAG_MAP_BUFFERS |
		PW_STREAM_FLAG_RT_PROCESS | PW_STREAM_FLAG_NO_CONVERT;

	if (driver)
		flags |= PW_STREAM_FLAG_DRIVER | PW_STREAM_FLAG_RT_TRIGGER_DONE;
	return pw_stream_connect(stream, direction, PW_ID_ANY, flags, params, count);
}

static uint32_t parse_positive_u32(const char *name, const char *value)
{
	char *end;
	unsigned long parsed;

	errno = 0;
	parsed = strtoul(value, &end, 10);
	if (errno != 0 || *value == '\0' || *end != '\0' || parsed == 0 ||
	    parsed > UINT32_MAX) {
		fprintf(stderr, "%s must be a positive UInt32\n", name);
		exit(2);
	}
	return (uint32_t)parsed;
}

static void parse_arguments(struct rtc_client *data, int argc, char *argv[])
{
	int index;

	data->frame_rate = 500u;
	data->warmup_frames = 100u;
	data->sample_frames = 10000u;
	data->readout_ns = 0;
	data->csv_path = NULL;
	for (index = 1; index < argc; index++) {
		if (strcmp(argv[index], "--frame-rate") == 0 && index + 1 < argc)
			data->frame_rate = parse_positive_u32("--frame-rate", argv[++index]);
		else if (strcmp(argv[index], "--warmup-frames") == 0 && index + 1 < argc)
			data->warmup_frames = parse_positive_u32("--warmup-frames", argv[++index]);
		else if (strcmp(argv[index], "--sample-frames") == 0 && index + 1 < argc)
			data->sample_frames = parse_positive_u32("--sample-frames", argv[++index]);
		else if (strcmp(argv[index], "--readout-us") == 0 && index + 1 < argc)
			data->readout_ns = (uint64_t)parse_positive_u32(
					"--readout-us", argv[++index]) * UINT64_C(1000);
		else if (strcmp(argv[index], "--overload-frame-rate") == 0 && index + 1 < argc)
			data->overload_frame_rate = parse_positive_u32("--overload-frame-rate", argv[++index]);
		else if (strcmp(argv[index], "--overload-frames") == 0 && index + 1 < argc)
			data->overload_frames = parse_positive_u32("--overload-frames", argv[++index]);
		else if (strcmp(argv[index], "--arrival-csv") == 0 && index + 1 < argc)
			data->arrival_csv_path = argv[++index];
		else if (strcmp(argv[index], "--csv") == 0 && index + 1 < argc)
			data->csv_path = argv[++index];
		else {
			fprintf(stderr, "usage: %s [--frame-rate HZ] [--warmup-frames N] "
				"[--sample-frames N] [--readout-us N] --csv PATH\n", argv[0]);
			exit(2);
		}
	}
	if (data->csv_path == NULL) {
		fprintf(stderr, "--csv is required\n");
		exit(2);
	}
	if (data->frame_rate > UINT32_MAX / BLOCKS_PER_FRAME) {
		fprintf(stderr, "--frame-rate is too large\n");
		exit(2);
	}
	if ((uint64_t)PRIMING_FRAMES + data->warmup_frames + data->sample_frames >
			UINT32_MAX / BLOCKS_PER_FRAME) {
		fprintf(stderr, "frame count is too large\n");
		exit(2);
	}
	data->total_frames = PRIMING_FRAMES + data->warmup_frames +
		data->sample_frames;
	data->total_blocks = data->total_frames * BLOCKS_PER_FRAME;
	data->block_interval_ns = UINT64_C(1000000000) /
		((uint64_t)data->frame_rate * BLOCKS_PER_FRAME);
	if (data->block_interval_ns == 0) {
		fprintf(stderr, "configured block interval is below one nanosecond\n");
		exit(2);
	}
	data->frame_period_ns = UINT64_C(1000000000) / data->frame_rate;
	if ((data->overload_frame_rate == 0) != (data->overload_frames == 0) ||
	    (data->overload_frames != 0 && (data->overload_frame_rate <= data->frame_rate ||
	     data->overload_frame_rate > UINT32_MAX / BLOCKS_PER_FRAME ||
	     data->overload_frames >= data->sample_frames || data->readout_ns == 0))) {
		fprintf(stderr, "overload requires a higher rate, finite measured frames followed by recovery, and explicit readout\n");
		exit(2);
	}
	data->overload_period_ns = data->overload_frame_rate == 0 ? data->frame_period_ns :
		UINT64_C(1000000000) / data->overload_frame_rate;
	if (data->readout_ns != 0) {
		uint64_t previous = 0;
		uint32_t block;

		if (data->readout_ns > SPA_MIN(data->frame_period_ns, data->overload_period_ns)) {
			fprintf(stderr, "--readout-us must not exceed the frame period\n");
			exit(2);
		}
		for (block = 1; block <= BLOCKS_PER_FRAME; block++) {
			uint64_t deadline = block == BLOCKS_PER_FRAME ?
				SPA_MIN(data->frame_period_ns, data->overload_period_ns) :
				(uint64_t)block * data->readout_ns / BLOCKS_PER_FRAME;

			if (deadline <= previous) {
				fprintf(stderr, "--readout-us does not yield strictly increasing "
					"block deadlines\n");
				exit(2);
			}
			previous = deadline;
		}
	}
}

/* Cold serialization uses the already preallocated finite measurement history.
 * It never runs on the producer data loop and allocates no per-row history. */
static int write_arrival_journal(struct rtc_client *data)
{
	if (data->arrival_csv_path == NULL)
		return 0;
	FILE *csv = fopen(data->arrival_csv_path, "w");
	if (csv == NULL)
		return 1;
	fprintf(csv, "arrival,sequence,offset,phase,nominal_deadline_ns,source_rejected,state,publication_ns,command_receipt_ns,offered_ns,woofer_ns,tweeter_ns,tiptilt_ns,duplicate_woofer,duplicate_tweeter,duplicate_tiptilt\n");
	for (uint32_t i = 0; i < data->total_blocks; i++) {
		uint32_t frame = i / BLOCKS_PER_FRAME;
		struct arrival_record *record = &data->arrivals[i];
		fprintf(csv, "%u,%u,%u,%s,%" PRIu64 ",%u,%d,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%u,%u,%u\n",
			i, frame + 1, (i % BLOCKS_PER_FRAME) * ROW_BLOCK_ROWS, frame_phase(data, frame),
			record->nominal_deadline_ns, (unsigned)data->frames[frame].source_rejected,
			atomic_load(&record->state), atomic_load(&record->publication_ns),
			atomic_load(&data->frames[frame].command_receipt_ns), record->offered_ns,
			atomic_load(&data->frames[frame].sink_receipt_ns[0]),
			atomic_load(&data->frames[frame].sink_receipt_ns[1]),
			atomic_load(&data->frames[frame].sink_receipt_ns[2]),
            atomic_load(&data->frames[frame].duplicates[0]),
            atomic_load(&data->frames[frame].duplicates[1]),
            atomic_load(&data->frames[frame].duplicates[2]));
	}
	bool failed = ferror(csv);
	int closed = fclose(csv);
	return failed || closed != 0;
}

static int write_results(struct rtc_client *data)
{
	FILE *csv;
	uint32_t frame, block, produced_blocks, missed = 0, coalesced_or_unserved = 0;
	if (write_arrival_journal(data) != 0)
		return 1;
	uint32_t priming_incomplete = 0, priming_without_command = 0;
	uint32_t warmup_incomplete = 0, warmup_without_command = 0;
	uint32_t incomplete = 0, without_command = 0, measured_commands = 0;
	uint32_t priming_commands = 0, warmup_commands = 0;
	uint64_t first, terminal, command, nominal;
	int state;

	for (block = 0; block < data->total_blocks; block++) {
		state = atomic_load_explicit(&data->arrivals[block].state,
				memory_order_acquire);
		if (state == ARRIVAL_PENDING)
			coalesced_or_unserved++;
		else if (state == ARRIVAL_MISSED || state == ARRIVAL_CLAIMED)
			missed++;
	}
	csv = fopen(data->csv_path, "w");
	if (csv == NULL) {
		pw_log_error("could not open raw CSV %s: %s", data->csv_path,
				strerror(errno));
		return 1;
	}
	fprintf(csv, "frame,sequence,nominal_first_block_deadline_ns,"
		"actual_first_publication_ns,terminal_publication_ns,command_receipt_ns,"
		"first_publication_to_command_ns,terminal_publication_to_command_ns,"
		"deadline_to_command_ns\n");
	for (frame = 0; frame < data->total_frames; frame++) {
		produced_blocks = 0;
		for (block = 0; block < BLOCKS_PER_FRAME; block++)
			produced_blocks += atomic_load_explicit(
				&data->arrivals[frame * BLOCKS_PER_FRAME + block].state,
				memory_order_acquire) == ARRIVAL_PUBLISHED;
		command = atomic_load_explicit(&data->frames[frame].command_receipt_ns,
				memory_order_acquire);
		if (frame < PRIMING_FRAMES) {
			priming_commands += command != 0;
			priming_incomplete += produced_blocks < BLOCKS_PER_FRAME;
			priming_without_command +=
				produced_blocks == BLOCKS_PER_FRAME && command == 0;
		} else if (frame < PRIMING_FRAMES + data->warmup_frames) {
			warmup_commands += command != 0;
			warmup_incomplete += produced_blocks < BLOCKS_PER_FRAME;
			warmup_without_command +=
				produced_blocks == BLOCKS_PER_FRAME && command == 0;
		} else {
			incomplete += produced_blocks < BLOCKS_PER_FRAME;
			without_command += produced_blocks == BLOCKS_PER_FRAME && command == 0;
		}
		if (frame < PRIMING_FRAMES + data->warmup_frames || command == 0)
			continue;
		first = atomic_load_explicit(
			&data->arrivals[frame * BLOCKS_PER_FRAME].publication_ns,
			memory_order_acquire);
		terminal = atomic_load_explicit(
			&data->arrivals[(frame + 1u) * BLOCKS_PER_FRAME - 1u].publication_ns,
			memory_order_acquire);
		nominal = data->arrivals[frame * BLOCKS_PER_FRAME].nominal_deadline_ns;
		if (first == 0 || terminal == 0 || command < first || command < terminal ||
		    command < nominal) {
			fclose(csv);
			pw_log_error("completed measured frame has inconsistent timestamps");
			return 1;
		}
		fprintf(csv, "%u,%u,%" PRIu64 ",%" PRIu64 ",%" PRIu64
			",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 "\n",
			frame - PRIMING_FRAMES - data->warmup_frames + 1u,
			frame + 1u, nominal, first,
			terminal, command, command - first, command - terminal,
			command - nominal);
		measured_commands++;
	}
	if (fclose(csv) != 0) {
		pw_log_error("could not close raw CSV: %s", strerror(errno));
		return 1;
	}
	printf("RESULT scheduled_blocks=%u accepted_blocks=%u produced_blocks=%u "
		"completed_graph_triggers=%u request_process_commands=%" PRIu64
		" command_frames=%u priming_command_frames=%u "
		"warmup_command_frames=%u measured_command_frames=%u "
		"missed_arrivals=%u coalesced_or_unserved_arrivals=%u "
		"missed_or_overwritten_arrivals=%u priming_incomplete_frames=%u "
		"priming_complete_frames_without_command=%u "
		"warmup_incomplete_frames=%u "
		"warmup_complete_frames_without_command=%u incomplete_frames=%u "
		"complete_frames_without_command=%u timer_catchup_expirations=%" PRIu64
		" max_timer_expirations_per_callback=%" PRIu64
		" row_publications_after_next_deadline=%" PRIu64
		" max_row_publication_lateness_ns=%" PRIu64
		" zero_command_frames=%u source_admitted_blocks=%u source_rejected_frames=%u "
		"source_pending_rows=%u source_reserved_rows=%u max_source_pending_rows=%u "
		"max_source_reserved_rows=%u source_pending_row_limit=%u "
		"trigger_accepted=%u trigger_busy=%u trigger_failures=%u\n",
		atomic_load_explicit(&data->scheduled, memory_order_relaxed),
		atomic_load_explicit(&data->accepted, memory_order_relaxed),
		atomic_load_explicit(&data->produced, memory_order_relaxed),
		atomic_load_explicit(&data->completed_triggers, memory_order_relaxed),
		atomic_load_explicit(&data->request_process_commands,
			memory_order_relaxed),
		atomic_load_explicit(&data->command_frames, memory_order_relaxed),
		priming_commands, warmup_commands, measured_commands, missed,
		coalesced_or_unserved, missed + coalesced_or_unserved,
		priming_incomplete, priming_without_command, warmup_incomplete,
		warmup_without_command, incomplete, without_command,
		atomic_load_explicit(&data->timer_catchup_expirations,
			memory_order_relaxed),
		atomic_load_explicit(&data->max_timer_expirations_per_callback,
			memory_order_relaxed),
		atomic_load_explicit(&data->row_publications_after_next_deadline,
			memory_order_relaxed),
		atomic_load_explicit(&data->max_row_publication_lateness_ns,
			memory_order_relaxed),
		atomic_load_explicit(&data->zero_command_frames,
			memory_order_relaxed),
		atomic_load(&data->accepted), data->rejected_source_frames, data->pending_rows, data->reserved_rows,
		data->max_pending_rows, data->max_reserved_rows, SOURCE_PENDING_ROWS,
		atomic_load(&data->trigger_accepted), atomic_load(&data->trigger_busy), atomic_load(&data->trigger_failures));
	fflush(stdout);
	printf("SOURCE_DIAGNOSTIC buffers=%u max_buffers=%u maxsize=%u empty_arrival_callbacks=%u dequeue_failures=%u\n",
		atomic_load(&data->source_buffer_count), atomic_load(&data->max_source_buffers),
		atomic_load(&data->source_buffer_maxsize),
		atomic_load(&data->empty_arrival_callbacks), atomic_load(&data->source_dequeue_failures));
	printf("SOURCE_QUEUE source_admitted_blocks=%u rejected_source_frames=%u pending_rows=%u reserved_rows=%u max_pending_rows=%u max_reserved_rows=%u pending_row_limit=%u trigger_accepted=%u trigger_busy=%u trigger_failures=%u\n",
		atomic_load(&data->accepted), data->rejected_source_frames, data->pending_rows, data->reserved_rows,
		data->max_pending_rows, data->max_reserved_rows, SOURCE_PENDING_ROWS, atomic_load(&data->trigger_accepted),
		atomic_load(&data->trigger_busy), atomic_load(&data->trigger_failures));
	for (uint32_t index = 0; getenv("RTC_SOURCE_DIAGNOSTICS") != NULL &&
	     index < data->total_blocks && index < 4096; index++) {
		struct arrival_record *record = &data->arrivals[index];
		printf("ARRIVAL_DIAGNOSTIC arrival=%u result=%d state_after=%d publications=%u final_state=%d dequeue_errno=%d available_at_failure=%u\n", index,
			atomic_load(&record->trigger_result), atomic_load(&record->state_after_trigger),
			atomic_load(&record->publications_in_trigger), atomic_load(&record->state),
			atomic_load(&record->dequeue_errno), atomic_load(&record->available_at_failure));
	}
	printf("NEGOTIATED source_rate=%u/%u command_rate=%u/%u\n",
		data->negotiated_source_rate.num, data->negotiated_source_rate.denom,
		data->negotiated_sink_rate.num, data->negotiated_sink_rate.denom);
	fflush(stdout);
	return 0;
}

static void source_add_buffer(void *userdata, struct pw_buffer *buffer)
{
	struct rtc_client *data = userdata;
	uint32_t count = atomic_fetch_add(&data->source_buffer_count, 1) + 1;
	uint32_t maximum = atomic_load(&data->max_source_buffers);
	while (maximum < count && !atomic_compare_exchange_weak(
			&data->max_source_buffers, &maximum, count))
		;
	if (buffer->buffer->n_datas > 0)
		atomic_store(&data->source_buffer_maxsize, buffer->buffer->datas[0].maxsize);
}

static void source_remove_buffer(void *userdata, struct pw_buffer *buffer SPA_UNUSED)
{
	struct rtc_client *data = userdata;
	atomic_fetch_sub(&data->source_buffer_count, 1);
}

static const struct pw_stream_events source_events = {
	PW_VERSION_STREAM_EVENTS,
	.state_changed = source_state_changed,
	.param_changed = source_param_changed,
	.process = source_process,
	.add_buffer = source_add_buffer,
	.remove_buffer = source_remove_buffer,
	.command = source_command,
	.trigger_done = source_trigger_done,
};

static const struct pw_stream_events sink_events = {
	PW_VERSION_STREAM_EVENTS,
	.state_changed = sink_state_changed,
	.param_changed = sink_param_changed,
	.process = command_process,
};

static int destroy_schedule_timer(struct spa_loop *loop, bool async, uint32_t seq,
		const void *payload, size_t size, void *userdata)
{
	struct rtc_client *data = userdata;

	(void)loop;
	(void)async;
	(void)seq;
	(void)payload;
	(void)size;
	if (data->retry_event != NULL) {
		pw_loop_destroy_source(data->schedule_loop, data->retry_event);
		data->retry_event = NULL;
	}
	if (data->schedule_timer != NULL) {
		pw_loop_destroy_source(data->schedule_loop, data->schedule_timer);
		data->schedule_timer = NULL;
	}
	return 0;
}

static void destroy_streams(struct rtc_client *data)
{
	/* Destroying each stream removes its RT callbacks under the data-loop lock.
	 * Take the result snapshot only after both callback domains are quiescent. */
	if (data->schedule_loop != NULL && (data->schedule_timer != NULL || data->retry_event != NULL))
		(void)pw_loop_locked(data->schedule_loop, destroy_schedule_timer,
				1, NULL, 0, data);
	if (data->source != NULL) {
		pw_stream_destroy(data->source);
		data->source = NULL;
	}
    for (unsigned i = 0; i < SINK_COUNT; i++) {
        if (data->sinks[i].stream != NULL)
            pw_stream_destroy(data->sinks[i].stream);
        data->sinks[i].stream = NULL;
    }
}

int main(int argc, char *argv[])
{
	static const char data_loops[] =
		"[ { loop.name=rtc-source loop.class=data.rt loop.idle=eventfd thread.affinity=[ 8 ] } "
		"{ loop.name=rtc-command loop.class=data.rt loop.idle=eventfd thread.affinity=[ 10 ] } ]";
	static const char data_loops_rt[] =
		"[ { loop.name=rtc-source loop.class=data.rt loop.idle=eventfd loop.rt-prio=15 thread.affinity=[ 8 ] } "
		"{ loop.name=rtc-command loop.class=data.rt loop.idle=eventfd loop.rt-prio=15 thread.affinity=[ 10 ] } ]";
	static const uint32_t source_shape[] = { ROW_BLOCK_ROWS, IMAGE_COLUMNS };
	struct rtc_client data = { 0 };
	struct pw_properties *context_properties, *source_properties, *sink_properties;
	struct spa_pod_builder source_builder, sink_builder;
	struct spa_pod *source_params[3], *sink_params[2];
	uint8_t source_pods[1024], sink_pods[1024];
	uint32_t index;
	int result;

	parse_arguments(&data, argc, argv);
	data.arrivals = calloc(data.total_blocks, sizeof(*data.arrivals));
	data.frames = calloc(data.total_frames, sizeof(*data.frames));
	if (data.arrivals == NULL || data.frames == NULL) {
		fprintf(stderr, "could not allocate RTC measurement records\n");
		free(data.arrivals);
		free(data.frames);
		return 1;
	}
	for (index = 0; index < data.total_blocks; index++) {
		atomic_init(&data.arrivals[index].state, ARRIVAL_EMPTY);
		atomic_init(&data.arrivals[index].publication_ns, 0);
		atomic_init(&data.arrivals[index].trigger_result, INT_MIN);
		atomic_init(&data.arrivals[index].state_after_trigger, ARRIVAL_EMPTY);
		atomic_init(&data.arrivals[index].publications_in_trigger, 0);
		atomic_init(&data.arrivals[index].dequeue_errno, 0);
		atomic_init(&data.arrivals[index].available_at_failure, 0);
	}
	for (index = 0; index < data.total_frames; index++) {
        atomic_init(&data.frames[index].command_receipt_ns, 0);
        atomic_init(&data.frames[index].received, 0);
        for (unsigned i = 0; i < SINK_COUNT; ++i) {
            atomic_init(&data.frames[index].duplicates[i], 0);
            atomic_init(&data.frames[index].sink_receipt_ns[i], 0);
        }
    }
	atomic_init(&data.source_state, PW_STREAM_STATE_UNCONNECTED);
	atomic_init(&data.source_format_verified, false);
	atomic_init(&data.streaming_reported, false);
	atomic_init(&data.ready_reported, false);
	atomic_init(&data.start_requested, false);
	atomic_init(&data.scheduled, 0);
	atomic_init(&data.accepted, 0);
	atomic_init(&data.claim_cursor, 0);
	atomic_init(&data.source_buffer_count, 0);
	atomic_init(&data.max_source_buffers, 0);
	atomic_init(&data.source_buffer_maxsize, 0);
    for (unsigned i = 0; i < SINK_COUNT; i++) {
        data.sinks[i].data = &data;
        data.sinks[i].index = i;
        atomic_init(&data.sinks[i].state, PW_STREAM_STATE_UNCONNECTED);
        atomic_init(&data.sinks[i].format_verified, false);
    }
    const char *capture_prefix = getenv("GPI2_CAPTURE_PREFIX");
    if (capture_prefix != NULL) {
        for (unsigned i = 0; i < SINK_COUNT; ++i) {
            captured[i] = calloc((size_t)data.total_frames * sink_elements[i], sizeof(float));
            if (captured[i] == NULL)
                return 2;
        }
    }
    data.negotiated_sink_rate = SPA_FRACTION(data.frame_rate, 1);
    const char *corpus = getenv("GPI2_REPLAY_CORPUS");
    FILE *frames = corpus ? fopen(corpus, "rb") : NULL;
    if (!frames || fseek(frames, 0, SEEK_END) != 0)
        return 2;
    long size = ftell(frames);
    if (size <= 0 || (size_t)size % (ROW_BLOCK_ELEMENTS * sizeof(uint16_t)) != 0)
        return 2;
    data.input_count = (size_t)size / (ROW_BLOCK_ELEMENTS * sizeof(uint16_t));
    data.input_frames = malloc((size_t)size);
    rewind(frames);
    if (!data.input_frames || fread(data.input_frames, 1, (size_t)size, frames) != (size_t)size)
        return 2;
    fclose(frames);
    atomic_init(&data.empty_arrival_callbacks, 0);
	atomic_init(&data.source_dequeue_failures, 0);
	atomic_init(&data.produced, 0);
	atomic_init(&data.trigger_accepted, 0);
	atomic_init(&data.trigger_busy, 0);
	atomic_init(&data.trigger_failures, 0);
	atomic_init(&data.completed_triggers, 0);
	atomic_init(&data.request_process_commands, 0);
	atomic_init(&data.command_frames, 0);
	atomic_init(&data.zero_command_frames, 0);
	atomic_init(&data.timer_catchup_expirations, 0);
	atomic_init(&data.max_timer_expirations_per_callback, 0);
	atomic_init(&data.row_publications_after_next_deadline, 0);
	atomic_init(&data.max_row_publication_lateness_ns, 0);
	atomic_init(&data.result, 0);
	atomic_init(&data.failure_message, (uintptr_t)NULL);

	pw_init(&argc, &argv);
	data.loop = pw_main_loop_new(NULL);
	if (data.loop == NULL) {
		pw_log_error("could not create RTC main loop: %s", strerror(errno));
		atomic_store(&data.result, 1);
		goto done;
	}
	context_properties = pw_properties_new(PW_KEY_CONFIG_NAME, "replay.conf", "context.data-loops",
            getenv("GPI2_FIFO") ? data_loops_rt : data_loops, NULL);
	data.context = pw_context_new(pw_main_loop_get_loop(data.loop),
			context_properties, 0);
	if (data.context == NULL) {
		pw_log_error("could not create RTC context: %s", strerror(errno));
		atomic_store(&data.result, 1);
		goto done;
	}
	data.core = pw_context_connect(data.context, NULL, 0);
	if (data.core == NULL) {
		pw_log_error("could not connect RTC core: %s", strerror(errno));
		atomic_store(&data.result, 1);
		goto done;
	}
	source_properties = pw_properties_new(PW_KEY_NODE_NAME, "rtc-row-source",
			PW_KEY_NODE_RELIABLE, "false",
			PW_KEY_NODE_LOOP_NAME, "rtc-source", PW_KEY_MEDIA_TYPE,
			"Application", PW_KEY_MEDIA_CATEGORY, "Playback",
			PW_KEY_MEDIA_ROLE, "Test", NULL);
    data.source = pw_stream_new(data.core, "detector", source_properties);
    if (data.source == NULL) {
        atomic_store(&data.result, 1);
        goto done;
    }
    pw_stream_add_listener(data.source, &data.source_listener, &source_events, &data);

	spa_pod_builder_init(&source_builder, source_pods, sizeof(source_pods));
	source_params[0] = build_format(&source_builder, SPA_ELEMENT_TYPE_U16_LE,
			source_shape, SPA_N_ELEMENTS(source_shape),
			data.frame_rate * BLOCKS_PER_FRAME,
			"org.heart.std-wfs.raw-pixels/1");
	source_params[1] = build_header_meta(&source_builder);
	source_params[2] = build_row_buffers(&source_builder);
    if (source_params[0] == NULL || source_params[1] == NULL || source_params[2] == NULL) {
        atomic_store(&data.result, 1);
        goto done;
    }

	result = connect_stream(data.source, PW_DIRECTION_OUTPUT,
			(const struct spa_pod **)source_params,
			SPA_N_ELEMENTS(source_params), true);
	if (result < 0) {
		pw_log_error("could not connect RTC source: %s", spa_strerror(result));
		atomic_store(&data.result, 1);
		goto done;
	}
	data.schedule_loop = pw_stream_get_data_loop(data.source);
	if (data.schedule_loop == NULL || pw_loop_locked(data.schedule_loop,
			create_source_retry, 1, NULL, 0, &data) < 0) {
		atomic_store(&data.result, 1);
		goto done;
	}
    for (unsigned i = 0; i < SINK_COUNT; i++) {
        struct command_sink *sink = &data.sinks[i];
        sink_properties = pw_properties_new(PW_KEY_NODE_NAME, sink_names[i],
            PW_KEY_NODE_LOOP_NAME, "rtc-command", PW_KEY_MEDIA_TYPE, "Application",
            PW_KEY_MEDIA_CATEGORY, "Capture", NULL);
        sink->stream = pw_stream_new(data.core, sink_names[i], sink_properties);
        if (!sink->stream) {
            atomic_store(&data.result, 1);
            goto done;
        }
        pw_stream_add_listener(sink->stream, &sink->listener, &sink_events, sink);
        spa_pod_builder_init(&sink_builder, sink_pods, sizeof(sink_pods));
        sink_params[0] = build_format(&sink_builder, SPA_ELEMENT_TYPE_F32_LE, &sink_elements[i], 1,
            data.frame_rate, sink_schemas[i]);
        sink_params[1] = build_header_meta(&sink_builder);
        if (!sink_params[0] || !sink_params[1] ||
            connect_stream(sink->stream, PW_DIRECTION_INPUT,
                (const struct spa_pod **)sink_params, SPA_N_ELEMENTS(sink_params), false) < 0) {
            atomic_store(&data.result, 1);
            goto done;
        }
    }

	data.finish_timer = pw_loop_add_timer(pw_main_loop_get_loop(data.loop),
			check_finish, &data);
	if (data.finish_timer == NULL) {
		pw_log_error("could not create RTC timers: %s", strerror(errno));
		atomic_store(&data.result, 1);
		goto done;
	}
	data.control = pw_loop_add_io(pw_main_loop_get_loop(data.loop), STDIN_FILENO,
			SPA_IO_IN | SPA_IO_HUP | SPA_IO_ERR, false, start_control, &data);
	if (data.control == NULL) {
		pw_log_error("could not create RTC start control: %s", strerror(errno));
		atomic_store(&data.result, 1);
		goto done;
	}
	pw_loop_add_signal(pw_main_loop_get_loop(data.loop), SIGINT, interrupted, &data);
	pw_loop_add_signal(pw_main_loop_get_loop(data.loop), SIGTERM, interrupted, &data);
	printf("CONNECT_ACCEPTED\n");
	fflush(stdout);
	pw_main_loop_run(data.loop);
	destroy_streams(&data);
	if (atomic_load_explicit(&data.result, memory_order_relaxed) == 0)
		atomic_store(&data.result, write_results(&data));
	else {
		(void)write_arrival_journal(&data);
		const char *message = (const char *)atomic_load_explicit(
			&data.failure_message, memory_order_acquire);
		fprintf(stderr, "RTC benchmark failed: %s\n",
			message == NULL ? "unknown failure" : message);
	}

done:
	destroy_streams(&data);
    if (capture_prefix != NULL) {
        for (unsigned i = 0; i < SINK_COUNT; ++i) {
            char path[4096];
            snprintf(path, sizeof(path), "%s-%s.f32", capture_prefix, sink_names[i]);
            FILE *output = fopen(path, "wb");
            size_t count = (size_t)data.total_frames * sink_elements[i];
            if (output == NULL || fwrite(captured[i], sizeof(float), count, output) != count)
                return 2;
            fclose(output);
            free(captured[i]);
        }
    }

	if (data.core != NULL)
		pw_core_disconnect(data.core);
	if (data.context != NULL)
		pw_context_destroy(data.context);
	if (data.loop != NULL)
		pw_main_loop_destroy(data.loop);
	pw_deinit();
	free(data.arrivals);
	free(data.frames);
	free(data.input_frames);
	return atomic_load_explicit(&data.result, memory_order_relaxed);
}
