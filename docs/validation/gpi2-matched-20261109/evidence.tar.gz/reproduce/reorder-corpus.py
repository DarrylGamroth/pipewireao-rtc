import sys
import numpy as np

source, destination = sys.argv[1:]
column_major = np.memmap(source, mode="r", dtype="<u2").reshape(-1, 240, 242)
assert len(column_major) == 1062
rows = column_major.transpose(0, 2, 1)
rows.tofile(destination)
replay = np.memmap(destination, mode="r", dtype="<u2").reshape(-1, 242, 240)
assert np.array_equal(rows, replay)
