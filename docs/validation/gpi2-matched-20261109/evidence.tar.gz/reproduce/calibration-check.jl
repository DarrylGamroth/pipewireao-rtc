using LinearAlgebra, Statistics
include(ARGS[1])
const F = GPI2Fixture
function check_calibration()
fixture = F.load_fixture()
graph = fixture.document["filter.graph"]
pyramid = only(filter(n -> n["name"] == "pyramid", graph["nodes"]))["config"]
@show pyramid["pupil_size"] pyramid["pupil_origins"]
origins = pyramid["pupil_origins"]
rows, cols = pyramid["pupil_size"]
mask = fixture.params[Symbol("pupil-mask")]
@show size(mask) count(mask) size(fixture.params[:reconstructor])
@assert size(mask) == (rows, cols)
pixels = [CartesianIndex(r, c) for r in 1:rows for c in 1:cols]
all_pixels = vcat(([pixel + CartesianIndex(origin...) for pixel in pixels] for origin in origins)...)
selected = vcat(([pixel + CartesianIndex(origin...) for pixel in pixels if mask[pixel]] for origin in origins)...)
selected_mask = falses(size(fixture.params[:flat]))
selected_mask[selected] .= true
flat = fixture.params[:flat]
background = fixture.params[:background]
masked_flat = flat .* selected_mask
@assert length(Set(all_pixels)) == length(all_pixels)
@assert length(Set(selected)) == length(selected)
@assert all(masked_flat[selected] .== flat[selected])
@assert all(iszero, masked_flat[.!selected_mask])
ratio = Float32(length(selected) / length(all_pixels))
R = fixture.params[:reconstructor]
@assert size(R,2) == length(selected)
R_heart = R .* ratio
@show size(R) extrema(flat) extrema(background) ratio
@show extrema(fixture.params[Symbol("modal-filter-coefficients")])
@show fixture.params[Symbol("tiptilt-filter-coefficients")]
observed = Float64[]
maximum_residual_delta = 0.0f0
max_residual = 0.0f0
prev_selected, prev_full, prev_masked = 1.0f0, 1.0f0, 1.0f0
for n in axes(fixture.frames, 3)
    raw = @view fixture.frames[:, :, n]
    calibrated = flat .* (Float32.(raw) .- background)
    masked = masked_flat .* (Float32.(raw) .- background)
    if n > 1
        unmasked_ratio = prev_selected / prev_full
        push!(observed, unmasked_ratio)
        reference = R * (calibrated[selected] ./ prev_selected)
        translated = R_heart * (masked[selected] ./ prev_masked)
        maximum_residual_delta = max(maximum_residual_delta, maximum(abs, reference - translated))
        max_residual = max(max_residual, maximum(abs, reference))
    end
    prev_selected = Float32(sum(Float64, calibrated[selected]) / length(selected))
    prev_full = Float32(sum(Float64, calibrated[all_pixels]) / length(all_pixels))
    prev_masked = Float32(sum(Float64, masked[all_pixels]) / length(all_pixels))
    @assert min(prev_selected, prev_full, prev_masked) > 0
end
@show length(observed) extrema(observed) median(observed) maximum_residual_delta max_residual
@assert maximum_residual_delta <= 1.0f-5 * max_residual

end
check_calibration()
