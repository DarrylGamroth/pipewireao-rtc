using CUDA, FilterGraphs, FilterGraphAlgorithms, FilterGraphPipeWire, PipeWireAO
include("fixture.jl")
const F = FilterGraphPipeWire
const G = FilterGraphs
const S = GPI2Fixture
CUDA.allowscalar(false)
CUDA.functional(true) || error("CUDA unavailable")
mode, remote, quit_request, raw = ARGS
println("PREPARING backend=$mode device=$(CUDA.name(CUDA.device()))")
flush(stdout)

fixture = S.load_fixture()
checked = S.cpu_graph(fixture; profile=:commands)
commands = (:woofer, :tweeter, :tiptilt)
captured = G.prepare_captured_graph(checked, CUDA.device();
    feedback=(var"constraint-feedback"=S.OUTFB,), outputs=commands)
@assert keys(G.input_formats(captured)) == (:raw,)
@assert keys(G.output_formats(captured)) == commands
cpu = S.Case("CPU", checked, S.arrays(G.input_formats(checked)), S.arrays(G.output_formats(checked)), false)
gpu = S.Case("CUDA", captured, S.arrays(G.input_formats(captured)), S.arrays(G.output_formats(captured)), true)
function check_commands(cpu, gpu, frames, outputs)
    maxima = zeros(length(outputs))
    for i in 1:400
        S.step!(cpu, frames, i, i)
        S.step!(gpu, frames, i, i)
        for (j, name) in enumerate(outputs)
            delta = maximum(abs, getproperty(cpu.outputs,name) .- getproperty(gpu.outputs,name))
            delta <= 1e-9 || error("CUDA command differs on frame $i, $name: $delta")
            maxima[j] = max(maxima[j], delta)
        end
    end
    return maxima
end
println("ORACLE max_abs_difference_m=", check_commands(cpu, gpu, fixture.frames, commands))
G.reset!(captured)
println("PREPARED ", G.input_formats(captured), ' ', G.output_formats(captured))
flush(stdout)

if mode == "trace"
    ENV["JULIA_FGPW_CALLBACK_METRICS_CAPACITY"] = "65536"
    ENV["JULIA_FGPW_CALLBACK_METRICS_LIBRARY"] = joinpath(@__DIR__, "libgpi2_metrics.so")
    ENV["JULIA_FGPW_CALLBACK_METRICS_PATH"] = joinpath(raw, "callbacks.csv")
    ENV["GPI2_GC_MAP"] = joinpath(raw, "gc.bin")
    F.enable_callback_metrics!()
    const METRICS = F._callback_metrics_from_environment(1)
    # Install the existing per-owner probe at the generic measured body.
    F._graph_callback_metrics(::F.PreparedCapturedGraphOwner) = METRICS
end

node = F.PipeWireNode(captured; name="gpi2-captured", remote, rate=2000//1, connect=false)
try
    F.connect!(node)
    println("CONNECTED")
    flush(stdout)
    finished = Threads.Atomic{Bool}(false)
    monitor = F.monitor_quit_request(node, quit_request, finished)
    try
        F.run!(node)
    finally
        finished[] = true
        wait(monitor)
    end
finally
    close(node)
    if mode == "trace"
        F._write_callback_metrics(METRICS)
    end
    F.close_execution(captured)
end
