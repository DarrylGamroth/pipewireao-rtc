using FITSIO, LinearAlgebra, YAML
include(ARGS[1])
const S = GPI2Fixture

function write_matrix(directory, name, matrix)
    FITS(joinpath(directory, name * ".fits"), "w") do f
        write(f, permutedims(matrix))
    end
end

function write_sparse(directory, name, matrix)
    open(joinpath(directory, name * ".sparse"), "w") do io
        rows, columns = size(matrix)
        println(io, "Sparse: rows=$rows cols=$columns nnz=$(count(!iszero, matrix)) name=$name")
        for row in 1:rows, col in 1:columns
            value = matrix[row, col]
            iszero(value) || println(io, row-1, ' ', col-1, ' ', value)
        end
    end
end

function prepare(directory)
    fixture = S.load_fixture()
    params = fixture.params
    param(name) = params[Symbol(name)]
    graph = fixture.document["filter.graph"]
    node(name) = only(filter(n -> n["name"] == name, graph["nodes"]))
    pyramid = node("pyramid")["config"]
    origins = pyramid["pupil_origins"]
    rows, columns = pyramid["pupil_size"]
    mask = param("pupil-mask")
    write_matrix(directory, "bias", params[:background])
    write_matrix(directory, "flat", params[:flat])
    open(joinpath(directory, "pupil-mask.csv"), "w") do io
        println(io, rows*columns, " 1 1 uint")
        for row in axes(mask, 1), column in axes(mask, 2)
            println(io, Int(mask[row, column]))
        end
    end
    open(joinpath(directory, "pupil-origins.csv"), "w") do io
        println(io, "4 2 1 uint")
        for origin in origins
            println(io, join(origin, ","))
        end
    end
    microns_per_metre = 1.0f6
    R = params[:reconstructor]
    @assert size(R,2) == 4count(mask)
    write_matrix(directory, "reconstructor", R .* microns_per_metre)
    modes = size(R, 1)
    modal = param("modal-filter-coefficients")
    @assert all(modal[:, 1, i] == Float32[1, 0, 0, 0, 0] for i in 1:modes)
    write_matrix(directory, "reference", reshape(microns_per_metre .* param("modal-reference"), 1, :))
    @assert all(iszero, param("tiptilt-offset"))
    T = param("controller-to-tiptilt")
    # With a mapped woofer, HEART does not use the stage-to-VDM map.
    write_sparse(directory, "vdm-to-tt", T)
    write_sparse(directory, "tt-to-vdm", Matrix{Float32}(I, modes, 2))
    write_matrix(directory, "tt-to-pdm", param("tiptilt-to-woofer"))
    tip = param("tiptilt-filter-coefficients")
    @assert tip[:,:,1] == tip[:,:,2] && all(iszero, tip[[3,5],1,1])
    open(joinpath(directory, "tiptilt-filter.csv"), "w") do io
        println(io, "1 3 1 float")
        println(io, join(tip[[1,2,4],1,1], ","))
    end
    for mirror in ("woofer", "tweeter")
        selection = param(mirror * "-selection")
        forward = param(mirror * "-vdm-to-pdm")
        reverse = param(mirror * "-pdm-to-vdm")
        feedback = param(mirror * "-vdm-to-controller")
        # The VDM/PDM tables carry the complete linear maps for both mirrors.
        completion = param(mirror * "-active-to-full")
        truncation = param(mirror * "-full-to-active")
        write_matrix(directory, mirror * "-forward", forward * completion * selection)
        write_matrix(directory, mirror * "-feedback", feedback * truncation * reverse)
        base = param(mirror * "-system-flat")
        shape = S.FGA.VdmShapeOffsetPlan(completion, reverse, param(mirror * "-shape-offset"))
        offset = param(mirror * "-offset") + forward * completion * shape.active_offset
        write_matrix(directory, mirror * "-flat", reshape(microns_per_metre .* base, 1, :))
        write_matrix(directory, mirror * "-offset", reshape(microns_per_metre .* offset, 1, :))
        limits = node(mirror * "-command")["config"]["command_limits"]
        @assert isnothing(node(mirror * "-command")["config"]["slew_limit"])
        clip = repeat(reshape(Float32.(reverse!(copy(limits))) .* microns_per_metre, :, 1), 1, length(base))
        write_matrix(directory, mirror * "-limits", clip)
        @show mirror size(selection) size(forward) size(feedback) size(reverse) limits
    end
    @show modes size(T) rank(T) size(R) count(mask)
    checked = S.cpu_graph(fixture; profile=:commands)
    case = S.Case("CPU", checked, S.arrays(S.FG.input_formats(checked)),
                  S.arrays(S.FG.output_formats(checked)), false)
    # Retain an exact independent reference for the low-rate wire parity gate.
    frames = min(400, size(fixture.frames, 3))
    for output in (:woofer, :tweeter, :tiptilt)
        open(joinpath(directory, string(output) * "-oracle.f32"), "w") do io
            S.reset_case!(case)
            for i in 1:frames
                S.step!(case, fixture.frames, i, i)
                write(io, getproperty(case.outputs, output))
            end
        end
    end
end

prepare(ARGS[2])
