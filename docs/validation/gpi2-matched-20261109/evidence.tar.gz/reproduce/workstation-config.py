import re
from pathlib import Path
import sys

root = Path(sys.argv[1])
source = (root / "workstation-single.yaml").read_text()
for key in ("TELEMETRY_FILE_STREAMS", "TELEMETRY_SOCKET_STREAMS"):
    source = re.sub(rf"(?ms)^    {key}: \[.*?^    \]", f"    {key}: []", source)

def patch(key, entries):
    global source
    pat = rf"(?ms)^    {key}: \[.*?^    \]"
    source, n = re.subn(pat, "    " + key + ": [\n" + ",\n".join("        " + e for e in entries) + "\n    ]", source)
    assert n == 1, key

def file_entry(index, i, file):
    return '{' + f'{index}: {i}, FILE: "matched-assets/{file}"' + '}'

def files(key, index, *paths):
    patch(key, [file_entry(index, i, file) for i, file in enumerate(paths)])

source = source.replace("1810", "1509").replace("NUM: 2825", "NUM: 2776").replace("ROWS: 62, COLS: 62", "ROWS: 60, COLS: 60")
files("PWFS_QUAD_LOCATION_FILE", "WFS_NUM", "pupil-origins.csv")
files("PWFS_QUAD_PIXEL_MASK_FILE", "WFS_NUM", "pupil-mask.csv")
files("HO_CONTROL_MATRIX_FILE", "WFS_NUM", "reconstructor.fits")
key = "    HO_CONTROL_MATRIX_FILE:"
source = source.replace(key, f'    BIAS_FILE: [{file_entry("WFS_NUM", 0, "bias.fits")}]\n'
                             f'    FLAT_FILE: [{file_entry("WFS_NUM", 0, "flat.fits")}]\n' + key)
files("PDM_SYS_FLAT_FILE", "PDM_NUM", "woofer-flat.fits", "tweeter-flat.fits")
files("PDM_CLIPPINGS_FILE", "PDM_NUM", "woofer-limits.fits", "tweeter-limits.fits")
source = source.replace("    PDM_CLIPPINGS_FILE:", "    PDM_OFFSETS_FILE: ["
                        + file_entry("PDM_NUM", 0, "woofer-offset.fits") + ", "
                        + file_entry("PDM_NUM", 1, "tweeter-offset.fits") + "]\n"
                        + "    PDM_CLIPPINGS_FILE:")
patch("PDM_SLEW_RATE_LIMIT", [f'{{ PDM_NUM: {i}, EXISTS: 0, LIMIT_FILE: "", INITIAL_SHAPE_FILE: "" }}' for i in range(2)])
patch("PDM_MODE_SELECT", [f'{{ PDM_NUM: {i}, NUM_MODES: 0, FILE: "" }}' for i in range(2)])
files("VDM_TO_PDM_FILE", "PDM_NUM", "woofer-forward.fits", "tweeter-forward.fits")
files("PDM_TO_VDM_FILE", "PDM_NUM", "woofer-feedback.fits", "tweeter-feedback.fits")
files("VDM_TO_TT_FILE", "TT_NUM", "vdm-to-tt.sparse")
files("TT_TO_VDM_FILE", "TT_NUM", "tt-to-vdm.sparse")
files("TT_TO_PDM_FILE", "TT_NUM", "tt-to-pdm.fits")
patch("TT_TEMPORAL_FILTER", ['{ TT_NUM: 0, EXISTS: 1, ORDER: 1, COEFF_FILE: "matched-assets/tiptilt-filter.csv", GAIN: 1.0 }'])
patch("TFC_INIT_GAIN_FILTER", ["{ HO: -0.3, LO: -0.3 }"])
source = source.replace('TFC_HO_NCPA_REF_VEC_FILEPATH : ""', 'TFC_HO_NCPA_REF_VEC_FILEPATH : "matched-assets/reference.fits"')
source = source.replace("TFC_SPLIT_TO_HO_LO: 1", "TFC_SPLIT_TO_HO_LO: 0")
(root / "workstation-calibrated.yaml").write_text(source)
