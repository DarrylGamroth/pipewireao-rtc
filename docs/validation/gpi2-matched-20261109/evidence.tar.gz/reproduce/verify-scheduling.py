from pathlib import Path
import sys

path, profile = Path(sys.argv[1]), sys.argv[2]
assignments = {"rtc-source": "8", "rtc-command": "10"}
if profile == "cuda":
    assignments["julia-data-loop"] = "4"
elif profile == "heart":
    assignments.update({"heart-udp": "12", "HOP0.wfs.w": "6", "HOP0.proc.w": "4",
                        "HOP0.recon.w": "2", "WCC.tfc.w": "14", "WCC.clwc.w": "14",
                        "WCC.clwc.pdm0": "14", "WCC.clwc.pdm1": "14",
                        "WCC.dm0.w": "14", "WCC.dm1.w": "14", "WCC.tt0.w": "14"})
else:
    raise ValueError(profile)
snapshot = [line.split() for line in path.read_text().splitlines()]
cpus = {line[0]: line[2] for line in snapshot if len(line) == 3 and line[1] == "Cpus_allowed_list:"}
for name, cpu in assignments.items():
    matches = [line for line in snapshot if len(line) == 6 and line[-1] == name]
    assert len(matches) == 1, (name, matches)
    _, tid, _, policy, priority, _ = matches[0]
    assert (policy, priority, cpus[tid]) == ("FF", "15", cpu), matches[0]
    print(name, "FIFO 15", "CPU", cpu)
