import os
from pathlib import Path
import subprocess as sp
import sys
import socket
import tempfile
import time

root, previous = map(Path, sys.argv[1:3])
case, rate, samples, warmup = sys.argv[3:]
raw = root / case
raw.mkdir()
native = Path(os.environ["PIPEWIREAO_PREFIX"])
plugin = os.environ["HEART_SPA_DIRECTORY"]
env = os.environ | {
    "PIPEWIREAO_CONFIG_DIR": str(root),
    "PIPEWIREAO_MODULE_DIR": str(native / "lib/pipewire-ao-0.3"),
    "PIPEWIREAO_SPA_PLUGIN_DIR": plugin + ":" + str(native / "lib/spa-ao-0.2"),
    "PIPEWIREAO_REMOTE": "pipewire-ao-0",
    "PIPEWIREAO_DEBUG": "2",
}
heart_bin = root / "heart-gpi2/source/template/bin"
sp.run(["mount", "-t", "tmpfs", "tmpfs", "/dev/shm"], check=True)
sp.run(["ip", "link", "set", "lo", "up"], check=True)
processes = []
def start(label, command, additions=None, stdin=None):
    with (raw / (label + ".log")).open("wb") as log:
        proc = sp.Popen(command, cwd=root, env=env | (additions or {}),
                        stdout=log, stderr=sp.STDOUT, stdin=stdin)
    processes.append((label, proc))
    return proc

def wait(predicate, process, seconds):
    deadline = time.monotonic() + seconds
    while not predicate():
        if process.poll() is not None:
            raise RuntimeError(f"early exit {process.args}: {process.returncode}")
        if time.monotonic() > deadline:
            raise TimeoutError(process.args)
        time.sleep(0.03)

def in_log(label, message):
    return message in (raw / (label + ".log")).read_text(errors="replace")

def listening():
    try:
        with socket.create_connection(("127.0.0.1", 5001), timeout=0.1):
            return True
    except OSError:
        return False

def control(command, check=True):
    result = sp.run([heart_bin / "gpiTemplateCmdClient", "-cmdName", command],
                    stdout=sp.PIPE, stderr=sp.STDOUT, timeout=8)
    (raw / (command + ".log")).write_bytes(result.stdout)
    if check and (result.returncode or b"status<0><SUCCESS>" not in result.stdout):
        raise RuntimeError(command)

config = root / ("core-" + case + ".conf")
config.write_text((root / "core-heart.in").read_text().replace("RATE", rate))
with tempfile.TemporaryDirectory(prefix="gm-", dir=env["XDG_RUNTIME_DIR"]) as runtime:
    env.update(XDG_RUNTIME_DIR=runtime, PIPEWIREAO_RUNTIME_DIR=runtime)
    remote = Path(runtime) / env["PIPEWIREAO_REMOTE"]
    def tool(name, *args):
        result = sp.run([native / "bin" / name, "-r", remote, *args], env=env,
                        capture_output=True, text=True, timeout=8)
        if result.returncode:
            raise RuntimeError((name, args, result.stderr))
        return result.stdout
    heart = None
    try:
        core = start("core", ["taskset", "-c", "2,12", native / "bin/pipewire-ao",
                              "-c", config.name])
        wait(remote.is_socket, core, 8)
        heart = start("heart", ["taskset", "-c", "0,2,4,6,14", heart_bin / "gpiTemplate",
                      "-nohuge", "-shm", "-host", "gpi2-workstation",
                      "-config", env.get("HEART_CONFIG", "workstation-single.yaml"), "-telFileRootPath", raw],
                      {"LD_PRELOAD": str(previous / "heart-busy-poll.so"),
                       "HRT_CPU_MACHINE_FILE": str(root / "workstation.cpu"),
                       "HRT_THREAD_MAP_FILE": str(root / "workstation.threads"),
                       "HRT_THREAD_PRIORITY_MAX": "15"})
        wait(listening, heart, 15)
        time.sleep(0.5)
        for command in ("INIT", "RUN", "CORRECT"):
            control(command)
        replay = start("replay", ["taskset", "-c", "8,10", root / "replay-heart",
                       "--frame-rate", rate, "--sample-frames", samples, "--warmup-frames",
                       warmup, "--csv", raw / "completed.csv", "--arrival-csv",
                       raw / "arrivals.csv"], {"GPI2_FIFO": "1",
                       "GPI2_REPLAY_CORPUS": str(root / "frames-row-major.u16")} |
                       ({"GPI2_CAPTURE_PREFIX": str(raw / "commands")} if os.getenv("HEART_CAPTURE") else {}), sp.PIPE)
        wait(lambda: in_log("replay", "CONNECT_ACCEPTED"), replay, 15)
        def find_ports(flag, names):
            ports = tool("pwao-link", flag).splitlines()
            return [next((p for p in ports if p.startswith(n + ":")), "") for n in names]
        out_names = ["rtc-row-source", "heart-woofer", "heart-tweeter", "heart-tiptilt"]
        in_names = ["heart-wfs", "gpi2-woofer", "gpi2-tweeter", "gpi2-tiptilt"]
        for _ in range(80):
            outputs, inputs = find_ports("-o", out_names), find_ports("-i", in_names)
            if all(outputs + inputs):
                break
            time.sleep(0.05)
        else:
            raise RuntimeError((outputs, inputs))
        (raw / "ports.txt").write_text("\n".join(outputs + inputs) + "\n")
        for output, input_port in zip(outputs, inputs):
            tool("pwao-link", "-w", output, input_port)
        wait(lambda: in_log("replay", "READY"), replay, 10)
        for task in Path(f"/proc/{heart.pid}/task").iterdir():
            name = (task / "comm").read_text().strip()
            if name.endswith(".w") or name.startswith(("HOP0.MVM", "WCC.clwc.pdm")):
                sp.run(["chrt", "-f", "-p", "15", task.name], check=True)
        with (raw / "threads.txt").open("w") as f:
            for label, process in processes:
                print(label, file=f, flush=True)
                sp.run(["ps", "-L", "-p", str(process.pid), "-o", "pid,tid,psr,cls,rtprio,comm"],
                       stdout=f, check=True)
                for task in Path(f"/proc/{process.pid}/task").iterdir():
                    status = (task / "status").read_text().splitlines()
                    print(task.name, next(x for x in status if x.startswith("Cpus_allowed_list:")), file=f)
        replay.stdin.write(b"s")
        replay.stdin.flush()
        if replay.wait(int(samples)//int(rate) + 20):
            raise RuntimeError("replay failed")
        (raw / "udp.txt").write_text(Path("/proc/net/snmp").read_text())
        (raw / "registry.json").write_text(tool("pwao-dump"))
        control("SHUTDOWN")
        heart.wait(12)
    finally:
        if heart is not None and heart.poll() is None:
            try:
                control("SHUTDOWN", check=False)
            except sp.TimeoutExpired:
                pass
        for label, proc in reversed(processes):
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(5)
                except sp.TimeoutExpired:
                    proc.kill()
                    proc.wait()
        (raw / "exits.txt").write_text("".join(f"{label} {proc.returncode}\n"
                                    for label, proc in processes))
