set -eu
p=$(cat /tmp/gpi2-connected-root)
q=$(cat /tmp/gpi2-matched-root)
. "$p/env.sh"
export HEART_SPA_DIRECTORY=$(dirname "$(dirname "$(find /tmp/heart-timing-release-stage -name libspa-heart.so -print -quit)")")
exec timeout 90s unshare -Urnim --fork --kill-child -- python3 "$q/heart-campaign.py" "$q" "$p" "$@"
