import csv
import json
from pathlib import Path
import sys

import numpy as np

record, oracle = map(Path, sys.argv[1:3])
with (record / "arrivals.csv").open() as f:
    rows = list(csv.DictReader(f))
assert [int(row["sequence"]) for row in rows] == list(range(1, len(rows) + 1))
assert all(int(row["command_receipt_ns"]) for row in rows)
assert all(int(row.get("duplicate_" + port, 0)) == 0 for row in rows for port in ("woofer", "tweeter", "tiptilt"))
result = {}
for name, count, limit in (("woofer", 97, 3.4e-6), ("tweeter", 2304, 1e-6), ("tiptilt", 2, 1e-6)):
    actual = np.fromfile(record / f"commands-gpi2-{name}.f32", "<f4").reshape(-1, count)
    expected = np.fromfile(oracle / f"{name}-oracle.f32", "<f4").reshape(-1, count)[:len(actual)]
    assert len(actual) == len(rows) and actual.shape == expected.shape
    delta = actual.astype(np.float64) - expected
    max_abs = np.max(np.abs(delta))
    assert np.isfinite(delta).all() and max_abs <= 1e-9
    result[name] = {
        "command_vectors": len(actual),
        "actuators": count,
        "absolute_difference_max_m": float(max_abs),
        "rms_difference_m": float(np.sqrt(np.mean(delta ** 2))),
        "reference_frames_at_limit": int(np.count_nonzero(np.any(np.abs(expected) >= np.float32(limit), axis=1))),
        "heart_frames_at_limit": int(np.count_nonzero(np.any(np.abs(actual) >= np.float32(limit), axis=1))),
    }
print(json.dumps(result, indent=2))
