set -eu
p=$(cat /tmp/gpi2-connected-root)
q=$(cat /tmp/gpi2-matched-root)
. "$p/env.sh"
base="$HOME/workspaces/codex"
export GPI2_APPLICATION="$base/adaptive-optics-simulations/gpi2"
export GPI2_INPUTS="$base/pipewire/JuliaFilterGraph.jl/benchmark/results/gpi2-scaling-20261104/fp16-graph-frames"
export GPI2_REPLAY_CORPUS="$GPI2_INPUTS/raw_frames_U16.bin" CUDA_VISIBLE_DEVICES=0
exec taskset -c 0,2,4,6,8,10,12 python3 "$q/cuda/tools/campaign.py" "$@"
