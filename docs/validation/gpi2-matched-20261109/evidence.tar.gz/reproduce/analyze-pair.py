import csv
import json
import math
from pathlib import Path
import sys

path = Path(sys.argv[1])
rate, warmup, measured = map(int, sys.argv[2:])
period = 1_000_000_000 // rate
ports = ("woofer", "tweeter", "tiptilt")
with (path / "arrivals.csv").open() as f:
    rows = []
    for row in csv.DictReader(f):
        rows.append({k: v if k == "phase" else int(v) for k, v in row.items()})
assert [r["sequence"] for r in rows] == list(range(1, 2 + warmup + measured))
assert [r["phase"] for r in rows] == ["priming"] + ["warmup"] * warmup + ["measured"] * measured
assert rows[0]["nominal_deadline_ns"] > 0
assert all(b["nominal_deadline_ns"] - a["nominal_deadline_ns"] == period
           for a, b in zip(rows, rows[1:]))
assert all(0 < r["nominal_deadline_ns"] <= r["offered_ns"] for r in rows)
def quantiles(values):
    ordered = sorted(values)
    if not ordered:
        return {}
    return {label: ordered[math.ceil(fraction * len(ordered)) - 1]
            for label, fraction in (("p50", .5), ("p95", .95), ("p99", .99), ("p99.9", .999), ("max", 1))}

def receipt_statistics(phase):
    scheduled = [r for r in rows if r["phase"] == phase]
    publications = [r for r in scheduled if r["publication_ns"]]
    complete = [r for r in scheduled if r["command_receipt_ns"]]
    duplicates = [r for r in scheduled if any(r.get("duplicate_" + port, 0) for port in ports)]
    assert all(r["offered_ns"] <= r["publication_ns"] for r in publications)
    assert all(bool(r["command_receipt_ns"]) == all(r[port + "_ns"] for port in ports) for r in scheduled)
    for row in scheduled:
        for port in ports:
            if row[port + "_ns"]:
                assert 0 < row["publication_ns"] <= row[port + "_ns"]
        if row["command_receipt_ns"]:
            assert row["command_receipt_ns"] == max(row[port + "_ns"] for port in ports)
    first_on_time = [r for r in complete if r["command_receipt_ns"] - r["nominal_deadline_ns"] <= period]
    duplicate_sequences = {r["sequence"] for r in duplicates}
    valid_on_time = [r for r in first_on_time if r["sequence"] not in duplicate_sequences]
    return {
        "offered": len(scheduled),
        "published": len(publications),
        "source_rejected": sum(r["source_rejected"] for r in scheduled),
        "complete_first_command_sets": len(complete),
        "partial_command_sets": sum(not r["command_receipt_ns"] and any(r[port + "_ns"] for port in ports) for r in scheduled),
        "duplicate_sequences": len(duplicates),
        "duplicates_by_command": {port: sum(r.get("duplicate_" + port, 0) for r in scheduled) for port in ports},
        "first_complete_late": len(complete) - len(first_on_time),
        "unique_complete_on_time": len(valid_on_time),
        "missed_slots": len(scheduled) - len(valid_on_time),
        "nominal_to_complete_first_ns": quantiles(r["command_receipt_ns"] - r["nominal_deadline_ns"] for r in complete),
        "publication_to_complete_first_ns": quantiles(r["command_receipt_ns"] - r["publication_ns"] for r in complete),
        "detector_publication_cadence_abs_error_ns": quantiles(abs(b["publication_ns"] - a["publication_ns"] - period)
           for a, b in zip(publications, publications[1:]) if b["sequence"] == a["sequence"] + 1),
    }
print(json.dumps({"period_ns": period, **{phase: receipt_statistics(phase)
                  for phase in ("priming", "warmup", "measured")}}, indent=2))
