set -eu
p=$(cat /tmp/gpi2-matched-root)
base="$HOME/workspaces/codex/heart"
export DAO_ROOT="$base/daoinsw-heart-comparison" CFITSIO_ROOT="$base/cfitsio"
export PATH="/tmp/heart-rtcexec-python/bin:$DAO_ROOT/bin:$PATH"
export PYTHONPATH="$p/heart-base/source/python:$DAO_ROOT/source/python"
h="$p/heart-base"
unset HARDWARE HARDWARE_NUVU HARDWARE_DPIO
make -C "$h/external" build
for lib in util math aoTypes commands wfsProc config cmdHandler device blocks testServer pipes monitors template; do
    if [ "$lib" = aoTypes ]; then make -j1 -C "$h/source/aoTypes/gms" build PARENT_MAKE=1; fi
    make -j1 -C "$h/source/$lib/src" build PARENT_MAKE=1
done
mkdir -p "$h/lib" "$h/include"
(
    echo "CREATE $h/lib/libheart.a"
    for file in "$h"/source/*/lib/*.a "$h"/external/kissfft/libkissfft-float.a; do
        if [ -f "$file" ]; then echo "ADDLIB $file"; fi
    done
    echo SAVE
    echo END
) | ar -M
for file in "$h"/source/*/include/*.h; do ln -sf "$file" "$h/include/$(basename "$file")"; done
export HEART_ROOT="$h" GPI2RTC_USE_SUBMODULES=0
make -j1 -C "$p/heart-gpi2/source/devices/src" build PARENT_MAKE=1
make -j1 -C "$p/heart-gpi2/source/template/src" build PARENT_MAKE=1
