# Installed CAL2 independent-source restart

This scratch fixture uses the previously installed calibrated standalone
CAL2 export. One new private core,
HIL process, pupil feeder, and pair of direct camera observers remain alive
across the timed RTC activations. Those owners have separate systemd units
and the fixture holds the host benchmark lease. The pupil feeder uses the
existing 30 nm static astigmatic OPD and one task-controlled publisher. The
source advances after each accepted 2 ms LLOWFS exposure. This is a paced CPU
simulation workload. Model timestamps and observed host times have separate
units and the test makes no camera rate or production deadline claim.

The normal Julia installer rebuilds application-local graph precompile images,
regenerates the application artifact catalog and installs a systemd template
for each arm. The package manifest keeps the prior release cohort with the RTC
tree identified by the per-arm receipt and registered FilterGraphPipeWire
0.5.11. Both applications use the same calibration arrays, simulator, native
PipeWireAO 4.0.8 and data placement. The final qualification arm adds the
installation selector and the live modal-residual gate to both graph owners.
The current `baseline` package precedes that live closure gate and retains
normal online synthetic warmup. Its startup configuration includes the
prepare-path simplification. Image builds and optical package warmup occur
before an RTC activation.

`timing.json` uses one host monotonic clock per process. Service wall time
runs from the systemctl start request to its successful return after
the native Ready check and publication. Start latency uses both send and
Running acknowledgement as recorded by the exact native control client.
The first usable measurement is the first finite, nonzero calibrated modal
residual paired by domain, generation, sequence and model PTS with the zero
physical offset and a real camera sample. FilterGraphPipeWire suppresses all
exports on the incomplete first SCC exposure. Its pair-status stream carries
the complete status for the second exposure.

The signed camera-to-output difference is the time between independent taps
on the same acquisition. Camera drain polling, observer drive cadence, and
independent PipeWire scheduling affect it. The source tap can observe a frame
after the queue tap. These data do not measure the controller callback or
detector-to-correction latency.

The closure test observes exact native requested and active property
generations. It independently identifies the first camera frame after
acknowledgement with a 100 ms host tap separation around the transaction.
If a camera tap arrived near the send, the frame-matched zero offset must
already have been observed before the send. SCC must report a complete
pair for the first post-adoption frame. The matching physical offset must
be present and nonzero. The numerical check compares all 2,304 projected
actuator channels with the Float32 CAL2 gain applied to the transported modal
residual for the same acquisition. It reads the sealed FITS projection
directly with the explicit axis permutation and calculates the dot products
in Float64 with an error bound based on Float32 summation. The fixture
taps native output queues and has no actuator sink.

`stage-app.sh`, `install-app.jl`, the package tree and checksum receipts
describe the applications. The `*-run-*` directories own the observer and
native-control logs and installation lifecycle receipts. Other scratch
or unrelated user services are outside this fixture.


The repeated Ready-only activations ran in reverse order on the same source,
with no controller output taps in either arm. All four activations reached
native Ready. The smaller host scheduling waits on the second and later
activations limit what can be inferred from the first wall-time comparison.

The gated application package was frozen before an additional runtime
rejection for a deliberately unpublished priming output. Its CAL2 profiles
use published modal-residual ports in both branches. The frozen package
already contained the behavior exercised here, and the per-arm provenance
records identify it exactly.

Run `python3 scripts/verify-captures.py` from any directory to verify the
public evidence without the installed apps. From an appropriate Julia
environment with a copy of the corresponding CAL2 application, rerun the
numerical calculation as follows. Use a disposable copy of the selected
evidence arm as the final argument because the checker writes its result there.

```sh
julia --startup-file=no --project="$application" scripts/numerical-oracle.jl "$application" "$evidence_run"
```
