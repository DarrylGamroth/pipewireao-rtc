import csv
import json
from pathlib import Path

out=Path(__file__).resolve().parents[1]

def load(file):
    return json.loads(file.read_text())

def check(rows,trace):
    gates={}
    for branch in ("llowfs","scc"):
        observed=rows["first_correction"][branch]
        physical=observed["physical"]
        before=[row for row in trace if row["name"]==branch+"-physical-offset" and
            row["observed_ns"]<physical["observed_ns"]]
        assert before and before[-1]["acquired_sequence"]+1==physical["acquired_sequence"]
        assert all(row["max_abs"]==0 for row in before)
        assert before[-1]["observed_ns"] < observed["close"]["sent_ns"]
        assert observed["close"]["received_ns"] < observed["camera"]["observed_ns"]
        assert physical["acquired_sequence"]==observed["camera"]["sequence"]
        gates[branch]={"preclosure_zero_count":len(before),"last_preclosure_sequence":before[-1]["acquired_sequence"],
            "first_correction_sequence":physical["acquired_sequence"]}
    return gates

baseline,candidate=[load(out/v/"timing.json") for v in ("baseline","candidate-gated")]
assert all(baseline[key]==candidate[key] for key in ("core","hil","private_socket_inode"))
assert baseline["rtc"]["pid"]!=candidate["rtc"]["pid"] and baseline["rtc"]["invocation"]!=candidate["rtc"]["invocation"]
assert len(set(baseline["rtc_links"]+candidate["rtc_links"]))==20
baseline_camera=baseline["post_quit_camera"]
assert baseline["service_ready_ns"] < baseline_camera["observed_ns"] < candidate["service_request_ns"]
with (out/"camera-trace.tsv").open() as f:
    inputs=list(csv.DictReader(f,delimiter="\t"))
for branch,period in (("llowfs",2_000_000),("scc",10_000_000)):
    records=[r for r in inputs if r["camera"]==f"cal2-{branch}"]
    assert all(r["generation"] == records[0]["generation"] and r["domain"]==records[0]["domain"] and
        int(r["sequence"])==i+1 and int(r["model_ns"])==period*i for i,r in enumerate(records))
names=("baseline","candidate-gated")
receipts={}
for name,timing in zip(names,(baseline,candidate)):
    trace=[json.loads(row) for row in (out/name/"output-trace.jsonl").read_text().splitlines()]
    receipts[name]=check(timing,trace)
    assert all(data["channels_compared"] == 2304 for data in load(out/name/"numerical-oracle.json").values())
a,b=[load(out/name/"oracle-input.json") for name in names]
matches={branch:{field:a[branch][field]["payload"]==b[branch][field]["payload"]
    for field in ("modal","physical")}
    for branch in ("llowfs","scc")}
assert all(all(row.values()) for row in matches.values()), matches
evidence={"same_core_incarnation":True,"same_hil_incarnation":True,"same_socket":True,
    "rtc_main_process_replaced":True,"all_ten_rtc_links_replaced":True,
    "native_camera_model_clocks_continuous":True,"first_correction_predecessors":receipts,
    "exact_first_correction_payload_matches":matches,
    "processing_latency_scope":"Separate camera and output taps. Signed wall-clock deltas are not callback or detector-to-command durations."}
for variant in ("repeat-baseline","repeat-candidate-gated"):
    if (out/variant/"timing.json").exists():
        result=load(out/variant/"timing.json")
        if "native_quit" not in result:
            continue
        assert result["core"]==baseline["core"] and result["hil"]==baseline["hil"]
        assert result["native_ready_and_both_open"] and result["native_quit"],result
        evidence[variant+"_ready_s"]=result["service_to_ready_s"]
assert evidence == load(out/"comparison.json")
print(json.dumps(evidence,indent=2,sort_keys=True))
