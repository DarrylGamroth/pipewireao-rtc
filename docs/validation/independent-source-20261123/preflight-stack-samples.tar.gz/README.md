# CAL2 startup profile

A fresh Julia 1.13.3 process ran the sealed CAL2 application's actual
`PipeWireAORTC.SessionCLI._preflight` once after loading the package. This
is the deployment validation step the installed `prepare` command calls
before systemd-owned preparation. The profile covers package import and
that first call. Its scope ends before owner launch, coordinator startup
and publication. The capture uses the normal helper's `-O0` setting,
CPU 3 and the original Project, Manifest and populated depots while
holding the shared benchmark lease.

The deployment check succeeded. The package import took 0.593 s and the
deployment check took 1.203 s. Julia's cumulative compilation counter
attributed 1.156 s to compilation within the check. The collector used
Julia's CPU profile sampler with a requested 5 ms interval. Sampling
lasted 1.846 s from before workload entry until the check returned. The
buffer did not fill. Stack resolution and folded-file output ran after
the sampling window. No paired measurement of profile overhead was
made.

The sampler recorded 582 Julia thread snapshots. Julia marked 294
sleeping, including all 291 snapshots from the interactive thread.
Thread 1 supplied all 288 awake samples. Of these, 183 include the
deployment `_preflight` call and 105 fall outside that call. Among the
183, 113 contain code-generation frames and 65 contain inference frames
under the classifier in `prepare-preflight/fold.py`. The remaining 5
lack those markers. Counts describe the sampled population. Julia's
sleep flag is a runtime observation and the sampling interval is a
request to the sampler. These counts cannot establish elapsed time per
frame, account for run-queue wait or provide hardware timing.

`prepare-preflight/preflight.folded` has the 183 deployment-stack samples.
`prepare-preflight/awake.folded` also includes the 105 awake samples
outside that call. `prepare-preflight/all.folded` retains both sleep
states. `prepare-preflight/rtc-profile-samples.tsv` preserves the single
raw stack per record, inlined frames, Julia thread ID, task ID, raw
cycle-clock counter and Julia sleep flag. Two address-range symbolizer
warnings are in `prepare-preflight/warnings.log`. The recovered text
contains unknown native frames alongside source-resolved Julia frames.

The live attempt used the byte-identical installed coordinator and
helper launchers. Both real camera outputs arrived before the fresh
systemd start. The external sampler encountered an undefined Python
path alias while trying to signal the coordinator. Fixture cleanup
stopped its own activation before Ready. No live Julia profile was
collected. The failed attempt's scheduler counters, camera trace,
driver log and journal are separate from the portable phase capture.
`driver-fixed.py` records the mechanical correction to the alias. Its
live behavior was unevaluated. The historical 58.287 s activation has
journal milestones only.
