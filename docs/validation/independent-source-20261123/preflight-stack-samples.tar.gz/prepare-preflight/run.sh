#!/usr/bin/env bash
set -euo pipefail
output=$(cd -- "$(dirname -- "$0")" && pwd)
profile_dir=$(dirname -- "$output")
source /var/tmp/cal2-independent.UcNIRN/environment.sh
export CAL2_PROFILE_DIR="$output" TMPDIR="$profile_dir/tmp" XDG_CACHE_HOME="$profile_dir/xdg-cache" POCL_CACHE_DIR="$profile_dir/pocl"
app="$stage/final-install"
exec flock -w 35 /run/user/1000/rtc-devel-benchmark.lock     taskset -c 3 "$julia" --startup-file=no "--project=$app" -O0     -L "$output/collect.jl" "$output/preflight.jl" "$app" "$prefix"
