module RTCProfiler
using Profile

const output = ENV["CAL2_PROFILE_DIR"]
const started_ns = Ref{UInt64}(0)
const stopped_ns = Ref{UInt64}(0)
const stop_request_ns = Ref{UInt64}(0)

function stop_capture()
    Profile.stop_timer()
    stopped_ns[] = time_ns()
end

function write_capture()
    if stopped_ns[] == 0
        Profile.stop_timer()
        stopped_ns[] = time_ns()
    end
    data, frames = Profile.retrieve()
    open(joinpath(output, "rtc-profile-metadata.tsv"), "w") do io
        println(io, "pid\t", getpid())
        println(io, "julia\t", VERSION)
        println(io, "default_threads\t", Threads.nthreads(:default))
        println(io, "interactive_threads\t", Threads.nthreads(:interactive))
        println(io, "start_ns\t", started_ns[])
        println(io, "stop_request_ns\t", stop_request_ns[])
        println(io, "stop_ns\t", stopped_ns[])
        println(io, "settings\t", Profile.init())
        println(io, "buffer_full\t", Profile.is_buffer_full())
        println(io, "raw_words\t", length(data))
    end
    open(joinpath(output, "rtc-profile-samples.tsv"), "w") do io
        println(io, "thread\ttask\tclock\tsleep_state\tstack")
        lower = firstindex(data)
        for upper in eachindex(data)
            upper < lower + 5 && continue
            Profile.is_block_end(data, upper) || continue
            labels = String[]
            for i in (upper - 6):-1:lower
                for f in Iterators.reverse(get(frames, data[i], Base.StackTraces.StackFrame[]))
                    name = isempty(String(f.func)) ? "[unknown]" : String(f.func)
                    path = String(f.file)
                    shortpath = replace(path, r"^.*/(packages|artifacts|srcdir|julia-ci)/" => s"\1/")
                    label = isempty(path) ? name : "$name [$shortpath:$(f.line)]"
                    push!(labels, replace(label, ';' => ',', '\t' => ' ', '\n' => ' '))
                end
            end
            thread = data[upper - Profile.META_OFFSET_THREADID]
            task = data[upper - Profile.META_OFFSET_TASKID]
            clock = data[upper - Profile.META_OFFSET_CPUCYCLECLOCK]
            state = data[upper - Profile.META_OFFSET_SLEEPSTATE] - 1
            println(io, thread, '\t', string(task; base=16), '\t', clock, '\t', state, '\t', join(labels, ';'))
            lower = upper + 1
        end
    end
    touch(joinpath(output, "profile-written"))
end

Profile.init(n=10_000_000, delay=0.005)
atexit(write_capture)
started_ns[] = time_ns()
Profile.start_timer()
end
