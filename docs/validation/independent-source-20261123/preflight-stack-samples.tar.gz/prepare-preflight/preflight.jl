app, prefix = ARGS
started = time_ns()
Base.cumulative_compile_timing(true)
using PipeWireAORTC
imported = time_ns()
arguments = [
    "--package", app,
    "--prefix", prefix,
    "--unit", "unused-profiler.service",
    "--launcher", joinpath(app, "bin", "pipewireao-rtc-session"),
    "--runtime-root", "/unused",
]
result = @timed PipeWireAORTC.SessionCLI._preflight(arguments)
RTCProfiler.stop_capture()
@assert result.value === nothing
println("preflight_status\tpassed")
println("call_wall_s\t", result.time)
println("call_compile_s\t", result.compile_time)
println("package_load_wall_s\t", (imported - started) / 1e9)
println("entry_ns\t", started)
println("call_end_ns\t", time_ns())
