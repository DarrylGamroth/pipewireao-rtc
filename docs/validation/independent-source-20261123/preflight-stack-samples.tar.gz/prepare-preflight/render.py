"""Render the sampled deployment preflight. Pass flamegraph.pl and an output SVG."""
import collections
import csv
import os
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).parent
stacks = collections.Counter()
with (root / "rtc-profile-samples.tsv").open() as source:
    for row in csv.DictReader(source, delimiter="\t"):
        if row["sleep_state"] != "0":
            continue
        names = [frame.rsplit(" [", 1)[0] for frame in row["stack"].split(";")]
        if "_preflight" not in names:
            continue
        names = names[names.index("_preflight"):]
        if len(names) > 28:
            names = names[:28] + ["[deeper calls in the sample archive]"]
        stacks[";".join(names)] += 1

assert sum(stacks.values()) == 183
svg = subprocess.run([
        "perl", sys.argv[1], "--inverted", "--hash", "--width=1280", "--height=21",
        "--bgcolors=#ffffff", "--colors=aqua",
        "--title=CAL2 startup | Check the installed deployment",
        "--subtitle=183 awake samples inside the first preflight call. Click a frame to zoom.",
    ], input="".join(f"{stack} {n}\n" for stack, n in sorted(stacks.items())),
       env={**os.environ, "PERL_HASH_SEED": "0", "PERL_PERTURB_KEYS": "0"},
       text=True, capture_output=True, check=True).stdout
pathlib.Path(sys.argv[2]).write_text("\n".join(line.rstrip() for line in svg.splitlines()) + "\n")
