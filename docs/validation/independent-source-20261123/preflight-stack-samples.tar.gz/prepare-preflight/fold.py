"""Aggregate full Julia Profile stacks from one fresh preflight process."""
import collections
import csv
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
all_samples = collections.Counter()
awake_samples = collections.Counter()
preflight_samples = collections.Counter()
counts = collections.Counter()
phase_counts = collections.Counter()
compiler_counts = collections.Counter()
with (root/"rtc-profile-samples.tsv").open() as source:
    for row in csv.DictReader(source, delimiter="\t"):
        stack = row["stack"] or "[no resolved frames]"
        all_samples[stack] += 1
        counts[(int(row["thread"]), int(row["sleep_state"]))] += 1
        if row["sleep_state"] != "0":
            continue
        awake_samples[stack] += 1
        phase = "deployment preflight" if "_preflight [" in stack else "outside deployment preflight"
        phase_counts[phase] += 1
        if phase == "deployment preflight":
            preflight_samples[stack] += 1
        if "jl_type_infer [" in stack or "/Compiler/src/" in stack:
            compiler_counts[(phase, "inference")] += 1
        elif "libLLVM" in stack or "jl_compile_codeinst_" in stack or "jl_emit_code [" in stack:
            compiler_counts[(phase, "code generation")] += 1

for name, data in (("all.folded", all_samples), ("awake.folded", awake_samples), ("preflight.folded", preflight_samples)):
    with (root/name).open("w") as output:
        for stack, count in data.most_common():
            print(f"{stack} {count}", file=output)
info = dict(total_samples=sum(all_samples.values()),
            awake_samples=sum(awake_samples.values()),
            by_thread_state=[dict(thread=t, sleep_state=s, samples=n) for (t,s),n in sorted(counts.items())],
            awake_by_phase=dict(phase_counts),
            compiler_frame_samples=[dict(phase=p, category=c, samples=n) for (p,c),n in sorted(compiler_counts.items())])
assert info["awake_samples"] > 0 and phase_counts["deployment preflight"] > 0, info
(root/"summary.json").write_text(json.dumps(info,indent=2)+"\n")
print(json.dumps(info,indent=2))
