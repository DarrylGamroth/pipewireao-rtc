#!/usr/bin/env bash
set -euo pipefail
stage=$(cd -- "$(dirname -- "$0")" && pwd)
source "/var/tmp/cal2-independent.UcNIRN/environment.sh"
source_fixture="$stage"
stage="/var/tmp/cal2-startup-attribution.boNvpkid"
tag=${stage##*.}
export PIPEWIREAORTC_CORE_UNIT="c2i-$tag-core.service" PIPEWIREAORTC_CORE_SOCKET="/run/user/1000/c2i-$tag/c" PIPEWIREAORTC_SOURCE_UNIT="c2i-$tag-hil.service"
export PIPEWIREAO_PREFIX="$prefix"
export CAL2_VALIDATION_JULIA="$julia"
export CAL2_VALIDATION_QUEUE_MODULE=/home/dgamroth/.julia/artifacts/20afa07132938ae663c7cf4c10f00172ca40e70f/lib/pipewire-ao-0.3/libpipewire-module-queue.so
tree=$(awk -F= '$1=="AdaptiveOpticsSimPipeWireHIL"{print $2}' "$source_fixture/receipts/package-trees")
slug=$("$julia" --startup-file=no -e 'using UUIDs; print(Base.version_slug(UUID("355e2bce-7765-4934-ac1c-873e1c98ec3d"), Base.SHA1(hex2bytes(only(ARGS)))))' "$tree")
export CAL2_VALIDATION_HIL_ENTRYPOINT="$source_fixture/private-depot/packages/AdaptiveOpticsSimPipeWireHIL/$slug/src/independent.jl"
test -r "$CAL2_VALIDATION_HIL_ENTRYPOINT"
test -r "$CAL2_VALIDATION_QUEUE_MODULE"
test -f "$source_fixture/final-install/systemd/pipewireao-session@.service"
exec python3 "$stage/driver.py"
