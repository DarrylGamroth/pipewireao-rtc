t0=time_ns()
Base.cumulative_compile_timing(true)
using PipeWireAORTC
t1=time_ns()
const RTC=PipeWireAORTC
app,prefix=ARGS
args=["--package",app,"--prefix",prefix,"--unit","unused.service","--launcher",joinpath(app,"bin","pipewireao-rtc-session"),"--runtime-root","/unused"]
for invocation in 1:2
    t=@timed RTC.SessionCLI._preflight(args)
    println("preflight",invocation," ",t.time," compile ",t.compile_time)
end
println("import ",(t1-t0)/1e9)
