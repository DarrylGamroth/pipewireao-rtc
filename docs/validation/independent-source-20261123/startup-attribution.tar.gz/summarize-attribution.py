"""Reduce the stored monotonic process samples inside each successful service-start window."""
import json
from pathlib import Path
base=Path(__file__).resolve().parent
samples=[json.loads(line) for line in (base/"rtc-processes.jsonl").read_text().splitlines()]
trials=json.loads((base/"comparison.json").read_text())
summary=[]
for i,trial in enumerate(trials,1):
    if "failure" in trial:
        cutoff=json.loads((base/"candidate-cutoff.json").read_text())
        assert json.loads((base/"candidate-cleanup.json").read_text())["cleanup_complete"]
        summary.append({"trial":i,"result":"interrupted before Ready","cutoff":cutoff})
        continue
    folder=base/f"activation-{i}"
    ledger=json.loads((folder/"stopped-ledger.json").read_text())
    assert ledger["cleanup_complete"] and ledger["systemd_quit"]=={"attempted":True,"accepted":True}
    assert len(trial["links"])==10
    leaders={}
    for role in ("prepare","RTC","publish"):
        relevant=[r for r in samples if trial["start_ns"]<=r[0]<=trial["ready_ns"] and r[2]==role]
        # Short fork/exec children can temporarily inherit their parent's argv.
        # Select the role's long-lived process. Keep only samples through Ready.
        primary=max(relevant,key=lambda r:r[3])[1]
        samples_for_pid=[r for r in relevant if r[1]==primary]
        t,pid,_,cpu,wait,_,start,_=samples_for_pid[-1]
        leaders[role]=dict(pid=pid,cpu_s=cpu/1e9,runqueue_s=wait/1e9,last_sample_ns=t)
    assert leaders["RTC"]["pid"]==trial["rtc"]["pid"]
    assert leaders["prepare"]["last_sample_ns"]<int(trial["systemd"]["ExecMainStartTimestampMonotonic"])*1000
    summary.append(dict(trial=i,ready_s=trial["ready_seconds"],leaders=leaders))
print(json.dumps(summary,indent=2))
