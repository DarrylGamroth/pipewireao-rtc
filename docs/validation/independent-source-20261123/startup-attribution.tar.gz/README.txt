The full service experiment reuses the installed private CAL2 project, SDK,
depots, graph images and feed configuration identified in the companion
cal2-restart.tar.gz. The captured scripts use the original absolute paths.
run.sh and driver.py need a fresh scratch directory and private unit names
for a new run. The exploratory launcher changes only the prepare and publish
Julia flags. Each ordinary run uses native controls and the original
launcher. Candidate publication was interrupted at the recorded time.
Run python3 summarize-attribution.py after extracting to recompute the tables.
For the preflight test invoke readiness.jl with the frozen project, Julia
1.13.3, CPU 3, -O0 and optionally --compile=min, followed by the CAL2
application and SDK prefix. placement.jl takes the same arguments and uses
-O0, alternating CPUs 3, 5, 5, 3. See the report for measurement scopes.
