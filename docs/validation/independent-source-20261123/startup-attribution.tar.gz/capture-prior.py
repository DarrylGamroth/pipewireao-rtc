import json, subprocess
from pathlib import Path
base=Path('/var/tmp/cal2-independent.UcNIRN')
observations=[]
for i in (1,2):
    d=base/f'activation-{i}'
    result=json.loads((d/'result.json').read_text())
    owners=json.loads((d/'ready-ledger.json').read_text())['owners']
    for name in ('cal2-llowfs','cal2-scc'):
        unit=owners[name]['unit']
        entries=[]
        journal=subprocess.check_output(['journalctl','--user','-u',unit,'--no-pager','-o','json'],text=True)
        for line in journal.splitlines():
            e=json.loads(line)
            m=e.get('MESSAGE','')
            if any(k in m for k in ('phase =','wall_seconds =','compile_seconds =','Startup phase','Started pipewireao-owner')):
                entries.append(dict(t_ns=int(e['__MONOTONIC_TIMESTAMP'])*1000, message=m))
        assert entries
        observations.append(dict(activation=i,role=name,unit=unit,start_ns=result['start_ns'],ready_ns=result['ready_ns'],events=entries))
Path('prior-graph-events.json').write_text(json.dumps(observations,indent=2)+'\n')
