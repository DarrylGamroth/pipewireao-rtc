sched() = parse.(UInt64, split(read("/proc/thread-self/schedstat", String)))[1:2]
start = time_ns()
start_sched = sched()
using PipeWireAORTC
pkg, prefix = ARGS
argv = ["--package",pkg,"--prefix",prefix,"--unit","unused.service","--launcher",joinpath(pkg,"bin","pipewireao-rtc-session"),"--runtime-root","/unused"]
function report(label, start, previous)
    current=sched()
    println(label," wall_ns=",time_ns()-start," cpu_ns=",current[1]-previous[1]," wait_ns=",current[2]-previous[2])
end
report("import", start, start_sched)
start = time_ns()
start_sched = sched()
PipeWireAORTC.SessionCLI._preflight(argv)
report("first_preflight", start, start_sched)
