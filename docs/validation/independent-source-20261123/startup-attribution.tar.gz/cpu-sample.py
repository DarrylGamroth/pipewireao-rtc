from pathlib import Path
import json,time,os
out=Path(__file__).resolve().parent
path=Path(r"/sys/fs/cgroup/user.slice/user-1000.slice/user@1000.service/app.slice/app-pipewireao\x2dsession.slice/pipewireao-session@c2i-boNvpkid.service/cgroup.procs")
end=time.monotonic()+2000
with (out/"rtc-processes.jsonl").open("w",buffering=1) as log:
 while time.monotonic()<end and not (out/"journal.txt").exists():
    try: pids=path.read_text().split()
    except FileNotFoundError: pids=()
    for pid in pids:
        proc=Path("/proc")/pid
        try:
            argv=(proc/"cmdline").read_bytes().decode(errors="replace").rstrip("\0").split("\0")
            sched=(proc/"schedstat").read_text().split()
            stat=(proc/"stat").read_text().rsplit(")",1)[1].split()
        except (OSError,ValueError): continue
        if not argv or Path(argv[0]).name!="julia": continue
        phase=next((a for a in argv if a in ("prepare","publish","stop","cleanup")),None)
        if phase is None and any('MediaSession.main' in a for a in argv): phase="RTC"
        if phase is None: continue
        print(json.dumps([time.monotonic_ns(),int(pid),phase,int(sched[0]),int(sched[1]),int(stat[11])+int(stat[12]),int(stat[19]),"--compile=min" in argv]),file=log)
    time.sleep(.2)
