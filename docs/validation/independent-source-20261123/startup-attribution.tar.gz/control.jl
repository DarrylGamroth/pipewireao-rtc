using PipeWireAORTC, PipeWireAO
const P=PipeWireAORTC
const C=P.ControlClient
const S=P.SessionCodec
const R=P.RunnerCodec
const L=P.SessionCLI
ledger, phase, remote=ARGS
d=P.Common.read_json(ledger)
pid=d["session_pid"]
@assert d["remote"]==remote
connect_started=time_ns()
client=C.connect(P.SessionProfile.Profile(),remote,"pipewireao.rtc.session.cal2",pid,
    d["session_control_instance"];deadline=C.monotonic()+45)
connect_ns=time_ns()-connect_started
request_times_ns=Dict{String,UInt64}()
try
    with_thread_loop_lock(client.loop) do _
        C.healthy(client)
        @assert client.observation.node_identity==d["session_uuid"]
        @assert client.observation.owner_pid==pid
        @assert client.observation.instance==d["session_control_instance"]
    end
    function request(op,lifecycle)
        started=time_ns()
        completion=C.request!(client,S.RunnerCommand(op);deadline=C.monotonic()+45)
        request_times_ns[string(op)]=time_ns()-started
        completion.header.result==0 && completion.lifecycle==lifecycle ||
            error("Unexpected native completion for $op: $completion")
        return completion
    end
    if phase=="start"
        L.confirm_ready(request(:status,R.Ready))
        request(:session_start,R.Running)
    elseif phase=="stop"
        request(:session_stop,R.Ready)
        L.confirm_ready(request(:status,R.Ready))
    else
        error("Unknown phase $phase")
    end
    println(P.Common.metadata_json((; phase, connect_ns, request_times_ns, observed_ns=time_ns(),session_uuid=d["session_uuid"],
        pid, instance=d["session_control_instance"], endpoint=client.global_id, serial=client.serial)))
finally
    close(client)
end
