import fcntl, json, os, pathlib, shutil, subprocess, time
P = pathlib.Path
stage = P(__file__).resolve().parent
app = stage / "final-install"
runtime = P(os.environ["PIPEWIREAORTC_CORE_SOCKET"]).parent
socket = runtime / "c"
prefix = P(os.environ["PIPEWIREAO_PREFIX"])
julia = os.environ["CAL2_VALIDATION_JULIA"]
reference = P("/var/tmp/cal2-services.6DdlJUDp")
tag = stage.name.split(".")[-1]
unit = f"pipewireao-session@c2i-{tag}.service"
rtc_runtime = runtime.parent / f"pipewireao-session-c2i-{tag}"
core_name, hil_name = (os.environ[key] for key in ("PIPEWIREAORTC_CORE_UNIT", "PIPEWIREAORTC_SOURCE_UNIT"))
units = runtime.parent / "systemd/user"
unit_file = units / unit
dropin = units / (unit + ".d")
services = (unit, hil_name, core_name)
depots = os.environ["JULIA_DEPOT_PATH"]
sdk_modules = str(prefix / "lib/pipewire-ao-0.3")
queue = os.environ["CAL2_VALIDATION_QUEUE_MODULE"]
julia_command = [julia,"--startup-file=no","--threads=2,0","--project="+str(app)]
helper_julia = ["taskset","-c","12,13",julia,"--startup-file=no","--threads=2,1","-O0","--project="+str(app)]
native = dict(PIPEWIREAO_RUNTIME_DIR=str(runtime), PIPEWIRE_RUNTIME_DIR=str(runtime),
    PIPEWIREAO_CONFIG_DIR=str(stage / "core-config"),
    PIPEWIREAO_MODULE_DIR=sdk_modules + ":" + str(P(queue).parent),
    PIPEWIREAO_SPA_PLUGIN_DIR=str(prefix / "lib/spa-ao-0.2"),
    LD_LIBRARY_PATH=str(prefix / "lib"))
environment = dict(os.environ, **native)
client_native = dict(native, PIPEWIREAO_MODULE_DIR=sdk_modules)
child_env = dict(os.environ, **client_native)
keep = {key:os.environ[key] for key in (
    "JULIA_DEPOT_PATH","JULIA_LOAD_PATH","JULIA_PKG_PRECOMPILE_AUTO","JULIA_NUM_PRECOMPILE_TASKS",
    "JULIA_IMAGE_THREADS","OPENBLAS_NUM_THREADS","TMPDIR","XDG_CACHE_HOME","POCL_CACHE_DIR")}
children = []
claimed = False

def run(*args,timeout=30,env=None,**kwargs):
    return subprocess.run([str(arg) for arg in args],check=True,timeout=timeout,env=env,**kwargs)
def system(*args,**kwargs):
    return run("systemctl","--user",*args,**kwargs)
def service_status(name):
    p=system("show",name,"-p","ActiveState,SubState,MainPID,InvocationID,Result,FragmentPath,ExecMainStartTimestampMonotonic,ActiveEnterTimestampMonotonic",
        text=True,capture_output=True)
    return dict(line.split("=",1) for line in p.stdout.splitlines() if "=" in line)
def now():
    return time.monotonic_ns()
def wait(predicate,seconds,label):
    stop=now()+int(seconds*1e9)
    while now()<stop:
        value=predicate()
        if value:
            return value
        time.sleep(.15)
    raise RuntimeError(f"Timed out awaiting {label}")
def persist(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
def start_owner(unit,cpu,env,command):
    args=["systemd-run","--user",f"--unit={unit}","--property=Type=exec",
          f"--property=CPUAffinity={cpu}","--property=KillSignal=SIGINT","--property=TimeoutStopSec=45",
          "--property=UMask=0077"]
    args.extend(f"--setenv={key}={value}" for key,value in env.items())
    run(*args,*command)
def launch(args,log):
    with open(log,"w") as output:
        child=subprocess.Popen([str(arg) for arg in args],env=child_env,stdout=output,stderr=subprocess.STDOUT)
    children.append(child)
    return child
def check_child(child,file):
    if child.poll() is not None:
        raise RuntimeError(f"Fixture exited {child.returncode}: {file}")
def stat_ticks(pid):
    return int(P(f"/proc/{pid}/stat").read_text().rsplit(')',1)[1].split()[19])
def live_service(unit):
    status=service_status(unit)
    assert status["ActiveState"]=="active",status
    pid=int(status["MainPID"])
    return {"pid":pid,"ticks":stat_ticks(pid),"invocation":status["InvocationID"]}
def dump(path):
    with open(path,"w") as sink:
        run(prefix/"bin/pwao-dump","-r",socket,env=child_env,stdout=sink)
    return json.loads(path.read_text())
def persistent_nodes(objects):
    result = {}
    by_id = {int(o["id"]):o for o in objects}
    roles={"cal2-pupil-input","cal2-llowfs","cal2-scc","independent-cal2-observe-cal2-llowfs","independent-cal2-observe-cal2-scc"}
    for o in objects:
        props=o.get("info",{}).get("props",{})
        name=props.get("node.name")
        if name in roles and o["type"].endswith(":Node"):
            client=by_id[int(props["client.id"])]["info"]["props"]
            result[name]={"id":o["id"],"serial":props["object.serial"],"client_serial":client["object.serial"],
                "client_pid":client["pipewire.sec.pid"]}
        if o["type"].endswith(":Link") and str(props.get("object.path","")).startswith("independent-cal2/"):
            result[props["object.path"]]={"id":o["id"],"serial":props["object.serial"]}
    assert len(result)==8,result
    return result
def feeder_recent():
    lines=(stage/"camera-trace.tsv").read_text().splitlines()
    return {name:next((line.split("\t") for line in reversed(lines) if line.startswith(name+"\t")),None)
        for name in ("cal2-llowfs","cal2-scc")}
def after(old):
    recent=feeder_recent()
    return recent if all(recent[k] and int(recent[k][1])>int(old[k][1]) for k in old) else None
def write_control(ledger,phase,path):
    with open(path,"w") as output:
        run(*helper_julia,stage/"control.jl",ledger,phase,socket,timeout=160,env=child_env,stdout=output)
    return json.loads(path.read_text())
def activation(index,core,hil,retained,inode,feed):
    directory=stage/f"activation-{index}"
    directory.mkdir()
    started=now()
    system("start",unit,timeout=970)
    ready=now()
    rtc=live_service(unit)
    systemd=service_status(unit)
    exec_us=int(systemd["ExecMainStartTimestampMonotonic"])
    active_us=int(systemd["ActiveEnterTimestampMonotonic"])
    assert 0 < exec_us <= active_us
    ledger=rtc_runtime/rtc["invocation"]/"launch.json"
    manifest=json.loads(ledger.read_text())
    shutil.copyfile(ledger,directory/"ready-ledger.json")
    shutil.copyfile(manifest["config"],directory/"rtc.conf")
    assert manifest["remote"]==str(socket) and manifest["phase"]=="prepared",manifest.get("remote")
    assert manifest["owners"]["core"]["pid"]==core["pid"] and manifest["owners"]["simulator"]["pid"]==hil["pid"]
    assert manifest["owners"]["core"]["external"] and manifest["owners"]["simulator"]["external"]
    assert manifest["owners"]["simulator"]["control-protocol"]=="external-stream"
    assert manifest["session_pid"]==rtc["pid"] and stat_ticks(rtc["pid"])==rtc["ticks"]
    assert live_service(core_name)==core and live_service(hil_name)==hil and socket.stat().st_ino==inode
    package_maps={}
    bindings = {role:item["pid"] for role,item in manifest["owners"].items()}
    bindings["rtc"]=rtc["pid"]
    for role,pid in bindings.items():
        maps=P(f"/proc/{pid}/maps").read_text().splitlines()
        package_maps[role] = [line for line in maps if any(marker in line for marker in
            ("ExportedGraphWarmup", "PipeWireAOOpticalStartup", "libpipewire-ao-0.3.so"))]
    persist(directory/"loaded-startup-objects.json",package_maps)
    observed=dump(directory/"ready-native.json")
    assert persistent_nodes(observed)==retained
    link_list=[o["info"]["props"]["object.serial"] for o in observed if o["type"].endswith(":Link")
        and str(o.get("info",{}).get("props",{}).get("object.path","")).startswith("pipewireao/session/")]
    assert link_list
    receipt={"iteration":index,"start_ns":started,"ready_ns":ready,"ready_seconds":(ready-started)/1e9,
        "core":core,"hil":hil,"rtc":rtc,"exec_start_to_active_seconds":(active_us-exec_us)/1e6,"systemd":systemd,"links":link_list,"session_uuid":manifest["session_uuid"]}
    persist(directory/"result.json",receipt)
    print("CAL2 READY",index,receipt["ready_seconds"], flush=True)
    offset=launch(
        [*helper_julia,stage/"offsets.jl",app,socket,directory,reference],directory/"offsets.log")
    def offsets_ready():
        check_child(offset,directory/"offsets.log")
        return (directory/"offsets-ready").exists()
    try:
        wait(offsets_ready,125,"physical-offset observers negotiated")
    except RuntimeError as error:
        receipt["offset_observation_error"]=str(error)
    receipt["running"]=write_control(ledger,"start",directory/"running.json")
    try:
        receipt["offset_observer_exit"]=offset.wait(timeout=660)
    except subprocess.TimeoutExpired:
        offset.terminate()
        receipt["offset_observation_error"]="Physical-offset observer timed out while Running"
    receipt["offset_witness_complete"]=(directory/"offsets.json").exists()
    persist(directory/"result.json",receipt)
    write_control(ledger,"stop",directory/"held.json")
    t=now()
    system("stop",unit,timeout=320)
    stopped=now()
    tail=json.loads(ledger.read_text())
    shutil.copyfile(ledger,directory/"stopped-ledger.json")
    assert tail["phase"]=="stopped" and tail["systemd_quit"]=={"attempted":True,"accepted":True}
    assert tail["cleanup_complete"] and service_status(unit)["ActiveState"]=="inactive"
    assert not P(manifest["discovery_locator"]).exists()
    assert live_service(core_name)==core and live_service(hil_name)==hil and socket.stat().st_ino==inode
    observed=dump(directory/"absent-native.json")
    assert persistent_nodes(observed)==retained
    assert not any(o["info"]["props"].get("object.serial") in link_list for o in observed if o["type"].endswith(":Link"))
    old=feeder_recent()
    def advanced():
        check_child(feed,stage/"feed.log")
        return after(old)
    recent=wait(advanced,650,"both cameras advancing while RTC is absent")
    receipt.update(quit_seconds=(stopped-t)/1e9,exit_ns=stopped,camera_at_absence=old,
        camera_later_absent=recent,absence_proved_at_ns=now())
    persist(directory/"result.json",receipt)
    print("CAL2 ABSENT CAMERAS",index,recent,flush=True)
    return receipt

def exercise():
    global claimed
    for path in (runtime,rtc_runtime,unit_file,dropin):
        assert not os.path.lexists(path),path
    for name in services:
        p=system("show",name,"-p","LoadState","--value",text=True,capture_output=True)
        assert p.stdout.strip()=="not-found", (name,p.stdout)
    claimed = True
    runtime.mkdir(mode=0o700)
    units.mkdir(exist_ok=True,parents=True)
    dropin.mkdir()
    shutil.copyfile(app/"systemd/pipewireao-session@.service",unit_file)
    (dropin/"fixture.conf").write_text("[Service]\n"+"".join(f'Environment="{key}={value}"\n' for key,value in keep.items()))
    cfg=stage/"core-config"
    cfg.mkdir(exist_ok=True)
    rel=json.loads((app/"deployment.conf").read_text())["core"]
    (cfg/"daemon.conf").write_text((app/rel).read_text().replace("@REMOTE@","c"))
    shutil.copyfile(app/"shared-runtime/client-simulator.conf.in",cfg/"client.conf")
    system("daemon-reload")
    start_owner(core_name,3,native,[prefix/"bin/pipewire-ao","-c","daemon.conf"])
    wait(socket.is_socket,30,"private core socket")
    core=live_service(core_name)
    hil_source=os.environ["CAL2_VALIDATION_HIL_ENTRYPOINT"]
    start_owner(hil_name,6,dict(client_native,**keep),[*julia_command,hil_source,
        "--config",app/"simulation.conf","--remote",socket,"--pipewire-cpu","7"])
    feed=launch([*helper_julia,stage/"feed.jl",app,socket,stage,reference],stage/"feed.log")
    def optics_ready():
        check_child(feed,stage/"feed.log")
        assert service_status(hil_name)["ActiveState"]=="active"
        return (stage/"feed-ready").exists()
    wait(optics_ready,1000,"independent CAL2 HIL plus real LLOWFS/SCC frames")
    hil=live_service(hil_name)
    observed=dump(stage/"before-first-native.json")
    retained=persistent_nodes(observed)
    assert all(int(v["client_pid"])==hil["pid"] for k,v in retained.items() if k in
        {"cal2-pupil-input","cal2-llowfs","cal2-scc"})
    inode=socket.stat().st_ino
    persist(stage/"persistent.json",dict(core=core,hil=hil,inode=inode,native=retained))
    print("CAL2 independent HIL publishing and both cameras observed",feeder_recent(),flush=True)
    results=[activation(index,core,hil,retained,inode,feed) for index in (1,2)]
    assert results[0]["rtc"]["pid"] != results[1]["rtc"]["pid"]
    assert results[0]["session_uuid"] != results[1]["session_uuid"]
    assert not (set(results[0]["links"]) & set(results[1]["links"]))
    persist(stage/"outcome.json",results)

def cleanup():
    if not claimed:
        return
    try: system("stop",unit,timeout=90)
    except Exception: pass
    (stage/"stop-feed").touch()
    for child in children:
        if child.poll() is None:
            try: child.wait(timeout=10)
            except subprocess.TimeoutExpired: child.terminate()
    try: system("stop",hil_name,core_name,timeout=120)
    except Exception: pass
    with open(stage/"journal.txt","w") as output:
        subprocess.run(["journalctl","--user","--no-pager","-o","short-monotonic",*[v for name in services for v in ("-u",name)]],
            stdout=output,stderr=subprocess.STDOUT,timeout=90,check=False)
    if unit_file.is_file() and unit_file.read_bytes()==(app/"systemd/pipewireao-session@.service").read_bytes():
        unit_file.unlink()
    if (dropin/"fixture.conf").is_file(): (dropin/"fixture.conf").unlink()
    if dropin.is_dir(): dropin.rmdir()
    try: system("daemon-reload")
    except Exception: pass

lock=runtime.parent/"rtc-devel-benchmark.lock"
with open(lock,"a") as acquired:
    print("CAL2 independent ready to queue for benchmark lock",lock,flush=True)
    fcntl.flock(acquired,fcntl.LOCK_EX)
    print("CAL2 independent has benchmark lock",flush=True)
    try: exercise()
    finally: cleanup()
