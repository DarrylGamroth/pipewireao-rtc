# Source only for this scratch fixture.
stage=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
tag=${stage##*.}
reference=/var/tmp/cal2-services.6DdlJUDp
prefix=/home/dgamroth/.julia/artifacts/77da251765f3124df77322c562e67a7c7742ab1d
julia=/home/dgamroth/.julia/juliaup/julia-1.13.3+0.x64.linux.gnu/bin/julia
runtime=/run/user/1000/c2i-$tag
export JULIA_DEPOT_PATH="$stage/private-depot:$reference/depot:" JULIA_LOAD_PATH="@:@stdlib" JULIA_PKG_PRECOMPILE_AUTO=0 JULIA_NUM_PRECOMPILE_TASKS=1 JULIA_IMAGE_THREADS=1 OPENBLAS_NUM_THREADS=1 TMPDIR="$stage/tmp"
export PIPEWIREAORTC_CORE_UNIT="c2i-$tag-core.service" PIPEWIREAORTC_CORE_SOCKET="$runtime/c" PIPEWIREAORTC_SOURCE_UNIT="c2i-$tag-hil.service"
export XDG_CACHE_HOME="$stage/xdg-cache" POCL_CACHE_DIR="$stage/pocl"
