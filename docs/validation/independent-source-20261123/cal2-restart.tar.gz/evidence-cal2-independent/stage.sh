#!/usr/bin/env bash
set -euo pipefail
stage=$(cd -- "$(dirname -- "$0")" && pwd)
work=/home/dgamroth/workspaces/codex/worktrees
reference=/var/tmp/cal2-services.6DdlJUDp
source=/home/dgamroth/workspaces/codex/adaptive-optics-simulations/build/cal2-fixed-pupil/applications/cal2
julia=/home/dgamroth/.julia/juliaup/julia-1.13.3+0.x64.linux.gnu/bin/julia
mkdir -p "$stage"/{private-depot,tmp,receipts}
export JULIA_DEPOT_PATH="$stage/private-depot:$reference/depot:" JULIA_LOAD_PATH="@:@stdlib" JULIA_PKG_PRECOMPILE_AUTO=0 JULIA_NUM_PRECOMPILE_TASKS=1 JULIA_IMAGE_THREADS=1 OPENBLAS_NUM_THREADS=1 TMPDIR="$stage/tmp"
function freeze() {
    local wt=$1 name=$2 uuid=$3
    local origin="$work/$wt" snapshot="$stage/$wt"
    git -C "$origin" rev-parse HEAD > "$stage/receipts/$wt.base"
    git -C "$origin" status --short > "$stage/receipts/$wt.status"
    git -C "$origin" diff --binary HEAD > "$stage/receipts/$wt.patch"
    git clone --quiet --shared --no-checkout "$origin" "$snapshot"
    git -C "$snapshot" checkout --quiet --detach "$(cat "$stage/receipts/$wt.base")"
    git -C "$snapshot" apply "$stage/receipts/$wt.patch"
    git -C "$origin" ls-files --others --exclude-standard -z |
    while IFS= read -r -d '' file; do
        install -D -m 0644 "$origin/$file" "$snapshot/$file"
    done
    git -C "$snapshot" add -A
    git -C "$snapshot" -c user.name='Local validation' -c user.email=validation@localhost commit --quiet -m "Freeze CAL2 independent $name validation candidate"
    git -C "$snapshot" rev-parse HEAD HEAD^{tree} > "$stage/receipts/$wt.git"
    local tree slug cache
    tree=$(tail -1 "$stage/receipts/$wt.git")
    slug=$("$julia" --startup-file=no -e 'using UUIDs; print(Base.version_slug(UUID(ARGS[1]), Base.SHA1(hex2bytes(ARGS[2]))))' "$uuid" "$tree")
    cache="$stage/private-depot/packages/$name/$slug"
    mkdir -p "$cache"
    git -C "$snapshot" archive HEAD | tar -xf - -C "$cache"
    chmod -R a-w "$cache"
    printf '%s=%s\n' "$name" "$tree" >> "$stage/receipts/package-trees"
}
freeze rtc-independent-service PipeWireAORTC a3e2c7da-f73f-4284-8482-36ac422b34e6
freeze hil-independent-simulator AdaptiveOpticsSimPipeWireHIL 355e2bce-7765-4934-ac1c-873e1c98ec3d
cp -a --reflink=auto "$source" "$stage/export"
cp "$stage/export/Manifest.toml" "$stage/receipts/original-Manifest.toml"
cp "$stage/export/Project.toml" "$stage/receipts/Project.toml"
python3 - "$stage" <<'PY'
from pathlib import Path
import re,sys,tomllib
stage=Path(sys.argv[1])
trees=dict(line.split("=") for line in (stage/'receipts/package-trees').read_text().splitlines())
manifest=stage/'export/Manifest.toml'
old=manifest.read_text()
out=old
for name,tree in trees.items():
    pattern=rf'(\[\[deps\.{name}\]\]\n(?:[^\n]*\n)*?git-tree-sha1 = ")[a-f0-9]{{40}}(")'
    out,count=re.subn(pattern,rf'\g<1>{tree}\2',out,count=1)
    assert count==1
before,after=map(tomllib.loads,(old,out))
for name,tree in trees.items():
    assert after['deps'][name][0]['git-tree-sha1']==tree
    before['deps'][name][0]['git-tree-sha1']=tree
assert before==after
manifest.write_text(out)
PY
diff -u "$stage/receipts/original-Manifest.toml" "$stage/export/Manifest.toml" > "$stage/receipts/Manifest.patch" || [ "$?" -eq 1 ]
sha256sum "$stage"/export/{Project.toml,Manifest.toml,deployment.conf,simulation.conf} > "$stage/receipts/export-digests.txt"
