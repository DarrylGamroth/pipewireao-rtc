from pathlib import Path
import csv,json
stage=Path(__file__).resolve().parent
results=json.loads((stage/"outcome.json").read_text())
with (stage/"camera-trace.tsv").open() as f:
    rows=list(csv.DictReader(f,delimiter="\t"))
cameras=("cal2-llowfs","cal2-scc")
samples={name:[r for r in rows if r["camera"]==name] for name in cameras}
lines=[]
for name, frames in samples.items():
    seq=[int(r["sequence"]) for r in frames]
    pts=[int(r["model_ns"]) for r in frames]
    exposure={int(r["exposure_ns"]) for r in frames}
    ident={(r["generation"],r["domain"]) for r in frames}
    assert len(ident)==len(exposure)==1
    duration=next(iter(exposure))
    assert seq==list(range(seq[0],seq[-1]+1))
    assert all(x==duration*(s-1) for s,x in zip(seq,pts))
    lines.append(f"{name} had {len(frames)} consecutive observed frames, sequence {seq[0]}–{seq[-1]}, +{duration/1e6:g} ms model PTS, one domain and generation.")
for iteration, result in enumerate(results,1):
    directory=stage/f"activation-{iteration}"
    ledger=json.loads((directory/"stopped-ledger.json").read_text())
    assert ledger["systemd_quit"]=={"attempted":True,"accepted":True} and ledger["cleanup_complete"]
    assert result["offset_witness_complete"]
    begin=json.loads((directory/"running.json").read_text())["observed_ns"]
    ended=json.loads((directory/"held.json").read_text())["observed_ns"]
    with (directory/"offset-trace.tsv").open() as f:
        offsets=list(csv.DictReader(f,delimiter="\t"))
    assert len(offsets)==2
    for row in offsets:
        assert begin<int(row["observed_ns"])<ended
        camera="cal2-"+row["name"].removesuffix("-physical-offset")
        assert any(all(camera_row[k]==row[k] for k in ("sequence","model_ns","domain","generation")) for camera_row in samples[camera])
    lines.append(f"Activation {iteration}: RTC PID {result['rtc']['pid']}, unit start to Ready {result['ready_seconds']:.3f} s, RTC ExecStart to active {result['exec_start_to_active_seconds']:.3f} s, systemd Stop {result['quit_seconds']:.3f} s. Actual physical-offset samples: "+", ".join(f"{r['name']} #{r['sequence']} at {int(r['model_ns'])/1e6:g} ms" for r in offsets)+".")
    lines.append(f"All 10 RTC-owned Link serials were {result['links'][0]}–{result['links'][-1]}, and retired on Quit.")
assert results[0]["core"]==results[1]["core"] and results[0]["hil"]==results[1]["hil"]
assert len(set(results[0]["links"]) & set(results[1]["links"]))==0
old,new=results
between=[row for row in rows if old["exit_ns"] < int(row["observed_ns"]) < new["start_ns"]]
lines += [f"Core PID {old['core']['pid']} and HIL PID {old['hil']['pid']} retained process and native source identities.",
          f"RTC absent {(new['start_ns']-old['exit_ns'])/1e9:.3f} s; actual camera observations: "+", ".join(f"{row['camera']} #{row['sequence']}" for row in between)+"."]
print("\n".join(lines))
