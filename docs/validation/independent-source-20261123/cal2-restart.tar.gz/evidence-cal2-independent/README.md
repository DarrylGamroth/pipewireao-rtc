# CAL2 independent service replacement validation staging

Scratch input assets come from the sealed CAL2 candidate. Neither the sealed
candidate nor the comparison installation was changed. The private Manifest
changes only two git-tree hashes, preserving the exact versions and all other
dependencies. See `receipts/final-Manifest.patch` and
`receipts/final-export-digests.txt`.

- RTC tree `764219a5109568325223d97dbeaff61758df2976`, the independently
  reviewed external-stream deployment snapshot at scratch commit
  `f15e8e608397836766be6120845286726c2c9611`.
- HIL tree `d0354f40493eefc8e3e9597c690df224d12ee566`, recorded against
  its original base and working changes in `receipts/hil-independent-simulator.*`.
- Julia 1.13.3, PipeWireAO.jl 0.9.6, PipeWireAO native SDK 4.0.8, queue
  artifact `20afa07132938ae663c7cf4c10f00172ca40e70f`.

`final-install` uses normal installation tooling to build the CAL2 LLOWFS and
SCC controller startup caches from these exact package trees. The HIL cache
from the managed paired run is deliberately excluded because its package
identity differs. Its preparation therefore occurs in the independent HIL
service before any RTC activation is timed.

The shipped configuration parser verifies two true CAL2 graphs, ten declared
RTC Links, eight queue modules, two camera sources and a pupil input with no
declared producer. The feeder creates a private synthetic 240×240 timestamped
pupil stream and waits for actual LLOWFS output before the next sample.
Separately owned direct Links observe both real camera outputs continuously.
Per-activation observers attach only to the declared physical-offset queue
outputs.

Run `./run.sh` after `final-install/systemd/pipewireao-session@.service` exists.
The driver acquires `/run/user/1000/rtc-devel-benchmark.lock` before any live
service. It uses only unique scratch units and a new private socket. The CAL2
core leader uses CPU 3 and the sealed affinity for data loops. The simulator
leader uses CPU 6 and its PipeWire loop uses CPU 7. The RTC uses the installed
application's own placement. For each launch the driver records both
systemctl start-to-Ready and MainPID start-to-active, validates the fresh
authenticated session, Start/Stop, physical-offset observation, exact
systemd Quit, and records observed camera advances after the RTC process
and its Links disappear. Both iterations share the same core and simulator
processes and permanent optical Links. Only the named scratch units are
stopped by cleanup.

## Observed CAL2 result

| Activation | RTC PID | Service start to Ready | RTC ExecStart to active | Shutdown |
| --- | ---: | ---: | ---: | ---: |
| 1 | 349780 | 103.976 s | 63.254 s | 51.373 s systemctl wall time |
| 2 | 364285 | 58.287 s | 43.669 s | 41.570 s systemd Stopping-to-Stopped journal interval |

Both activations reached authenticated Ready and Running, received finite
real physical-offset buffers and completed native Stop and Quit. Both
controller startup caches were mapped. All ten RTC Link serials changed on
replacement and were removed by each Quit. Core PID 341891, HIL PID 341896,
and the permanent sensor and pupil Links remained unchanged. There were
86.442 seconds from the first service exit to the second service start.
During that window the independent observer recorded LLOWFS sequences 23–25
and SCC sequence 5, with the same domains and generations as before exit.
The four actual offset witnesses match their separately observed camera
sequences, model PTS, domains and generations. Demand remained zero in this
non-actuating configuration.

After the second successful Quit, the independent observer received LLOWFS
sequence 42 at a model PTS of 82 ms. The second end-of-run condition requiring
another LLOWFS and SCC advance failed. Pupil 43 entered local source staging and
was retriggered until the feeder's 200-second LLOWFS deadline expired. The core
and source processes were still alive and the three permanent Links were Active
when inspected. The fixture sampled outputs but did not record the source
callback dequeue, receipt at the HIL ingress or publication at HIL egress for
pupil 43. The failure can therefore be localized to this offered sample's
unconfirmed transport and execution path, without identifying which stage
stopped advancing. The native dump contains queue counters for the controller
outputs while Running and Link/Node state for the permanent paths. The HIL
ports do not expose per-sample native counters in that dump.

`partial-outcome.json` records the successful lifecycle and data checks, plus
the failed final condition. `feed.log` contains the timeout. `camera-trace.tsv`,
each activation's `offset-trace.tsv`, pre/post native snapshots and launch
ledgers provide the underlying evidence. `attempt-1` preserves the prior
scratch-direct-observer negotiation failure. The successful camera negotiation
used the exact source buffers and added the required optical chopping and
electrical trigger metadata to the SCC observer.

The frozen RTC package predates commit `057544f`'s additional pre-start Core PID
probe. See `receipts/frozen-vs-057544f.patch`. Native session admission in the
frozen package still verifies the expected core process. The normal Julia
packages and both graph startup caches were prepared before measurement.
Neither Ready timing includes preparing a new CAL2 optical owner. The two
timings are observations of this private deployment on this workstation.
