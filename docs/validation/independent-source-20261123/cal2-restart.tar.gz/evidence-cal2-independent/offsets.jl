using PipeWireAORTC, PipeWireAO
include(joinpath(ARGS[4],"sealed_application_flow.jl"))
app,remote,destination=ARGS[1:3]
specs,_=probe_specs("cal2",app)
selected=("llowfs-physical-offset","scc-physical-offset")
out=joinpath(destination,"offset-trace.tsv")
mkpath(destination)
rows=NamedTuple[]
seen=Dict{String,UInt64}()
accepted = Threads.Atomic{Bool}(false)
cutoff = Dict{String,Int64}()
function ready()
    touch(joinpath(destination,"offsets-ready"))
    running=joinpath(destination,"running.json")
    timedwait(() -> isfile(running) && filesize(running)>0,120;pollint=0.01)==:ok ||
        error("No authenticated RTC Start acknowledgement")
    started=RTC.Common.read_json(running)["observed_ns"]
    for line in Iterators.drop(eachline(joinpath(dirname(destination),"camera-trace.tsv")),1)
        name,_,pts,_,_,host=split(line,'\t')[1:6]
        parse(UInt64,host)<=started || continue
        spec=replace(name,"cal2-"=>"")*"-physical-offset"
        cutoff[spec]=parse(Int64,pts)
    end
    @assert all(k -> haskey(cutoff,k),selected)
    accepted[]=true
    return nothing
end
done(captures)=all(spec -> get(seen,spec,0)>0,selected)
function wrap(capture,spec)
    return stream -> capture(stream;on_metadata = (cap,metadata) -> begin
        cap.finite || error("Nonfinite physical offset")
        id=cap.identity
        sequence=cap.header.sequence
        if accepted[] && cap.header.pts>cutoff[spec.name] && get(seen,spec.name,0)==0
            seen[spec.name]=sequence
            push!(rows,(name=spec.name,sequence,model_ns=cap.header.pts,identity=id,
                observed_ns=time_ns(),max_abs=maximum(abs,cap.values)))
        end
    end)
end
record=try
    observe_classic(remote; timeout=650., selected_streams=selected,
        stream_specs=specs,process_capture=wrap,on_ready=ready,
        finished=done)
finally
    open(out,"w") do trace
        println(trace,"name\tsequence\tmodel_ns\tgeneration\tdomain\tobserved_ns\tmax_abs")
        for row in rows
            id=row.identity
            println(trace,join((row.name,row.sequence,row.model_ns,
                id===nothing ? "" : id.generation,id===nothing ? "" : bytes2hex(collect(id.domain.bytes)),
                row.observed_ns,row.max_abs),'\t'))
        end
    end
end
RTC.Common.write_json(joinpath(destination,"offsets.json"),record;atomic=true)
