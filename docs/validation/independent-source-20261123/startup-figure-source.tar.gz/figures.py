"""Render the CAL2 startup diagrams from the two retained evidence archives."""
from pathlib import Path
import sys,json,tarfile,re
from decimal import Decimal
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
from matplotlib.transforms import blended_transform_factory

root=Path(sys.argv[1])
def contents(archive,name,mode='json'):
    with tarfile.open(root/archive) as t:
        raw=t.extractfile(name).read()
    return json.loads(raw) if mode=='json' else raw.decode()
a='cal2-restart.tar.gz'
prefix='evidence-cal2-independent/'
r=contents(a,prefix+'activation-2/result.json')
journal=contents(a,prefix+'journal.txt','str')
b='startup-attribution.tar.gz'
graphs={x['role']:x for x in contents(b,'prior-graph-events.json') if x['activation']==2}
def get_stamp(token):
    hits=[float((Decimal(l.split(']')[0][1:])*10**9-r['start_ns'])/Decimal(10**9))
          for l in journal.splitlines() if token in l and l.startswith('[')]
    return next(x for x in hits if 0<x<r['ready_seconds'])
main=(int(r['systemd']['ExecMainStartTimestampMonotonic'])*1000-r['start_ns'])/1e9
bounds=[0,main,get_stamp('Waiting for RTC control endpoint'),get_stamp('Waiting for owner preparation and RTC warmup'),
        get_stamp('RTC warmup completed'),r['ready_seconds']]
assert all(y>x for x,y in zip(bounds,bounds[1:]))
assert abs(sum(y-x for x,y in zip(bounds,bounds[1:]))-r['ready_seconds'])<1e-6
ink='#172d3d'; muted='#445d6c'; faint='#dce4e8'; teal='#137677'; orange='#a34d21'; blue='#345d83'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'text.color':ink,'xtick.color':muted,'ytick.color':muted,
                     'axes.edgecolor':faint,'axes.labelcolor':muted,'savefig.facecolor':'white','figure.facecolor':'white'})
fig=plt.figure(figsize=(12.2,5.45))
fig.text(.035,.925,'CAL2 restart to Ready',fontsize=22,fontweight='bold')
fig.text(.035,.868,'Elapsed time from the service start request. The independent simulator was already publishing.',fontsize=12,color=muted)
ax=fig.add_axes([.156,.243,.805,.536])
ax.set(xlim=(-.2,60.4),ylim=(-.12,4.55))
for edge in ax.spines.values():edge.set_visible(False)
ax.set_yticks([]); ax.set_xticks(range(0,61,10));ax.tick_params(axis='x',length=0,pad=8)
ax.set_xlabel('Seconds since start request',labelpad=9)
for x in range(0,61,10):ax.vlines(x,-.03,4.05,color=faint,lw=.8,zorder=0)
ax.axhline(-.03,color='#9eafb8',lw=1)
coords=blended_transform_factory(ax.transAxes,ax.transData)
for y,name in ((3.72,'Service'),(2.56,'RTC process'),(1.60,'SCC graph'),(.75,'LLOWFS graph')):
    ax.text(-.026,y,name,transform=coords,ha='right',va='center',fontsize=12,fontweight='bold',clip_on=False)
colors=['#355772','#3d6b87','#39656a','#276467','#214b59']
for lo,hi,lab,c in zip(bounds,bounds[1:],('Start controllers','Open RTC control','Connect','Check links and hold','Confirm Ready'),colors):
    ax.add_patch(Rectangle((lo,3.47),hi-lo,.5,color=c,ec='white',linewidth=1.2))
    ax.text((lo+hi)/2,3.72,lab,color='white',fontsize=9.2,ha='center',va='center',fontweight='bold')
for x in bounds:
    ax.text(x,4.10,f'{x:.2f}' if x else '0',ha='center',va='bottom',fontsize=9,color=muted)
ax.plot([main,bounds[-1]],[2.56]*2,color=blue,lw=2)
ax.scatter([main,bounds[-1]],[2.56]*2,s=34,color=blue,zorder=4)
ax.annotate('Process starts',(main,2.56),xytext=(3,-15),textcoords='offset points',size=9,color=blue)
ax.annotate('Ready confirmed¹',(bounds[-1],2.56),xytext=(-2,9),textcoords='offset points',size=9,
            color=blue,ha='right')
last_end=0
for name,y in [('cal2-scc',1.60),('cal2-llowfs',.75)]:
    g=graphs[name];assert g['start_ns']==r['start_ns'] and g['ready_ns']==r['ready_ns']
    def matching(phrase):
        return [(v['t_ns']-r['start_ns'])*1e-9 for v in g['events'] if phrase in v['message']]
    launch=matching('Started pipewireao-owner')[0]
    prep0,prep1=matching('phase = "prepare graph"')
    _,done=matching('phase = "warm up graph"');last_end=max(done,last_end)
    ax.plot([launch,done],[y,y],color='#809ba4',lw=2,zorder=1)
    ax.scatter(launch,y,s=29,fc='white',ec='#647f8a',lw=1.5,zorder=3)
    ax.plot([prep0,prep1],[y,y],c=teal,lw=8,solid_capstyle='butt',zorder=4)
    ax.scatter(done,y,marker='D',color=orange,s=40,zorder=4)
    warm_logged=[float(e['message'].split('=')[-1]) for e in g['events'] if 'wall_seconds =' in e['message']][-1]
    ax.annotate(f'{done:.2f} s   ·   call took {warm_logged*1000:.2f} ms',(done,y),xytext=(8,0),textcoords='offset points',va='center',color=orange,fontsize=10)
ax.annotate('',xy=(last_end,.15),xytext=(bounds[-1],.15),arrowprops={'arrowstyle':'|-|','lw':1.15,'color':muted,'shrinkA':0,'shrinkB':0})
ax.text((last_end+bounds[-1])/2,.28,f'{bounds[-1]-last_end:.2f} s from last graph warmup to service Ready',ha='center',fontsize=10,color=muted)
fig.legend([Line2D([],[],marker='o',mfc='white',mec='#647f8a',ls=''),Line2D([],[],c=teal,lw=6),
            Line2D([],[],marker='D',c=orange,ls='')],['Graph process starts','Graph preparation','Numerical warmup finishes'],
           loc='center',bbox_to_anchor=(.505,.101),frameon=False,ncol=3,fontsize=10,handlelength=1.3)
fig.text(.035,.037,'¹ Service start returned after native Admit and a fresh Ready status. The exact instant of the internal transition was not logged.',
         fontsize=9,color=muted)
fig.savefig(root/'cal2-timeline.png',dpi=150);plt.close(fig)

leaders=contents(b,'leaders.json')
results=[row for row in leaders if 'leaders' in row]
fig=plt.figure(figsize=(13.1,5.8))
fig.text(.035,.912,'CPU execution and scheduler wait',fontsize=21,fontweight='bold')
fig.text(.035,.85,'Two further CAL2 starts, with the same settings. A reached Ready in 190.9 s. B reached Ready in 37.8 s.',fontsize=11.2,color=muted)
ax=fig.add_axes([.333,.203,.625,.493])
ax.set_ylim(-.58,5.8);ax.set_xlim(0,146)
for ed in ax.spines.values():ed.set_visible(False)
ax.set_yticks([]);ax.set_xticks(range(0,131,20));ax.tick_params(axis='x',length=0)
ax.set_xlabel('Seconds accumulated by that thread',labelpad=8)
for x in range(0,131,20):ax.axvline(x,color=faint,lw=.7,zorder=0)
roles=('prepare','RTC','publish');label={'prepare':'Start the controller processes','RTC':'Connect and control the session','publish':'Verify and announce Ready'}
meaning={'prepare':'Find the source and core. Launch SCC and LLOWFS.', 'RTC':'Connect ports. Handle Start, Stop and Reset.', 'publish':'Check identity and placement. Confirm Ready.'}
tr=blended_transform_factory(ax.transAxes,ax.transData)
for y,role in zip((4.8,2.75,.70),roles):
    ax.text(-.064,y+.02,label[role],ha='right',va='center',transform=tr,weight='bold',size=12,clip_on=False)
    ax.text(-.064,y-.59,meaning[role],ha='right',va='center',transform=tr,size=9.2,color=muted,clip_on=False)
    for record,dy in zip(results,(0,-.72)):
        cpu=record['leaders'][role]['cpu_s'];wait=record['leaders'][role]['runqueue_s'];yp=y+dy
        ax.barh(yp,cpu,.38,color=blue);ax.barh(yp,wait,.38,left=cpu,color='#d19a65')
        ax.text(-.014,yp,'A' if dy==0 else 'B',va='center',ha='right',transform=tr,size=10,color=ink,weight='bold')
        ax.text(cpu+wait+1.15,yp,f'{cpu:.1f} + {wait:.1f}',va='center',fontsize=9.4,color=ink)
fig.legend([Rectangle((0,0),1,1,color=blue),Rectangle((0,0),1,1,color='#d19a65')],
        ['Executing on CPU','Runnable, waiting for CPU'],loc='center',bbox_to_anchor=(.51,.756),frameon=False,ncol=2,fontsize=10.5)
fig.text(.035,.047,'Each bar covers one main thread. The last two processes overlap in time. Sleeping and I/O waits are excluded.',fontsize=9.7,color=muted)
fig.savefig(root/'cal2-cpu-wait.png',dpi=150);plt.close(fig)

# Trace Event format uses microseconds. Logical lanes identify services, not OS threads.
events=[]
def meta(tid,name):
    events.append(dict(ph='M',pid=1,tid=tid,name='thread_name',args={'name':name}))
def span(tid,name,lo,hi,**args):
    events.append(dict(ph='X',cat='elapsed',pid=1,tid=tid,name=name,ts=round(lo*1e6,3),
                       dur=round((hi-lo)*1e6,3),args=args))
def point(tid,name,at,**args):
    events.append(dict(ph='i',s='t',cat='journal',pid=1,tid=tid,name=name,ts=round(at*1e6,3),args=args))
events.append(dict(ph='M',pid=1,tid=0,name='process_name',args={'name':'CAL2 replacement RTC · timed activation 2'}))
for i,name in enumerate(('Service milestones','RTC process','SCC graph','LLOWFS graph'),1):
    meta(i,name)
explanations=[
    ('Prepare','Validate the deployment, identify external services, launch graph owners and write the current RTC configuration.','Bind a fresh RTC to the intended owners.'),
    ('Initialize','RTC and publication helper start; the RTC opens its control path and the helper checks the process and launch record.','Establish a command endpoint for this RTC.'),
    ('Connect to RTC control','Connect to the expected process and control instance.','Correlate commands and replies with the current RTC.'),
    ('Check session preparation','Observe the Warmup reply after owner connection, Link setup and initial graph Hold.','Allow admission only after the declared session is connected and held.'),
    ('Admit and publish Ready','Check placement and identity; require successful Admit and Status, then publish discovery.','Expose the confirmed live session to operators.')]
for i,(name,operation,purpose) in enumerate(explanations):
    span(1,name,bounds[i],bounds[i+1],activity=operation,purpose=purpose)
span(2,'RTC lifetime shown through service Ready',main,bounds[-1])
point(2,'Control dispatch preparation completed (journal)',get_stamp('wall_seconds = 0.000759623'),measured_call_ms=0.759623)
for i,name in [(3,'cal2-scc'),(4,'cal2-llowfs')]:
    g=graphs[name]
    lane=[((e['t_ns']-r['start_ns'])*1e-9,e['message']) for e in g['events']]
    point(i,'Controller process starts',next(t for t,m in lane if m.startswith('Started pipewireao-owner')))
    for phase in ('load FilterGraphPipeWire','prepare graph','warm up graph'):
        p=[j for j,(_,m) in enumerate(lane) if m.endswith('phase = "'+phase+'"')]
        start,end=lane[p[0]][0],lane[p[1]][0]
        reported=float(lane[p[1]+1][1].split('=')[-1])
        compiled=float(lane[p[1]+2][1].split('=')[-1])
        span(i,phase+' (journal interval)',start,end,measured_call_ms=reported*1000,
             compilation_within_call_ms=compiled*1000,
             timing='Slice uses journal receipt times. The call timer is in the arguments.')
point(1,'Service start returned',bounds[-1])
trace=dict(displayTimeUnit='ms',traceEvents=events)
(root/'cal2-timeline.trace.json').write_text(json.dumps(trace,indent=2,ensure_ascii=False)+'\n')
