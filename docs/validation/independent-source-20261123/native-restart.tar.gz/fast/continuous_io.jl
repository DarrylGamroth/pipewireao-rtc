const RATE = 100
const PERIOD = Int64(10_000_000)
const SCHEMA = "org.pipewireao.test.persistent-source/1"
const DOMAIN = AcquisitionDomain(ntuple(UInt8,16))
const WireReceipt = NamedTuple{(:sequence,:model_ns,:observed_ns),Tuple{UInt64,Int64,UInt64}}
struct Capture
    buffer::StreamBuffer
    frames::Vector{WireReceipt}
    callbacks::Threads.Atomic{Int}
    buffers::Threads.Atomic{Int}
    without_header::Threads.Atomic{Int}
end
Capture() = Capture(StreamBuffer(),WireReceipt[],Threads.Atomic{Int}(0),Threads.Atomic{Int}(0),Threads.Atomic{Int}(0))
function (capture::Capture)(stream)
    Threads.atomic_add!(capture.callbacks,1)
    dequeue_buffer!(capture.buffer,stream) || return nothing
    Threads.atomic_add!(capture.buffers,1)
    try
        header=buffer_header(capture.buffer)
        if header !== nothing && header.sequence != 0
            push!(capture.frames,(sequence=header.sequence,model_ns=header.pts,observed_ns=time_ns()))
        else
            Threads.atomic_add!(capture.without_header,1)
        end
    finally
        queue_buffer!(capture.buffer,stream)
    end
    return nothing
end
function array_format()
    NdArrayFormat(NdArray.F32_LE,(2,); layout=NdArray.ROW_MAJOR,rate=SPA.Fraction(RATE,1))
end
function sink_parameters()
    return (Pod(buffers_param(buffers=2,blocks=1,size=8,metadata_types=Int32(1 << PipeWireAO.LibPipeWire.SPA_META_Header))),
        Pod(header_metadata_param()),
        Pod(metadata_param(MetadataRequirement(SPA.META_ACQUISITION_IDENTITY))),
        Pod(metadata_param(MetadataRequirement(SPA.META_EXPOSURE_TIMING))),
        Pod(metadata_param(MetadataRequirement(SPA.META_REFERENCE_TIMESTAMP))))
end
struct SinkParameters{P}
    buffers::P
end
function (callback::SinkParameters)(stream,id,parameter)
    id==SPA.PARAM_FORMAT && parameter!==nothing && update_params!(stream,callback.buffers)
    return nothing
end
function open_sink(core,name,capture)
    buffers=sink_parameters()
    sink=Stream(core,name;properties=Dict("node.name"=>name,"media.type"=>"Application",
        "media.category"=>"Capture","media.role"=>"Analysis"),on_process=capture,
        on_param_changed=SinkParameters(buffers))
    precompile(sink.callbacks.on_param_changed,(typeof(sink),UInt32,Pod))
    connect!(sink,:input;flags=STREAM_MAP_BUFFERS|STREAM_INACTIVE|STREAM_DONT_RECONNECT|STREAM_NO_CONVERT,
        params=(ndarray_format(array_format();schema=SCHEMA),buffers...))
    return sink
end
