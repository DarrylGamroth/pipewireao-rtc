using PipeWireAO
include("continuous_io.jl")
function run_owner(remote, stop_path)
    loop=ThreadLoop("continuous RTC test source")
    ctx=Context(loop)
    core=CoreConnection(ctx;properties=Dict("remote.name"=>remote))
    source=NdArraySource(core,"restart-test-source",zeros(Float32,2),array_format();schema=SCHEMA,properties=Dict("node.output-mode"=>"fast"))
    capture=Capture()
    sink=open_sink(core,"restart-test-sink",capture)
    start!(loop)
    start!(source)
    with_thread_loop_lock(_ -> set_active!(sink,true),loop)
    started=false
    sequence=UInt64(0)
    values=zeros(Float32,2)
    println("source and sink connected")
    flush(stdout)
    try
        while !isfile(stop_path)
            if !started
                started=with_thread_loop_lock(_ -> is_driving(source.stream) && stream_state(source.stream)==PipeWireAO.LibPipeWire.PW_STREAM_STATE_STREAMING,loop)
                if !started
                    sleep(0.005)
                    continue
                end
            end
            sequence+=1
            values[1]=Float32(sequence)
            pts=Int64(sequence-1)*PERIOD
            header=BufferHeader(0,0,pts,0,sequence)
            token=submit_array!(source,values,header;identity=AcquisitionIdentity(DOMAIN,UInt64(1),sequence),
                exposure_duration_ns=UInt64(PERIOD))
            wait_array_source!(source,token;timeout_ns=Int64(15_000_000_000))
            sleep(PERIOD / 1e9)
        end
    finally
        frames=with_thread_loop_lock(_ -> copy(capture.frames),loop)
        open(joinpath(@__DIR__,"rtc-sink-trace.tsv"),"w") do trace
            println(trace,"sequence\tmodel_ns\tobserved_ns")
            for frame in frames
                println(trace,frame.sequence,'\t',frame.model_ns,'\t',frame.observed_ns)
            end
        end
        println((;last_sequence=sequence,sink_samples=length(capture.frames),sink_callbacks=capture.callbacks[],sink_buffers=capture.buffers[],sink_without_header=capture.without_header[]))
        flush(stdout)
        with_thread_loop_lock(loop) do _
            close(sink)
            close(source)
        end
        stop!(loop)
        close(core)
        close(ctx)
        close(loop)
    end
end
run_owner(ARGS...)
