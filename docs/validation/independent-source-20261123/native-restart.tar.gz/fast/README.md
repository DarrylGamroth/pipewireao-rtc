# RTC replacement with a continuously publishing source and a receiving RTC Link

Run from the rtc-continuous-input checkout at
`8ebb1b4146e7eabea4cdbea4adc9d26066bd0b69` with its Manifest, Julia 1.13.4 and
the native PipeWireAO SDK supplied by PipeWireAO.jl 0.9.6.

```sh
taskset -c 10,11 julia --startup-file=no --threads=1,0 --project=. -e 'using PipeWireAORTC, PipeWireAO'
taskset -c 10,11 julia --startup-file=no --threads=1,0 -O0 --project=. \
  /tmp/rtc-persistent-restart-review/fast/continuous_probe.jl 3
```

The probe stages the normal generated RTC launcher and starts a fresh process
on each iteration. The `-O0` flag applies to the probe and synthetic owner only.
The native protocol and process checks use monotonic wall time and scoped native identities.
The same private core and independent publisher/sink process remain alive,
with stable process start ticks, authenticated client IDs, node and port
serials. A permanent observer Link sees the same publisher output as the
separate, newly admitted RTC Link on each iteration.

| RTC process | Launch to discovery | Launch to warmed | Launch to native Ready | Sink frames during Running | Quit to exit |
| --- | ---: | ---: | ---: | ---: | ---: |
| 263414 | 3.498 s | 7.206 s | 8.612 s | 112 | 1.846 s |
| 263655 | 3.210 s | 6.851 s | 8.187 s | 118 | 1.778 s |
| 263841 | 3.216 s | 6.912 s | 8.288 s | 119 | 1.662 s |

The sink received 1,220 Header-bearing buffers across all admitted RTC Links,
each with a matching sequence and model PTS on the permanent observer. Both
links were Active during Running. Between the first two coordinator exits and
relaunches, the observer received 38 samples in 426 ms and 11 in 128 ms. Sequence
and model time advanced through both coordinator absences. The observer had
eight skipped records over the full observation period, none within those
absence windows.

The fixture explicitly sets the publisher's existing `node.output-mode` to
`fast` to exercise same-port fan-out. The original reliable-mode trial had two
Active links and a Running target sink, but that sink had no callbacks or
buffers while the always-ready first peer received every frame. The tagged
4.0.8 reliable output hands each buffer to the first eligible peer. The
refcounted trial with this specific NdArraySource harness replayed stale
buffers and failed its advance check. Neither of those fixture variants is
included in the passing evidence. No native or RTC production source changed.

`results.txt` records native lifecycle timings, process identities and
monotonic boundaries. `running-dump-*.json` records both native Links while
Running. The two TSV traces contain each receiver's Header sequence, model
PTS and host receipt timestamp. `summary.txt` records both Running windows
and the interval between the old process exit and the next launch.

This non-actuating test is scoped to functional native transport and
coordinator replacement. There is no correction graph, optical plant,
systemd deployment or hardware under test.
