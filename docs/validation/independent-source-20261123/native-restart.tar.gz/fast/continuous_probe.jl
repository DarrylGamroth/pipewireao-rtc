using PipeWireAORTC, PipeWireAO, UUIDs
const C = PipeWireAORTC.ControlClient
const S = PipeWireAORTC.SessionCodec
const L = PipeWireAORTC.SessionCLI
const E = PipeWireAORTC.ScienceExport
const D = PipeWireAORTC.DeploymentConfiguration
const PROJ = realpath(dirname(Base.active_project()))
const SRC = pkgdir(PipeWireAORTC)
include("continuous_io.jl")
const JULIA = realpath(Base.julia_cmd().exec[1])
const ART = @__DIR__
const NODE = "pipewireao.rtc.session.persistent-restart"
const names = ("restart-test-source", "restart-test-sink", "restart-test-observer")
const schema = SCHEMA
include(joinpath(SRC,"test","control_private_core.jl"))
ENV["PIPEWIREAO_PREFIX"] = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
ENV["JULIA_PKG_PRECOMPILE_AUTO"] = "0"
proc_ticks(pid) = parse(Int, split(split(read("/proc/$pid/stat",String), ") "; limit=2)[2])[20])
seconds(since) = (time_ns() - since) / 1e9
function config(socket, directory, corepid, ownerpid, iteration, output_port, input_port)
    uuid = string(uuid4())
    instances = [500 + iteration*10 + i for i in 1:3]
    port_record(port, dir) = Dict("name"=>port, "direction"=>dir,
        "element-type"=>"F32_LE", "shape"=>[2], "schema"=>schema)
    port_owner(name, port, dir) = Dict("node.name"=>name, "ownership"=>"external",
        "ports"=>[port_record(port,dir)])
    source = Dict("role"=>"fixture","pid"=>ownerpid,"control-protocol"=>"external-stream")
    policy = Dict(
        "instance"=>string(instances[1]),
        "controller.instance"=>string(instances[2]),
        "admission.controller-instance"=>string(instances[3]),
        "node.name"=>NODE,
        "controller.node.name"=>"pipewireao.rtc.controller.persistent-restart",
        "startup.timeout-ms"=>120000,
        "session.uuid"=>uuid,
        "properties"=>Dict("pipewireao.rtc.session.session-uuid"=>uuid),
        "core.owner"=>Dict("pid"=>corepid,"nodes"=>String[]),
        "owners"=>[], "node.pids"=>Dict(name=>ownerpid for name in names[1:2]),
        "source"=>source,
        "session"=>Dict(
            "rate"=>"100/1", "execution"=>"external-rtc", "authority"=>"none",
            "sources"=>[port_owner(names[1],output_port,"output")], "graphs"=>[],
            "sinks"=>[port_owner(names[2],input_port,"input")],
            "links"=>[Dict("output"=>names[1]*":"*output_port,"input"=>names[2]*":"*input_port)]))
    full = Dict(
        "context.properties"=>Dict("remote.name"=>socket,"library.use-fallback"=>false,"support.dbus"=>false),
        "context.modules"=>[Dict("name"=>m) for m in
            ("libpipewire-module-protocol-native","libpipewire-module-client-node")],
        "pipewireao.session"=>policy)
    path = joinpath(directory,"session-$iteration.conf")
    E.write_spa_config(path,full)
    return path, uuid, instances
end
function snapshot(loop, registry)
    with_thread_loop_lock(loop) do _
        [(id=o.id, interface=o.type, props=copy(o.properties)) for o in globals(registry)]
    end
end
objects(snapshot, kind) = filter(o -> o.interface == "PipeWire:Interface:"*kind, snapshot)
function node(snapshot, name)
    only(filter(o -> get(o.props,"node.name","")==name,objects(snapshot,"Node")))
end
function port(snapshot, id)
    only(filter(o -> get(o.props,"node.id","")==string(id),objects(snapshot,"Port")))
end
identity(o) = (;o.id, serial=parse(Int, o.props["object.serial"]))
function owner_client(snap, o)
    client=only(filter(c -> string(c.id) == o.props["client.id"],objects(snap,"Client")))
    return (; identity=identity(client),pid=parse(Int,client.props["pipewire.sec.pid"]))
end
function owners(snapshot)
    data = map(name -> node(snapshot, name), names)
    return (; nodes=map(identity,data), ports=map(o -> identity(port(snapshot,o.id)),data),client=map(o -> owner_client(snapshot,o),data))
end
function sample(socket, directory, corepid, ownerpid, loop, registry, iteration, output, input, persistent, peer, capture)
    path, uuid, instances = config(socket, directory, corepid, ownerpid, iteration,
        output.props["port.name"],input.props["port.name"])
    cp(path, joinpath(ART,"continuous-"*basename(path));force=true)
    log = open(joinpath(ART,"continuous-rtc-$iteration.log"),"w+")
    command = addenv(Cmd([joinpath(E.stage_rtc!(directory),"bin/pipewireao-rtc"),"-c",path]),
        "PIPEWIREAORTC_JULIA"=>JULIA, "PIPEWIREAORTC_PROJECT"=>PROJ)
    at_launch = last_capture(loop,capture)
    start = time_ns()
    child = run(pipeline(command; stdout=log, stderr=log);wait=false)
    pid = getpid(child)
    client = nothing
    try
        stamp = proc_ticks(pid)
        deadline = C.monotonic() + 120
        client = C.connect(PipeWireAORTC.SessionProfile.Profile(),socket,NODE,pid,instances[1];
            deadline, controller_instance=instances[3],
            check=() -> (Base.process_exited(child) && error("RTC exited during control discovery")))
        discovered = seconds(start)
        D.verify_session_process(pid, Dict("julia"=>JULIA, "project"=>PROJ,
            "config"=>path, "argv"=>E.rtc_arguments(JULIA,PROJ,path)))
        while !L.warmup_complete(C.request!(client,S.WarmupCommand();deadline))
            C.monotonic() < deadline || error("warmup deadline")
            sleep(0.1)
        end
        warmed = seconds(start)
        L.confirm_admission(C.request!(client,S.AdmitCommand();deadline))
        admitted = seconds(start)
        L.confirm_ready(C.request!(client,S.RunnerCommand(:status);deadline))
        ready = seconds(start)
        sid = with_thread_loop_lock(client.loop) do _
            C.healthy(client)
            @assert client.observation.node_identity == uuid
            @assert client.observation.owner_pid == UInt32(pid)
            @assert client.observation.instance == instances[1]
            (;pid, stamp, uuid, instance=instances[1], id=client.global_id, serial=client.serial)
        end
        observed = snapshot(loop,registry)
        @assert owners(observed) == persistent
        at_ready = last_capture(loop,capture)
        @assert at_ready.sequence > at_launch.sequence && at_ready.model_ns > at_launch.model_ns
        links = filter(o -> identity(o) != peer,objects(observed,"Link"))
        link = only(links)
        @assert link.props["link.output.port"] == string(output.id)
        @assert link.props["link.input.port"] == string(input.id)

        started = C.request!(client,S.RunnerCommand(:session_start);deadline=C.monotonic()+15)
        @assert started.lifecycle == PipeWireAORTC.RunnerCodec.Running && started.header.result == 0
        running_ns=time_ns()
        sdk=ENV["PIPEWIREAO_PREFIX"]
        dump=joinpath(sdk,"bin/pwao-dump")
        command=`$dump --remote $socket`
        open(io -> run(pipeline(command;stdout=io)),joinpath(ART,"running-dump-$iteration.json"),"w")
        wait_proof(() -> last_capture(loop,capture).sequence > at_ready.sequence + 150, 8,"source advances in Running")
        stop_ns=time_ns()
        stopped = C.request!(client,S.RunnerCommand(:session_stop);deadline=C.monotonic()+15)
        L.confirm_ready(C.request!(client,S.RunnerCommand(:status);deadline=C.monotonic()+15))
        @assert stopped.lifecycle == PipeWireAORTC.RunnerCodec.Ready && stopped.header.result == 0
        before_quit = last_capture(loop,capture)
        quit_start = time_ns()
        L.confirm_shutdown(C.request!(client,S.RunnerCommand(:quit);deadline=C.monotonic()+15))
        quit_ack = seconds(quit_start)
        timedwait(() -> Base.process_exited(child),15;pollint=0.002)==:ok || error("RTC did not exit")
        @assert success(child)
        exit_ns = time_ns()
        exited = seconds(quit_start)
        wait_proof(5, "old RTC endpoint and Link retirement") do
            snap = snapshot(loop,registry)
            @assert owners(snap) == persistent
            no_rtc = !any(o -> o.id==sid.id && get(o.props,"object.serial","")==string(sid.serial),snap)
            return no_rtc && map(identity,objects(snap,"Link")) == [peer]
        end
        after_exit = last_capture(loop,capture)
        wait_proof(() -> last_capture(loop,capture).sequence >= after_exit.sequence + 10,
            5, "data advanced while RTC was absent")
        after_absence = last_capture(loop,capture)
        @assert after_absence.model_ns > after_exit.model_ns
        @assert after_absence.sequence > before_quit.sequence
        result = (;iteration, discovered, warmed, admitted, ready, quit_ack, exited, sid, link=identity(link),
            launch_ns=start,running_ns,stop_ns,quit_ns=quit_start,exit_ns,at_launch,at_ready,before_quit,after_exit,after_absence)
        println(result)
        flush(stdout)
        return result
    finally
        client === nothing || close(client)
        stop_proof_child!(child,"isolated RTC coordinator")
        close(log)
    end
end

function last_capture(loop,capture)
    with_thread_loop_lock(loop) do _
        isempty(capture.frames) ? nothing : last(capture.frames)
    end
end
function run_probe()
    with_control_private_core(temporary_prefix="rtc-continuous-review-") do socket, directory, daemon
        chmod(dirname(socket),0o700)
        stop_path = joinpath(directory,"stop-owner")
        owner_log = open(joinpath(ART,"continuous-owner.log"),"w+")
        owner = run(pipeline(`$JULIA --startup-file=no --threads=1,0 -O0 --project=$PROJ $(joinpath(ART,"continuous_owner.jl")) $socket $stop_path`;
            stdout=owner_log,stderr=owner_log);wait=false)
        lo = ThreadLoop("persistent RTC test observer")
        ctx = Context(lo)
        core = CoreConnection(ctx;properties=Dict("remote.name"=>socket))
        reg = Registry(core)
        capture = Capture()
        watcher = open_sink(core,names[3],capture)
        start!(lo)
        with_thread_loop_lock(_ -> set_active!(watcher,true),lo)
        peer_link = nothing
        peer_info = Ref{Any}(nothing)
        try
            corepid, ownerpid = getpid(daemon), getpid(owner)
            coreid=(;pid=corepid, ticks=proc_ticks(corepid), inode=stat(socket).inode)
            ownerid=(;pid=ownerpid, ticks=proc_ticks(ownerpid))
            wait_proof(180,"existing fixture endpoints";
                check=() -> (Base.process_exited(owner) && error("fixture exited during startup"))) do
                snap=snapshot(lo,reg)
                try
                    owners(snap)
                    true
                catch error
                    if length(objects(snap,"Node")) >= 3
                        rethrow(error)
                    end
                    false
                end
            end
            snap = snapshot(lo,reg)
            persistent = owners(snap)
            source, sink = map(name -> node(snap,name),names[1:2])
            output, input = port(snap,source.id), port(snap,sink.id)
            watcher_node = node(snap,names[3])
            watcher_port = port(snap,watcher_node.id)
            peer_link = with_thread_loop_lock(lo) do _
                create_object(core,"link-factory",PipeWireAO.Link;properties=Dict(
                    "link.output.node"=>string(source.id),"link.output.port"=>string(output.id),
                    "link.input.node"=>string(watcher_node.id),"link.input.port"=>string(watcher_port.id),
                    "link.passive"=>"false","object.linger"=>"false","object.path"=>"persistent-review-observer"), on_info=(_,info)->(peer_info[]=info))
            end
            try
                wait_proof(() -> last_capture(lo,capture) !== nothing,20,"first publication through independent observer Link";
                    check=() -> (Base.process_exited(owner) && error("continuous owner exited")))
            catch
                @show peer_info[]
                rethrow()
            end
            peer = identity(only(objects(snapshot(lo,reg),"Link")))
            println((;VERSION,rtc=Base.pkgversion(PipeWireAORTC),pipewire=Base.pkgversion(PipeWireAO),
                coreid,ownerid,persistent,peer))
            previous = nothing
            count = isempty(ARGS) ? 4 : parse(Int,only(ARGS))
            for iteration in 1:count
                result = sample(socket,directory,corepid,ownerpid,lo,reg,iteration,output,input,persistent,peer,capture)
                @assert (;pid=getpid(daemon), ticks=proc_ticks(corepid), inode=stat(socket).inode) == coreid
                @assert (;pid=getpid(owner), ticks=proc_ticks(ownerpid)) == ownerid
                if previous !== nothing
                    @assert result.sid.pid != previous.sid.pid
                    @assert result.sid.serial != previous.sid.serial
                    @assert result.link.serial != previous.link.serial
                end
                previous = result
            end
            
        finally
            touch(stop_path)
            timedwait(() -> Base.process_exited(owner),5;pollint=0.01)
            stop_proof_child!(owner,"persistent synthetic source")
            with_thread_loop_lock(lo) do _
                trace=copy(capture.frames)
                open(joinpath(ART,"continuous-frame-trace.tsv"),"w") do log
                    println(log,"sequence\tmodel_ns\tobserved_ns")
                    foreach(f -> println(log,f.sequence,'\t',f.model_ns,'\t',f.observed_ns),trace)
                end
                peer_link===nothing || close(peer_link)
                close(watcher)
                close(reg)
                close(core)
                close(ctx)
            end
            stop!(lo)
            close(lo)
            close(owner_log)
        end
    end
end
run_probe()
