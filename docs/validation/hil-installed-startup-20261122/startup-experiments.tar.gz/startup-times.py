import json, os, re, sys
from pathlib import Path
s=Path(__file__).resolve().parent
profiles={}
for name in ('gpi2','cal2','spiders','spiders-single'):
    trials=[]
    for result in sorted((s/'evidence'/name).glob('*/outcome.json')):
        if (result.parent/'startup-experiment.json').exists() and '--include-experiments' not in sys.argv: continue
        out=json.loads(result.read_text())
        trial=result.parent
        if not out.get('ready_s'): continue
        record=json.loads((trial/'prepared.json').read_text())
        msg=[]
        for line in (trial/'journal.txt').read_text().splitlines():
            m=re.match(r'\[\s*([\d.]+)\]\s+(.+)',line)
            if m:msg.append((float(m[1]),m[2]))
        def stamp(sub):
            return next((v for v,t in msg if sub in t),None)
        def duration(a,b):
            return round(b-a,3) if a is not None and b is not None else None
        unit=out['unit']; simulator=record['owners']['simulator']
        clk=os.sysconf('SC_CLK_TCK')
        start=stamp('Starting '+unit); ready=stamp('Started '+unit)
        stun=stamp('Starting '+simulator['unit']); sexec=int(simulator['start-ticks'])/clk
        rexec=int(record['session_start_ticks'])/clk
        assert abs(stun-sexec)<1, (stun,sexec)
        assert abs(duration(start,ready)-out['ready_s'])<2
        model=stamp('SIMULATOR_PREPARED') if name=='gpi2' else stamp('Optical model prepared')
        prep=stamp('SIMULATOR_PREPARING') if name=='gpi2' else stamp('Preparing optical model')
        warm=stamp('Optical execution warmed up'); warmstart=stamp('Warming up optical execution')
        connected=stamp('SIMULATOR_CONNECTED')
        endpoint=stamp('Waiting for owner preparation and RTC warmup')
        rtcwarm=stamp('RTC warmup completed')
        metrics={'unit':unit,'flow':out.get('flow_pass'),'quit':out.get('quit_pass'),'service_to_ready_s':out['ready_s'],'service_to_RTC_exec_s':duration(start,rexec),'RTC_exec_to_ready_s':duration(rexec,ready),'RTC_exec_to_endpoint_seen_by_client_s':duration(rexec,endpoint),'service_to_simulator_exec_s':duration(start,sexec),'simulator_exec_to_model_prepared_s':duration(sexec,model),'model_prepare_s':duration(prep,model),'simulator_exec_to_connected_s':duration(sexec,connected),'simulator_connected_to_service_ready_s':duration(connected,ready),'simulator_exec_to_optical_warmup_end_s':duration(sexec,warm),'optical_warmup_s':duration(warmstart,warm),'RTC_warmup_ack_to_service_ready_s':duration(rtcwarm,ready)}
        metrics['owner_exec_after_unit_start_s']={role:duration(start,int(v['start-ticks'])/clk) for role,v in record['owners'].items() if v.get('start-ticks')}
        inputs=['Starting '+unit,'Started '+unit,'Waiting for RTC control endpoint','Waiting for owner preparation and RTC warmup','RTC warmup completed','SIMULATOR_PREPARING','SIMULATOR_PREPARED','SIMULATOR_CONNECTED','Preparing optical model','Optical model prepared','Warming up optical execution','Optical execution warmed up']
        metrics['journal_markers_since_service_start_s']={needle:duration(start,stamp(needle)) for needle in inputs if stamp(needle) is not None}
        trials.append(metrics)
    profiles[name]=trials
Path(sys.argv[1]).write_text(json.dumps(profiles,indent=2)+'\n')
