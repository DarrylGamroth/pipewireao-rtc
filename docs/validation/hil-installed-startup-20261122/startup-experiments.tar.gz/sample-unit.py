"""Sample Linux scheduler counters and loaded RTC caches in this test installation's own service."""
import os, sys, time, json, subprocess as sp
from pathlib import Path
s=Path(__file__).resolve().parent
profile,tag=sys.argv[1:]
e=s/'evidence'/profile
known=set(p.name for p in e.iterdir() if (p/'outcome.json').exists())
if tag=='retry': known.update(('f05eba2f28a8',))
limit=time.monotonic()+2400
while time.monotonic()<limit:
    found=[p for p in e.iterdir() if p.is_dir() and p.name not in known and not (p/'outcome.json').exists()]
    if found: break
    time.sleep(.1)
else: raise RuntimeError("no new test invocation")
trial=found[0]
unit='pipewireao-session@'+trial.name+'.service'
target=s/'speed-runs'/(tag+'-'+trial.name+'.jsonl')
group=None
with target.open('w',buffering=1) as out:
    def output(**r): out.write(json.dumps(r,separators=(',',':'))+'\n')
    tables={};pids={}
    while not (trial/'outcome.json').exists() and time.monotonic()<limit:
        if group is None or not group.is_dir():
            p=sp.run(['systemctl','--user','show',unit,'-p','ControlGroup','--value'],capture_output=True,text=True)
            path=p.stdout.strip()
            group=Path('/sys/fs/cgroup')/path.lstrip('/') if path and p.returncode==0 else None
            if group is None or not group.is_dir(): time.sleep(.1);continue
        try: members=list(map(int,(group/'cgroup.procs').read_text().split()))
        except FileNotFoundError: continue
        now=time.monotonic_ns()
        for pid in members:
            proc=Path('/proc')/str(pid)
            try:
                if pid not in pids:
                    args=proc.joinpath('cmdline').read_bytes().split(b'\0')
                    if not args or not args[0]:continue
                    names={b'prepare',b'publish',b'stop',b'cleanup'}
                    role=next((x.decode() for x in args if x in names),Path(os.fsdecode(args[0])).name)
                    pids[pid]=role;tables[pid]={}
                    output(pid=pid,started=now,role=role,exe=os.readlink(proc/'exe'),affinity=sorted(os.sched_getaffinity(pid)))
                th=tables[pid]
                for d in (proc/'task').iterdir():
                    try: th[int(d.name)]=list(map(int,(d/'schedstat').read_text().split()[:2]))
                    except (FileNotFoundError,ProcessLookupError):continue
                if th:
                    output(pid=pid,t=now,main=th.get(pid,[0,0]),total=list(map(sum,zip(*th.values()))))
            except (FileNotFoundError,ProcessLookupError,PermissionError):continue
        time.sleep(.25)
