from pathlib import Path
import contextlib, datetime, fcntl, json, os, secrets, shutil, subprocess as sp, sys, time, traceback
stage = Path(__file__).resolve().parent
xdg = Path(os.environ["XDG_RUNTIME_DIR"])
repo = Path("/home/dgamroth/workspaces/codex/worktrees/rtc-trace-and-startup")
prefix = stage/"depot/artifacts/77da251765f3124df77322c562e67a7c7742ab1d"
def save(p, obj):
    p.write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n")
def system(*args, timeout=30, check=True):
    p = sp.run(["systemctl","--user",*map(str,args)],capture_output=True,text=True,timeout=timeout)
    if check and p.returncode:
        raise RuntimeError(f"systemctl {args}: {p.stderr} {p.stdout}")
    return p.stdout.strip()
def properties(unit):
    names = "ActiveState,SubState,Result,ExecMainStatus,InvocationID,MainPID,FragmentPath"
    return dict(line.split("=",1) for line in system("show",unit,"-p",names).splitlines())
def kill_child(child):
    if child and child.poll() is None:
        child.terminate()
        try: child.wait(6)
        except sp.TimeoutExpired:
            child.kill()
            child.wait()
def run(name):
    app=stage/"installs"/name
    eid=secrets.token_hex(6)
    e=stage/"evidence"/name/eid
    e.mkdir()
    handshake=e/"handshake"
    handshake.mkdir()
    unit="pipewireao-session@"+eid+".service"
    root=xdg/("pipewireao-session-"+eid)
    f=app/"systemd"/unit
    dest=xdg/"systemd/user"/unit
    drop=dest.with_name(unit+".d")
    for path in [f,root,dest,drop]:
        if os.path.lexists(path): raise RuntimeError(f"refusing collision at {path}")
    proc=probe=None
    log_ctl=log_probe=None
    receipt={"profile":name,"unit":unit,"start_utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
    ledger=None
    try:
        shutil.copyfile(f.with_name("pipewireao-session@.service"),f)
        drop.mkdir()
        version="1.13.4" if name=="gpi2" else "1.13.3"
        jbin = Path.home()/f".julia/juliaup/julia-{version}+0.x64.linux.gnu/bin/julia"
        env = dict(JULIA_DEPOT_PATH=str(stage/"depot")+":", JULIA_LOAD_PATH="@:@stdlib",
            JULIA_PKG_PRECOMPILE_AUTO="0",JULIA_NUM_PRECOMPILE_TASKS="1",JULIA_IMAGE_THREADS="1",
            OPENBLAS_NUM_THREADS="1",TMPDIR=str(stage/"tmp"),XDG_CACHE_HOME=str(stage/"cache"),POCL_CACHE_DIR=str(stage/"cache/pocl"))
        (drop/"flow.conf").write_text("[Service]\n"+"".join(f'Environment="{k}={v}"\n' for k,v in env.items()))
        system("link","--runtime",f)
        system("daemon-reload")
        assert Path(properties(unit)["FragmentPath"]).resolve()==f
        print(name,unit,"starting",flush=True)
        t=time.monotonic()
        system("start",unit,timeout=960)
        receipt["ready_s"]=round(time.monotonic()-t,3)
        s=properties(unit)
        receipt["active"]=s
        assert s["ActiveState"]=="active" and s["MainPID"]!="0" and len(s["InvocationID"])==32
        ledger=root/s["InvocationID"]/"launch.json"
        rec=json.loads(ledger.read_text())
        assert rec["unit"]==unit and rec["phase"]=="prepared"
        assert rec["invocation"]==s["InvocationID"]
        shutil.copyfile(ledger,e/"prepared.json")
        remote=Path(rec["remote"])
        assert remote.is_absolute() and remote.is_socket() and root in remote.parents,remote
        core=rec["owners"]["core"]
        daemon=Path(f'/proc/{core["pid"]}/exe').resolve()
        assert daemon==(prefix/"bin/pipewire-ao").resolve(),(daemon,core)
        receipt["remote"]=str(remote)
        print(name,unit,"Ready",receipt["ready_s"],flush=True)
        env=dict(os.environ,**env,PIPEWIREAO_PREFIX=str(prefix))
        env.update(PIPEWIREAO_RUNTIME_DIR=str(remote.parent),PIPEWIRE_RUNTIME_DIR=str(remote.parent),PIPEWIREAO_CONFIG_DIR=str(remote.parent/"session"),PIPEWIREAO_MODULE_DIR=str(prefix/"lib/pipewire-ao-0.3"),PIPEWIREAO_SPA_PLUGIN_DIR=str(prefix/"lib/spa-ao-0.2"))
        if name=="cal2":
            env.update(RTC_FLOW_RUNNING_TIMEOUT="1100", RTC_FLOW_TIMEOUT="1400")
        spid=rec["owners"]["simulator"]["pid"]
        environ=dict(row.split(b"=",1) for row in Path(f"/proc/{spid}/environ").read_bytes().split(b"\0") if b"=" in row)
        depots=environ[b"JULIA_DEPOT_PATH"].decode()
        assert str(Path.home()/".julia")+":" not in depots
        maps=Path(f"/proc/{spid}/maps").read_text().splitlines()
        libraries=sorted({row.split()[-1] for row in maps if "libhil_command_receiver" in row or "/PipeWireAOOpticalStartup/" in row or "libpipewire-ao-0.3.so" in row})
        image = app/"optical-startup/simulator"
        if image.is_dir():
            assert any(str(image/"depot") in path and "/PipeWireAOOpticalStartup/" in path for path in libraries),libraries
            views = sorted((image/"sources").iterdir())
            assert all(not (v/"compiled").exists() for v in views)
            assert (image/"depot") == Path(depots.split(":")[0])
        libs = [path for path in libraries if "libhil_command_receiver" in path]
        if name in ("spiders","spiders-single"):
            assert libs == [str(app/"command-receiver/simulator/libhil_command_receiver.so")],libs
        else:
            assert not libs,libs
        receipt.update(simulator_depots=depots,simulator_libraries=libraries)
        j=[str(jbin),"--startup-file=no","--threads=2,1",f"--project={app}"]
        assert (repo/"test/integration/sealed_application_flow.jl").is_file()
        log_ctl=(e/"control.log").open("w")
        log_probe=(e/"probe.log").open("w")
        proc=sp.Popen(j+[str(repo/"docs/validation/rtc-0728-running/controls.jl"),unit,str(root),str(handshake),str(e)],env=env,stdout=log_ctl,stderr=sp.STDOUT)
        probe=sp.Popen(j+[str(repo/"test/integration/sealed_application_flow.jl"),name,str(app),str(remote),str(handshake)],env=env,stdout=log_probe,stderr=sp.STDOUT)
        end=time.monotonic()+(1500 if name=="cal2" else 550)
        while proc.poll() is None:
            if probe.poll() is not None and not (handshake/"observed").exists():
                (handshake/"probe_failed").touch()
            if time.monotonic()>end: raise TimeoutError("control driver")
            time.sleep(.3)
        receipt["control_exit"]=proc.returncode
        if proc.returncode==0:
            receipt["probe_exit"]=probe.wait(timeout=90)
        else:
            receipt["probe_exit"]=probe.poll()
        assert receipt["control_exit"]==0 and receipt["probe_exit"]==0,receipt
        for marker in ["ready","running","observed","stopped","complete"]:
            assert (handshake/marker).exists(),marker
        receipt["flow_pass"]=True
    except Exception:
        receipt["flow_pass"]=False
        receipt["error"]=traceback.format_exc()
        print(receipt["error"],flush=True)
    finally:
        for child in (proc,probe): kill_child(child)
        for file in (log_ctl,log_probe):
            if file: file.close()
        try:
            pre=properties(unit)
            if not ledger and len(pre["InvocationID"])==32: ledger=root/pre["InvocationID"]/"launch.json"
            t=time.monotonic()
            system("stop",unit,timeout=320)
            receipt["quit_s"]=round(time.monotonic()-t,3)
            post=properties(unit)
            receipt["final"]=post
            assert ledger and ledger.is_file(),ledger
            stopped=json.loads(ledger.read_text())
            shutil.copyfile(ledger,e/"shutdown.json")
            assert stopped["unit"]==unit and stopped["phase"]=="stopped" and not stopped.get("error")
            assert stopped["systemd_quit"]=={"attempted":True,"accepted":True},stopped.get("systemd_quit")
            assert post["ActiveState"]=="inactive" and post["Result"]=="success" and post["ExecMainStatus"]=="0",post
            assert not Path(stopped["remote"]).exists()
            if (e/"prepared.json").exists():
                saved=json.loads((e/"prepared.json").read_text())
                procs=[(r["pid"],r["start-ticks"]) for r in saved["owners"].values() if r.get("pid") and r.get("start-ticks")]
                procs.append((saved["session_pid"],saved["session_start_ticks"]))
                for pid,ticks in procs:
                    try: current=int(Path(f"/proc/{pid}/stat").read_text().rsplit(")",1)[1].split()[19])
                    except FileNotFoundError: continue
                    assert current!=int(ticks),pid
                receipt["original_processes_alive"]=0
            receipt["quit_pass"]=True
        except Exception:
            receipt["quit_pass"]=False
            receipt["quit_error"]=traceback.format_exc()
        try:
            units=[unit]
            for fname in ["prepared.json","shutdown.json"]:
                if (e/fname).is_file():
                    units.extend(r["unit"] for r in json.loads((e/fname).read_text())["owners"].values() if r.get("unit"))
                    break
            with (e/"journal.txt").open("w") as file:
                sp.run(["journalctl","--user","--no-pager","-o","short-monotonic",*[a for u in units for a in ("-u",u)]],stdout=file,stderr=sp.STDOUT,timeout=45)
            if properties(unit)["ActiveState"] in ["inactive","failed"]:
                if dest.is_symlink() and dest.resolve()==f: dest.unlink()
                if (drop/"flow.conf").exists(): (drop/"flow.conf").unlink()
                if drop.exists(): drop.rmdir()
                if f.is_file(): f.unlink()
                system("daemon-reload")
                if receipt.get("quit_pass") and ledger and ledger.parent.parent==root and root.name.endswith(eid):
                    shutil.rmtree(root)
        except Exception:
            receipt["cleanup_error"]=traceback.format_exc()
        save(e/"outcome.json",receipt)
        print(name,"completed",e,receipt.get("flow_pass"),receipt.get("quit_pass"),flush=True)
    return receipt.get("flow_pass") and receipt.get("quit_pass") and not receipt.get("cleanup_error")
if __name__=="__main__":
    with (xdg/"rtc-devel-benchmark.lock").open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        success=True
        for name in sys.argv[1:]:
            success=run(name) and success
        sys.exit(0 if success else 1)
