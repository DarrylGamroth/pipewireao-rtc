from pathlib import Path
import fcntl, importlib.util, json, os, subprocess, sys, time
s=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('flow_test',s/'managed.py')
flow=importlib.util.module_from_spec(spec)
spec.loader.exec_module(flow)
name=os.environ.get('RTC_SPEED_PROFILE','gpi2')
launcher=s/'installs'/name/'bin/pipewireao-rtc-session'
policy=sys.argv[1]
label=sys.argv[2]
assert policy in ('0','1','default','generated','publish-cpu14')
lock=flow.xdg/'rtc-devel-benchmark.lock'
with lock.open('a') as f:
    fcntl.flock(f,fcntl.LOCK_EX)
    saved=launcher.read_bytes(); st=launcher.stat()
    assert b'--startup-file=no --project=' in saved and b'PIPEWIREAO_RTC_EXPORT_COMMIT=' in saved and b'rtc_startup_flag' not in saved
    tests=s/'evidence'/name
    previous=set(tests.glob('*/outcome.json'))
    # This generated launcher belongs to the test installation. Select only the
    # two one-shot startup clients. systemd launches the RTC itself independently.
    changed=saved.replace(b'exec ',b'case "$1" in\n  prepare|publish) rtc_startup_flag=-O'+policy.encode()+b';;\n  *) rtc_startup_flag=;;\nesac\nexec ',1).replace(b'--startup-file=no --project=',b'${rtc_startup_flag} --startup-file=no --project=',1)
    if policy in ('generated','publish-cpu14'):
        changed=(s/'rtc-speed'/('generated-'+name)).read_bytes()
        assert b'prepare|publish)' in changed and b'-O0' in changed
        if policy=='publish-cpu14':
            header=b'case "${1-}" in'
            assert changed.count(header)==1
            changed=changed.replace(header,b'if [ "${1-}" = publish ]; then /usr/bin/taskset -pc 14 "$$" >/dev/null || exit 1; fi\n'+header)
    def replace(data):
        temp=launcher.with_name('.comparison-launcher')
        assert not temp.exists()
        temp.write_bytes(data)
        temp.chmod(st.st_mode)
        temp.replace(launcher)
    try:
        if policy!='default': replace(changed)
        start=time.monotonic()
        l0=Path('/proc/loadavg').read_text().split()[:3]
        sampler=subprocess.Popen([sys.executable,str(s/'sample-unit.py'),name,label])
        try:
            okay=flow.run(name)
        finally:
            try: sampler.wait(15)
            except subprocess.TimeoutExpired: sampler.terminate(); sampler.wait(5)
        new=set(tests.glob('*/outcome.json'))-previous
        assert len(new)==1,new
        record=new.pop().parent
        receipt={'label':label,'policy':policy,'probe_success':okay,'duration_s':time.monotonic()-start,'start_loadavg':l0,'end_loadavg':Path('/proc/loadavg').read_text().split()[:3]}
        (record/'startup-experiment.json').write_text(json.dumps(receipt,indent=2)+'\n')
        print(receipt,flush=True)
    finally:
        if policy!='default':
            assert launcher.read_bytes()==changed
            replace(saved)
            os.utime(launcher,ns=(st.st_atime_ns,st.st_mtime_ns))
    assert launcher.read_bytes()==saved
    sys.exit(0 if okay else 1)
