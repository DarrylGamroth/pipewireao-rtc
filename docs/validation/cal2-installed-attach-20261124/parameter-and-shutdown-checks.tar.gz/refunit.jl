unit = "codex-rtc-stop-result-$(getpid()).service"
run(`systemd-run --user --quiet --unit=$unit /usr/bin/sleep 1.5`)
bus = Ref{Ptr{Cvoid}}(C_NULL)
@show ccall((:sd_bus_open_user, "libsystemd.so.0"), Cint, (Ref{Ptr{Cvoid}},), bus)
try
    @show ccall((:sd_bus_set_method_call_timeout, "libsystemd.so.0"), Cint,
        (Ptr{Cvoid}, UInt64), bus[], UInt64(2_000_000))
    @show ccall((:sd_bus_call_method, "libsystemd.so.0"), Cint,
        (Ptr{Cvoid}, Cstring, Cstring, Cstring, Cstring, Ptr{Cvoid}, Ptr{Cvoid}, Cstring, Cstring...),
        bus[], "org.freedesktop.systemd1", "/org/freedesktop/systemd1", "org.freedesktop.systemd1.Manager", "RefUnit",
        C_NULL, C_NULL, "s", unit)
    show_unit = `systemctl --user show --property=Id,LoadState,ActiveState,MainPID,InvocationID,ExecMainPID,ExecMainCode,ExecMainStatus,Result $unit`
    run(show_unit)
    sleep(1.6)
    run(show_unit)
finally
    ccall((:sd_bus_close_unref, "libsystemd.so.0"), Ptr{Cvoid}, (Ptr{Cvoid},), bus[])
end
sleep(.3)
run(`systemctl --user show --property=Id,LoadState,ActiveState,MainPID,InvocationID,ExecMainPID,ExecMainCode,ExecMainStatus,Result $unit`)
