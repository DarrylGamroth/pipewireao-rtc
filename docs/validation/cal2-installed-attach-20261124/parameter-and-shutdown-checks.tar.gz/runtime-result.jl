using Test, PipeWireAORTC
const Runtime = PipeWireAORTC.SessionRuntime
const S = PipeWireAORTC.SystemdOwners
const C = PipeWireAORTC.Common
clock = Runtime.Clocks.SystemNanoClock()
@testset "direct RTC runtime reconciles the actual manager result" begin
    for exitcode in (0, 1)
        unit = "pipewireao-session@codex-stop-proof-$(getpid())-$exitcode.service"
        run(`systemd-run --user --quiet --unit=$unit /bin/sh -c $("sleep 6; exit $exitcode")`)
        try
            deadline = Runtime.Clocks.time_nanos(clock) + 30_000_000_000
            Runtime._with_unit_reference(unit, deadline; clock) do
                started = S.properties(unit; deadline, clock)
                pid = parse(Int, started["MainPID"])
                ticks = S.start_ticks(pid)
                mktempdir() do root
                    handle = Runtime.Handle(unit, root, started["InvocationID"], pid, ticks,
                        started["ControlGroup"], true, nothing)
                    record = Dict("version" => 2, "direct_attach" => true,
                        "unit" => unit, "session_pid" => pid, "session_start_ticks" => ticks,
                        "runtime" => root, "invocation" => handle.invocation,
                        "phase" => "stopped", "cleanup_complete" => true, "scoped_services" => String[])
                    C.write_json(joinpath(root, "launch.json"), record; atomic = true)
                    if exitcode == 0
                        result = Runtime._stopped_record(handle, deadline; clock)
                        @test result["service_result"] == "success"
                        @test !haskey(C.read_json(joinpath(root, "launch.json")), "service_result")
                    else
                        @test_throws "systemd Result=exit-code" Runtime._stopped_record(handle, deadline; clock)
                    end
                end
            end
        finally
            exitcode == 0 || run(`systemctl --user reset-failed $unit`)
        end
    end
end
