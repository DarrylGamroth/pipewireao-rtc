using Test, PipeWireAORTC, PipeWireAO
const RTC = PipeWireAORTC
const Launch = RTC.SessionLaunch
const Bootstrap = RTC.OwnerBootstrapClient
const Codec = RTC.OwnerBootstrapCodec
const Client = RTC.ControlClient
const Params = RTC.ParameterSource
include(joinpath(pkgdir(RTC), "test", "control_private_core.jl"))

function launch_unit(path, invocation, log)
    lines = readlines(path)
    argv = Base.shell_split(chopprefix(only(filter(line -> startswith(line, "ExecStart=:"), lines)), "ExecStart=:"))
    insert!(argv, 2, "--compiled-modules=existing")
    env = Dict("INVOCATION_ID" => invocation)
    for line in filter(line -> startswith(line, "Environment="), lines)
        key, value = split(only(Base.shell_split(chopprefix(line, "Environment="))), '='; limit = 2)
        env[key] = value
    end
    cwd = chopprefix(only(filter(line -> startswith(line, "WorkingDirectory="), lines)), "WorkingDirectory=")
    command = addenv(Cmd(Cmd(vcat(["taskset", "-c", "14"], argv)); dir = cwd), env)
    return run(pipeline(command; stdout = log, stderr = log); wait = false)
end

function native_port(registry, node_name)
    nodes = find_globals(registry; interface = "PipeWire:Interface:Node", properties = (("node.name" => node_name),))
    length(nodes) == 1 || return nothing
    id = only(nodes).id
    ports = find_globals(registry; interface = "PipeWire:Interface:Port", properties = (("node.id" => string(id)),))
    length(ports) == 1 || return nothing
    return id, only(ports).id
end

const prefix = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
const schema = "pipewireao/test/installed-parameter"
deadline(seconds = 20) = Int64(time_ns()) + round(Int64, seconds * 1e9)

@testset "generated direct parameter service on private core" begin
    with_control_private_core(; prefix, temporary_prefix = "direct-param-", remote_name = "core",
        modules = "{ name = libpipewire-module-spa-node-factory }",
        objects = "{ factory = spa-node-factory args = { factory.name = support.node.driver node.name = ParameterFixtureDriver priority.driver = 200000 } }",
    ) do socket, directory, daemon
        chmod(dirname(socket), 0o700)
        package = mkdir(joinpath(directory, "app"))
        systemd = mkdir(joinpath(package, "systemd"))
        cp(joinpath(directory, "configuration", "client.conf"), joinpath(package, "client.conf"))
        spec = Dict("name" => "fixture", "environment" => Dict{String,String}(), "owners" => [Dict("role" => "simulator")],
            "client" => Dict("rtc" => "client.conf"), "placement" => Dict("session" =>
                Dict("cpus" => [14], "leader-cpu" => 14, "threads" => Any[])))
        common_port = Dict("parameter" => true, "element-type" => "F32_LE", "shape" => [2, 2], "schema" => schema)
        parameter_output = merge(common_port, Dict("name" => "output_1", "direction" => "output"))
        graph_input = merge(common_port, Dict("name" => "matrix", "direction" => "input"))
        session = Dict("sources" => [Dict("factory" => "pipewireao.runtime-parameter",
            "node.name" => "fixture-matrix-publisher", "ports" => [parameter_output])],
            "graphs" => [Dict("node.name" => "fixture-graph", "ports" => [graph_input])],
            "links" => [Dict("output" => "fixture-matrix-publisher:output_1", "input" => "fixture-graph:matrix")])
        external = (; socket, core = "fixture-independent-core.service")
        parameter = Launch.install_direct_parameters!(package, prefix, pkgdir(RTC), spec, session, external, Base.julia_cmd().exec[1])
        @test parameter.unit == "pipewireao-parameters-fixture@%i.service"
        unit_file = joinpath(systemd, "pipewireao-parameters-fixture@.service")
        @test occursin("StopWhenUnneeded=yes", read(unit_file, String))
        @test occursin(RTC.SystemdOwners.unit_argument("JULIA_DEPOT_PATH=" * ENV["JULIA_DEPOT_PATH"]), read(unit_file, String))
        @test !ispath(joinpath(systemd, "julia-depot"))
        "generation-only" in ARGS && return nothing
        payload = joinpath(directory, "parameter.bin")
        write(payload, Float32[1, 2, 3, 4])
        format = NdArrayFormat(NdArray.F32_LE, (2, 2); layout = NdArray.ROW_MAJOR)
        previous = nothing
        for invocation in ("1"^32, "2"^32)
            log = open(joinpath(directory, invocation * ".log"), "w+")
            process = launch_unit(unit_file, invocation, log)
            bootstrap = control = sink = link = nothing
            try
                pid = getpid(process)
                instance = parse(Int64, Launch.graph_bootstrap_instance(invocation))
                control_instance = parse(Int64, Launch.parameter_control_instance(invocation))
                @test previous === nothing || (pid != previous.pid && instance != previous.instance && control_instance != previous.control_instance)
                bootstrap = Bootstrap.connect(socket, parameter.owner["bootstrap-node"], pid, instance; deadline = deadline(120))
                connected = Bootstrap.connect_owner!(bootstrap; deadline = deadline(60))
                @test connected.lifecycle === Codec.Connected
                @test connected.header.endpoint_instance == instance
                control = Client.connect(Params.PROFILE, socket, parameter.owner["control-node"], pid, control_instance; deadline = deadline())
                received = zeros(Float32, 4)
                with_thread_loop_lock(control.loop) do _
                    sink = NdArraySink(control.core, "fixture-matrix-sink", received, format; schema)
                    start!(sink)
                    arm_array_sink!(sink, UInt64(1))
                end
                wait_proof(20, "native parameter output and sink input") do
                    with_thread_loop_lock(control.loop) do _
                        native_port(control.registry, "fixture-matrix-publisher") !== nothing &&
                        native_port(control.registry, "fixture-matrix-sink") !== nothing
                    end
                end
                with_thread_loop_lock(control.loop) do _
                    out_node, out_port = native_port(control.registry, "fixture-matrix-publisher")
                    in_node, in_port = native_port(control.registry, "fixture-matrix-sink")
                    link = create_object(control.core, "link-factory", PipeWireAO.Link; properties = Dict(
                        "link.output.node" => string(out_node), "link.output.port" => string(out_port),
                        "link.input.node" => string(in_node), "link.input.port" => string(in_port),
                        "object.linger" => "false"))
                end
                invalid = RTC.RunnerCodec.RunnerCommand(:parameter, "fixture-graph", "matrix", "F32_LE", UInt32[1, 4], schema, payload)
                rejection = Client.request!(control, invalid; deadline = deadline())
                @test rejection.header.endpoint_instance == control_instance
                @test rejection.header.result == -Base.Libc.EINVAL && !rejection.submitted
                update = RTC.RunnerCodec.RunnerCommand(:parameter, "fixture-graph", "matrix", "F32_LE", UInt32[2, 2], schema, payload)
                completed = Client.request!(control, update; deadline = deadline())
                @test completed.header.result == 0 && completed.submitted && completed.sequence == 1
                @test completed.header.endpoint_instance == control_instance
                @test !completed.active_adoption_observed
                wait_array_sink!(sink; timeout_ns = 10_000_000_000)
                @test array_values(sink) == Float32[1, 2, 3, 4]
                quit = Bootstrap.quit!(bootstrap; deadline = deadline())
                @test quit.lifecycle === Codec.Stopped
                wait_proof(() -> Base.process_exited(process), 20, "clean parameter service quit")
                @test success(process)
                @test !Base.process_exited(daemon)
                previous = (; pid, instance, control_instance)
            catch
                flush(log)
                seekstart(log)
                print(stderr, read(log, String))
                rethrow()
            finally
                if control !== nothing
                    with_thread_loop_lock(control.loop) do _
                        link === nothing || close(link)
                        sink === nothing || close(sink)
                    end
                    close(control)
                end
                bootstrap === nothing || close(bootstrap)
                stop_proof_child!(process, "generated parameter service child")
                close(log)
            end
        end
    end
end
