using Test, PipeWireAORTC, PipeWireAO
const RTC = PipeWireAORTC
const Launch = RTC.SessionLaunch
const S = RTC.SystemdOwners
const Bootstrap = RTC.OwnerBootstrapClient
include(joinpath(pkgdir(RTC), "test", "control_private_core.jl"))

const MANAGER_RUNTIME = ENV["XDG_RUNTIME_DIR"]
const prefix = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
const schema = "pipewireao/test/installed-parameter"

in_manager(f) = withenv(f, "XDG_RUNTIME_DIR" => MANAGER_RUNTIME)
ctl(args...) = in_manager(() -> run(`timeout 12s systemctl --user $args`))
ctl_cleanup(args...) = in_manager(() -> run(ignorestatus(`timeout 15s systemctl --user $args`)))
manager_run(args) = in_manager(() -> run(`timeout 12s systemd-run --user --quiet $args`))
deadline(seconds) = Int64(time_ns()) + round(Int64, seconds * 1e9)
function install(directory, client, spec, session, external)
    package = mkdir(directory)
    mkdir(joinpath(package, "systemd"))
    cp(client, joinpath(package, "client.conf"))
    Launch.install_direct_parameters!(package, prefix, pkgdir(RTC), spec, session, external, Base.julia_cmd().exec[1])
end

@testset "real systemd installed parameter service identity" begin
    with_control_private_core(; prefix, temporary_prefix = "direct-param-", remote_name = "core",
        modules = "{ name = libpipewire-module-spa-node-factory }",
    ) do socket, directory, daemon
        chmod(dirname(socket), 0o700)
        suffix = "bindingfixture$(getpid())"
        core = "$suffix-core.service"
        attachment = "$suffix-attachment.service"
        spec = Dict("name" => suffix, "environment" => Dict{String,String}(),
            "owners" => [Dict("role" => "simulator")], "client" => Dict("rtc" => "client.conf"),
            "placement" => Dict("session" => Dict("cpus" => [14, 15], "leader-cpu" => 14, "threads" => Any[])))
        common_port = Dict("parameter" => true, "element-type" => "F32_LE", "shape" => [2, 2], "schema" => schema)
        parameter_output = merge(common_port, Dict("name" => "output_1", "direction" => "output"))
        graph_input = merge(common_port, Dict("name" => "matrix", "direction" => "input"))
        session = Dict("sources" => [Dict("factory" => "pipewireao.runtime-parameter",
            "node.name" => "fixture-matrix-publisher", "ports" => [parameter_output])],
            "graphs" => [Dict("node.name" => "fixture-graph", "ports" => [graph_input])],
            "links" => [Dict("output" => "fixture-matrix-publisher:output_1", "input" => "fixture-graph:matrix")])
        external = (; socket, core)
        client = joinpath(directory, "configuration", "client.conf")
        parameter = install(joinpath(directory, "app"), client, spec, session, external)
        other = install(joinpath(directory, "other"), client, spec, session, external)
        @test parameter.unit != other.unit
        unit = replace(parameter.unit, "%i" => suffix)
        template = parameter.service["fragment"]
        staged = cp(template, joinpath(dirname(template), unit))
        runtime_link = joinpath(MANAGER_RUNTIME, "systemd", "user", unit)
        @test !ispath(runtime_link) && !islink(runtime_link)
        bootstrap = nothing
        try
            ctl("link", "--runtime", "--no-reload", staged)
            in_manager(() -> run(`flock -x -w 35 $(joinpath(MANAGER_RUNTIME, "rtc-devel-benchmark.lock")) timeout 12s systemctl --user daemon-reload`))
            manager_run(["--unit=$core", "--property=Type=exec", "--property=CPUAffinity=14 15",
                "--property=RuntimeMaxSec=255", "--property=TimeoutStopSec=5", "/usr/bin/sleep", "255"])
            manager_run(["--unit=$attachment", "--property=Type=exec", "--property=CPUAffinity=14 15",
                "--property=RuntimeMaxSec=255", "--property=TimeoutStopSec=5", "--property=Requires=$unit",
                "--property=After=$unit", "/usr/bin/sleep", "255"])
            coordinator = S.Coordinator(attachment, "", "")
            service = in_manager(() -> Launch.external_service(coordinator, "parameters", unit))
            invocation = service.invocation
            instance = parse(Int64, Launch.graph_bootstrap_instance(invocation))
            bootstrap = Bootstrap.connect(socket, parameter.owner["bootstrap-node"], S.pid(service),
                instance; deadline = deadline(200))
            @test Bootstrap.connect_owner!(bootstrap; deadline = deadline(15)).lifecycle === RTC.OwnerBootstrapCodec.Connected
            verify(item) = in_manager(() -> Launch.verify_persistent_service!(service, item;
                instance_template = true, attached = true, deadline = deadline(10)))
            @test verify(parameter.service) === nothing
            @test_throws r"unit differs from its installed service" verify(other.service)
            @test_throws r"unit differs from its installed service" verify(merge(other.service, Dict("sha256" => parameter.service["sha256"])))
            @test_throws r"unit differs from its installed service" verify(merge(parameter.service, Dict("sha256" => "0"^64)))
            props = in_manager(() -> S.properties(unit;
                extra = "FragmentPath,DropInPaths,NeedDaemonReload,Type,Restart,KillMode"))
            @test realpath(props["FragmentPath"]) == staged
            @show props["Type"] props["Restart"] props["KillMode"] S.pid(service) props["NeedDaemonReload"] props["FragmentPath"]
            @test Bootstrap.quit!(bootstrap; deadline = deadline(10)).lifecycle === RTC.OwnerBootstrapCodec.Stopped
            wait_proof(() -> !S.alive(service), 15, "generated parameter service exit")
            @test !Base.process_exited(daemon)
        catch
            in_manager(() -> run(ignorestatus(`timeout 5s journalctl --user -u $unit --no-pager -n 40`)))
            rethrow()
        finally
            bootstrap === nothing || close(bootstrap)
            ctl_cleanup("stop", attachment, unit, core)
            islink(runtime_link) && readlink(runtime_link) == staged && rm(runtime_link)
        end
    end
end
