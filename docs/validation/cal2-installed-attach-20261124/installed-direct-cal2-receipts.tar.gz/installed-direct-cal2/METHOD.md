# Installed direct CAL2 comparison

Use the existing live CUDA CAL2 fixture in
`/var/tmp/rtc-cal2-cuda.jhjhtFE9`. Its independently owned PipeWire core,
CUDA simulator, pupil feeder, camera receiver and two retained graph
services publish throughout the experiment. The preceding fixture archive
contains their scripts, pinned application and dependency manifests, and
earlier startup receipts.

Each arm starts and stops its normal installed systemd unit. Both use Julia
1.13.3's distribution image. The timed intervals run from each systemctl
request until it returns. A fresh public Status after the attach requires
held Ready with exactly 10 owned Links. A native dump verifies those 10
Links' endpoint names, ports and NDArray formats against the previous
installed CAL2 qualification. No request closes either controller. Both
report Open and unprimed in Held. The only state-changing command before
Quit is native Start. A final public Status and property checks confirm
both are still open after the usable outputs.

The output observer runs with the same stock pinned project and CPU as in
both arms. It connects before timing and does not submit camera data. The
checked LLOWFS and SCC camera observations must arrive strictly after
native Start acknowledgement and match output identifiers by generation,
domain, sequence and model timestamp. Outputs must include a nonzero
modal residual and zero physical offset. SCC must also return valid
pair status for the matching acquisition. The reported first output time
includes the time until the next independently paced exposure or pair.

Normal native Quit must report Offline and a successful terminal launch
receipt. After every stop, both cameras must advance with their original
epochs. Native dumps and systemd identities verify the unchanged source,
core and both graph services and the absence of the RTC's admitted Links.
Only benchmark sidecar receipts use trial directories. The direct service's
runtime directory holds one receipt and no invocation subdirectories.

The baseline uses the earlier installed RTC at source `a4cacb8`. The diff
from that source to comparison base `bc829d7` contains dated evidence and
documentation only. The bootstrapped graph services retain their original
calibration and exact installed provenance. The direct RTC uses their
separate pinned graph installation and the same external core and source.
Neither arm executes synthetic graph warmup during activation.

An initial baseline attach reached Ready in 6.101 s. It is excluded from
the matched group because the added benchmark client omitted a required
deadline argument. The native systemd stop on that attempt completed
normally. The revised client then verified all three baseline trials.

## Results

The direct installation uses RTC source `807a6986ee5e6268b2a5fb21ac132bf360891601`.
Its three starts reached held Ready in 6.030–6.339 s, compared with
6.119–6.276 s for the previous installed service. Median time to Ready
was 6.238 s and 6.219 s, respectively. Median normal stop time fell from
4.533 s to 3.467 s, a reduction of 1.066 s or 23.5%. Median time from
the RTC process exit to the systemctl response fell from 1.860 s to
0.431 s. The direct service used the same 10 NDArray Links on every
invocation. All observed physical offsets after Start were exactly zero.
The first matching LLOWFS residual arrived 0.085–0.492 s after Start
acknowledgement. The first matching SCC result with valid pair status
arrived 2.610–4.040 s after acknowledgement. For each pair both consecutive
camera observations arrived after Start acknowledgement. The runs measure
the observed ranges on the shared development workstation.

The earlier `eabb6a2` install succeeded but systemd 257 omitted an empty
`ExecStopPost` property and the startup check treated the omission as an
error. The service failed before admitting any Links and left its runtime
directory empty. The startup check in `807a698` handled the omitted property,
and that build passed all three trials.

After the timed block, overriding only the installed activation digest
caused `807a698` to refuse startup before native admission. The fixed
runtime receipt from the preceding successful stop stayed byte-identical.
Both cameras continued to advance. Removing the scratch override let the
same installed unit reach Ready. The operator's public
`SessionRuntime.running!` returned Running and its regular Stop accepted
native Quit according to the exact invocation's terminal receipt. The
journal lacked a stop timing line for this additional operator run. All
six timed trials have matching stop timing lines.

The direct and previous RTC units were inactive at the final check. The
original simulator, both retained graphs, the private core and the
independent receiver kept their identities. The receiver had observed
10,808 LLOWFS and 2,161 SCC acquisitions with no sequence gaps through
the preserved final fixture status.
