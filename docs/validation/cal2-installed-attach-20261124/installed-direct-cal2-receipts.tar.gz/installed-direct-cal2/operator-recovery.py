"""Verify standard installed operator attachment after the refused activation."""

import sys
import time

import benchmark as b

m = b.m
unit = "pipewireao-session@c2l-cuda-jhjhtfe9-direct.service"


def operation(out, name):
    command = [b.stage / "cal2-direct-ops.sh", name]
    sent = time.monotonic_ns()
    result = b.command(*command, timeout=60)
    received = time.monotonic_ns()
    m.save(out / (name + ".json"), dict(request_ns=sent, completed_ns=received, command=result.args,
           returncode=result.returncode, stdout=result.stdout, stderr=result.stderr))
    result.check_returncode()
    return result.stdout.strip()


def probe(out):
    out.mkdir()
    assert m.status(unit)["ActiveState"] == "inactive"
    b.capture_native(out, "before")
    m.save(out / "publishing-before.json", b.publishing_snapshot())
    try:
        operation(out, "attach")
        owner = m.owner(unit)
        m.save(out / "rtc-identity.json", owner)
        b.capture_native(out, "ready", attached=True)
        assert operation(out, "start") == "running"
        operation(out, "detach")
    finally:
        if m.status(unit)["MainPID"] != "0":
            operation(out, "detach")
    verify_detached(out)


def verify_detached(out):
    owner = m.load(out / "rtc-identity.json")
    result = m.load(out / "detach.json")
    assert result["returncode"] == 0
    b.stop_journal(out, unit, owner, result, required=False)
    runtime = m.runtime.parent / "pipewireao-session-c2l-cuda-jhjhtfe9-direct"
    stopped = m.load(runtime / "launch.json")
    assert stopped["invocation"] == owner["invocation"]
    assert stopped["phase"] == "stopped" and stopped["cleanup_complete"]
    assert stopped["systemd_quit"] == {"attempted": True, "accepted": True}
    m.save(out / "terminal-receipt.json", stopped)
    b.capture_native(out, "after")
    m.save(out / "camera-after-detach.json", m.wait(
        lambda: b.retained.advancing_source(result["completed_ns"]), 30,
        "both cameras advance after operator detach"))
    m.save(out / "publishing-after.json", b.publishing_snapshot())
    status = b.command(b.stage / "cal2-direct-ops.sh", "status")
    status.check_returncode()
    (out / "operator-status.txt").write_text(status.stdout)
    assert m.status(unit)["ActiveState"] == "inactive"


if __name__ == "__main__":
    target = b.stage / sys.argv[1]
    verify_detached(target) if len(sys.argv) > 2 and sys.argv[2] == "--verify-detached" else probe(target)
