using PipeWireAORTC, PipeWireAO
const R = PipeWireAORTC
const I = R.SessionInstall
const L = R.SessionLaunch
const C = R.Common
const D = R.DeploymentConfiguration
const PREFIX = realpath(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
const BASE = only(ARGS)
const PROFILES = (
    ("classic-persistent-eabb6a2-o0", 5, ["julia"], true),
    ("gpi2-persistent-eabb6a2-o0", 8, ["julia"], true),
    ("spiders-persistent-eabb6a2-76cb8f2-o0", 1, ["scc-differential", "spiders-scc"], false),
)
const EXTERNAL_SERVICES = Dict(
    "PIPEWIREAORTC_CORE_UNIT" => "rtc-installer-check-core.service",
    "PIPEWIREAORTC_CORE_SOCKET" => "/run/user/1000/rtc-installer-check",
    "PIPEWIREAORTC_SOURCE_UNIT" => "rtc-installer-check-source.service",
)
merge!(ENV, EXTERNAL_SERVICES)

function verify(destination, count, roles, analysis; prefix=PREFIX, persistent=true)
    systemd = joinpath(destination, "systemd")
    config = joinpath(systemd, "rtc.conf")
    activation = C.read_json(joinpath(systemd, L.ACTIVATION_FILE))
    @assert activation["config"] == config
    for (file, identity) in activation["files"]
        @assert L.graph_file_identity(file) == identity
    end
    @assert D.decode(config, prefix)["context.properties"]["remote.name"] ==
        EXTERNAL_SERVICES["PIPEWIREAORTC_CORE_SOCKET"]
    @assert activation["direct-services"]["core"] == EXTERNAL_SERVICES["PIPEWIREAORTC_CORE_UNIT"]
    @assert activation["direct-services"]["simulator"] == EXTERNAL_SERVICES["PIPEWIREAORTC_SOURCE_UNIT"]
    unit = read(joinpath(systemd, "pipewireao-session@.service"), String)
    @assert !occursin("ExecStopPost=", unit) && !occursin("INVOCATION_ID", unit)
    @assert occursin(" -c \"$config\"", unit)
    @assert occursin("--direct", unit)
    fragments = filter(name -> endswith(name, ".service"), readdir(systemd))
    @assert any(startswith("pipewireao-analysis-"), fragments) == analysis
    @assert length(C.read_json(joinpath(systemd, "parameters", "sources.json"))["sources"]) == count
    if persistent
        manifest = activation["graph-manifest"]
        @assert activation["graph-manifest-sha256"] == C.sha256_file(manifest)
        @assert sort!(collect(keys(C.read_json(manifest)["owners"]))) == roles
    else
        @assert !haskey(activation, "graph-manifest")
        @assert activation["direct-services"]["julia"] == "rtc-installer-site-controller.service"
    end
    files = [joinpath(systemd, name) for name in fragments]
    append!(files, [config, joinpath(systemd, L.ACTIVATION_FILE), joinpath(systemd, "parameters", "sources.json"),
                    joinpath(destination, "Project.toml"), joinpath(destination, "Manifest.toml"),
                    joinpath(destination, "deployment.conf")])
    haskey(activation, "graph-manifest") && push!(files, activation["graph-manifest"])
    println(basename(destination), " verified with ", count, " parameter sources and graph roles ", roles)
    return Dict("destination" => destination, "parameter_sources" => count, "graph_roles" => roles,
                "analysis" => analysis, "sha256" => Dict(relpath(path, destination) => C.sha256_file(path) for path in files))
end

summary = []
for (profile, count, roles, analysis) in PROFILES
    package = joinpath(BASE, profile)
    destination = package * "-installed"
    if !isdir(destination)
        R.ScienceExport.stage_rtc!(package)
        R.InstrumentExport.seal!(package)
        @assert I.install((; package, destination, pipewire_prefix=PREFIX, persistent_graph_owners=true)) == destination
    end
    checked = verify(destination, count, roles, analysis)
    @assert isempty(filter(path -> occursin("julia-depot/artifacts/Overrides.toml", path),
                          collect(keys(C.read_json(joinpath(destination, "systemd", L.ACTIVATION_FILE))["files"]))))
    checked["dependency_manifest_sha256"] = C.sha256_file(joinpath(package, "Manifest.toml"))
    checked["deployment_sha256"] = C.sha256_file(joinpath(package, "deployment.conf"))
    push!(summary, checked)
end

# The site-supplied role deliberately includes a failing local workload.
# Create two deployments of the same profile to check their support names.
site_source = joinpath(BASE, "site-classic-export")
sdk = joinpath(BASE, "custom-native-prefix")
if !isdir(site_source)
    run(`cp -a $(joinpath(BASE, first(first(PROFILES)))) $site_source`)
    workload = joinpath(site_source, "graph-startup/julia/ExportedGraphWarmup/src")
    mkpath(workload)
    write(joinpath(workload, "ExportedGraphWarmup.jl"), "error(\"site graph workload ran inside RTC installer\")\n")
    R.InstrumentExport.seal!(site_source)
end
if !isdir(sdk)
    mkdir(sdk)
    for name in readdir(PREFIX)
        symlink(joinpath(PREFIX, name), joinpath(sdk, name))
    end
end
names = Set{String}()
for (variant, prefix) in (("default", PREFIX), ("custom-prefix", sdk))
    site_destination = joinpath(BASE, "site-classic-final-" * variant)
    if !isdir(site_destination)
        @assert I.install((; package=site_source, destination=site_destination, pipewire_prefix=prefix,
            external_owner=["julia=rtc-installer-site-controller.service"])) == site_destination
    end
    checked = verify(site_destination, 5, ["julia"], true; prefix, persistent=false)
    activation = C.read_json(joinpath(site_destination, "systemd", L.ACTIVATION_FILE))
    for role in ("analysis", "parameters")
        path = joinpath(site_destination, "systemd", role, "julia-depot/artifacts/Overrides.toml")
        units = filter(path -> endswith(path, ".service") && occursin("/pipewireao-$role-", path),
            readdir(joinpath(site_destination, "systemd"); join=true))
        @assert length(units) == 1
        name = basename(only(units))
        @assert !(name in names) && occursin(r"-[a-f0-9]{12}@\.service$", name)
        push!(names, name)
        if variant == "custom-prefix"
            @assert haskey(activation["files"], path) && isfile(path)
            @assert occursin("JULIA_DEPOT_PATH=$(dirname(dirname(path))):", read(only(units), String))
        else
            @assert !isfile(path)
        end
    end
    push!(summary, checked)
end
C.write_json(joinpath(BASE, "offline-install-verification.json"), summary)
