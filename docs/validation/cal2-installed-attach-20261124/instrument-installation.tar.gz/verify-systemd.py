import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

base = Path(sys.argv[1])
with tempfile.TemporaryDirectory(prefix="systemd-verify-", dir=base) as scratch:
    runtime = Path(scratch) / "runtime"
    runtime.mkdir(mode=0o700)
    units = Path(scratch) / "units"
    units.mkdir(mode=0o700)
    for suffix in ("core", "source", "site-controller"):
        (units / f"rtc-installer-check-{suffix}.service").write_text(
            "[Service]\nType=oneshot\nExecStart=/usr/bin/true\nRemainAfterExit=yes\n"
        )
    (units / "rtc-installer-site-controller.service").write_text(
        "[Service]\nType=oneshot\nExecStart=/usr/bin/true\nRemainAfterExit=yes\n"
    )
    instances = []
    for suffix in ("default", "custom-prefix"):
        app = base / f"site-classic-final-{suffix}"
        for template in (app / "systemd").glob("*@.service"):
            unit = units / template.name.replace("@.service", f"@{suffix}.service")
            assert not unit.exists()
            shutil.copyfile(template, unit)
            if unit.name.startswith("pipewireao-session@"):
                instances.append(unit)
    command = ["systemd-analyze", "--user", "--man=no", "--generators=no", "verify",
               *map(str, instances)]
    subprocess.run(command, env=dict(os.environ, XDG_RUNTIME_DIR=str(runtime),
                                    SYSTEMD_UNIT_PATH=f"{units}:"), check=True)
    print("systemd verified both exact RTC instances and their distinct support units")
