"""Select a committed RTC package for the immutable CAL2 deployment inputs."""

import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tomllib

base = Path(__file__).resolve().parent
repo, revision = sys.argv[1:]
julia = os.environ["CAL2_VALIDATION_JULIA"]
commit = subprocess.check_output(["git", "-C", repo, "rev-parse", revision + "^{commit}"], text=True).strip()
tree = subprocess.check_output(["git", "-C", repo, "rev-parse", commit + "^{tree}"], text=True).strip()
code = 'using UUIDs; print(Base.version_slug(UUID("a3e2c7da-f73f-4284-8482-36ac422b34e6"), Base.SHA1(hex2bytes(only(ARGS)))))'
slug = subprocess.check_output([julia, "--startup-file=no", "-e", code, tree], text=True)
package = base / "depot" / "packages" / "PipeWireAORTC" / slug
if not package.is_dir():
    package.mkdir(parents=True)
    with subprocess.Popen(["git", "-C", repo, "archive", commit], stdout=subprocess.PIPE) as archive:
        subprocess.run(["tar", "-x", "-C", package], stdin=archive.stdout, check=True)
        assert archive.wait() == 0
project = tomllib.loads((package / "Project.toml").read_text())
prior = Path(os.environ["CAL2_PRIOR_INSTALL"])
source = (prior / "Manifest.toml").read_text()
pattern = r"(^\[\[deps\.PipeWireAORTC\]\]\n)(.*?)(?=^\[\[deps\.)"
match = re.search(pattern, source, flags=re.M | re.S)
block = re.sub(r"^deps = .*$", "deps = " + json.dumps(sorted(project["deps"])), match[2],
               count=1, flags=re.M)
block = re.sub(r"^git-tree-sha1 = .*$", "git-tree-sha1 = " + json.dumps(tree), block,
               count=1, flags=re.M)
block = re.sub(r"^version = .*$", "version = " + json.dumps(project["version"]), block,
               count=1, flags=re.M)
manifest = base / "export" / "Manifest.toml"
contents = source[:match.start(2)] + block + source[match.end(2):]
manifest.write_text(contents)
before, after = (tomllib.loads(value) for value in (source, contents))
before["deps"].pop("PipeWireAORTC")
entry = after["deps"].pop("PipeWireAORTC")[0]
assert before == after
assert entry["git-tree-sha1"] == tree
print(json.dumps(dict(commit=commit, tree=tree, package=str(package), prior_install=str(prior)),
                 indent=2))
