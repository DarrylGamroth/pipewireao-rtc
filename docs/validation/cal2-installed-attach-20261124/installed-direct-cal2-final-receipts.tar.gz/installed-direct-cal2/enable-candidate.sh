#!/usr/bin/env bash
set -euo pipefail
cal2_direct_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/rtc-cal2-cuda.jhjhtFE9/session-env.sh
cal2_direct_app=${1:-$cal2_direct_dir/installed}
cal2_direct_unit=pipewireao-session@c2l-cuda-jhjhtfe9-direct.service
cal2_direct_link=$XDG_RUNTIME_DIR/systemd/user/$cal2_direct_unit
cal2_direct_dropin=$cal2_direct_link.d
test ! -e "$cal2_direct_link"
test ! -L "$cal2_direct_link"
test ! -e "$cal2_direct_dropin"
test -f "$cal2_direct_app/systemd/rtc.conf"
test -f "$cal2_direct_app/systemd/pipewireao-session@.service"
ln -s "$cal2_direct_app/systemd/pipewireao-session@.service" "$cal2_direct_link"
mkdir "$cal2_direct_dropin"
cat > "$cal2_direct_dropin/validation.conf" <<CONFIG
[Service]
Environment="JULIA_DEPOT_PATH=$cal2_direct_dir/depot:$JULIA_DEPOT_PATH"
Environment="JULIA_LOAD_PATH=@:@stdlib"
Environment="JULIA_PKG_PRECOMPILE_AUTO=0"
Environment="JULIA_NUM_PRECOMPILE_TASKS=1"
Environment="JULIA_IMAGE_THREADS=1"
Environment="OPENBLAS_NUM_THREADS=1"
Environment="TMPDIR=$TMPDIR"
Environment="XDG_CACHE_HOME=$XDG_CACHE_HOME"
Environment="POCL_CACHE_DIR=$POCL_CACHE_DIR"
CONFIG
systemctl --user daemon-reload
systemctl --user cat "$cal2_direct_unit"
