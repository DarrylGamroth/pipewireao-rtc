#!/usr/bin/env bash
set -euo pipefail
cal2_direct_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cal2_direct_unit=pipewireao-session@c2l-cuda-jhjhtfe9-direct.service
cal2_direct_link=$XDG_RUNTIME_DIR/systemd/user/$cal2_direct_unit
cal2_direct_app=$(realpath -- "${1:?Installed direct application path required}")
test -L "$cal2_direct_link"
case "$(readlink -- "$cal2_direct_link")" in
    "$cal2_direct_dir"/installed*/systemd/pipewireao-session@.service) ;;
    *) exit 1 ;;
esac
test -f "$cal2_direct_app/systemd/rtc.conf"
test -f "$cal2_direct_app/systemd/pipewireao-session@.service"
exec 9>"$XDG_RUNTIME_DIR/rtc-devel-benchmark.lock"
flock -x 9
main_pid=$(systemctl --user show "$cal2_direct_unit" -p MainPID --value)
test "$main_pid" = 0
cal2_direct_pending=$cal2_direct_link.select-$$
ln -s "$cal2_direct_app/systemd/pipewireao-session@.service" "$cal2_direct_pending"
mv -Tf "$cal2_direct_pending" "$cal2_direct_link"
systemctl --user daemon-reload
if systemctl --user is-failed --quiet "$cal2_direct_unit"; then
    systemctl --user reset-failed "$cal2_direct_unit"
fi
systemctl --user cat "$cal2_direct_unit"
