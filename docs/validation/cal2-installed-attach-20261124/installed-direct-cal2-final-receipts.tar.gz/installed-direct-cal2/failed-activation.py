"""Exercise direct activation's installed-input rejection on the private CAL2 unit."""

import fcntl
from pathlib import Path
import sys
import time

import benchmark as b

m = b.m


def checked(*args):
    result = b.command(*args)
    result.check_returncode()
    return result.stdout


def probe(out, unit):
    out.mkdir()
    suffix = unit.removeprefix("pipewireao-session@").removesuffix(".service")
    runtime = m.runtime.parent / ("pipewireao-session-" + suffix)
    ledger = runtime / "launch.json"
    previous = ledger.read_bytes()
    assert m.load(ledger)["phase"] == "stopped"
    assert m.status(unit)["ActiveState"] == "inactive"
    assert m.status(b.baseline_unit)["ActiveState"] == "inactive"
    b.capture_native(out, "before")
    m.save(out / "publishing-before.json", b.publishing_snapshot())
    dropin = m.unit_dir / (unit + ".d") / "zzz-poison-validation.conf"
    assert not dropin.exists()
    start = time.monotonic_ns()
    try:
        with dropin.open("x") as fault:
            fault.write('[Service]\nEnvironment=PIPEWIREAORTC_ACTIVATION_SHA256=' + '0' * 64 + '\n')
        checked("systemctl", "--user", "daemon-reload")
        result = b.command("systemctl", "--user", "start", unit, timeout=40)
        end = time.monotonic_ns()
        assert result.returncode != 0, result
        m.save(out / "start-systemd.json", dict(command=result.args, returncode=result.returncode,
              stdout=result.stdout, stderr=result.stderr, request_ns=start, completed_ns=end))
        state = m.status(unit)
        assert state["ActiveState"] == "failed" and state["MainPID"] == "0", state
        m.save(out / "failed-systemd.json", state)
        journal = checked("journalctl", "--user", "--no-pager", "-u", unit, "-n", 90)
        (out / "failed.journal").write_text(journal)
        assert "persistent graph document changed" in journal, journal
        assert ledger.read_bytes() == previous
        assert sorted(path.name for path in runtime.iterdir()) == ["launch.json"]
        b.capture_native(out, "after")
        m.save(out / "camera-after-failure.json",
               m.wait(lambda: b.retained.advancing_source(end), 20, "new independent camera frames"))
    finally:
        if dropin.is_file():
            dropin.unlink()
        checked("systemctl", "--user", "daemon-reload")
    checked("systemctl", "--user", "reset-failed", unit)
    m.save(out / "publishing-after.json", b.publishing_snapshot())
    assert m.status(unit)["ActiveState"] == "inactive"


if __name__ == "__main__":
    with (m.runtime.parent / "rtc-devel-benchmark.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        probe(b.stage / sys.argv[2], sys.argv[1])
