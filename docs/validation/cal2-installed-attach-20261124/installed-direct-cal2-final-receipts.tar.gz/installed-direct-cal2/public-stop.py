"""Verify exact-unit public SessionRuntime stop on the installed CAL2 candidate."""

import fcntl
from pathlib import Path
import sys

import subprocess

import benchmark as b

m = b.m
unit = "pipewireao-session@c2l-cuda-jhjhtfe9-direct.service"
instance = unit.removeprefix("pipewireao-session@").removesuffix(".service")


def check(directory, app, package):
    directory.mkdir()
    with (m.runtime.parent / "rtc-devel-benchmark.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        assert m.status(unit)["ActiveState"] == "inactive"
        assert m.status(b.baseline_unit)["ActiveState"] == "inactive"
        b.artifact_receipt(directory, unit, app)
        b.capture_native(directory, "before")
        m.save(directory / "publishing-before.json", b.publishing_snapshot())
        try:
            b.systemd_action(directory, unit, "start")
            worker = m.owner(unit)
            m.save(directory / "rtc-identity.json", worker)
            b.capture_native(directory, "ready", attached=True)
            command = ["taskset", "-c", "13", m.julia, "--startup-file=no", "--threads=2,1",
                       "--project=" + str(app), str(b.stage / "public-stop.jl"),
                       unit, str(directory), str(app), str(package)]
            result = subprocess.run(command, timeout=70, env=m.child_env, text=True, capture_output=True)
            m.save(directory / "public-client-command.json", dict(command=result.args,
                returncode=result.returncode, stdout=result.stdout, stderr=result.stderr))
            result.check_returncode()
            receipt = m.load(directory / "public-stop.json")
            assert receipt["stopped"]["service_result"] == "success"
            assert receipt["stopped"]["invocation"] == worker["invocation"]
            assert receipt["stopped"]["session_pid"] == worker["pid"]
            assert receipt["stopped"]["phase"] == "stopped" and receipt["stopped"]["cleanup_complete"]
            state = m.status(unit)
            m.save(directory / "inactive-systemd.json", state)
            assert state["ActiveState"] == "inactive" and state["MainPID"] == "0" and state["Result"] == "success"
            runtime = m.runtime.parent / ("pipewireao-session-" + instance)
            assert b.capture_runtime(directory, runtime, "stopped") == ["launch.json"]
            disk = m.load(runtime / "launch.json")
            m.save(directory / "native-cleanup-receipt.json", disk)
            assert disk["invocation"] == worker["invocation"]
            assert disk["phase"] == "stopped" and disk["cleanup_complete"]
            assert "service_result" not in disk
            b.capture_native(directory, "after")
            m.save(directory / "camera-after-detach.json", m.wait(
                lambda: b.retained.advancing_source(receipt["received_ns"]), 30,
                "both cameras advance after public stop"))
            m.save(directory / "publishing-after.json", b.publishing_snapshot())
            print("Public SessionRuntime stopped the direct RTC and observed systemd success.", flush=True)
        finally:
            state = m.status(unit)
            if state["MainPID"] != "0":
                b.systemd_action(directory, unit, "stop")
            logs = b.command("journalctl", "--user", "--no-pager", "-u", unit, "-n", "110")
            (directory / "unit.journal").write_text(logs.stdout)


if __name__ == "__main__":
    app = Path(sys.argv[1]).resolve(strict=True)
    package = Path(sys.argv[2]).resolve(strict=True)
    check(b.stage / sys.argv[3], app, package)
