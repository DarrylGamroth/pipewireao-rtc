# Final installed direct CAL2 comparison

The verified deployment pins RTC source
`b24edf9785c7ee8e5b958a2ce98f2e8dc5d8729d` and tree
`632900f22f304868f908a71588c50b8a4edfe152`. The installed direct service
uses the original graph installation by its sealed manifest and the same
already-running private core, independent CUDA source, pupil feeder and
camera receiver as the baseline. The baseline was measured earlier on
installed RTC `a4cacb81b0d4a4c4389233da7b57e0be5a83aa0f`. The source diff
from `a4cacb8` to comparison base `bc829d7` is documentation and dated
evidence. Each RTC uses standard Julia 1.13.3. The fixture uses simulated
CAL2 inputs and PipeWireAO graph services on the development workstation.

A separate observer was ready before each timed invocation. The timed
service intervals run from the systemctl request until it returns. Fresh
native Status reported held Ready and 10 owned Links. The native registry
dump also verified the expected names, ordered port pairs and NDArray
formats for those 10 Links. Both integrators reported Open. After native
Start, the observer associated an LLOWFS residual and a valid SCC pair
with camera acquisition identity and model timestamp. Both cameras and
the SCC pair's preceding exposure were observed after Start acknowledgement.
The measured residuals were nonzero and the physical offsets were zero.
Both integrators still reported Open after these results. These trials
used the retained processes' live data and performed no synthetic warmup.

Normal systemd Stop submitted native Quit and observed Offline. On the
direct installation the runtime contained only its fixed launch receipt.
The native registry, process identities and systemd state were checked
after every stop. Both cameras advanced with their original epochs
throughout, and passive tap counters retained zero sequence gaps.

The separately identified public API probe invokes
`SessionRuntime.attach(unit)`, confirms Ready, publishes native Start
with `SessionRuntime.running!`, and submits Quit with
`SessionRuntime.stop!`. The asserted service result comes from
verification against the live systemd manager. The on-disk fixed
receipt records native cleanup.

Earlier trial exclusions remain in the first comparison receipt archive.
The initial baseline Ready witness was excluded when the observing client
omitted a required deadline. That RTC stopped normally. The `eabb6a2`
candidate failed before acquiring native Links because systemd omitted
an empty command property. The repaired `807a698` candidate completed
its own comparison and recovery checks. Those candidate runs are separate
from the final comparison. The intermediate `7b2743c` build was installed
and held while the final stop-reconciliation change was prepared.

## Final results

All three timed trials passed on the final build. Held Ready took
6.049–6.206 s, compared with 6.119–6.276 s on the baseline. Median
time to Ready was 6.205 s and 6.219 s, respectively. Normal detach
took 3.169–3.228 s, compared with 4.385–4.582 s. The median fell from
4.533 s to 3.223 s, a 1.310 s reduction (28.9%). The median interval
from RTC process exit to systemctl completion fell from 1.860 s to
0.403 s. The direct LLOWFS output and SCC pair arrived 0.079–0.402 s
and 2.595–4.918 s after Start acknowledgement, respectively. There
were no exclusions or reruns in the final three-trial block.

The separate public stop probe passed. The returned record reported
`service_result=success` for the exact RTC invocation. The fixed
on-disk receipt reported completed native cleanup and omitted the
service result. Systemd observed inactive with a zero MainPID. The
source and both graph services retained their identities and both
cameras advanced after the public stop. Both the previous and the
direct RTC services were inactive at the final check.

The camera-trace replay verifies every acquisition sequence from the start
of the retained fixture through the public-stop observation. The cumulative
status file is refreshed periodically. The replay receipt uses the newer
individual observations and confirms they have no sequence gaps.
