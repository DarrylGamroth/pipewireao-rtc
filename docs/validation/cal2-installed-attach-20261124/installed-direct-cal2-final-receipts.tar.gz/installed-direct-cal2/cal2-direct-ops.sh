#!/usr/bin/env bash
# Operate the direct RTC attached to the existing independent CUDA CAL2 fixture.
set -euo pipefail
cal2_direct_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /var/tmp/rtc-cal2-cuda.jhjhtFE9/session-env.sh
cal2_direct_instance=c2l-cuda-jhjhtfe9-direct
cal2_direct_unit=pipewireao-session@$cal2_direct_instance.service
cal2_previous_unit=pipewireao-session@c2l-cuda-jhjhtfe9-measure.service
cal2_direct_app=$(dirname -- "$(dirname -- "$(readlink -f -- "$XDG_RUNTIME_DIR/systemd/user/$cal2_direct_unit")")")
case "${1:-status}" in
    status)
        systemctl --user show -p Id,ActiveState,MainPID,InvocationID "$cal2_direct_unit"
        exec "$cal2_fixture/cal2-ops.sh" status
        ;;
    attach)
        exec 9>"$XDG_RUNTIME_DIR/rtc-devel-benchmark.lock"
        flock -x 9
        test "$(systemctl --user show "$cal2_previous_unit" -p MainPID --value)" = 0
        exec systemctl --user start "$cal2_direct_unit"
        ;;
    start)
        exec 9>"$XDG_RUNTIME_DIR/rtc-devel-benchmark.lock"
        flock -x 9
        export JULIA_DEPOT_PATH="$cal2_direct_dir/depot:$JULIA_DEPOT_PATH"
        export PIPEWIREAO_RUNTIME_DIR="${PIPEWIREAORTC_CORE_SOCKET%/*}"
        export PIPEWIRE_RUNTIME_DIR="$PIPEWIREAO_RUNTIME_DIR"
        export PIPEWIREAO_CONFIG_DIR="$cal2_fixture/core-config"
        export PIPEWIREAO_MODULE_DIR="$PIPEWIREAO_PREFIX/lib/pipewire-ao-0.3"
        export PIPEWIREAO_SPA_PLUGIN_DIR="$PIPEWIREAO_PREFIX/lib/spa-ao-0.2"
        export LD_LIBRARY_PATH="$PIPEWIREAO_PREFIX/lib"
        exec taskset -c 13 "$CAL2_VALIDATION_JULIA" --startup-file=no --threads=2,1 \
            --project="$cal2_direct_app" -e '
                import PipeWireAORTC
                runtime = PipeWireAORTC.SessionRuntime
                println(runtime.running!(runtime.attach(only(ARGS)))["phase"])
            ' "${XDG_RUNTIME_DIR}/pipewireao-session-$cal2_direct_instance"
        ;;
    detach)
        exec 9>"$XDG_RUNTIME_DIR/rtc-devel-benchmark.lock"
        flock -x 9
        exec systemctl --user stop "$cal2_direct_unit"
        ;;
    *)
        printf 'Use %s {status|attach|start|detach}\n' "$0" >&2
        exit 2
        ;;
esac
