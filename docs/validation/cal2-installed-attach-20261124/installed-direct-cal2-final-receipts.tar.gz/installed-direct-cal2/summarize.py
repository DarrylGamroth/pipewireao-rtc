"""Summarize comparable systemd intervals from the archived CAL2 trials."""

import csv
import json
from pathlib import Path
import statistics
import sys


def millis(time_ns):
    return round(time_ns / 1e6, 3)


def run(groups):
    measurements = {}
    writer = csv.writer(sys.stdout)
    writer.writerow(("arm", "trial", "ready_s", "stop_s", "quit_to_offline_ms",
                     "stop_before_quit_ms", "llowfs_first_s", "scc_pair_first_s",
                     "llowfs_acquisition", "scc_acquisition"))
    link_serials = set()
    pids = set()
    for group in groups:
        for trial in json.loads((Path(group) / "trials.json").read_text()):
            arm = trial["arm"]
            result = measurements.setdefault(arm, {"attach": [], "detach": []})
            for op in result:
                result[op].append(trial[op]["elapsed_s"])
            assert trial["rtc"]["pid"] not in pids
            pids.add(trial["rtc"]["pid"])
            links = set(trial["link_serials"])
            assert len(links) == 10 and links.isdisjoint(link_serials)
            link_serials.update(links)
            quit = trial["native_quit"]
            submit = quit["deadline_ns"] - quit["quit_submission_remaining_ns"]
            offline = quit["deadline_ns"] - quit["offline_remaining_ns"]
            frames = trial["fresh_open_frames"]
            writer.writerow((arm, trial["directory"], round(trial["attach"]["elapsed_s"], 6),
                round(trial["detach"]["elapsed_s"], 6), millis(offline - submit),
                millis(submit - trial["detach"]["request_ns"]),
                round(frames["llowfs"]["first_observed_s"], 6),
                round(frames["scc"]["first_observed_s"], 6),
                frames["llowfs"]["camera"]["sequence"], frames["scc"]["camera"]["sequence"]))
    for arm, result in measurements.items():
        for op, data in result.items():
            print(f"{arm} {op}, median {statistics.median(data):.3f} s, "
                  f"range {min(data):.3f}–{max(data):.3f} s", file=sys.stderr)


if __name__ == "__main__":
    run(sys.argv[1:])
