using PipeWireAORTC

const RTC = PipeWireAORTC
const Runtime = RTC.SessionRuntime

function run(unit, directory, expected_installation, expected_package)
    @assert pkgdir(RTC) == expected_package
    handle = Runtime.attach(unit)
    held = Runtime.ready(handle)
    @assert held["phase"] == "ready"
    RTC.Common.write_json(joinpath(directory, "held.json"), held; atomic = true)
    running = Runtime.running!(handle)
    @assert running["phase"] == "running"
    RTC.Common.write_json(joinpath(directory, "running.json"), running; atomic = true)
    sent_ns = time_ns()
    stopped = Runtime.stop!(handle)
    received_ns = time_ns()
    @assert stopped["service_result"] == "success" stopped
    @assert stopped["phase"] == "stopped" && stopped["cleanup_complete"] stopped
    @assert stopped["invocation"] == handle.invocation stopped
    @assert stopped["direct_attach"] === true stopped
    @assert stopped["admission"]["package"] == expected_installation stopped
    RTC.Common.write_json(joinpath(directory, "public-stop.json"), (; sent_ns, received_ns, stopped); atomic = true)
    return nothing
end

run(ARGS...)
