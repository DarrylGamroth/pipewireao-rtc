using PipeWireAORTC

const RTC = PipeWireAORTC
const Client = RTC.SessionClient
const Discovery = RTC.SessionDiscovery
const Graphs = ("cal2-llowfs-controller", "cal2-scc-controller")
const Closed = "correction:closed"
const State = "pipewireao.correction-control.correction:closed"

function request(connection, operation, arguments...)
    sent_ns = time_ns()
    command = RTC.SessionCodec.RunnerCommand(operation, arguments...)
    completion = Client.request!(connection, command; deadline = RTC.ControlClient.monotonic() + 15)
    received_ns = time_ns()
    reply = Client.render_direct(connection, completion)
    @assert reply["ok"] reply
    return (; sent_ns, received_ns, reply)
end

function observe_open(connection, expected; held)
    status = request(connection, :status)
    @assert status.reply["state"] == expected status
    @assert status.reply["result"]["owned_links"] == 10 status
    @assert status.reply["result"]["running"] === !held status
    properties = map(Graphs) do graph
        result = request(connection, :properties, graph)
        values = result.reply["result"]["properties"]
        @assert values[Closed]["value"] === false values
        @assert values[State * ".state"]["value"] == "Open" values
        @assert values[State * ".requested"]["value"] === false values
        @assert isempty(values[State * ".fault"]["value"]) values
        held && @assert values[State * ".primed"]["value"] === false values
        return result
    end
    return (; status, properties)
end

function wait_for_file(path)
    deadline = time_ns() + 180_000_000_000
    while !isfile(path)
        time_ns() < deadline || error("Timed out waiting for " * path)
        sleep(0.01)
    end
end

function run(directory, pid, remote)
    listing = Discovery.list_sessions(Discovery.existing_registry_directory())
    selected = only(filter(listing) do entry
        record = entry.record
        return record !== nothing && record.owner_pid == pid && record.remote == remote
    end)
    connection = Client.select_direct_session(selected; deadline = Int64(time_ns()) + 20_000_000_000)
    @assert connection isa Client.Connection connection
    try
        held = observe_open(connection, "Ready"; held = true)
        RTC.Common.write_json(joinpath(directory, "held.json"), held; atomic = true)
        wait_for_file(joinpath(directory, "start"))
        start = request(connection, :session_start)
        @assert start.reply["state"] == "Running" start
        RTC.Common.write_json(joinpath(directory, "started.json"), start; atomic = true)
        wait_for_file(joinpath(directory, "read-running"))
        running = observe_open(connection, "Running"; held = false)
        RTC.Common.write_json(joinpath(directory, "running.json"), running; atomic = true)
    finally
        close(connection)
    end
end

run(ARGS[1], parse(UInt32, ARGS[2]), ARGS[3])
