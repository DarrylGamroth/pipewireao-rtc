import json, os, pathlib, re, shutil, subprocess as sp, sys
root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path("/home/dgamroth/workspaces/codex/worktrees/rtc-installed-attach")
stock=pathlib.Path("/var/tmp/rtc-ndarray-integration.beRGH1")
profile, commit, scope=sys.argv[1:]
rev=sp.check_output(["git","-C",repo,"rev-parse",f"{commit}^{{commit}}"],text=True).strip()
tree=sp.check_output(["git","-C",repo,"rev-parse",f"{commit}^{{tree}}"],text=True).strip()
julia=(pathlib.Path.home()/(".julia/juliaup/julia-1.13.4+0.x64.linux.gnu/bin/julia"))
depot=[root/"depot",stock/"classic/depot",stock/"instruments/depot",
       pathlib.Path("/var/tmp/gpi2-source-revocation.integration.J7fhfNWC/arm/depot"),
       pathlib.Path("/var/tmp/gpi2-source-revocation.integration.J7fhfNWC/arm/run-depot"),
       pathlib.Path("/var/tmp/cal2-independent.UcNIRN/private-depot"),
       pathlib.Path("/var/tmp/cal2-services.6DdlJUDp/depot"),
       pathlib.Path("/var/tmp/cal2-live-prime.12QydM/depot"),pathlib.Path.home()/".julia"]
env=dict(os.environ,JULIA_DEPOT_PATH=":".join(map(str,depot))+":",JULIA_LOAD_PATH="@:@stdlib",
         JULIA_NUM_PRECOMPILE_TASKS="1",JULIA_IMAGE_THREADS="1",OPENBLAS_NUM_THREADS="1",
         XDG_CACHE_HOME=str(root/"cache"),POCL_CACHE_DIR=str(root/"cache/pocl"),TMPDIR=str(root/"tmp"))
slug=sp.check_output([julia,"--startup-file=no","-e",
    'using UUIDs; print(Base.version_slug(UUID("a3e2c7da-f73f-4284-8482-36ac422b34e6"), Base.SHA1(hex2bytes(only(ARGS)))))',
    tree],env=env,text=True)
package=root/"depot/packages/PipeWireAORTC"/slug
if not package.is_dir():
    package.mkdir(parents=True)
    with sp.Popen(["git","-C",repo,"archive",rev],stdout=sp.PIPE) as archive:
        sp.run(["tar","-x","-C",package],stdin=archive.stdout,check=True)
        assert archive.wait()==0
fgpw_repo=os.environ.get("RTC_VALIDATION_FGPW")
companion=None
if fgpw_repo:
    branch="julia/FilterGraphPipeWire"
    fgpw_rev=sp.check_output(["git","-C",fgpw_repo,"rev-parse","8b1838554f7fef041cbfedd9e21d8d1bf0898bee"],text=True).strip()
    fgpw_tree=sp.check_output(["git","-C",fgpw_repo,"rev-parse",f"{fgpw_rev}:{branch}"],text=True).strip()
    fgpw_slug=sp.check_output([julia,"--startup-file=no","-e",
        'using UUIDs; print(Base.version_slug(UUID("0366a544-13dd-48a3-a3d6-bd2ba4547294"), Base.SHA1(hex2bytes(only(ARGS)))))',
        fgpw_tree],env=env,text=True)
    companion=root/"depot/packages/FilterGraphPipeWire"/fgpw_slug
    if not companion.is_dir():
        companion.mkdir(parents=True)
        with sp.Popen(["git","-C",fgpw_repo,"archive",fgpw_rev,branch],stdout=sp.PIPE) as archive:
            sp.run(["tar","-x","--strip-components=2","-C",companion],stdin=archive.stdout,check=True)
            assert archive.wait()==0
inputs={"classic":stock/"classic/export", "gpi2":stock/"instruments/sources/gpi2-final",
        "spiders":stock/"instruments/sources/spiders"}[profile]
owner_optimization = os.environ.get("RTC_FUNCTIONAL_GRAPH_OPTLEVEL")
assert owner_optimization is None or owner_optimization == "0"
optimization_suffix = "-o0" if owner_optimization else ""
app=root/f"{profile}-{scope}-{rev[:7]}{("-"+fgpw_tree[:7]) if companion else ""}{optimization_suffix}"
def write(path,text):
    path.unlink(missing_ok=True)
    path.write_text(text)
if not app.exists():
    def ignores(directory,entries):
        return {"graph-startup","optical-startup","command-receiver","systemd", ".rtc-export.git"}.intersection(entries) if pathlib.Path(directory)==inputs else set()
    shutil.copytree(inputs,app,copy_function=os.link,ignore=ignores)
    manifest=app/"Manifest.toml"
    old=manifest.read_text()
    pattern=r"(\[\[deps\.PipeWireAORTC\]\]\n)(.*?)(?=\n\[\[deps\.)"
    match=re.search(pattern,old,flags=re.S)
    import tomllib
    metadata=tomllib.loads((package/"Project.toml").read_text())
    new=re.sub(r'^deps = .*$',"deps = "+json.dumps(sorted(metadata["deps"])),match[2],count=1,flags=re.M)
    new=re.sub(r'^git-tree-sha1 = .*$',"git-tree-sha1 = "+json.dumps(tree),new,count=1,flags=re.M)
    new=re.sub(r'^version = .*$',"version = "+json.dumps(metadata["version"]),new,count=1,flags=re.M)
    write(manifest,old[:match.start(2)]+new+old[match.end(2):])
    if companion:
        data=manifest.read_text()
        data,n=re.subn(r'(\[\[deps\.FilterGraphPipeWire\]\][\s\S]*?git-tree-sha1 = ")[0-9a-f]{40}(")',
                       lambda match:match[1]+fgpw_tree+match[2],data,count=1)
        assert n==1
        write(manifest,data)
    project=app/"Project.toml"
    write(project,re.sub(r'^PipeWireAORTC = "=0\.7\.\d+"$',f'PipeWireAORTC = "={metadata["version"]}"',project.read_text(),flags=re.M))
    digest=sp.check_output([julia,"--startup-file=no","--project="+str(app),"-e",
        "using Pkg; print(Pkg.Types.project_resolve_hash(Pkg.Types.EnvCache(Base.active_project()), VERSION))"],env=env,text=True)
    write(manifest,re.sub(r'^project_hash = ".*"$',f'project_hash = "{digest}"',manifest.read_text(),flags=re.M))
    cpus={2:12,3:13,6:14,7:15,8:12,9:13,10:14,11:15}
    def cpu(value):
        return cpus[value]
    def change_list(cpulist):
        return ",".join(str(cpu(int(value))) for value in cpulist.split(","))
    def change_mask(text):
        return re.sub(r"\bthread\.affinity(?:\s*=\s*|\s*:\s*)(\[[0-9\s,]+\])",
            lambda match: match.group(0).replace(match[1],re.sub(r"\d+",lambda value:str(cpu(int(value[0]))),match[1])),text)
    config=app/"deployment.conf"
    spec=json.loads(config.read_text())
    spec["name"]=profile+"-direct-"+root.name[-5:].lower()
    for analysis in spec.get("analysis", []):
        analysis["cpus"]=[4,5]
    for place in spec["placement"].values():
        place["cpus"]=sorted(set(map(cpu,place["cpus"])))
        place["leader-cpu"]=cpu(place["leader-cpu"])
        for thread in place["threads"]:
            if "cpu" in thread: thread["cpu"]=cpu(thread["cpu"])
            if "cpus" in thread: thread["cpus"]=sorted(set(map(cpu,thread["cpus"])))
    for path in {spec["core"],*spec["client"].values()}:
        p=app/path
        data=p.read_text()
        remapped=change_mask(data)
        if remapped!=data: write(p,remapped)
    primes={"classic":["slopes,validity"],"gpi2":["reconstruction-pixels"],
        "spiders":["correction:closed=modal-residual","llowfs-correction:closed=llowfs-modal-residual,llowfs-validity"]}[profile]
    primary={"classic":"julia","gpi2":"julia","spiders":"spiders-scc"}[profile]
    for owner in spec["owners"]:
        args=owner["argv"]
        args[0]=str(julia)
        if owner_optimization and owner["role"]!=spec["source-owner"]:
            args.insert(1, "-O"+owner_optimization)
        for option in ("--pipewire-cpu","--optical-diagnostics-cpu","--pupil-output-cpu","--pin-cpus"):
            if option in args:
                index=args.index(option)+1
                args[index]=change_list(args[index])
        if owner["role"]==primary:
            for prime in primes:
                args.extend(["--prime-on-output",prime])
            graph=app/args[args.index("--graph")+1].removeprefix("@PACKAGE@/")
            if profile!="spiders":
                text=graph.read_text()
                target=r'(name = closed-loop-correction\b(?:.(?!\n\s*\}))*?props = \{)'
                start=text.index("name = closed-loop-correction")
                props=text.index("props = {",start)+len("props = {")
                write(graph,text[:props]+"\n          closed = false"+text[props:])
    write(config,json.dumps(spec,sort_keys=True,separators=(",",":"))+"\n")
record={"profile":profile,"commit":rev,"tree":tree,"input":str(inputs),"source":str(package),
        "app":str(app),"owner_optimization":owner_optimization,"julia":str(julia),"env":{key:env[key] for key in
        ["JULIA_DEPOT_PATH","JULIA_LOAD_PATH","JULIA_NUM_PRECOMPILE_TASKS","JULIA_IMAGE_THREADS","OPENBLAS_NUM_THREADS","XDG_CACHE_HOME","POCL_CACHE_DIR","TMPDIR"]}}
(root/f"{profile}-{scope}.json").write_text(json.dumps(record,indent=2)+"\n")
if companion:
    record["fgpw"]={"source":str(companion),"commit":fgpw_rev,"tree":fgpw_tree}
    (root/f"{profile}-{scope}.json").write_text(json.dumps(record,indent=2)+"\n")
print(app)
if os.environ.get("RTC_STAGE_ONLY") != "1" and not (app/"systemd/pipewireao-session@.service").exists():
    sp.run(["nice","-n","6","taskset","-c","14,15",julia,"--startup-file=no","--threads=2,0","--project="+str(app),
            str(root/"install.jl"),str(app),str(package),scope],env=env,check=True)
