using PipeWireAORTC, PipeWireAO, TOML

const R = PipeWireAORTC
const L = R.SessionLaunch
const C = R.Common
const D = R.DeploymentConfiguration
const BASE = only(ARGS)
const COMMIT = "b24edf9785c7ee8e5b958a2ce98f2e8dc5d8729d"
const TREE = "632900f22f304868f908a71588c50b8a4edfe152"
const PREFIX = realpath(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
const PROFILES = (
    ("classic", 5, ["julia"], ["wfs"]),
    ("gpi2", 8, ["julia"], ["pupil-flux"]),
    ("spiders", 1, ["scc-differential", "spiders-scc"], String[]),
)
const CORE = "rtc-sealed-companions-core.service"
const SOURCE = "rtc-sealed-companions-source.service"
const SOCKET = "/run/user/1000/rtc-sealed-companions"
ENV["PIPEWIREAORTC_CORE_UNIT"] = CORE
ENV["PIPEWIREAORTC_SOURCE_UNIT"] = SOURCE
ENV["PIPEWIREAORTC_CORE_SOCKET"] = SOCKET

function verify_profile(profile, parameter_count, graph_roles, analysis_roles)
    staged = C.read_json(joinpath(BASE, profile * "-persistent.json"))
    @assert staged["commit"] == COMMIT && staged["tree"] == TREE
    @assert realpath(staged["source"]) == realpath(pkgdir(R))
    package = staged["app"]
    manifest = TOML.parsefile(joinpath(package, "Manifest.toml"))
    @assert only(manifest["deps"]["PipeWireAORTC"])["git-tree-sha1"] == TREE
    if profile == "spiders"
        @assert staged["fgpw"]["commit"] == "8b1838554f7fef041cbfedd9e21d8d1bf0898bee"
        @assert only(manifest["deps"]["FilterGraphPipeWire"])["git-tree-sha1"] == staged["fgpw"]["tree"]
    end
    R.ScienceExport.stage_rtc!(package)
    R.InstrumentExport.seal!(package)
    destination = package * "-installed"
    @assert R.SessionInstall.install((;
        package, destination, pipewire_prefix=PREFIX, persistent_graph_owners=true,
    )) == destination
    systemd = joinpath(destination, "systemd")
    activation_path = joinpath(systemd, L.ACTIVATION_FILE)
    activation = C.read_json(activation_path)
    config_path = joinpath(systemd, "rtc.conf")
    @assert activation["config"] == config_path
    @assert D.decode(config_path, PREFIX)["context.properties"]["remote.name"] == SOCKET
    main_unit_path = joinpath(systemd, "pipewireao-session@.service")
    main_unit = read(main_unit_path, String)
    @assert occursin(" -c \"$config_path\"", main_unit) && !occursin("ExecStopPost=", main_unit)
    @assert occursin(L.ACTIVATION_ENV * "=" * C.sha256_file(activation_path), main_unit)
    wanted = split(only(filter(startswith("Wants="), split(main_unit, '\n')))[7:end])
    parameters_path = joinpath(systemd, "parameters", "sources.json")
    @assert length(C.read_json(parameters_path)["sources"]) == parameter_count

    name = activation["profile"]["name"]
    templates = [L.support_unit_name("parameters", name, destination);
        [L.support_unit_name("analysis-" * role, name, destination) for role in analysis_roles]]
    companion_units = replace.(templates, "@.service" => "@%i.service")
    @assert sort(activation["direct-companions"]) == sort(companion_units)
    direct_services = activation["direct-services"]
    @assert direct_services["parameters"] == first(companion_units)
    @assert direct_services["core"] == CORE && direct_services["simulator"] == SOURCE
    @assert !any(startswith("analysis-"), keys(direct_services))
    companion_paths = joinpath.(systemd, templates)
    for fragment in companion_paths
        @assert activation["files"][fragment] == L.graph_file_identity(fragment)
        @assert occursin("PartOf=pipewireao-session@%i.service", read(fragment, String))
    end
    parameter_service = activation["direct-parameter-service"]
    @assert parameter_service["fragment"] == first(companion_paths)
    @assert parameter_service["sha256"] == C.sha256_file(first(companion_paths))

    manifest_path = activation["graph-manifest"]
    @assert activation["graph-manifest-sha256"] == C.sha256_file(manifest_path)
    graph_manifest = C.read_json(manifest_path)
    @assert sort(collect(keys(graph_manifest["owners"]))) == graph_roles
    @assert graph_manifest["core"] == CORE && graph_manifest["source"] == SOURCE
    graph_paths = String[]
    graph_units = String[]
    for role in graph_roles
        item = graph_manifest["owners"][role]
        @assert direct_services[role] == item["unit"]
        @assert item["unit"] ∉ activation["direct-companions"]
        @assert item["sha256"] == C.sha256_file(item["fragment"])
        graph_unit = read(item["fragment"], String)
        @assert occursin("Requisite=$CORE", graph_unit)
        @assert occursin("bind_persistent_graph!", graph_unit)
        @assert all(key -> !occursin(key, graph_unit), ("PartOf=", "BindsTo=", "StopWhenUnneeded="))
        push!(graph_units, item["unit"])
        push!(graph_paths, item["fragment"])
    end
    @assert sort(wanted) == sort([companion_units; graph_units])

    paths = [activation_path, config_path, main_unit_path, manifest_path, parameters_path,
        joinpath(destination, "Manifest.toml"), joinpath(destination, "deployment.conf")]
    append!(paths, companion_paths)
    append!(paths, graph_paths)
    println(profile, " verified with ", parameter_count, " parameter sources, ",
        length(analysis_roles), " optional analysis units and independent graph units ", graph_units)
    return Dict(
        "profile" => profile, "installed_path" => destination,
        "companion_units" => companion_units, "parameter_sources" => parameter_count,
        "analysis_roles" => analysis_roles, "independent_graph_units" => graph_units,
        "sha256" => Dict(relpath(path, destination) => C.sha256_file(path) for path in paths),
    )
end

results = [verify_profile(profile...) for profile in PROFILES]
C.write_json(joinpath(BASE, "results.json"), Dict(
    "commit" => COMMIT, "tree" => TREE, "installer" => pathof(R), "native_prefix" => PREFIX,
    "julia_version" => string(VERSION), "pipewireao_jll_version" => string(pkgversion(PipeWireAO.LibPipeWire.PipeWireAO_jll)),
    "profiles" => results,
))
