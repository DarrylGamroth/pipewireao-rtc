# Offline sealed-companion installation check

The driver loads PipeWireAORTC from the registered package tree for commit
`b24edf9785c7ee8e5b958a2ce98f2e8dc5d8729d`. The instrument inputs are the
calibrated Classic, GPI2, and fitted dual SPIDERS exports preserved in
`/var/tmp/rtc-ndarray-integration.beRGH1`. The staging driver applies the
recorded open-loop and live-priming declarations. The SPIDERS application
pins FilterGraphPipeWire companion commit
`8b1838554f7fef041cbfedd9e21d8d1bf0898bee`.

Extract the two driver files in a fresh workspace on the fixture host
and run these commands there.

```sh
revision=b24edf9785c7ee8e5b958a2ce98f2e8dc5d8729d
mkdir tmp cache
for profile in classic gpi2; do
    RTC_STAGE_ONLY=1 RTC_FUNCTIONAL_GRAPH_OPTLEVEL=0 taskset -c 1 python3 stage.py "$profile" "$revision" persistent
done
RTC_STAGE_ONLY=1 RTC_FUNCTIONAL_GRAPH_OPTLEVEL=0 RTC_VALIDATION_FGPW=/home/dgamroth/workspaces/codex/pipewire/JuliaFilterGraph.jl taskset -c 1 python3 stage.py spiders "$revision" persistent
classic=$(python3 -c 'import json; print(json.load(open("classic-persistent.json"))["app"])')
export JULIA_DEPOT_PATH=$(python3 -c 'import json; print(json.load(open("classic-persistent.json"))["env"]["JULIA_DEPOT_PATH"])')
taskset -c 1 julia --startup-file=no --compiled-modules=existing -O0 --project="$classic" verify.jl "$PWD"
```

The check installs each sealed export through the ordinary installer. It
opens the resulting fixed RTC configuration with the native parser and checks
the activation seal, the parameter source count, the instance-scoped support
units and the independent persistent graph fragments. Service ownership here
comes from the installed unit declarations. This check is offline.
