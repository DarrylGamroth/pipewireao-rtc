from pathlib import Path
import sys

source = Path(sys.argv[1])


def inject(file, operations):
    path = source / file
    text = path.read_text()
    for fragment, replacement in operations:
        assert text.count(fragment) == 1, (file, fragment, text.count(fragment))
        text = text.replace(fragment, replacement)
    path.write_text(text)


def marker(label, indent):
    return " " * indent + f'PipeWireAORTC.startup_attribution("{label}")'


def before(label, fragment, indent):
    return fragment, marker(label, indent) + "\n" + fragment


def after(label, fragment, indent):
    return fragment, fragment + "\n" + marker(label, indent)


def around(label, fragment, indent):
    return fragment, marker(label + "_begin", indent) + "\n" + fragment + "\n" + marker(label + "_end", indent)


inject("src/PipeWireAORTC.jl", [
    ('include("media_session/MediaSession.jl")', '''const STARTUP_ATTRIBUTION = Ref(:none)

function startup_attribution(label)
    STARTUP_ATTRIBUTION[] === :none && return nothing
    now = time_ns()
    comp, recomp = Base.cumulative_compile_time_ns()
    cpu = Common.startup_process_cpu_ns()
    tid = ccall(:gettid, Cint, ())
    thread_time = Ref{NTuple{2,Clong}}()
    ccall(:clock_gettime, Cint, (Cint, Ref{NTuple{2,Clong}}), Cint(3), thread_time)
    seconds, nanoseconds = thread_time[]
    thread_cpu = seconds * 1_000_000_000 + nanoseconds
    wait = Common.startup_thread_runqueue_ns(tid)
    println(stderr, "RTC_STARTUP ", getpid(), " ", label, " ", now, " ",
        comp, " ", recomp, " ", cpu, " ", tid, " ", thread_cpu, " ", wait)
    return nothing
end

function end_startup_attribution()
    STARTUP_ATTRIBUTION[] === :none && return nothing
    STARTUP_ATTRIBUTION[] === :trace &&
        ccall(:jl_force_trace_compile_timing_disable, Cvoid, ())
    Base.cumulative_compile_timing(false)
    STARTUP_ATTRIBUTION[] = :none
    return nothing
end

function __init__()
    mode = get(ENV, "RTC_STARTUP_ATTRIBUTION", "")
    mode in ("phases", "trace") && length(ARGS) == 2 && first(ARGS) == "-c" &&
        haskey(ENV, "PIPEWIREAORTC_ACTIVATION_SHA256") &&
        haskey(ENV, "PIPEWIREAORTC_SYSTEMD_UNIT") || return nothing
    # Compile the diagnostic logger before turning on the measurement counters.
    startup_attribution("commissioning")
    STARTUP_ATTRIBUTION[] = Symbol(mode)
    Base.cumulative_compile_timing(true)
    STARTUP_ATTRIBUTION[] === :trace &&
        ccall(:jl_force_trace_compile_timing_enable, Cvoid, ())
    startup_attribution("package_init")
    return nothing
end

include("media_session/MediaSession.jl")''')
])
inject("src/media_session/MediaSession.jl", [
    ("import ..Common\n", "import ..PipeWireAORTC\nimport ..Common\n"),
])
inject("src/deployment/session_cli.jl", [
    around("installation_check", "    activation = activation_document(package, digest)", 4),
    around("prepare_invocation", "    SessionLaunch.prepare!(request; render!, validate_profile = require_node_owners, activation)", 4),
    around("placement", '    record["placement_snapshot"] = _placement_snapshot(context; deadline, clock)', 4),
    around("discovery", '    context.discovery = _verified_discovery!(record, session_record)', 4),
    around("retain_ledger", '    SessionLaunch.launch_record!(record["runtime"], record)', 4),
])
inject("src/deployment/session_launch.jl", [
    around("check_persistent_graphs", "    persistent = retain_persistent_graphs!(package, prefix, spec, external, coordinator, record)", 4),
    around("render_inputs", "    session = render_inputs!(request, spec, bindings, runtime; graphs)", 4),
    before("validate_rendered_inputs_end", "    prepare_julia_overlay!(request, paths, spec, runtime)", 4),
    before("reserve_external_owners_begin", "        services = Dict{String,S.Service}()", 8),
    before("verify_core_begin", "        wait_core!(core, remote)", 8),
    before("verify_core_end", "        hil_startup = external === nothing", 8),
    before("render_configuration_begin", "        config = render!(\n", 8),
    before("verify_owners_begin", "        final_coordinator, started_us = preparation_identity(request, source_role; main)", 8),
    before("verify_owners_end", '        julia = main ? String(activation["julia"]) : D.selected_julia_executable(Base.julia_cmd().exec[1])', 8),
])
inject("src/media_session/session.jl", [
    around("activate", "    SessionCLI.activate_installed!(last(arguments))", 4),
    around("construct", "    session = Session(last(arguments))", 4),
    around("verify_installed_main", "    deployment = SessionCLI.installed_admission(file; clock)", 4),
    before("serve", "        serve!(session)", 8),
    ("    session.active_task = @async execute_effect!(session, job)",
     '    PipeWireAORTC.startup_attribution("submit_" * string(nameof(typeof(ticket.effect))))\n'
     '    session.active_task = @async execute_effect!(session, job)'),
    ("        result = perform!(session, job, ticket.effect)",
     '        PipeWireAORTC.startup_attribution("begin_" * string(nameof(typeof(ticket.effect))))\n'
     '        result = perform!(session, job, ticket.effect)\n'
     '        PipeWireAORTC.startup_attribution("end_" * string(nameof(typeof(ticket.effect))))'),
])
inject("src/media_session/admission.jl", [
    before("connect_proof_client_begin", "    client = ControlClient.connect(\n", 4),
    after("connect_proof_client_end", "    admission.client = client", 4),
    around("verify_activation_identity", "    SessionCLI.verify_admission!(admission.deployment, endpoint; deadline, clock)", 4),
    before("native_status_begin", "        completion = ControlClient.request!(\n", 8),
    after("native_status_end", "        SessionCLI.confirm_ready(completion)", 8),
    before("publication_begin", "        SessionCLI.publish_ready!(admission.deployment, endpoint; deadline, clock) do", 8),
    before("publication_end", "        admission.result = DiscoveryPublished()", 8),
    around("close_proof_client", "    close(something(admission.client))", 4),
    around("fence_native_sync", "    synchronize!(session, job)", 4),
    around("verify_held_links", "    verify_held_links!(session)", 4),
    ("        SessionCLI.notify_ready!()",
     '        PipeWireAORTC.startup_attribution("notify_begin")\n'
     '        SessionCLI.notify_ready!()\n'
     '        PipeWireAORTC.startup_attribution("notify_end")\n'
     '        PipeWireAORTC.end_startup_attribution()'),
])
