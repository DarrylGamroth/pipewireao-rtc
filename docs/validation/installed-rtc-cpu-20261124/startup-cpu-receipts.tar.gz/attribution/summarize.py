#!/usr/bin/env python3
"""Summarize observer and phase markers for installed RTC starts."""
from collections import Counter
import json
from pathlib import Path
import re
from statistics import median
import subprocess
import sys


def summarize(directory):
    receipt = json.loads((directory / "observer.json").read_text())
    state = receipt["after_start_properties"]
    starting = int(state["ExecMainStartTimestampMonotonic"]) * 1000
    ready = int(state["ActiveEnterTimestampMonotonic"]) * 1000
    start_request = receipt["requested_ns"]
    samples = [row for row in receipt["samples"] if row["time_ns"] <= ready]
    last = samples[-1]
    ticks = last["proc"]
    hz = receipt["proc_stat_hz"]
    numbers = {
        "request_to_active_s": (ready - start_request) / 1e9,
        "request_to_return_s": (receipt["returned_ns"] - start_request) / 1e9,
        "request_to_main_s": (starting - start_request) / 1e9,
        "main_to_active_s": (ready - starting) / 1e9,
        "pid_to_first_sample_s": (samples[0]["time_ns"] - starting) / 1e9,
        "last_sample_before_active_s": (ready - last["time_ns"]) / 1e9,
        "main_cpu_s": last["main_thread_cpu_ns"] / 1e9,
        "main_runnable_wait_s": last["main_thread_runqueue_ns"] / 1e9,
        "main_other_s": (last["time_ns"] - starting - last["main_thread_cpu_ns"] -
                         last["main_thread_runqueue_ns"]) / 1e9,
        "process_user_s": ticks["user_ticks"]/hz,
        "process_kernel_s": ticks["system_ticks"]/hz,
        "reaped_child_cpu_s": (ticks["child_user_ticks"]+ticks["child_system_ticks"])/hz,
        "major_faults": ticks["majflt"],
        "proc_io": last["proc_io"],
        "observer_cpu_s": receipt["observer_process_cpu_ns"]/1e9,
        "observer_children_cpu_s": receipt["observer_children_cpu_seconds"],
        "median_sample_s": median(row["sample_duration_ns"] for row in samples)/1e9,
        "waiting_snapshots": Counter(row["wchan"] for row in samples),
    }
    for cpu in ("2", "3"):
        freq = [row["scaling_cur_freq_khz"][cpu] for row in samples if cpu in row["scaling_cur_freq_khz"]]
        if freq:
            numbers[f"cpu{cpu}_scaling_freq_khz_min_med_max"] = [min(freq), median(freq), max(freq)]
    perf_file = directory / "perf.data"
    if perf_file.exists():
        lines = subprocess.check_output(
            ["perf", "script", "-i", str(perf_file), "-F", "tid,time,period,ip,sym,dso"], text=True
        ).splitlines()
        counts = Counter()
        weights = Counter()
        first = None
        for line in lines:
            match = re.fullmatch(r"\s*(\d+)\s+(\d+\.\d+):\s+(\d+)\s+([a-f0-9]+)\s+(.*?)\s+\((.+)\)", line)
            if not match:
                continue
            t = float(match[2])
            if t > ready/1e9:
                break
            first = t if first is None else first
            symbol, dso = match[5], match[6]
            if "libLLVM" in dso or "libjulia-codegen" in dso:
                label = "JIT codegen and LLVM"
            elif re.match(r"^(?:julia|j1|jfptr)_", symbol) and re.search(
                r"typeinf|abstract_(?:call|eval|interpret)|infer_(?:call|result)|native_interp", symbol
            ):
                label = "Julia inference symbol"
            elif "libjulia-internal" in dso and re.search(
                r"(?:jl_compile_method_internal|jl_type_infer|jl_get_compile_hint)", symbol
            ):
                label = "Julia compiler runtime symbol"
            elif re.match(r"(?:gc_mark_|gc_sweep_|jl_gc_collect)", symbol):
                label = "GC mark/sweep"
            elif re.match(r"(?:jl_read_reloclist|jl_restore_package_image)", symbol):
                label = "Julia package image restoration symbol"
            elif "/compiled/" in dso:
                label = "Prebuilt package code"
            else:
                label = "Other/unresolved " + Path(dso).name
            counts[label] += 1
            weights[label] += int(match[3])
        numbers["perf_first_s_after_main"] = None if first is None else first - starting/1e9
        numbers["perf_samples"] = dict(counts.most_common())
        numbers["perf_cpu_clock_ns"] = dict(weights.most_common())

    print(directory, json.dumps(numbers, indent=2))


def phases(journal):
    phase_pattern = re.compile(
        r"RTC_STARTUP (\d+) (\w+) " + r" ".join([r"(\d+)"]*7)
    )
    compile_pattern = re.compile(r"#=\s*([\d.]+) ms\s*=#\s*(precompile\(.*)$")
    marks = []
    signatures = []
    previous_label = None
    for line in journal.read_text().splitlines():
        phase = phase_pattern.search(line)
        if phase:
            pid, label, now, compile_time, recompile_time, cpu, tid, thread_cpu, wait = phase.groups()
            marks.append((label, *(int(value) for value in phase.groups()[2:])))
            previous_label = label
        signature = compile_pattern.search(line)
        if signature and previous_label != "notify_end":
            signatures.append((float(signature[1]), previous_label, signature[2]))
    print(journal, "successive marker deltas, seconds")
    print(f"{'marker':40} {'wall':>8}  {'JIT':>8}  {'CPU':>8}  {'leader':>8}  {'wait':>8}")
    for previous, mark in zip(marks, marks[1:]):
        label, *values = mark
        dt, jit, _, cpu, _, leader, wait = [
            (value - old)/1e9 for value, old in zip(values, previous[1:])
        ]
        print(f"{label:40} {dt:8.4f}  {jit:8.4f}  {cpu:8.4f}  {leader:8.4f}  {wait:8.4f}")
    print("Largest generated code signatures, inclusive times can overlap")
    for milliseconds, phase, signature in sorted(signatures, reverse=True, key=lambda row: row[0])[:28]:
        print(f"{milliseconds:8.2f} ms after {phase or 'package init'}: {signature}")


if __name__ == "__main__":
    for name in sys.argv[1:]:
        path = Path(name)
        if path.is_dir():
            summarize(path)
        else:
            phases(path)
