from pathlib import Path
import re
import shutil
import sys
import tomllib

app, source, overlay = map(Path, sys.argv[1:])
meta = tomllib.loads((app / "Project.toml").read_text())
assert "PipeWireAORTC" in meta["deps"], "RTC absent from app"
(overlay / "Project.toml").write_text('[deps]\nPipeWireAORTC = "' + meta["deps"]["PipeWireAORTC"] + '"\n')
old = (app / "Manifest.toml").read_text()
pattern = r"(\[\[deps\.PipeWireAORTC\]\]\n)(.*?)(?=\n\[\[deps\.)"
match = re.search(pattern, old, flags=re.S)
body = re.sub(r"^(?:git-tree-sha1|registries|path) = .*\n", "", match[2], flags=re.M)
(overlay / "Manifest.toml").write_text(old[:match.start(2)] + 'path = "' + str(source) + '"\n' + body + old[match.end(2):])
