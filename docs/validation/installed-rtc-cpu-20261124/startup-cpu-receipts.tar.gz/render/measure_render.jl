using PipeWireAORTC
using Sockets: listen

const RTC = PipeWireAORTC
const C = RTC.Common
const D = RTC.DeploymentConfiguration
const S = RTC.SessionCLI

function measure_render(receipt, scratch)
    ledger = C.read_json(joinpath(receipt, "ready-ledger.json"))
    package = ledger["admission"]["package"]
    prefix = ledger["admission"]["prefix"]
    spec = C.read_json(joinpath(package, "systemd", "session-activation.json"))["profile"]
    source = only(owner for owner in spec["owners"] if owner["role"] == spec["source-owner"])
    RTC.SessionLaunch.external_source!(spec, source)
    reference = D.decode(joinpath(receipt, "rtc.conf"), prefix)
    policy = reference["pipewireao.session"]
    session = policy["session"]
    links = D.session_links(session)
    owners = ledger["owners"]
    mktempdir(scratch; prefix = "render-") do runtime
        socket = joinpath(runtime, "private")
        listener = listen(socket)
        try
            bindings = Dict(
                "PACKAGE" => package,
                "RUNTIME" => runtime,
                "REMOTE" => socket,
                "SESSION_UUID" => policy["session.uuid"],
                "SESSION_CONTROL_INSTANCE" => policy["instance"],
                "SESSION_CONTROLLER_INSTANCE" => policy["controller.instance"],
                "ADMISSION_CONTROLLER_INSTANCE" => policy["admission.controller-instance"],
            )
            for (role, owner) in owners
                instance = get(owner, "bootstrap-instance", nothing)
                instance === nothing || (bindings[D.bootstrap_instance_key(role)] = instance)
            end
            expected = deepcopy(reference)
            expected["context.properties"]["remote.name"] = socket
            cpu_before = C.startup_process_cpu_ns()
            render = @timed Base.invokelatest(S.render!, spec, session, bindings, owners, runtime; links)
            decoded = @timed Base.invokelatest(D.decode, render.value, prefix)
            cpu_s = (C.startup_process_cpu_ns() - cpu_before) / 1e9
            isequal(decoded.value, expected) || error("rendered CAL2 configuration differs from retained invocation")
            println("source=", pkgdir(RTC))
            println("render_wall_s=", render.time, " render_compiler_s=", render.compile_time)
            println("decode_wall_s=", decoded.time, " decode_compiler_s=", decoded.compile_time)
            println("combined_process_cpu_s=", cpu_s)
            println("document_bytes=", filesize(render.value), " links=", length(links))
        finally
            close(listener)
        end
    end
end

measure_render(ARGS...)
