#!/usr/bin/env python3
"""Join installed RTC A/B scheduler observations, exact identity and native receipts."""
import json
from pathlib import Path
import re
import sys


def load(path):
    return json.loads(path.read_text())


def summarize(trial):
    receipt = load(trial / "lifecycle.json")
    ready = load(trial / "systemd-ready.json")
    ledger = load(trial / "ready-ledger.json")
    stopped = load(trial / "stopped-ledger.json")
    assert receipt["native_ready"]["ready"]["reply"]["state"] == "Ready"
    assert receipt["native_ready"]["ready"]["reply"]["result"]["running"] is False
    assert receipt["native_ready"]["ready"]["reply"]["result"]["owned_links"] == 10
    assert stopped["phase"] == "stopped" and stopped["cleanup_complete"]
    assert stopped["systemd_quit"] == {"attempted": True, "accepted": True}
    same_roles = {
        role: tuple(record[key] for key in ("pid", "start-ticks", "invocation"))
        for role, record in ledger["owners"].items()
    }
    maps = (trial / "main-code-maps.txt").read_text().splitlines()
    images = sorted({
        tuple(re.split(r"\s+", line, maxsplit=5)[4:])
        for line in maps
        if "/compiled/" in line and "/PipeWireAORTC/" in line and line.endswith(".so")
    })
    lib = sorted({
        tuple(re.split(r"\s+", line, maxsplit=5)[4:])
        for line in maps
        if "libpipewire-ao-0.3.so" in line
    })
    assert len(images) == len(lib) == 1, (images, lib)
    pid = receipt["rtc"]["pid"]
    main_started = int(receipt["unit_properties"]["ExecMainStartTimestampMonotonic"]) * 1000
    active = int(receipt["unit_properties"]["ActiveEnterTimestampMonotonic"]) * 1000
    samples = [
        json.loads(line) for line in (trial / "startup-schedstat.jsonl").read_text().splitlines()
    ]
    last = [row for row in samples if row["pid"] == pid and
            row["role"] == "rtc" and row["monotonic_ns"] <= active][-1]
    return {
        "trial": trial.name,
        "pid": pid,
        "launch": receipt["rtc"],
        "request_to_return_s": ready["request_to_systemd_ready_s"],
        "request_to_active_s": (active - ready["request_ns"]) / 1e9,
        "request_to_main_s": (main_started - ready["request_ns"]) / 1e9,
        "last_sample_before_active_s": (active - last["monotonic_ns"]) / 1e9,
        "main_cpu_s": last["runtime_ns"] / 1e9,
        "main_runnable_wait_s": last["runnable_wait_ns"] / 1e9,
        "other_main_s": (last["monotonic_ns"] - main_started - last["runtime_ns"] - last["runnable_wait_ns"]) / 1e9,
        "retained": same_roles,
        "link_serials": sorted(edge["serial"] for edge in receipt["links"]),
        "image": images[0],
        "lib": lib[0],
    }


root = Path(sys.argv[1])
numbers = [summarize(trial) for trial in sorted(root.glob("[0-9][0-9]-*"))]
assert len(numbers) == 4
old_1, new_1, new_2, old_2 = numbers
assert all(row["retained"] == old_1["retained"] for row in numbers)
assert all(row["lib"] == old_1["lib"] for row in numbers)
assert len(set(serial for row in numbers for serial in row["link_serials"])) == 40
baseline, candidate = old_1["image"], new_1["image"]
assert baseline != candidate and old_2["image"] == baseline and new_2["image"] == candidate
print(json.dumps(numbers, indent=2))
