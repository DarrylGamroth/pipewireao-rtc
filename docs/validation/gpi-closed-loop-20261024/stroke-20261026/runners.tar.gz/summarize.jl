using PipeWireAORTC,Statistics,SHA
const C=PipeWireAORTC.Common
const OUT=@__DIR__
function main()
 report=C.read_json(joinpath(OUT,"replay-result.json"))
 summary=Dict{String,Any}("completed"=>report["completed"],"scope"=>report["scope"],"no_hardware_qualification"=>true,"cases"=>Dict{String,Any}(),"source_preflight"=>report["preflight"],"runtime_actuator_models"=>get(report,"runtime_actuator_models",nothing),"historical_baseline_match"=>get(report,"historical_baseline_match",nothing),"short_pair_match"=>get(report,"short_pair_match",nothing),"long_pair_match"=>get(report,"long_pair_match",nothing),"short_late_mean_WFE_ratio"=>get(report,"short_late_mean_WFE_ratio",nothing),"long_late_mean_WFE_ratio"=>get(report,"long_late_mean_WFE_ratio",nothing),"extension_decision"=>get(report,"extension_decision",nothing),"frozen_graph_receipt_manifest_unchanged"=>get(report,"frozen_graph_receipt_manifest_unchanged",false),"artifacts"=>Dict{String,Any}(),"external_inputs"=>Dict{String,Any}())
 for (label,entry) in report["cases"]
  label=="warmup" && continue
  case=C.read_json(entry["path"])
  result=Dict{String,Any}("completed"=>case["completed"],"frames_completed"=>case["frames_completed"],"woofer_limit_mOPD"=>case["woofer_limit_mOPD"],"actual_float32_limits_mOPD"=>case["actual_float32_limits_mOPD"],"elapsed_s"=>get(case,"elapsed_s",nothing),"reset_detector_rng"=>case["reset_detector_rng"],"all_controller_and_optical_outputs_finite"=>case["completed"] && case["all_controller_and_optical_outputs_finite"],"windows"=>Dict{String,Any}(),"structural_errors_nm"=>Dict(k=>v for (k,v) in case if startswith(k,"maximum_") && endswith(k,"_error_nm")))
  for (window,values) in get(case,"windows",Dict())
   a,b=parse.(Int,split(window,'-'));b>case["frames_completed"] && continue
   metrics=Dict{String,Any}("sampled_optical_statistics"=>values,"full_frame_command_statistics"=>Dict{String,Any}())
   for name in ("woofer","tweeter","stage")
    clipped=Float64.(case["per_frame"][name*"_clipped_count"][a:b])
    requested=Float64.(case["per_frame"][name*"_requested_peak_nm"][a:b])
    demanded=Float64.(case["per_frame"][name*"_demanded_peak_nm"][a:b])
    metrics["full_frame_command_statistics"][name]=Dict("mean_clipped_coordinates"=>mean(clipped),"max_clipped_coordinates"=>maximum(clipped),"percentage_frames_with_clipping"=>100count(>(0),clipped)/length(clipped),"mean_requested_peak_nm"=>mean(requested),"maximum_requested_peak_nm"=>maximum(requested),"maximum_demanded_peak_nm"=>maximum(demanded),"frames_with_demanded_peak_above_original_1um"=>count(>(1000.0),demanded))
   end
   result["windows"][window]=metrics
  end
  summary["cases"][label]=result
 end
 summary["long_short_restart_prefix_equal"]=Dict{String,Bool}()
 for name in ("baseline","candidate")
  longlabel=name*"-16384";shortlabel=name*"-4096"
  haskey(report["cases"],longlabel) || continue
  longcase=C.read_json(report["cases"][longlabel]["path"])
  longcase["completed"] || continue
  shortcase=C.read_json(report["cases"][shortlabel]["path"])
  n=length(shortcase["sampled_frames"])
  equal=all(k->isequal(longcase["per_frame"][k][1:4096],shortcase["per_frame"][k]),keys(shortcase["per_frame"])) &&
   all(k->isequal(longcase["series"][k][1:n],shortcase["series"][k]),keys(shortcase["series"])) &&
   isequal(longcase["raw_camera_sha256_at_observations"][1:n],shortcase["raw_camera_sha256_at_observations"])
  @assert equal "Long/short restart prefix differs for $name"
  summary["long_short_restart_prefix_equal"][name]=equal
 end
 for path in (
  "/home/dgamroth/.cache/pipewireao/gpi2-tiptilt-20261025/gpi2_closed_loop_helpers.jl",
  "/home/dgamroth/.cache/pipewireao/gpi2-registered-20261025/with-env.sh",
  "/home/dgamroth/.cache/pipewireao/gpi2-registered-20261025/environment/Project.toml",
  "/home/dgamroth/.cache/pipewireao/gpi2-registered-20261025/environment/Manifest.toml",
  "/home/dgamroth/.local/state/pipewireao/gpi2-registered-live-20261025/application/rtc/graph.conf",
  "/home/dgamroth/.local/state/pipewireao/gpi2-registered-live-20261025/application/calibration/result.yaml",
  "/home/dgamroth/.cache/pipewireao/gpi2-validation-20261025/instrument-source-v8/gpi2/simulation/definition.yaml",
  "/home/dgamroth/.cache/pipewireao/gpi2-validation-20261025/instrument-source-v8/gpi2/simulation/production.yaml",
  "/home/dgamroth/.cache/pipewireao/gpi2-registered-20261025/cache-depot-1/packages/AdaptiveOpticsSim/Pp8Re/src/algorithm_graphs/native_nodes.jl",
  "/home/dgamroth/.cache/pipewireao/gpi2-registered-20261025/cache-depot-1/packages/AdaptiveOpticsSim/Pp8Re/src/optics/deformable_mirror.jl",
  "/home/dgamroth/.cache/pipewireao/gpi2-registered-20261025/cache-depot-1/packages/AdaptiveOpticsSim/Pp8Re/src/backends/random.jl",
  "/home/dgamroth/.cache/pipewireao/gpi2-registered-20261025/depot/packages/FilterGraphAlgorithms/QSqQa/src/algorithms/vector/vector_conditioning.jl")
  summary["external_inputs"][path]=Dict("bytes"=>filesize(path),"sha256"=>C.sha256_file(path))
 end
 for path in sort(readdir(OUT;join=true))
  isfile(path) || continue
  basename(path) in ("summary.json","summary.txt","summarize.log") && continue
  summary["artifacts"][basename(path)]=Dict("bytes"=>filesize(path),"sha256"=>C.sha256_file(path))
 end
 ratio=get(report,"long_late_mean_WFE_ratio",get(report,"short_late_mean_WFE_ratio",nothing))
 summary["adjudication"]=ratio===nothing ? "Incomplete scientific evidence" : ratio<1 ? "Observed improved finite matched-window WFE with wider provisional woofer bound; retain as sensitivity evidence only, no hardware qualification or deployment authorization" : "Wider provisional woofer bound does not improve the matched-window WFE; reject this sensitivity candidate as a remedy"
 C.write_json(joinpath(OUT,"summary.json"),summary)
 open(joinpath(OUT,"summary.txt"),"w") do io
  println(io,"Completed: ",summary["completed"])
  println(io,"Adjudication: ",summary["adjudication"])
  for (label,result) in sort(collect(summary["cases"]);by=first)
   println(io,"\n",label," frames=",result["frames_completed"]," limit_mOPD=",result["woofer_limit_mOPD"])
   for (window,metrics) in sort(collect(result["windows"]);by=first)
    println(io," window ",window," residual WFE nm ",metrics["sampled_optical_statistics"]["residual_rms_nm"])
    for name in ("woofer","tweeter","stage")
     println(io," ",name," ",metrics["full_frame_command_statistics"][name])
    end
   end
   println(io," structural_errors_nm=",result["structural_errors_nm"])
  end
 end
 println(read(joinpath(OUT,"summary.txt"),String))
end
main()
