include("/home/dgamroth/.cache/pipewireao/gpi2-tiptilt-20261025/gpi2_closed_loop_helpers.jl")
using LinearAlgebra, Statistics, SHA
const V=GPIClosedLoopValidation
const C=V.C
const O=V.AdaptiveOpticsSim.Optics
const OUT=@__DIR__
const APP="/home/dgamroth/.local/state/pipewireao/gpi2-registered-live-20261025/application"
const SOURCE="/home/dgamroth/.cache/pipewireao/gpi2-validation-20261025/instrument-source-v8/gpi2"
const PRIOR="/home/dgamroth/.cache/pipewireao/gpi2-hidden-20261025/replay-hidden-result.json"
include("resource-path-resolver.jl")
function graph_document(limit)
 original=V.PipeWireAORTC.DeploymentConfiguration.decode(joinpath(APP,"rtc/graph.conf"),"/opt/pipewireao")
 concrete=deepcopy(original);g=concrete["filter.graph"]
 node=only(n for n in g["nodes"] if n["name"]=="closed-loop-correction")
 @assert node["label"]=="closed-loop-integrator-f32"
 @assert node["props"]==Dict("gain"=>-0.3,"hidden-mode-gain"=>0,"pole"=>1,"anti-windup-gain"=>1)
 for name in ("woofer","tweeter","tiptilt")
  command=only(n for n in g["nodes"] if n["name"]==name*"-command")
  @assert command["config"]["command_limits"]==[-1e-6,1e-6]
 end
 only(n for n in g["nodes"] if n["name"]=="woofer-command")["config"]["command_limits"]=[-limit,limit]
 restored=deepcopy(concrete)
 only(n for n in restored["filter.graph"]["nodes"] if n["name"]=="woofer-command")["config"]["command_limits"]=[-1e-6,1e-6]
 @assert restored==original "Unexpected science configuration change"
 # Shared direct observations; they do not change numerical connections.
 for (name,endpoint) in (("woofer-preclip","woofer-offset:output"),("tweeter-preclip","tweeter-offset:output"),("stage-preclip","tiptilt-offset:output"),("stage-constraint-feedback","tiptilt-command:constraint-feedback"))
  push!(g["outputs"],Dict("name"=>name,"endpoint"=>endpoint))
 end
 return concrete
end
function prepare_control(cal,receipt,limit)
 concrete=graph_document(limit)
 path=joinpath(OUT,limit==1e-6 ? "baseline-observed.conf" : "candidate-observed.conf")
 V.PipeWireAORTC.ScienceExport.write_spa_config(path,concrete;header="Private woofer-amplitude sensitivity graph; original integrator, hidden removal disabled")
 V.progress("prepare controller woofer_limit=$limit")
 graph=V.JuliaFilterGraph.prepare_graph(path;algorithms=V.FilterGraphAlgorithms.algorithms())
 parameters=Dict(name=>begin
  text=String(name)
  if endswith(text,"-shape-offset")
   zeros(format.element_type,format.shape)
  else
   asset=replace(text,"-shape-active-to-full"=>"-active-to-full","-shape-pdm-to-vdm"=>"-pdm-to-vdm")
   V.artifact(cal,receipt,asset,format.element_type,format.shape)
  end
 end for(name,format) in pairs(V.JuliaFilterGraph.parameter_formats(graph)))
 V.JuliaFilterGraph.replace_parameters!(graph,pairs(parameters)...)
 inputs=map(f->zeros(f.element_type,f.shape),V.JuliaFilterGraph.input_formats(graph))
 outputs=map(f->zeros(f.element_type,f.shape),V.JuliaFilterGraph.output_formats(graph))
 hashes=Dict(string(name)=>bytes2hex(sha256(reinterpret(UInt8,vec(a)))) for (name,a) in parameters)
 return (;graph,parameters,inputs,outputs,limit,parameter_hashes=hashes,graph_path=path)
end
function source_preflight(receipt)
 declaration=V.IC.load_simulation(joinpath(SOURCE,receipt["recipe"]["simulation"]))
 settings=V.IC.settings(declaration,get(receipt["recipe"],"settings",Dict()))
 identity=V.IC.prescription_identity(declaration,settings)
 @assert identity==receipt["source_prescription_identity"]
 staged=V.IC.load_simulation(joinpath(APP,"simulation/definition.yaml"))
 stagedsettings=V.IC.settings(staged,Dict())
 @assert V.IC.prescription_identity(staged,stagedsettings)==receipt["staged_prescription_identity"]
 resolved=V.IC.graph_document(declaration,settings)
 @assert resolved==V.IC.graph_document(staged,stagedsettings)
 detector=only(n for n in resolved["nodes"] if n["name"]=="detector")
 atmo=only(n for n in resolved["nodes"] if n["name"]=="atmosphere")
 return Dict("passed"=>true,"source_prescription_identity"=>identity,"staged_prescription_identity"=>receipt["staged_prescription_identity"],"resolved_source_and_staged_graph_equal"=>true,"detector"=>detector,"atmosphere"=>atmo,"settings"=>settings,"candidate_sole_science_change"=>"woofer-command.config.command_limits: [-1e-6,1e-6] -> [-3.4e-6,3.4e-6] mOPD; restoring two numbers yields original graph exactly","plant_limit_policy"=>"Grid Gaussian DM exposes no clip/stroke field, constructs DM with no actuator_model, default LinearStaticActuators. Runtime assertions and adopted/grid/applied command equality verify no additional device clipping. Optical graph/prescription/calibration unchanged.")
end
function rng_observation(owner)
 rng=owner.rng
 sequence=hasproperty(rng,:state) && hasproperty(rng.state,:draw_sequence) ? only(Array(rng.state.draw_sequence)) : nothing
 return Dict("type"=>string(typeof(rng)),"seed"=>owner.rng_seed,"draw_sequence"=>sequence)
end
function plant_owners(p)
 w=V.AG.prepared_graph_node(p.system.graph,:woofer)
 t=V.AG.prepared_graph_node(p.system.graph,:tweeter)
 s=V.AG.prepared_graph_node(p.system.graph,:tiptilt)
 detector=V.AG.prepared_graph_node(p.system.graph,:detector)
 for owner in (w,t)
  @assert O.actuator_model(owner.deformable_mirror) isa O.LinearStaticActuators
 end
 return (;woofer=w,tweeter=t,stage=s,detector)
end
function windows!(data)
 frames=data["sampled_frames"];series=data["series"]
 for (a,b) in ((513,2048),(2049,4096),(2049,16384),(4097,8192),(8193,16384))
  b>data["frames_requested"] && continue
  selected=findall(f->a<=f<=b,frames)
  isempty(selected) && continue
  get!(data,"windows",Dict())["$a-$b"]=Dict(k=>Dict("mean"=>mean(v[selected]),"max"=>maximum(v[selected]),"min"=>minimum(v[selected])) for (k,v) in series)
 end
end
Base.@constprop :none function run_case!(p,control,owners,frames,label,report,checkpoint,runtime_bound)
 command=V.commands(p.system);V.reset!(p,control,command)
 reset_rng=rng_observation(owners.detector)
 @assert reset_rng["seed"]==2
 reset_rng["draw_sequence"]===nothing || @assert reset_rng["draw_sequence"]==0
 limits=Dict("woofer"=>Float64(Float32(control.limit)),"tweeter"=>Float64(1f-6),"stage"=>Float64(1f-6))
 data=Dict{String,Any}("completed"=>false,"frames_requested"=>frames,"frames_completed"=>0,"woofer_limit_mOPD"=>control.limit,"actual_float32_limits_mOPD"=>limits,"reset_detector_rng"=>reset_rng,"sampled_frames"=>Int[],"atmosphere_field_sha256_every_frame"=>String[],"raw_camera_sha256_at_observations"=>String[],"detector_rng_at_observations"=>Any[],"series"=>Dict{String,Any}(),"per_frame"=>Dict{String,Any}(),"maximum_feedback_identity_error_nm"=>0.0,"maximum_adopted_command_error_nm"=>0.0,"maximum_grid_command_error_nm"=>0.0,"maximum_applied_command_error_nm"=>0.0,"maximum_conditioner_clamp_error_nm"=>0.0,"all_controller_and_optical_outputs_finite"=>true)
 casepath=joinpath(OUT,"case-"*label*".json")
 report["cases"][label]=Dict("path"=>casepath,"completed"=>false,"frames_requested"=>frames)
 series=data["series"];perframe=data["per_frame"]
 for name in ("atmosphere_rms_nm","residual_rms_nm","woofer_requested_peak_nm","tweeter_requested_peak_nm","stage_requested_peak_nm","woofer_clipped_count","tweeter_clipped_count","stage_clipped_count")
  series[name]=Float64[]
 end
 for name in ("woofer","tweeter","stage")
  perframe[name*"_clipped_count"]=Int[]
  perframe[name*"_requested_peak_nm"]=Float64[]
  perframe[name*"_demanded_peak_nm"]=Float64[]
 end
 checkpoint_case()=begin
  C.write_json(casepath,data)
  report["cases"][label]["frames_completed"]=data["frames_completed"]
  report["cases"][label]["completed"]=data["completed"]
  checkpoint()
 end
 checkpoint_case();started=time_ns();V.progress("begin $label frames=$frames woofer_limit=$(control.limit)")
 try
  for frame in 1:frames
   # frame n adopts command n-1. Inspect the plant's actual inputs and applied
   # actuator commands before the controller creates command n.
   raw=V.frame!(p.system,command)
   for (name,key) in (("woofer",:woofer),("tweeter",:tweeter),("stage",:tiptilt))
    expected=Array(getproperty(command,key))
    input=Array(V.AG.graph_input(p.system.graph,key))
    error=maximum(abs,Float64.(input)-Float64.(expected))*1e9
    data["maximum_adopted_command_error_nm"]=max(data["maximum_adopted_command_error_nm"],error)
    @assert isequal(input,expected) "Plant adopted command differs at frame$frame: $name"
    @assert all(isfinite,input) && maximum(abs,input)<=limits[name]
    if name!="stage"
     owner=getproperty(owners,Symbol(name));dm=owner.deformable_mirror
     grid=Array(O.command_storage(dm));indices=Int.(Array(owner.actuator_grid_indices))
     applied=Array(dm.state.actuator_coefs)
     griderror=maximum(abs,Float64.(grid[indices])-Float64.(input))*1e9
     applyerror=maximum(abs,Float64.(applied)-Float64.(grid))*1e9
     data["maximum_grid_command_error_nm"]=max(data["maximum_grid_command_error_nm"],griderror)
     data["maximum_applied_command_error_nm"]=max(data["maximum_applied_command_error_nm"],applyerror)
     @assert isequal(grid[indices],input) && isequal(applied,grid)
     @assert all(isfinite,applied) && maximum(abs,applied)<=limits[name]
    else
     @assert isequal(Array(owners.stage.coefficients),input)
    end
   end
   atmosphere=Array(V.AG.graph_output(p.system.graph,:atmosphere_opd))
   @assert all(isfinite,atmosphere)
   push!(data["atmosphere_field_sha256_every_frame"],bytes2hex(sha256(reinterpret(UInt8,vec(atmosphere)))))
   pupil=V.AG.graph_output(p.system.graph,:pupil_opd)
   @assert all(isfinite,pupil)
   V.process!(control,raw)
   @assert all(a->all(isfinite,a),values(control.outputs))
   for (name,key,fbkey) in (("woofer",:woofer,Symbol("woofer-constraint-feedback")),("tweeter",:tweeter,Symbol("tweeter-constraint-feedback")),("stage",:tiptilt,Symbol("stage-constraint-feedback")))
    requested=getproperty(control.outputs,Symbol(name*"-preclip"));demanded=getproperty(control.outputs,key);feedback=getproperty(control.outputs,fbkey)
    expected=clamp.(requested,-Float32(limits[name]),Float32(limits[name]))
    clamp_error=maximum(abs,Float64.(expected)-Float64.(demanded))*1e9
    feedback_error=maximum(abs,Float64.(requested.-demanded)-Float64.(feedback))*1e9
    data["maximum_conditioner_clamp_error_nm"]=max(data["maximum_conditioner_clamp_error_nm"],clamp_error)
    data["maximum_feedback_identity_error_nm"]=max(data["maximum_feedback_identity_error_nm"],feedback_error)
    @assert isequal(demanded,expected) && isequal(feedback,requested.-demanded)
    @assert maximum(abs,demanded)<=limits[name]
    push!(perframe[name*"_clipped_count"],count(!iszero,feedback))
    push!(perframe[name*"_requested_peak_nm"],maximum(abs,requested)*1e9)
    push!(perframe[name*"_demanded_peak_nm"],maximum(abs,demanded)*1e9)
   end
   for key in keys(command);copyto!(getproperty(command,key),getproperty(control.outputs,key));end
   copyto!(control.inputs.var"constraint-feedback",control.outputs.var"controller-constraint-feedback")
   if frame<=32 || frame%64==0
    push!(data["sampled_frames"],frame)
    push!(data["raw_camera_sha256_at_observations"],bytes2hex(sha256(reinterpret(UInt8,vec(Array(raw))))))
    push!(data["detector_rng_at_observations"],rng_observation(owners.detector))
    push!(series["atmosphere_rms_nm"],V.pupil_rms(atmosphere,p.valid)*1e9)
    push!(series["residual_rms_nm"],V.pupil_rms(pupil,p.valid)*1e9)
    for name in ("woofer","tweeter","stage"),quantity in ("requested_peak_nm","clipped_count")
     push!(series[name*"_"*quantity],last(perframe[name*"_"*quantity]))
    end
   end
   data["frames_completed"]=frame
   if frame%512==0 || frame==frames
    data["elapsed_s"]=(time_ns()-started)/1e9
    checkpoint_case();V.progress("$label frame=$frame residual_nm=$(last(series["residual_rms_nm"])) elapsed_s=$(data["elapsed_s"])")
    data["elapsed_s"]>runtime_bound && frame<frames && error("Per-case warm execution bound reached: $runtime_bound seconds")
   end
  end
  # The last controller output has not yet been consumed by a new optical
  # frame; verify its demanded bound here. Every earlier output was adopted.
  data["adoption_boundary"]="Frame n checks command n-1 in graph inputs and applied actuator storage; final command n is bounded/finite but awaits the next frame. No extra scientific frame is advanced."
  windows!(data);data["completed"]=true
  return data
 catch error
  data["error"]=sprint(showerror,error,catch_backtrace());rethrow()
 finally
  checkpoint_case()
 end
end
function verify_pair!(baseline,candidate)
 @assert candidate["atmosphere_field_sha256_every_frame"]==baseline["atmosphere_field_sha256_every_frame"]
 @assert candidate["reset_detector_rng"]==baseline["reset_detector_rng"]
 @assert candidate["detector_rng_at_observations"]==baseline["detector_rng_at_observations"]
 return Dict("all_frame_full_atmosphere_hashes_equal"=>true,"number_of_frames"=>baseline["frames_completed"],"detector_reset_seed_and_sampled_draw_sequence_equal"=>true,"raw_camera_boundary"=>"Settings/reset seed/draw policy match; detector photon inputs and realized stochastic outputs depend on differing optical trajectories, so camera bit equality is not required")
end
function verify_history!(baseline)
 prior=C.read_json(PRIOR);reference=prior["cases"]["0.0"]
 @assert prior["original_graph_sha256"]==C.sha256_file(joinpath(APP,"rtc/graph.conf"))
 index=Dict(f=>i for (i,f) in enumerate(baseline["sampled_frames"]))
 checks=Dict{String,Any}()
 for key in ("atmosphere_rms_nm","residual_rms_nm","woofer_clipped_count","tweeter_clipped_count")
  observed=[baseline["series"][key][index[f]] for f in reference["sampled_frames"]]
  expected=reference["series"][key]
  @assert isequal(observed,expected) "Historical baseline observation mismatch: $key"
  checks[key]=Dict("exact_values_equal"=>true,"observations"=>length(observed))
 end
 # Historical requested peaks were reconstructed as demanded+feedback; direct
 # input observations can differ by one Float32 rounding operation.
 for key in ("woofer_requested_peak_nm","tweeter_requested_peak_nm")
  observed=[baseline["series"][key][index[f]] for f in reference["sampled_frames"]]
  expected=reference["series"][key]
  difference=maximum(abs,observed-expected)
  @assert difference<0.002 "Historical direct/reconstructed requested peak mismatch"
  checks[key]=Dict("maximum_direct_vs_reconstructed_difference_nm"=>difference,"observations"=>length(observed))
 end
 hashes=baseline["atmosphere_field_sha256_every_frame"]
 @assert [hashes[f] for f in reference["sampled_frames"]]==reference["atmosphere_field_sha256"]
 return Dict("passed"=>true,"reference_path"=>PRIOR,"reference_sha256"=>C.sha256_file(PRIOR),"original_graph_identity_equal"=>true,"all96_full_atmosphere_hashes_equal"=>true,"checks"=>checks)
end
function main()
 BLAS.set_num_threads(1);V.B.set_fft_provider_threads!(1)
 cal=joinpath(APP,"calibration");receipt=C.read_yaml(joinpath(cal,"result.yaml"))
 path=joinpath(OUT,"replay-result.json")
 report=Dict{String,Any}("completed"=>false,"cases"=>Dict{String,Any}(),"scope"=>"Private matched provisional-versus-HEART-reference woofer amplitude sensitivity; original integrator/hidden disabled; no native core/session/GUI or live/package/repository mutations","driver_sha256"=>C.sha256_file(@__FILE__),"resource_path_workaround"=>RESOURCE_PATCH,"original_graph_sha256"=>C.sha256_file(joinpath(APP,"rtc/graph.conf")),"receipt_sha256"=>C.sha256_file(joinpath(cal,"result.yaml")),"manifest_sha256"=>C.sha256_file(joinpath(dirname(Base.active_project()),"Manifest.toml")),"julia_version"=>string(VERSION),"science_sampling"=>"Full atmosphere spatial SHA256 every frame; WFE and camera/RNG observations first32 then every64; clipping/preclip/demanded peaks and finite/adopted/applied/bound checks every frame","runtime_bounds_s"=>Dict("controller_preparation"=>600,"optical_preparation"=>600,"cold_runner_specialization"=>600,"warm_case"=>300),"no_hardware_qualification"=>true)
 checkpoint()=C.write_json(path,report);checkpoint()
 try
  report["preflight"]=source_preflight(receipt)
  base_document=graph_document(1e-6);candidate_document=graph_document(3.4e-6)
  reduced=deepcopy(candidate_document)
  only(n for n in reduced["filter.graph"]["nodes"] if n["name"]=="woofer-command")["config"]["command_limits"]=[-1e-6,1e-6]
  @assert reduced==base_document
  report["candidate_configuration_difference_verified_only_two_limit_values"]=true;checkpoint()
  V.progress("source/graph preflight passed; only woofer lower/upper differ")
  if "preflight-only" in ARGS;report["completed"]=true;return;end
  @assert V.CUDA_MODULE!==nothing;V.CUDA_MODULE.allowscalar(false)
  started=time_ns()
  baseline=prepare_control(cal,receipt,1e-6)
  candidate=prepare_control(cal,receipt,3.4e-6)
  @assert baseline.parameter_hashes==candidate.parameter_hashes
  @assert typeof(baseline)==typeof(candidate)
  report["parameter_hashes_identical_both_cases"]=baseline.parameter_hashes
  report["controller_preparation_s"]=(time_ns()-started)/1e9
  @assert report["controller_preparation_s"]<=600
  checkpoint();V.progress("controllers ready; prepare unchanged CUDA optics")
  started=time_ns()
  p=V.plant(SOURCE,receipt,V.B.AcceleratorComputeDevice(V.B.CUDABackend(),0);calibration=false)
  owners=plant_owners(p)
  report["optical_preparation_s"]=(time_ns()-started)/1e9
  @assert report["optical_preparation_s"]<=600
  report["runtime_actuator_models"]=Dict(name=>string(typeof(O.actuator_model(getproperty(owners,Symbol(name)).deformable_mirror))) for name in ("woofer","tweeter"))
  report["cuda_version"]=string(Base.pkgversion(V.CUDA_MODULE));checkpoint()
  started=time_ns()
  Base.invokelatest(run_case!,p,baseline,owners,2,"warmup",report,checkpoint,600.0)
  report["cold_instrumentation_preparation_s"]=(time_ns()-started)/1e9
  @assert report["cold_instrumentation_preparation_s"]<=600
  report["warmup_policy"]="Two instrumentation frames before timing; full graph/controller/command/model-time/detector RNG reset occurs at every scientific case start"
  ref=Base.invokelatest(run_case!,p,baseline,owners,4096,"baseline-4096",report,checkpoint,300.0)
  report["historical_baseline_match"]=verify_history!(ref);checkpoint()
  changed=Base.invokelatest(run_case!,p,candidate,owners,4096,"candidate-4096",report,checkpoint,300.0)
  report["short_pair_match"]=verify_pair!(ref,changed)
  ratio=changed["windows"]["2049-4096"]["residual_rms_nm"]["mean"]/ref["windows"]["2049-4096"]["residual_rms_nm"]["mean"]
  report["short_late_mean_WFE_ratio"]=ratio;checkpoint()
  if ratio<=0.98
   report["extension_decision"]="At least2% lower matched late-window mean WFE and no structural/finite/adoption/bound gate failed; extend BOTH cases from reset, record flares without claiming stability"
   longref=Base.invokelatest(run_case!,p,baseline,owners,16384,"baseline-16384",report,checkpoint,300.0)
   longchanged=Base.invokelatest(run_case!,p,candidate,owners,16384,"candidate-16384",report,checkpoint,300.0)
   report["long_pair_match"]=verify_pair!(longref,longchanged)
   @assert longref["atmosphere_field_sha256_every_frame"][1:4096]==ref["atmosphere_field_sha256_every_frame"]
   @assert longchanged["atmosphere_field_sha256_every_frame"][1:4096]==changed["atmosphere_field_sha256_every_frame"]
   report["long_late_mean_WFE_ratio"]=longchanged["windows"]["2049-16384"]["residual_rms_nm"]["mean"]/longref["windows"]["2049-16384"]["residual_rms_nm"]["mean"]
  else
   report["extension_decision"]="Less than2% improvement or worse late-window mean WFE; no long extension"
  end
  @assert C.sha256_file(joinpath(APP,"rtc/graph.conf"))==report["original_graph_sha256"]
  @assert C.sha256_file(joinpath(cal,"result.yaml"))==report["receipt_sha256"]
  @assert C.sha256_file(joinpath(dirname(Base.active_project()),"Manifest.toml"))==report["manifest_sha256"]
  report["frozen_graph_receipt_manifest_unchanged"]=true;report["completed"]=true
 catch error
  report["error"]=sprint(showerror,error,catch_backtrace());rethrow()
 finally
  checkpoint()
 end
end
const RESOURCE_PATCH=install_resource_paths!()
main()
