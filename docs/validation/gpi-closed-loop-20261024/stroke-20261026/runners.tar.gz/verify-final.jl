using PipeWireAORTC,SHA
const C=PipeWireAORTC.Common
const OUT=@__DIR__
r=C.read_json(joinpath(OUT,"replay-result.json"));s=C.read_json(joinpath(OUT,"summary.json"))
@assert r["completed"] && s["completed"] && !haskey(r,"error")
@assert r["frozen_graph_receipt_manifest_unchanged"]
@assert r["historical_baseline_match"]["passed"]
@assert r["short_pair_match"]["all_frame_full_atmosphere_hashes_equal"] && r["long_pair_match"]["all_frame_full_atmosphere_hashes_equal"]
@assert r["short_pair_match"]["detector_reset_seed_and_sampled_draw_sequence_equal"] && r["long_pair_match"]["detector_reset_seed_and_sampled_draw_sequence_equal"]
@assert all(values(s["long_short_restart_prefix_equal"]))
@assert r["driver_sha256"]==C.sha256_file(joinpath(OUT,"replay-woofer-stroke.jl"))
for (label,case) in s["cases"]
 @assert case["completed"] && case["all_controller_and_optical_outputs_finite"]
 @assert all(iszero,values(case["structural_errors_nm"]))
 @assert case["elapsed_s"]<300
end
checks=Dict("passed"=>true,"scientific_cases"=>length(s["cases"]),"full_atmosphere_fields_matched_short"=>4096,"full_atmosphere_fields_matched_long"=>16384,"historical_baseline_observations"=>96,"all_structural_errors_nm"=>0.0,"short_mean_WFE_improvement_percent"=>100*(1-r["short_late_mean_WFE_ratio"]),"long_mean_WFE_improvement_percent"=>100*(1-r["long_late_mean_WFE_ratio"]),"driver_sha256"=>r["driver_sha256"],"result_sha256"=>C.sha256_file(joinpath(OUT,"replay-result.json")),"runtime_actuator_models"=>r["runtime_actuator_models"],"source_prescription_identity"=>r["preflight"]["source_prescription_identity"],"source_staged_optics_equal"=>true)
C.write_json(joinpath(OUT,"final-verification.json"),checks)
println(checks)
