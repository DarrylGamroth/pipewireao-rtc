include("/home/dgamroth/.cache/pipewireao/gpi2-tiptilt-20261025/gpi2_closed_loop_helpers.jl")
using LinearAlgebra, Statistics, SHA, TOML
const V=GPIClosedLoopValidation
const C=V.C
const O=V.AdaptiveOpticsSim.Optics
const OUT=@__DIR__
const APP="/home/dgamroth/.local/state/pipewireao/gpi2-registered-live-20261025/application"
const SOURCE=joinpath(OUT,"source/gpi2")
const FROZEN_SOURCE="/home/dgamroth/.cache/pipewireao/gpi2-validation-20261025/instrument-source-v8/gpi2"
const PRIOR="/home/dgamroth/.cache/pipewireao/gpi2-woofer-stroke-20261026/case-candidate-4096.json"
include("resource-path-resolver.jl")
function graph_document(limit)
 original=V.PipeWireAORTC.DeploymentConfiguration.decode(joinpath(APP,"rtc/graph.conf"),"/opt/pipewireao")
 concrete=deepcopy(original);g=concrete["filter.graph"]
 node=only(n for n in g["nodes"] if n["name"]=="closed-loop-correction")
 @assert node["label"]=="closed-loop-integrator-f32"
 @assert node["props"]==Dict("gain"=>-0.3,"hidden-mode-gain"=>0,"pole"=>1,"anti-windup-gain"=>1)
 for name in ("woofer","tweeter","tiptilt")
  command=only(n for n in g["nodes"] if n["name"]==name*"-command")
  @assert command["config"]["command_limits"]==[-1e-6,1e-6]
 end
 only(n for n in g["nodes"] if n["name"]=="woofer-command")["config"]["command_limits"]=[-limit,limit]
 restored=deepcopy(concrete)
 only(n for n in restored["filter.graph"]["nodes"] if n["name"]=="woofer-command")["config"]["command_limits"]=[-1e-6,1e-6]
 @assert restored==original "Unexpected science configuration change"
 # Shared direct observations; they do not change numerical connections.
 for (name,endpoint) in (("woofer-preclip","woofer-offset:output"),("tweeter-preclip","tweeter-offset:output"),("stage-preclip","tiptilt-offset:output"),("stage-constraint-feedback","tiptilt-command:constraint-feedback"))
  push!(g["outputs"],Dict("name"=>name,"endpoint"=>endpoint))
 end
 return concrete
end
function prepare_control(cal,receipt,lowpass)
 limit=3.4e-6
 concrete=graph_document(limit)
 path=joinpath(OUT,lowpass ? "controller-25hz.conf" : "controller-identity.conf")
 V.PipeWireAORTC.ScienceExport.write_spa_config(path,concrete;header="Private woofer-amplitude sensitivity graph; original integrator, hidden removal disabled")
 V.progress("prepare controller woofer_limit=$limit lowpass25=$lowpass")
 graph=V.JuliaFilterGraph.prepare_graph(path;algorithms=V.FilterGraphAlgorithms.algorithms())
 parameters=Dict(name=>begin
  text=String(name)
  if endswith(text,"-shape-offset")
   zeros(format.element_type,format.shape)
  else
   asset=replace(text,"-shape-active-to-full"=>"-active-to-full","-shape-pdm-to-vdm"=>"-pdm-to-vdm")
   V.artifact(cal,receipt,asset,format.element_type,format.shape)
  end
 end for(name,format) in pairs(V.JuliaFilterGraph.parameter_formats(graph)))
 original_filter_hash=bytes2hex(sha256(reinterpret(UInt8,vec(parameters[Symbol("tiptilt-filter-coefficients")]))))
 if lowpass
  coefficients=V.PipeWireAORTC.InstrumentCalibration.lowpass_coefficients(Float32;cutoff_frequency_hz=25,sample_rate_hz=2000)
  bank=copy(parameters[Symbol("tiptilt-filter-coefficients")])
  @assert size(bank)==(5,1,2)
  for axis in 1:2;bank[:,1,axis].=coefficients;end
  parameters[Symbol("tiptilt-filter-coefficients")]=bank
 end
 V.JuliaFilterGraph.replace_parameters!(graph,pairs(parameters)...)
 inputs=map(f->zeros(f.element_type,f.shape),V.JuliaFilterGraph.input_formats(graph))
 outputs=map(f->zeros(f.element_type,f.shape),V.JuliaFilterGraph.output_formats(graph))
 hashes=Dict(string(name)=>bytes2hex(sha256(reinterpret(UInt8,vec(a)))) for (name,a) in parameters)
 return (;graph,parameters,inputs,outputs,limit,lowpass,original_filter_hash,parameter_hashes=hashes,graph_path=path)
end
function adopt_control!(control,bank,lowpass)
 key=Symbol("tiptilt-filter-coefficients")
 @assert size(bank)==(5,1,2)
 V.JuliaFilterGraph.replace_parameters!(control.graph,key=>bank)
 control.parameters[key]=bank
 hashes=Dict(string(name)=>bytes2hex(sha256(reinterpret(UInt8,vec(a)))) for (name,a) in control.parameters)
 @assert all(name->name==string(key) || hashes[name]==control.parameter_hashes[name],keys(hashes))
 if !lowpass
  @assert hashes==control.parameter_hashes
 else
  @assert hashes[string(key)]!=control.parameter_hashes[string(key)]
 end
 return merge(control,(;lowpass,parameter_hashes=hashes))
end
function source_preflight(receipt)
 idealpath=joinpath(SOURCE,receipt["recipe"]["simulation"])
 original=C.read_yaml(idealpath)
 @assert !haskey(original,"responses")
 dynamic=deepcopy(original)
 dynamic["responses"]=Dict("tiptilt"=>Dict("kind"=>"second_order","natural_frequency_hz"=>250.0,"damping_ratio"=>0.7,"schema"=>"pipewireao/tip-tilt-opd-coefficients-m-f32/1"))
 dynamicpath=joinpath(SOURCE,"simulation/definition-dynamic.yaml")
 C.write_yaml(dynamicpath,dynamic)
 restored=deepcopy(C.read_yaml(dynamicpath));delete!(restored,"responses")
 @assert restored==original
 declaration=V.IC.load_simulation(idealpath)
 settings=V.IC.settings(declaration,get(receipt["recipe"],"settings",Dict()))
 identity=V.IC.prescription_identity(declaration,settings)
 @assert identity==receipt["source_prescription_identity"]
 resolved=V.IC.graph_document(declaration,settings)
 frozen=V.IC.load_simulation(joinpath(FROZEN_SOURCE,receipt["recipe"]["simulation"]))
 @assert resolved==V.IC.graph_document(frozen,settings)
 derivative=V.IC.load_simulation(dynamicpath)
 dynamicidentity=V.IC.prescription_identity(derivative,settings)
 @assert dynamicidentity!=identity
 dynamicgraph=V.IC.graph_document(derivative,settings)
 nodeorder=Dict(node["name"]=>index for (index,node) in enumerate(dynamicgraph["nodes"]))
 for link in get(dynamicgraph,"links",[])
  @assert nodeorder[first(split(link["source"],'.'))]<nodeorder[first(split(link["destination"],'.'))] "Generated direct link violates explicit topological order"
 end
 response=only(n for n in dynamicgraph["nodes"] if n["name"]=="tiptilt_response")
 @assert response["config"]==Dict("count"=>2,"schema"=>"pipewireao/tip-tilt-opd-coefficients-m-f32/1","natural_frequency_hz"=>250.0,"damping_ratio"=>0.7,"sample_period_s"=>0.0005)
 graphrestored=deepcopy(dynamicgraph)
 filter!(n->n["name"]!="tiptilt_response",graphrestored["nodes"])
 filter!(l->l["source"]!="tiptilt_response.output",graphrestored["links"])
 only(i for i in graphrestored["inputs"] if i["name"]=="tiptilt")["destination"]="tiptilt.coefficients"
 @assert graphrestored==resolved
 idealcal=V.IC.graph_document(declaration,settings;calibration=true)
 dynamiccal=V.IC.graph_document(derivative,settings;calibration=true)
 @assert idealcal==dynamiccal
 detector=only(n for n in resolved["nodes"] if n["name"]=="detector")
 atmo=only(n for n in resolved["nodes"] if n["name"]=="atmosphere")
 omega=2pi*250.0;A=[0.0 1.0;-omega^2 -2*0.7*omega]
 phi=exp(A*0.0005);gamma=[1-phi[1,1],-phi[2,1]]
 coefficients=V.PipeWireAORTC.InstrumentCalibration.lowpass_coefficients(Float32;cutoff_frequency_hz=25,sample_rate_hz=2000)
 return Dict("passed"=>true,"ideal_definition"=>idealpath,"dynamic_definition"=>dynamicpath,"source_prescription_identity"=>identity,"dynamic_source_prescription_identity"=>dynamicidentity,"original_receipt_identity_preserved_for_ideal"=>true,"response_key_only_definition_change"=>true,"resolved_dynamic_graph_restores_exactly_to_ideal"=>true,"calibration_graphs_equal"=>true,"response_node"=>response,"detector"=>detector,"atmosphere"=>atmo,"settings"=>settings,"lowpass_coefficients_f32"=>coefficients,"response_phi_f64"=>[collect(row) for row in eachrow(phi)],"response_gamma_f64"=>gamma,"model_scope"=>"Provisional250Hz/0.7 physical response, end-of-hold exact ZOH at2000Hz; same-schema input/output; no added delay or response clamp; not measured calibration")
end
function prepare_plant(preflight,dynamic)
 path=preflight[dynamic ? "dynamic_definition" : "ideal_definition"]
 declaration=V.IC.load_simulation(path);settings=preflight["settings"]
 @assert V.IC.prescription_identity(declaration,settings)==preflight[dynamic ? "dynamic_source_prescription_identity" : "source_prescription_identity"]
 target=V.B.AcceleratorComputeDevice(V.B.CUDABackend(),0)
 V.progress("prepare unchanged optics with dynamic_stage=$dynamic")
 system=V.IC.prepare_system(path;settings,calibration=false,target,execution=V.AG.CapturedGraphExecution())
 support=V.IC.binding_values(declaration,settings,Dict("kind"=>"pupil_support","resolution"=>"pupil_resolution"))
 xy=V.IC.binding_values(declaration,settings,Dict("kind"=>"pupil_coordinates","resolution"=>"pupil_resolution"))
 return (;system,declaration,settings,valid=findall(vec(support).!=0),xy)
end
function rng_observation(owner)
 rng=owner.rng
 sequence=hasproperty(rng,:state) && hasproperty(rng.state,:draw_sequence) ? only(Array(rng.state.draw_sequence)) : nothing
 return Dict("type"=>string(typeof(rng)),"seed"=>owner.rng_seed,"draw_sequence"=>sequence)
end
function plant_owners(p)
 w=V.AG.prepared_graph_node(p.system.graph,:woofer)
 t=V.AG.prepared_graph_node(p.system.graph,:tweeter)
 s=V.AG.prepared_graph_node(p.system.graph,:tiptilt)
 detector=V.AG.prepared_graph_node(p.system.graph,:detector)
 for owner in (w,t)
  @assert O.actuator_model(owner.deformable_mirror) isa O.LinearStaticActuators
 end
 response=hasproperty(p.system.graph.nodes,:tiptilt_response) ? V.AG.prepared_graph_node(p.system.graph,:tiptilt_response).prepared : nothing
 return (;woofer=w,tweeter=t,stage=s,detector,response)
end
function windows!(data)
 frames=data["sampled_frames"];series=data["series"]
 for (a,b) in ((513,2048),(2049,4096),(2049,16384),(4097,8192),(8193,16384))
  b>data["frames_requested"] && continue
  selected=findall(f->a<=f<=b,frames)
  isempty(selected) && continue
  get!(data,"windows",Dict())["$a-$b"]=Dict(k=>Dict("mean"=>mean(v[selected]),"max"=>maximum(v[selected]),"min"=>minimum(v[selected])) for (k,v) in series)
 end
end
Base.@constprop :none function run_case!(p,control,owners,frames,label,report,checkpoint,runtime_bound)
 command=V.commands(p.system);V.reset!(p,control,command)
 dynamic=owners.response!==nothing
 if dynamic
  @assert all(iszero,Array(owners.response.state.position)) && all(iszero,Array(owners.response.state.velocity)) && all(iszero,Array(owners.response.output))
  @assert all(iszero,Array(owners.stage.coefficients))
 end
 omega=2pi*250.0;phi=exp([0.0 1.0;-omega^2 -2*0.7*omega]*0.0005)
 gamma=[1-phi[1,1],-phi[2,1]]
 reset_rng=rng_observation(owners.detector)
 @assert reset_rng["seed"]==2
 reset_rng["draw_sequence"]===nothing || @assert reset_rng["draw_sequence"]==0
 limits=Dict("woofer"=>Float64(Float32(control.limit)),"tweeter"=>Float64(1f-6),"stage"=>Float64(1f-6))
 data=Dict{String,Any}("completed"=>false,"frames_requested"=>frames,"frames_completed"=>0,"woofer_limit_mOPD"=>control.limit,"actual_float32_limits_mOPD"=>limits,"reset_detector_rng"=>reset_rng,"sampled_frames"=>Int[],"atmosphere_field_sha256_every_frame"=>String[],"raw_camera_sha256_at_observations"=>String[],"detector_rng_at_observations"=>Any[],"series"=>Dict{String,Any}(),"per_frame"=>Dict{String,Any}(),"maximum_feedback_identity_error_nm"=>0.0,"maximum_adopted_command_error_nm"=>0.0,"maximum_grid_command_error_nm"=>0.0,"maximum_applied_command_error_nm"=>0.0,"maximum_conditioner_clamp_error_nm"=>0.0,"all_controller_and_optical_outputs_finite"=>true)
 data["dynamic_stage"]=dynamic;data["stage_lowpass_25hz"]=control.lowpass
 data["controller_parameter_hashes"]=control.parameter_hashes
 data["adopted_stage_filter_coefficients_f32"]=[collect(control.parameters[Symbol("tiptilt-filter-coefficients")][:,1,axis]) for axis in 1:2]
 data["reset_response_state_zero"]=true
 data["full_demanded_command_sha256_every_frame"]=Dict(name=>String[] for name in ("woofer","tweeter","stage"))
 data["maximum_response_position_recurrence_error_nm"]=0.0
 data["maximum_response_velocity_recurrence_error_nm_per_s"]=0.0
 data["maximum_stage_application_error_nm"]=0.0
 data["response_recurrence_tolerance"]=Dict("relative_scaled_float32_rounding_budget"=>64Float64(eps(Float32)),"position_scale"=>"max(abs(expected),abs(previous),dt*abs(previous velocity),abs(held command),1e-12m)","velocity_scale"=>"max(abs(expected),abs(previous),omega*abs(held command),omega*abs(previous position),1e-9m/s)","independent_method"=>"2x2 exp(A*dt); gamma=[1-phi11,-phi21], independent of implementation's augmented3x3 exp")
 casepath=joinpath(OUT,"case-"*label*".json")
 report["cases"][label]=Dict("path"=>casepath,"completed"=>false,"frames_requested"=>frames)
 series=data["series"];perframe=data["per_frame"]
 for name in ("atmosphere_rms_nm","residual_rms_nm","woofer_requested_peak_nm","tweeter_requested_peak_nm","stage_requested_peak_nm","woofer_clipped_count","tweeter_clipped_count","stage_clipped_count")
  series[name]=Float64[]
 end
 for name in ("woofer","tweeter","stage")
  perframe[name*"_clipped_count"]=Int[]
  perframe[name*"_requested_peak_nm"]=Float64[]
  perframe[name*"_demanded_peak_nm"]=Float64[]
 end
 for name in ("stage_adopted_x_nm","stage_adopted_y_nm","stage_issued_x_nm","stage_issued_y_nm","stage_applied_x_nm","stage_applied_y_nm","stage_velocity_x_nm_per_s","stage_velocity_y_nm_per_s","stage_tracking_error_x_nm","stage_tracking_error_y_nm","stage_tracking_error_peak_nm","stage_applied_peak_nm","stage_applied_outside_command_limit_count")
  perframe[name]=Float64[]
 end
 checkpoint_case()=begin
  C.write_json(casepath,data)
  report["cases"][label]["frames_completed"]=data["frames_completed"]
  report["cases"][label]["completed"]=data["completed"]
  checkpoint()
 end
 checkpoint_case();started=time_ns();V.progress("begin $label frames=$frames woofer_limit=$(control.limit)")
 try
  for frame in 1:frames
   oldposition=dynamic ? Float64.(Array(owners.response.state.position)) : zeros(2)
   oldvelocity=dynamic ? Float64.(Array(owners.response.state.velocity)) : zeros(2)
   # frame n adopts command n-1. Inspect the plant's actual inputs and applied
   # actuator commands before the controller creates command n.
   raw=V.frame!(p.system,command)
   for (name,key) in (("woofer",:woofer),("tweeter",:tweeter),("stage",:tiptilt))
    expected=Array(getproperty(command,key))
    input=Array(V.AG.graph_input(p.system.graph,key))
    error=maximum(abs,Float64.(input)-Float64.(expected))*1e9
    data["maximum_adopted_command_error_nm"]=max(data["maximum_adopted_command_error_nm"],error)
    @assert isequal(input,expected) "Plant adopted command differs at frame$frame: $name"
    @assert all(isfinite,input) && maximum(abs,input)<=limits[name]
    if name!="stage"
     owner=getproperty(owners,Symbol(name));dm=owner.deformable_mirror
     grid=Array(O.command_storage(dm));indices=Int.(Array(owner.actuator_grid_indices))
     applied=Array(dm.state.actuator_coefs)
     griderror=maximum(abs,Float64.(grid[indices])-Float64.(input))*1e9
     applyerror=maximum(abs,Float64.(applied)-Float64.(grid))*1e9
     data["maximum_grid_command_error_nm"]=max(data["maximum_grid_command_error_nm"],griderror)
     data["maximum_applied_command_error_nm"]=max(data["maximum_applied_command_error_nm"],applyerror)
     @assert isequal(grid[indices],input) && isequal(applied,grid)
     @assert all(isfinite,applied) && maximum(abs,applied)<=limits[name]
    else
     applied=Array(owners.stage.coefficients)
     @assert all(isfinite,applied)
     if dynamic
      position=Array(owners.response.state.position);velocity=Array(owners.response.state.velocity)
      @assert isequal(position,Array(owners.response.output)) && isequal(position,applied)
      @assert isequal(Array(owners.response.input),input) && all(isfinite,velocity)
      expectedstate=phi*vcat(transpose(oldposition),transpose(oldvelocity))+gamma*transpose(Float64.(input))
      yerror=maximum(abs,Float64.(position)-vec(expectedstate[1,:]));verror=maximum(abs,Float64.(velocity)-vec(expectedstate[2,:]))
      data["maximum_response_position_recurrence_error_nm"]=max(data["maximum_response_position_recurrence_error_nm"],yerror*1e9)
      data["maximum_response_velocity_recurrence_error_nm_per_s"]=max(data["maximum_response_velocity_recurrence_error_nm_per_s"],verror*1e9)
      for axis in 1:2
       yscale=max(abs(expectedstate[1,axis]),abs(oldposition[axis]),0.0005abs(oldvelocity[axis]),abs(input[axis]),1e-12)
       vscale=max(abs(expectedstate[2,axis]),abs(oldvelocity[axis]),omega*abs(input[axis]),omega*abs(oldposition[axis]),1e-9)
       @assert abs(position[axis]-expectedstate[1,axis])<=64eps(Float32)*yscale
       @assert abs(velocity[axis]-expectedstate[2,axis])<=64eps(Float32)*vscale
      end
     else
      @assert isequal(applied,input)
      velocity=zeros(2)
     end
     applicationerror=dynamic ? maximum(abs,Float64.(applied)-Float64.(Array(owners.response.output))) : maximum(abs,Float64.(applied)-Float64.(input))
     data["maximum_stage_application_error_nm"]=max(data["maximum_stage_application_error_nm"],applicationerror*1e9)
     for (axis,suffix) in ((1,"x"),(2,"y"))
      push!(perframe["stage_adopted_"*suffix*"_nm"],Float64(input[axis])*1e9)
      push!(perframe["stage_applied_"*suffix*"_nm"],Float64(applied[axis])*1e9)
      push!(perframe["stage_velocity_"*suffix*"_nm_per_s"],Float64(velocity[axis])*1e9)
      push!(perframe["stage_tracking_error_"*suffix*"_nm"],Float64(applied[axis]-input[axis])*1e9)
     end
     push!(perframe["stage_tracking_error_peak_nm"],maximum(abs,Float64.(applied)-Float64.(input))*1e9)
     push!(perframe["stage_applied_peak_nm"],maximum(abs,applied)*1e9)
     push!(perframe["stage_applied_outside_command_limit_count"],count(x->abs(x)>limits[name],applied))
    end
   end
   atmosphere=Array(V.AG.graph_output(p.system.graph,:atmosphere_opd))
   @assert all(isfinite,atmosphere)
   push!(data["atmosphere_field_sha256_every_frame"],bytes2hex(sha256(reinterpret(UInt8,vec(atmosphere)))))
   pupil=V.AG.graph_output(p.system.graph,:pupil_opd)
   @assert all(isfinite,pupil)
   V.process!(control,raw)
   @assert all(a->all(isfinite,a),values(control.outputs))
   for (name,key,fbkey) in (("woofer",:woofer,Symbol("woofer-constraint-feedback")),("tweeter",:tweeter,Symbol("tweeter-constraint-feedback")),("stage",:tiptilt,Symbol("stage-constraint-feedback")))
    requested=getproperty(control.outputs,Symbol(name*"-preclip"));demanded=getproperty(control.outputs,key);feedback=getproperty(control.outputs,fbkey)
    expected=clamp.(requested,-Float32(limits[name]),Float32(limits[name]))
    clamp_error=maximum(abs,Float64.(expected)-Float64.(demanded))*1e9
    feedback_error=maximum(abs,Float64.(requested.-demanded)-Float64.(feedback))*1e9
    data["maximum_conditioner_clamp_error_nm"]=max(data["maximum_conditioner_clamp_error_nm"],clamp_error)
    data["maximum_feedback_identity_error_nm"]=max(data["maximum_feedback_identity_error_nm"],feedback_error)
    @assert isequal(demanded,expected) && isequal(feedback,requested.-demanded)
    @assert maximum(abs,demanded)<=limits[name]
    push!(perframe[name*"_clipped_count"],count(!iszero,feedback))
    push!(perframe[name*"_requested_peak_nm"],maximum(abs,requested)*1e9)
    push!(perframe[name*"_demanded_peak_nm"],maximum(abs,demanded)*1e9)
    push!(data["full_demanded_command_sha256_every_frame"][name],bytes2hex(sha256(reinterpret(UInt8,vec(demanded)))))
    if name=="stage"
     push!(perframe["stage_issued_x_nm"],Float64(demanded[1])*1e9)
     push!(perframe["stage_issued_y_nm"],Float64(demanded[2])*1e9)
    end
   end
   for key in keys(command);copyto!(getproperty(command,key),getproperty(control.outputs,key));end
   copyto!(control.inputs.var"constraint-feedback",control.outputs.var"controller-constraint-feedback")
   if frame<=32 || frame%64==0
    push!(data["sampled_frames"],frame)
    push!(data["raw_camera_sha256_at_observations"],bytes2hex(sha256(reinterpret(UInt8,vec(Array(raw))))))
    push!(data["detector_rng_at_observations"],rng_observation(owners.detector))
    push!(series["atmosphere_rms_nm"],V.pupil_rms(atmosphere,p.valid)*1e9)
    push!(series["residual_rms_nm"],V.pupil_rms(pupil,p.valid)*1e9)
    for name in ("woofer","tweeter","stage"),quantity in ("requested_peak_nm","clipped_count")
     push!(series[name*"_"*quantity],last(perframe[name*"_"*quantity]))
    end
   end
   data["frames_completed"]=frame
   if frame%512==0 || frame==frames
    data["elapsed_s"]=(time_ns()-started)/1e9
    checkpoint_case();V.progress("$label frame=$frame residual_nm=$(last(series["residual_rms_nm"])) elapsed_s=$(data["elapsed_s"])")
    data["elapsed_s"]>runtime_bound && frame<frames && error("Per-case warm execution bound reached: $runtime_bound seconds")
   end
  end
  # The last controller output has not yet been consumed by a new optical
  # frame; verify its demanded bound here. Every earlier output was adopted.
  data["adoption_boundary"]="Frame n checks command n-1 in graph inputs and applied actuator storage; final command n is bounded/finite but awaits the next frame. No extra scientific frame is advanced."
  windows!(data);data["completed"]=true
  return data
 catch error
  data["error"]=sprint(showerror,error,catch_backtrace());rethrow()
 finally
  checkpoint_case()
 end
end
function verify_pair!(baseline,candidate)
 @assert candidate["atmosphere_field_sha256_every_frame"]==baseline["atmosphere_field_sha256_every_frame"]
 @assert candidate["reset_detector_rng"]==baseline["reset_detector_rng"]
 @assert candidate["detector_rng_at_observations"]==baseline["detector_rng_at_observations"]
 return Dict("all_frame_full_atmosphere_hashes_equal"=>true,"number_of_frames"=>baseline["frames_completed"],"detector_reset_seed_and_sampled_draw_sequence_equal"=>true,"raw_camera_boundary"=>"Settings/reset seed/draw policy match; detector photon inputs and realized stochastic outputs depend on differing optical trajectories, so camera bit equality is not required")
end
function verify_history!(baseline)
 reference=C.read_json(PRIOR)
 @assert baseline["sampled_frames"]==reference["sampled_frames"]
 checks=Dict{String,Any}()
 for section in ("series","per_frame"),key in keys(reference[section])
  @assert isequal(baseline[section][key],reference[section][key]) "Accepted ideal/identity retained trace mismatch: $section/$key"
  checks[section*"/"*key]=Dict("exact_values_equal"=>true,"observations"=>length(reference[section][key]))
 end
 @assert baseline["atmosphere_field_sha256_every_frame"]==reference["atmosphere_field_sha256_every_frame"]
 @assert baseline["raw_camera_sha256_at_observations"]==reference["raw_camera_sha256_at_observations"]
 @assert baseline["detector_rng_at_observations"]==reference["detector_rng_at_observations"]
 return Dict("passed"=>true,"reference_path"=>PRIOR,"reference_sha256"=>C.sha256_file(PRIOR),"checks"=>checks,"all4096_full_atmosphere_hashes_equal"=>true,"all96_camera_hashes_equal"=>true,"full_old_command_vector_boundary"=>"Prior full vectors unavailable; exact comparison covers every retained requested/demanded peak and clip count. New full vector hashes support reset comparisons.")
end
function main()
 BLAS.set_num_threads(1);V.B.set_fft_provider_threads!(1)
 cal=joinpath(APP,"calibration");receipt=C.read_yaml(joinpath(cal,"result.yaml"))
 path=joinpath(OUT,"replay-result.json")
 report=Dict{String,Any}("completed"=>false,"cases"=>Dict{String,Any}(),"scope"=>"Private matched temporal sensitivity: ideal/dynamic stage crossed with identity/25Hz controller; all woofer bounds3.4umOPD, stage/tweeter1umOPD; original integrator/hidden0; no live/prod/native/session/GUI changes","driver_sha256"=>C.sha256_file(@__FILE__),"resource_path_workaround"=>RESOURCE_PATCH,"original_graph_sha256"=>C.sha256_file(joinpath(APP,"rtc/graph.conf")),"receipt_sha256"=>C.sha256_file(joinpath(cal,"result.yaml")),"manifest_sha256"=>C.sha256_file(joinpath(dirname(Base.active_project()),"Manifest.toml")),"julia_version"=>string(VERSION),"science_sampling"=>"Full atmosphere spatial SHA256 and demanded command-vector hashes every frame; WFE/camera/RNG first32 then every64; clipping and response/adoption/finite checks every frame","runtime_bounds_s"=>Dict("controller_preparation"=>600,"optical_preparation"=>600,"cold_runner_specialization"=>600,"warm_case"=>300),"model_claim"=>"Provisional engineering assumptions; no measured stage-model, physical-device, stability or real-time qualification")
 checkpoint()=C.write_json(path,report);checkpoint()
 try
  originalmanifest=TOML.parsefile("/home/dgamroth/.cache/pipewireao/gpi2-registered-20261025/environment/Manifest.toml")
  newmanifest=TOML.parsefile(joinpath(dirname(Base.active_project()),"Manifest.toml"))
  for (name,entries) in originalmanifest["deps"]
   name in ("AdaptiveOpticsSim","PipeWireAORTC") && continue
   old=only(entries);new=only(newmanifest["deps"][name])
   @assert all(key->get(old,key,nothing)==get(new,key,nothing),("uuid","version","git-tree-sha1")) "Unplanned science dependency change: $name"
  end
  report["only_AOS_RTC_science_source_overrides_verified"]=true
  report["preflight"]=source_preflight(receipt)
  graph_document(3.4e-6) # Validate unchanged controller apart from accepted woofer bounds.
  admission=joinpath(pkgdir(V.PipeWireAORTC),"test/test_response_cadence.jl")
  report["cheap_native_response_admission_selector"]=Dict{String,Any}("path"=>admission,"sha256"=>C.sha256_file(admission))
  include(admission) # Two modes / 2x2 native pupil; no full controller or optics preparation.
  report["cheap_native_response_admission_selector"]["passed"]=true
  checkpoint();V.progress("source/response/coefficients preflight passed")
  if "preflight-only" in ARGS;report["completed"]=true;return;end
  @assert V.CUDA_MODULE!==nothing;V.CUDA_MODULE.allowscalar(false)
  started=time_ns()
  control=prepare_control(cal,receipt,false)
  identitybank=copy(control.parameters[Symbol("tiptilt-filter-coefficients")])
  lowpassbank=copy(identitybank)
  coefficients=V.PipeWireAORTC.InstrumentCalibration.lowpass_coefficients(Float32;cutoff_frequency_hz=25,sample_rate_hz=2000)
  for axis in 1:2;lowpassbank[:,1,axis].=coefficients;end
  identity=adopt_control!(control,identitybank,false)
  lowpass=adopt_control!(control,lowpassbank,true)
  changed=sort([key for key in keys(identity.parameter_hashes) if identity.parameter_hashes[key]!=lowpass.parameter_hashes[key]])
  @assert changed==["tiptilt-filter-coefficients"] && identity.original_filter_hash==lowpass.original_filter_hash
  @assert typeof(identity)==typeof(lowpass)
  report["parameter_hashes_identity"]=identity.parameter_hashes
  report["parameter_hashes_lowpass25"]=lowpass.parameter_hashes
  report["sole_parameter_change"]=changed
  report["controller_preparation_policy"]="Exactly one prepared topology/owner. Before each case, adopt the existing stage coefficient parameter bank off frame, verify ALL parameter hashes, then reset graph/controller/plant/model-time/RNG in run_case!. Default optimization unchanged."
  report["controller_preparation_s"]=(time_ns()-started)/1e9
  @assert report["controller_preparation_s"]<=600
  checkpoint();started=time_ns()
  ideal=prepare_plant(report["preflight"],false);idealowners=plant_owners(ideal)
  dynamic=prepare_plant(report["preflight"],true);dynamicowners=plant_owners(dynamic)
  report["optical_preparation_s"]=(time_ns()-started)/1e9
  @assert report["optical_preparation_s"]<=600
  report["runtime_response_plan"]=Dict("coefficients"=>collect(dynamicowners.response.plan.coefficients),"natural_frequency_hz"=>dynamicowners.response.plan.natural_frequency_hz,"damping_ratio"=>dynamicowners.response.plan.damping_ratio,"sample_period_s"=>dynamicowners.response.plan.sample_period_s)
  @assert dynamicowners.response.plan.sample_period_s==0.0005
  report["runtime_actuator_models"]=Dict(name=>string(typeof(O.actuator_model(getproperty(idealowners,Symbol(name)).deformable_mirror))) for name in ("woofer","tweeter"))
  report["cuda_version"]=string(Base.pkgversion(V.CUDA_MODULE));checkpoint()
  started=time_ns()
  Base.invokelatest(run_case!,ideal,adopt_control!(control,identitybank,false),idealowners,2,"warmup-ideal",report,checkpoint,600.0)
  Base.invokelatest(run_case!,dynamic,adopt_control!(control,identitybank,false),dynamicowners,2,"warmup-dynamic",report,checkpoint,600.0)
  report["cold_instrumentation_preparation_s"]=(time_ns()-started)/1e9
  @assert report["cold_instrumentation_preparation_s"]<=600
  report["warmup_policy"]="Two instrumented frames for each plant type before timing; every scientific case resets graph/controller/command/model-time/detector RNG and asserts dynamic position/velocity/output immediately zero"
  ref=Base.invokelatest(run_case!,ideal,adopt_control!(control,identitybank,false),idealowners,4096,"ideal-identity-4096",report,checkpoint,300.0)
  report["historical_accepted_woofer_match"]=verify_history!(ref);checkpoint()
  idealLP=Base.invokelatest(run_case!,ideal,adopt_control!(control,lowpassbank,true),idealowners,4096,"ideal-lowpass25-4096",report,checkpoint,300.0)
  dynamicID=Base.invokelatest(run_case!,dynamic,adopt_control!(control,identitybank,false),dynamicowners,4096,"dynamic-identity-4096",report,checkpoint,300.0)
  dynamicLP=Base.invokelatest(run_case!,dynamic,adopt_control!(control,lowpassbank,true),dynamicowners,4096,"dynamic-lowpass25-4096",report,checkpoint,300.0)
  report["short_pair_matches"]=Dict("ideal-lowpass25"=>verify_pair!(ref,idealLP),"dynamic-identity"=>verify_pair!(ref,dynamicID),"dynamic-lowpass25"=>verify_pair!(ref,dynamicLP))
  report["extension_decision"]="All4096 structural/finite/response gates passed; extend BOTH dynamic conditions unconditionally, regardless of relative WFE; no retuning"
  checkpoint()
  longID=Base.invokelatest(run_case!,dynamic,adopt_control!(control,identitybank,false),dynamicowners,16384,"dynamic-identity-16384",report,checkpoint,300.0)
  longLP=Base.invokelatest(run_case!,dynamic,adopt_control!(control,lowpassbank,true),dynamicowners,16384,"dynamic-lowpass25-16384",report,checkpoint,300.0)
  report["long_pair_match"]=verify_pair!(longID,longLP)
  report["reset_prefix_matches"]=Dict{String,Bool}()
  for (name,short,long) in (("identity",dynamicID,longID),("lowpass25",dynamicLP,longLP))
   @assert long["atmosphere_field_sha256_every_frame"][1:4096]==short["atmosphere_field_sha256_every_frame"]
   @assert all(key->isequal(long["full_demanded_command_sha256_every_frame"][key][1:4096],short["full_demanded_command_sha256_every_frame"][key]),keys(short["full_demanded_command_sha256_every_frame"]))
   @assert all(key->isequal(long["per_frame"][key][1:4096],short["per_frame"][key]),keys(short["per_frame"]))
   n=length(short["sampled_frames"])
   @assert all(key->isequal(long["series"][key][1:n],short["series"][key]),keys(short["series"]))
   @assert long["raw_camera_sha256_at_observations"][1:n]==short["raw_camera_sha256_at_observations"]
   report["reset_prefix_matches"][name]=true
  end
  @assert C.sha256_file(joinpath(APP,"rtc/graph.conf"))==report["original_graph_sha256"]
  @assert C.sha256_file(joinpath(cal,"result.yaml"))==report["receipt_sha256"]
  @assert C.sha256_file(joinpath(dirname(Base.active_project()),"Manifest.toml"))==report["manifest_sha256"]
  report["frozen_graph_receipt_manifest_unchanged"]=true;report["completed"]=true
 catch error
  report["error"]=sprint(showerror,error,catch_backtrace());rethrow()
 finally
  checkpoint()
 end
end
const RESOURCE_PATCH=install_resource_paths!()
main()
