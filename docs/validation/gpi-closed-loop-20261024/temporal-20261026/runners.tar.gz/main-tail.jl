function main()
 BLAS.set_num_threads(1);V.B.set_fft_provider_threads!(1)
 cal=joinpath(APP,"calibration");receipt=C.read_yaml(joinpath(cal,"result.yaml"))
 path=joinpath(OUT,"replay-result.json")
 report=Dict{String,Any}("completed"=>false,"cases"=>Dict{String,Any}(),"scope"=>"Private matched temporal sensitivity: ideal/dynamic stage crossed with identity/25Hz controller; all woofer bounds3.4umOPD, stage/tweeter1umOPD; original integrator/hidden0; no live/prod/native/session/GUI changes","driver_sha256"=>C.sha256_file(@__FILE__),"resource_path_workaround"=>RESOURCE_PATCH,"original_graph_sha256"=>C.sha256_file(joinpath(APP,"rtc/graph.conf")),"receipt_sha256"=>C.sha256_file(joinpath(cal,"result.yaml")),"manifest_sha256"=>C.sha256_file(joinpath(dirname(Base.active_project()),"Manifest.toml")),"julia_version"=>string(VERSION),"science_sampling"=>"Full atmosphere spatial SHA256 and demanded command-vector hashes every frame; WFE/camera/RNG first32 then every64; clipping and response/adoption/finite checks every frame","runtime_bounds_s"=>Dict("controller_preparation"=>600,"optical_preparation"=>600,"cold_runner_specialization"=>600,"warm_case"=>300),"model_claim"=>"Provisional engineering assumptions; no measured stage-model, physical-device, stability or real-time qualification")
 checkpoint()=C.write_json(path,report);checkpoint()
 try
  originalmanifest=TOML.parsefile("/home/dgamroth/.cache/pipewireao/gpi2-registered-20261025/environment/Manifest.toml")
  newmanifest=TOML.parsefile(joinpath(dirname(Base.active_project()),"Manifest.toml"))
  for (name,entries) in originalmanifest["deps"]
   name in ("AdaptiveOpticsSim","PipeWireAORTC") && continue
   old=only(entries);new=only(newmanifest["deps"][name])
   @assert all(key->get(old,key,nothing)==get(new,key,nothing),("uuid","version","git-tree-sha1")) "Unplanned science dependency change: $name"
  end
  report["only_AOS_RTC_science_source_overrides_verified"]=true
  report["preflight"]=source_preflight(receipt)
  @assert graph_document(3.4e-6)==graph_document(3.4e-6)
  checkpoint();V.progress("source/response/coefficients preflight passed")
  if "preflight-only" in ARGS;report["completed"]=true;return;end
  @assert V.CUDA_MODULE!==nothing;V.CUDA_MODULE.allowscalar(false)
  started=time_ns()
  identity=prepare_control(cal,receipt,false)
  lowpass=prepare_control(cal,receipt,true)
  changed=sort([key for key in keys(identity.parameter_hashes) if identity.parameter_hashes[key]!=lowpass.parameter_hashes[key]])
  @assert changed==["tiptilt-filter-coefficients"] && identity.original_filter_hash==lowpass.original_filter_hash
  @assert typeof(identity)==typeof(lowpass)
  report["parameter_hashes_identity"]=identity.parameter_hashes
  report["parameter_hashes_lowpass25"]=lowpass.parameter_hashes
  report["sole_parameter_change"]=changed
  report["controller_preparation_s"]=(time_ns()-started)/1e9
  @assert report["controller_preparation_s"]<=600
  checkpoint();started=time_ns()
  ideal=prepare_plant(report["preflight"],false);idealowners=plant_owners(ideal)
  dynamic=prepare_plant(report["preflight"],true);dynamicowners=plant_owners(dynamic)
  report["optical_preparation_s"]=(time_ns()-started)/1e9
  @assert report["optical_preparation_s"]<=600
  report["runtime_response_plan"]=Dict("coefficients"=>collect(dynamicowners.response.plan.coefficients),"natural_frequency_hz"=>dynamicowners.response.plan.natural_frequency_hz,"damping_ratio"=>dynamicowners.response.plan.damping_ratio,"sample_period_s"=>dynamicowners.response.plan.sample_period_s)
  @assert dynamicowners.response.plan.sample_period_s==0.0005
  report["runtime_actuator_models"]=Dict(name=>string(typeof(O.actuator_model(getproperty(idealowners,Symbol(name)).deformable_mirror))) for name in ("woofer","tweeter"))
  report["cuda_version"]=string(Base.pkgversion(V.CUDA_MODULE));checkpoint()
  started=time_ns()
  Base.invokelatest(run_case!,ideal,identity,idealowners,2,"warmup-ideal",report,checkpoint,600.0)
  Base.invokelatest(run_case!,dynamic,identity,dynamicowners,2,"warmup-dynamic",report,checkpoint,600.0)
  report["cold_instrumentation_preparation_s"]=(time_ns()-started)/1e9
  @assert report["cold_instrumentation_preparation_s"]<=600
  report["warmup_policy"]="Two instrumented frames for each plant type before timing; every scientific case resets graph/controller/command/model-time/detector RNG and asserts dynamic position/velocity/output immediately zero"
  ref=Base.invokelatest(run_case!,ideal,identity,idealowners,4096,"ideal-identity-4096",report,checkpoint,300.0)
  report["historical_accepted_woofer_match"]=verify_history!(ref);checkpoint()
  idealLP=Base.invokelatest(run_case!,ideal,lowpass,idealowners,4096,"ideal-lowpass25-4096",report,checkpoint,300.0)
  dynamicID=Base.invokelatest(run_case!,dynamic,identity,dynamicowners,4096,"dynamic-identity-4096",report,checkpoint,300.0)
  dynamicLP=Base.invokelatest(run_case!,dynamic,lowpass,dynamicowners,4096,"dynamic-lowpass25-4096",report,checkpoint,300.0)
  report["short_pair_matches"]=Dict("ideal-lowpass25"=>verify_pair!(ref,idealLP),"dynamic-identity"=>verify_pair!(ref,dynamicID),"dynamic-lowpass25"=>verify_pair!(ref,dynamicLP))
  report["extension_decision"]="All4096 structural/finite/response gates passed; extend BOTH dynamic conditions unconditionally, regardless of relative WFE; no retuning"
  checkpoint()
  longID=Base.invokelatest(run_case!,dynamic,identity,dynamicowners,16384,"dynamic-identity-16384",report,checkpoint,300.0)
  longLP=Base.invokelatest(run_case!,dynamic,lowpass,dynamicowners,16384,"dynamic-lowpass25-16384",report,checkpoint,300.0)
  report["long_pair_match"]=verify_pair!(longID,longLP)
  report["reset_prefix_matches"]=Dict{String,Bool}()
  for (name,short,long) in (("identity",dynamicID,longID),("lowpass25",dynamicLP,longLP))
   @assert long["atmosphere_field_sha256_every_frame"][1:4096]==short["atmosphere_field_sha256_every_frame"]
   @assert all(key->isequal(long["full_demanded_command_sha256_every_frame"][key][1:4096],short["full_demanded_command_sha256_every_frame"][key]),keys(short["full_demanded_command_sha256_every_frame"]))
   @assert all(key->isequal(long["per_frame"][key][1:4096],short["per_frame"][key]),keys(short["per_frame"]))
   n=length(short["sampled_frames"])
   @assert all(key->isequal(long["series"][key][1:n],short["series"][key]),keys(short["series"]))
   @assert long["raw_camera_sha256_at_observations"][1:n]==short["raw_camera_sha256_at_observations"]
   report["reset_prefix_matches"][name]=true
  end
  @assert C.sha256_file(joinpath(APP,"rtc/graph.conf"))==report["original_graph_sha256"]
  @assert C.sha256_file(joinpath(cal,"result.yaml"))==report["receipt_sha256"]
  @assert C.sha256_file(joinpath(dirname(Base.active_project()),"Manifest.toml"))==report["manifest_sha256"]
  report["frozen_graph_receipt_manifest_unchanged"]=true;report["completed"]=true
 catch error
  report["error"]=sprint(showerror,error,catch_backtrace());rethrow()
 finally
  checkpoint()
 end
end
const RESOURCE_PATCH=install_resource_paths!()
main()
