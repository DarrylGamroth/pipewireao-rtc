using PipeWireAORTC,Statistics,SHA
const C=PipeWireAORTC.Common
const OUT=@__DIR__
function main()
 r=C.read_json(joinpath(OUT,"replay-result.json"))
 s=Dict{String,Any}("completed"=>r["completed"],"scope"=>r["scope"],"model_claim"=>r["model_claim"],"cases"=>Dict{String,Any}(),"preflight"=>r["preflight"],"artifacts"=>Dict{String,Any}(),"external_inputs"=>Dict{String,Any}())
 for key in ("historical_accepted_woofer_match","short_pair_matches","long_pair_match","reset_prefix_matches","runtime_response_plan","runtime_actuator_models","sole_parameter_change","controller_preparation_s","optical_preparation_s","cold_instrumentation_preparation_s","frozen_graph_receipt_manifest_unchanged","extension_decision","cheap_native_response_admission_selector","runtime_bounds_s","parameter_hashes_identity","parameter_hashes_lowpass25")
  s[key]=get(r,key,nothing)
 end
 for (label,item) in r["cases"]
  startswith(label,"warmup") && continue
  d=C.read_json(item["path"])
  @assert !d["completed"] || d["elapsed_s"]<=300 "Completed science case exceeded declared warm bound: $label"
  result=Dict{String,Any}("completed"=>d["completed"],"frames_completed"=>d["frames_completed"],"dynamic_stage"=>d["dynamic_stage"],"lowpass25"=>d["stage_lowpass_25hz"],"reset_response_state_zero"=>d["reset_response_state_zero"],"elapsed_s"=>get(d,"elapsed_s",nothing),"windows"=>Dict{String,Any}(),"exact_structural_errors_nm"=>Dict(k=>v for (k,v) in d if startswith(k,"maximum_") && endswith(k,"_error_nm") && !occursin("response_position",k)),"maximum_response_position_recurrence_error_nm"=>d["maximum_response_position_recurrence_error_nm"],"maximum_response_velocity_recurrence_error_nm_per_s"=>d["maximum_response_velocity_recurrence_error_nm_per_s"],"response_recurrence_tolerance"=>d["response_recurrence_tolerance"])
  observed=d["series"]["residual_rms_nm"]
  result["all_sampled_WFE_nm"]=Dict("mean"=>mean(observed),"max"=>maximum(observed),"min"=>minimum(observed),"observation_count"=>length(observed))
  for (window,values) in get(d,"windows",Dict())
   a,b=parse.(Int,split(window,'-'));b>d["frames_completed"] && continue
   command=Dict{String,Any}()
   for name in ("woofer","tweeter","stage")
    clips=Float64.(d["per_frame"][name*"_clipped_count"][a:b]);request=Float64.(d["per_frame"][name*"_requested_peak_nm"][a:b]);demand=Float64.(d["per_frame"][name*"_demanded_peak_nm"][a:b])
    command[name]=Dict("mean_clipped_coordinates"=>mean(clips),"percentage_frames_with_clipping"=>100count(>(0),clips)/length(clips),"maximum_clipped_coordinates"=>maximum(clips),"mean_requested_peak_nm"=>mean(request),"maximum_requested_peak_nm"=>maximum(request),"maximum_demanded_peak_nm"=>maximum(demand))
   end
   f=d["per_frame"]
   x=Float64.(f["stage_tracking_error_x_nm"][a:b]);y=Float64.(f["stage_tracking_error_y_nm"][a:b]);peak=Float64.(f["stage_tracking_error_peak_nm"][a:b]);outside=Float64.(f["stage_applied_outside_command_limit_count"][a:b])
   response=Dict("two_axis_tracking_error_norm_RMS_nm"=>sqrt(mean(x.^2+y.^2)),"maximum_axis_tracking_error_nm"=>maximum(peak),"maximum_applied_stage_coefficient_nm"=>maximum(Float64.(f["stage_applied_peak_nm"][a:b])),"applied_coordinate_samples_outside_command_limit"=>sum(outside),"percentage_frames_applied_outside_command_limit"=>100count(>(0),outside)/length(outside),"quantity_boundary"=>"Tracking compares actual end-of-hold applied coefficients to held adopted command n-1; coefficient norm is not pupil WFE. Physical response is not clamped.")
   result["windows"][window]=Dict("WFE_nm"=>values["residual_rms_nm"],"commands"=>command,"stage_response"=>response)
  end
  s["cases"][label]=result
 end
 s["WFE_ratios"]=Dict{String,Any}()
 for (label,numerator,denominator,window) in (("ideal_25hz_over_identity_4096","ideal-lowpass25-4096","ideal-identity-4096","2049-4096"),("dynamic_identity_over_ideal_identity_4096","dynamic-identity-4096","ideal-identity-4096","2049-4096"),("dynamic_25hz_over_identity_4096","dynamic-lowpass25-4096","dynamic-identity-4096","2049-4096"),("dynamic_25hz_over_identity_16384","dynamic-lowpass25-16384","dynamic-identity-16384","2049-16384"))
  all(k->haskey(s["cases"],k) && s["cases"][k]["completed"],(numerator,denominator)) || continue
  ratio=s["cases"][numerator]["windows"][window]["WFE_nm"]["mean"]/s["cases"][denominator]["windows"][window]["WFE_nm"]["mean"]
  s["WFE_ratios"][label]=Dict("ratio"=>ratio,"mean_WFE_change_percent"=>100*(ratio-1),"window"=>window)
 end
 isfile(joinpath(OUT,"graph-receipts.json")) && (s["graph_receipts"]=C.read_json(joinpath(OUT,"graph-receipts.json")))
 if s["completed"]
  runpath=joinpath(OUT,"RUN.md")
  prefix=first(split(read(runpath,String),"\n## Observed results\n"))
  open(runpath,"w") do io
   print(io,prefix,"\n\n## Observed results\n\n")
   println(io,"All six scientific cases completed; every saved final duration is below300s. Ideal/identity exactly reproduced all retained historical statistics,96 camera/WFE observations and4096 full atmosphere fields. Both dynamic short/long reset prefixes match exact full command hashes, per-frame traces, sampled WFE/cameras and atmosphere fields. All paired atmosphere fields and detector seed/draw policies match. No source or scientific setting changed during the run.\n")
   println(io,"| Case | Frames | Seconds | Late WFE mean/max nm | Mean clipped coordinates W/T/stage | Stage tracking norm RMS nm |")
   println(io,"|---|---:|---:|---:|---:|---:|")
   for (label,d) in sort(collect(s["cases"]);by=first)
    window=d["frames_completed"]==4096 ? "2049-4096" : "2049-16384"
    w=d["windows"][window];wf=w["WFE_nm"];commands=w["commands"]
    clips=join([string(round(commands[name]["mean_clipped_coordinates"];digits=4)) for name in ("woofer","tweeter","stage")]," / ")
    println(io,"| ",label," | ",d["frames_completed"]," | ",round(d["elapsed_s"];digits=3)," | ",round(wf["mean"];digits=5)," / ",round(wf["max"];digits=5)," | ",clips," | ",round(w["stage_response"]["two_axis_tracking_error_norm_RMS_nm"];digits=5)," |")
   end
   println(io,"\nLate windows are2049–4096 or2049–16384; WFE uses first32 then every64 sampling. Clipping/tracking use every frame in the window. Reported maxima describe the sampled WFE flares within those windows, not a stability qualification. Tracking is √mean(error_x²+error_y²) of physical coefficients relative to held adopted commands, not pupil WFE.")
   println(io,"\nWFE changes from the fixed25Hz filter: ",s["WFE_ratios"],". No retuning or deployment follows from these finite provisional-model results.")
   println(io,"\nSource identities: ideal ",s["preflight"]["source_prescription_identity"],"; dynamic ",s["preflight"]["dynamic_source_prescription_identity"],". Dynamic source adds only the response declaration; expanded graph restoration and static calibration equality are exact. Original calibration receipt, reconstructor, source/settings and resolved graph hashes are retained in graph-receipts.json. Runtime and parameter hashes are retained in replay-result.json; summary.json records source/runner/helper/environment hashes.")
   println(io,"\nObserved: all finite, clamp/feedback/adoption/application and independent response recurrence gates passed. Derived: reported ratios describe this matched finite trajectory only. The250Hz/0.7 stage is an assumed response model, not a measured plant calibration; hardware limits, temporal stability and real-time performance remain unqualified. No live/production/GUI/native-session changes occurred.")
  end
 end
 for path in (
  joinpath(OUT,"environment/Project.toml"),joinpath(OUT,"environment/Manifest.toml"),
  "/home/dgamroth/.cache/pipewireao/gpi2-tiptilt-20261025/gpi2_closed_loop_helpers.jl",
  "/home/dgamroth/.cache/pipewireao/gpi2-registered-20261025/with-env.sh",
  "/home/dgamroth/.local/state/pipewireao/gpi2-registered-live-20261025/application/rtc/graph.conf",
  "/home/dgamroth/.local/state/pipewireao/gpi2-registered-live-20261025/application/calibration/result.yaml",
  joinpath(OUT,"source/gpi2/simulation/definition.yaml"),joinpath(OUT,"source/gpi2/simulation/definition-dynamic.yaml"),joinpath(OUT,"source/gpi2/simulation/calibration.yaml"),
  "/home/dgamroth/workspaces/codex/worktrees/aos-stage-response-20261026/src/optics/second_order_response.jl",
  "/home/dgamroth/workspaces/codex/worktrees/aos-stage-response-20261026/src/algorithm_graphs/second_order_response_node.jl",
  "/home/dgamroth/workspaces/codex/worktrees/rtc-gpi2-temporal-split-20261026/src/instruments/responses.jl",
  "/home/dgamroth/workspaces/codex/worktrees/rtc-gpi2-temporal-split-20261026/src/instrument_calibration.jl",
  "/home/dgamroth/workspaces/codex/worktrees/rtc-gpi2-temporal-split-20261026/ext/aos/instruments.jl")
  s["external_inputs"][path]=Dict("bytes"=>filesize(path),"sha256"=>C.sha256_file(path))
 end
 for path in sort(readdir(OUT;join=true))
  isfile(path) || continue
  basename(path) in ("summary.json","summary.txt","summarize.log") && continue
  s["artifacts"][basename(path)]=Dict("bytes"=>filesize(path),"sha256"=>C.sha256_file(path))
 end
 s["adjudication"]="Finite provisional-model temporal sensitivity only. Report both dynamic cases and WFE flares; no retuning, measured-model, stability, physical-device or deployment claim."
 C.write_json(joinpath(OUT,"summary.json"),s)
 open(joinpath(OUT,"summary.txt"),"w") do io
  println(io,"Completed: ",s["completed"])
  println(io,s["adjudication"])
  for (label,d) in sort(collect(s["cases"]);by=first)
   println(io,"\n",label," frames=",d["frames_completed"]," completed=",d["completed"])
   for (window,w) in sort(collect(d["windows"]);by=first)
    println(io," ",window," WFE_nm=",w["WFE_nm"])
    println(io," stage response=",w["stage_response"])
    println(io," command clips=",Dict(k=>v["mean_clipped_coordinates"] for (k,v) in w["commands"]))
   end
   println(io," response errors: position_nm=",d["maximum_response_position_recurrence_error_nm"]," velocity_nm_per_s=",d["maximum_response_velocity_recurrence_error_nm_per_s"])
   println(io," exact_structural_errors_nm=",d["exact_structural_errors_nm"])
  end
  println(io,"\nWFE ratios=",s["WFE_ratios"])
 end
 println(read(joinpath(OUT,"summary.txt"),String))
end
main()
