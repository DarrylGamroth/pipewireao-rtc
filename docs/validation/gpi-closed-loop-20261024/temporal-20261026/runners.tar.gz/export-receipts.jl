include("/home/dgamroth/.cache/pipewireao/gpi2-tiptilt-20261025/gpi2_closed_loop_helpers.jl")
using SHA
const V=GPIClosedLoopValidation
const C=V.C
const OUT=@__DIR__
include("resource-path-resolver.jl")
function main()
 source=joinpath(OUT,"source/gpi2")
 original=C.read_yaml("/home/dgamroth/.local/state/pipewireao/gpi2-registered-live-20261025/application/calibration/result.yaml")
 report=Dict{String,Any}("passed"=>false,"original_calibration_receipt_sha256"=>C.sha256_file("/home/dgamroth/.local/state/pipewireao/gpi2-registered-live-20261025/application/calibration/result.yaml"),"original_reconstructor_sha256"=>original["artifact_sha256"]["reconstructor.fits"],"graphs"=>Dict{String,Any}())
 graphs=Dict{String,Any}()
 for (name,path) in (("ideal","simulation/definition.yaml"),("dynamic","simulation/definition-dynamic.yaml"))
  definition=joinpath(source,path);declaration=V.IC.load_simulation(definition)
  settings=V.IC.settings(declaration,get(original["recipe"],"settings",Dict()))
  identity=V.IC.prescription_identity(declaration,settings)
  name=="ideal" && @assert identity==original["source_prescription_identity"]
  item=Dict{String,Any}("definition"=>definition,"definition_sha256"=>C.sha256_file(definition),"source_prescription_identity"=>identity)
  for (mode,calibration) in (("production",false),("calibration",true))
   graph=V.IC.graph_document(declaration,settings;calibration)
   file=joinpath(OUT,name*"-"*mode*"-resolved.json");C.write_json(file,graph)
   item[mode*"_graph_path"]=file;item[mode*"_graph_sha256"]=C.sha256_file(file)
   graphs[name*"-"*mode]=graph
  end
  report["graphs"][name]=item
 end
 @assert graphs["ideal-calibration"]==graphs["dynamic-calibration"]
 @assert report["graphs"]["ideal"]["calibration_graph_sha256"]==report["graphs"]["dynamic"]["calibration_graph_sha256"]
 restored=deepcopy(graphs["dynamic-production"])
 filter!(n->n["name"]!="tiptilt_response",restored["nodes"])
 filter!(l->l["source"]!="tiptilt_response.output",restored["links"])
 only(i for i in restored["inputs"] if i["name"]=="tiptilt")["destination"]="tiptilt.coefficients"
 @assert restored==graphs["ideal-production"]
 report["passed"]=true;report["calibration_hash_identical"]=true;report["dynamic_production_restores_exactly_to_ideal"]=true
 C.write_json(joinpath(OUT,"graph-receipts.json"),report)
 println(report)
end
const RESOURCE_PATCH=install_resource_paths!()
main()
