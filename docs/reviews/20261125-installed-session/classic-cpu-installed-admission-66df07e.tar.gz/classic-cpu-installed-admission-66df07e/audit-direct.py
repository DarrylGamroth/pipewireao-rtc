import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
trial = root / "classic-persistent-run"
provider = root / "classic-independent-v3"
owned = json.loads((trial / "ready-ledger.json").read_text())
terminal = json.loads((trial / "terminal.json").read_text())
controls = json.loads((trial / "controls.json").read_text())
assert owned["invocation"] == terminal["invocation"]
assert terminal["phase"] == "stopped" and terminal["cleanup_complete"]
assert terminal["systemd_quit"] == {"accepted": True, "attempted": True}
role = "closed-loop-correction:closed"
state = "pipewireao.correction-control." + role
assert controls["ready"]["reply"]["state"] == "Ready"
assert controls["ready"]["reply"]["result"]["owned_links"] == 20
assert controls["started"]["reply"]["state"] == "Running"
assert controls["held"]["reply"]["result"]["properties"][role]["value"] is False
assert controls["held"]["reply"]["result"]["properties"][state + ".primed"]["value"] is False
assert controls["running_open"]["reply"]["result"]["properties"][role]["value"] is False
assert controls["running_open"]["reply"]["result"]["properties"][state + ".primed"]["value"] is True
assert all(value["first_identity"] for value in controls["observation"]["streams"].values())

prefix = "RTC systemd stop timing "
markers = [json.loads(line.split(prefix, 1)[1]) for line in (trial / "journal.log").read_text().splitlines()
           if prefix in line]
[result] = [row for row in markers if row["invocation"] == owned["invocation"]]
assert result["outcome"] == "completed"
exit_ns = result["deadline_ns"] - result["process_exit_remaining_ns"]
cursors = [json.loads(line) for line in (provider / "source-cursor.jsonl").read_text().splitlines()]
assert all(row["pid"] == owned["owners"]["simulator"]["pid"] for row in cursors)
assert len({(row["instance"], row["generation"]) for row in cursors}) == 1
after = next((row for row in cursors if row["host_monotonic_ns"] > exit_ns), None)

units = [owned["unit"], *(peer["unit"] for peer in owned["owners"].values()),
         *owned["scoped_services"]]
shutdown = {}
for unit in dict.fromkeys(units):
    state = subprocess.run(["systemctl","--user","show",unit,"-p",
                            "ActiveState,MainPID,Result,ControlGroup"], check=True,
                            capture_output=True, text=True).stdout
    details = dict(line.split("=",1) for line in state.splitlines())
    assert details["MainPID"] == "0"
    assert details["ActiveState"] in ("inactive", "failed")
    shutdown[unit] = details

checks = {}
for role, process in {"rtc":{"pid": owned["session_pid"], "start-ticks": owned["session_start_ticks"]},
                      **owned["owners"]}.items():
    path = Path(f'/proc/{process["pid"]}/stat')
    current = int(path.read_text().rsplit(")",1)[1].split()[19]) if path.exists() else None
    assert current != int(process["start-ticks"]), role
    checks[role] = dict(pid=process["pid"], start_ticks=process["start-ticks"],
                        original_process_exited=True)
summary = dict(invocation=owned["invocation"], owned_links=20, quit=result,
               source_first_cursor=cursors[0], source_latest_cursor=cursors[-1],
               cursor_after_rtc_exit=after, rtc_exit_monotonic_ns=exit_ns,
               scoped_services=owned["scoped_services"], units=shutdown, owned_processes=checks)
(root/"direct-audit.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps({key:summary[key] for key in ("invocation","source_first_cursor","source_latest_cursor",
                                             "cursor_after_rtc_exit","rtc_exit_monotonic_ns")},indent=2))
