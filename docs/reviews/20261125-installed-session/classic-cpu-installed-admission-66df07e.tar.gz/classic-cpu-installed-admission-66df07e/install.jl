using PipeWireAO, PipeWireAORTC, Pkg
const R = PipeWireAORTC
app, expected, scope = ARGS
@assert realpath(pkgdir(R)) == realpath(expected)
prefix = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
@assert pkgversion(R) == v"0.7.30"
@assert pkgversion(PipeWireAO.LibPipeWire.PipeWireAO_jll) == v"4.0.8+0"
launcher = joinpath(app, "rtc/bin/pipewireao-rtc")
rm(launcher)
write(launcher, R.ScienceExport.rtc_launcher())
chmod(launcher, 0o755)
if get(ENV, "RTC_FUNCTIONAL_NO_HIL_IMAGE", "") == "1"
    receipt = joinpath(app, R.InstrumentConfiguration.SIMULATOR_PREPARATION)
    if isfile(receipt)
        cp(receipt, app * "-simulator-preparation.json"; force = true)
        rm(receipt)
    end
else
    R.InstrumentConfiguration.stage_simulator_preparation!(app, prefix)
end
R.InstrumentExport.seal!(app)
println("Installing in isolated copy ", app, " using ", pathof(R))
flush(stdout)
R.SessionInstall.finish_install(app, prefix, Base.julia_cmd().exec[1], nothing;
    persistent_graph_owners = scope == "persistent")
