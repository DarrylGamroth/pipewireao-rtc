# Installed admission extraction on disposable Classic CPU cohorts

The RTC source is commit `66df07e89c1e56dd2e4023d5cb283036b19d3a71`,
including the installed shutdown changes `ec4c91b` and `1cb3281`.
The archived Classic fixture supplied the calibration, v3 CPU simulation
and ordinary native source/graph contracts. Its staging helper prepared
disposable export copies and called the normal `SessionInstall.finish_install`
after sealing. The graph owner used Julia `-O0` for bounded cold setup.
The independent CPU simulator also used `-O0`. Both RTC services used
Julia 1.13.4's distribution image and PipeWireAO JLL 4.0.8+0. Each used
a separate private core and the test touched only its created services.

The directory named `classic-persistent-run` contains the installed
direct attachment. The directory named `classic-direct-run` is the
managed path. Its name follows the archived fixture labels. The direct
activation had a fixed configuration and runtime receipt. The managed
activation verified the independently generated invocation configuration.

Each lifecycle sent native Status against the exact RTC PID and session
instance, verified held Ready with 20 owned Links, queried the integrator
Open and unprimed, sent native Start and observed detector and slopes
acquisition identities. The integrator remained Open and became primed.
The driver submits no correction closure. Normal systemd Stop used the
installed native Quit hook. The terminal receipt verifies acknowledgement
and cleanup for the exact invocation.

## Direct result and separate graph disposal observation

The private core and independently supervised CPU source were publishing
before the start request. The graph and instance-scoped parameter owner
started with the RTC request. Thus the **75.160 s** to held Ready includes
cold graph and parameter startup through the systemd Ready notification.
It is a first activation, not a warm reattach. Native Quit completed in
**9.458 s**. Detector sequence 473 and slopes sequence 484 were observed
within generation 1. The integrator reported Open and primed while Running.

The direct receipt records the exact instance-scoped parameter and analysis
units. The graph and source outlive normal RTC Quit while the scoped
companions stop. The independent source in generation 1 was still
publishing at sequence 548 after RTC MainPID exit and reached 552 before
the fixture was retired. The driver's first postcondition expected every
external owner to stay alive and rejected the correctly stopped scoped
parameter owner. The raw native Quit receipt, exact stop journal and
independent post-run audit establish the RTC lifecycle. The controller
and graph had already been retired by the time the warm-reattach request
arrived, so the evidence includes one direct activation.

During subsequent disposal, the graph's own service stop sent SIGTERM.
The graph was idle in `take_connect!` and `run_persistent_owner`, waiting
for a new claimant after the RTC exit. The backtrace reports wrong-context
filter and proxy destruction followed by allocator corruption and SIGABRT
in `PipeWireAO.close` / `pw_proxy_destroy`. This is a distinct unresolved
graph-owner disposal result. The direct RTC had already completed native
Quit, and the fixture core was stopped afterward. The backtrace contains
no SessionAdmission frame and provides no causal attribution to the
admission extraction. The complete graph disposal journal is retained.

## Managed result

The independently sealed managed installation used the invocation
configuration, private core, CPU simulator, graph and parameter owner
started by its RTC service. The complete start request reached held
Ready in **137.250 s**. Both detector and slopes produced generation 1
sequence 1 after Start. The integrator remained Open and primed.
Native Quit completed in **11.333 s** with acknowledged cleanup.
The managed socket disappeared, all captured PID incarnations exited,
and the owned service cgroups and manager jobs were quiescent. The
final process scan found no command referencing the disposable fixture.

Both installations used RTC package tree
`a34ea2179bb2434ff9f6f105e401f80f438edc9f`, PipeWireAO.jl 0.9.6,
PipeWireAO JLL 4.0.8+0, FilterGraphPipeWire 0.5.11 and
AdaptiveOpticsSimPipeWireHIL 0.5.11. The installed manifests retain the
exact source and dependency pins. These are functional CPU fixture
observations on a shared workstation.
