"""Run one normal installed Classic RTC lifecycle against newly owned CPU services."""

import fcntl
import json
import os
from pathlib import Path
import subprocess as sp
import sys
import time

root = Path(__file__).resolve().parent
profile, scope = sys.argv[1:]
assert profile == "classic"
record = json.loads((root / f"{profile}-{scope}.json").read_text())
app = Path(record["app"])
runtime_parent = Path(os.environ["XDG_RUNTIME_DIR"])
variant = "c" + root.name[-5:].lower() + ("p" if scope == "persistent" else "d")
unit = f"pipewireao-session@{variant}.service"
rtc_runtime = runtime_parent / ("pipewireao-session-" + variant)
fragment = runtime_parent / "systemd/user" / unit
drop = fragment.with_suffix(".service.d")
prefix = Path.home() / ".julia/artifacts/77da251765f3124df77322c562e67a7c7742ab1d"
env = dict(os.environ, **record["env"])
output = root / f"{profile}-{scope}-run"
output.mkdir()


def system(*args, timeout=25, check=True):
    return sp.run(["systemctl", "--user", *args], check=check,
                  capture_output=True, text=True, timeout=timeout)


def props(name):
    fields = "ActiveState,MainPID,InvocationID,Result,ControlGroup,FragmentPath,LoadState"
    return dict(line.split("=", 1) for line in system("show", name, "-p", fields).stdout.splitlines())


def save(name, value):
    (output / (name + ".json")).write_text(json.dumps(value, indent=2) + "\n")


def start_ticks(pid):
    stat = Path(f"/proc/{pid}/stat")
    return int(stat.read_text().rsplit(")", 1)[1].split()[19]) if stat.exists() else None


def live(directory, ledger):
    runtime = Path(ledger["remote"]).parent
    return dict(env, PIPEWIREAO_PREFIX=str(prefix), LD_LIBRARY_PATH=str(prefix/"lib"),
                PIPEWIREAO_CONFIG_DIR=str(prefix/"share/pipewire-ao"),
                PIPEWIREAO_RUNTIME_DIR=str(runtime), PIPEWIRE_RUNTIME_DIR=str(runtime),
                PIPEWIREAO_MODULE_DIR=str(prefix/"lib/pipewire-ao-0.3"),
                PIPEWIREAO_SPA_PLUGIN_DIR=str(prefix/"lib/spa-ao-0.2"))


def run():
    started = False
    admitted = {}
    assert all(not path.exists() and not path.is_symlink() for path in (fragment, drop, rtc_runtime))
    assert (app / "systemd/pipewireao-session@.service").is_file()
    with (runtime_parent / "rtc-devel-benchmark.lock").open("a") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX)
        try:
            fragment.symlink_to(app / "systemd/pipewireao-session@.service")
            drop.mkdir()
            (drop / "fixture.conf").write_text("[Service]\n" + "".join(f'Environment="{k}={v}"\n' for k, v in record["env"].items()))
            system("daemon-reload")
            (output / "installed-unit.txt").write_text(system("cat", unit).stdout)
            print(scope, "starting", unit, flush=True)
            begin = time.monotonic_ns()
            started = True
            start = system("start", unit, timeout=275, check=False)
            elapsed = (time.monotonic_ns() - begin) / 1e9
            save("start", dict(returncode=start.returncode, stdout=start.stdout, stderr=start.stderr, seconds=elapsed))
            start.check_returncode()
            running = props(unit)
            assert running["ActiveState"] == "active"
            pid = int(running["MainPID"])
            main_ticks = start_ticks(pid)
            invocation = running["InvocationID"]
            ledger_path = rtc_runtime / "launch.json" if scope == "persistent" else rtc_runtime / invocation / "launch.json"
            admitted = json.loads(ledger_path.read_text())
            assert admitted["invocation"] == invocation and admitted["session_pid"] == pid
            assert admitted["phase"] == "prepared"
            assert bool(admitted.get("direct_attach")) == (scope == "persistent")
            argv = Path(f"/proc/{pid}/cmdline").read_bytes().rstrip(b"\0").decode().split("\0")
            assert argv[0] == record["julia"] and "--project=" + str(app) in argv
            save("ready-ledger", admitted)
            save("ready-unit", dict(systemd=running, argv=argv))
            print(scope, "held Ready", elapsed, flush=True)
            client_env = live(output, admitted)
            objects = sp.run([prefix/"bin/pwao-dump", "-N", "-r", admitted["remote"]],
                             env=client_env, text=True, capture_output=True, check=True, timeout=20)
            (output / "ready-registry.json").write_text(objects.stdout)
            links = [item for item in json.loads(objects.stdout) if item["type"].endswith(":Link") and
                     item["info"]["props"].get("object.path", "").startswith(
                         "pipewireao/session/" + str(admitted["session_control_instance"]) + "/")]
            assert len(links) == 20, len(links)
            with (output / "controls.log").open("w") as log:
                sp.run(["taskset", "-c", "4,5", record["julia"], "--startup-file=no", "--threads=2,0",
                        "--compiled-modules=existing", "--project=" + str(app), root / "controls.jl",
                        ledger_path, output / "controls.json"], env=client_env, stdout=log,
                       stderr=sp.STDOUT, check=True, timeout=185)
            begin = time.monotonic_ns()
            stop = system("stop", unit, timeout=90, check=False)
            completed = time.monotonic_ns()
            elapsed = (completed - begin) / 1e9
            save("stop", dict(returncode=stop.returncode, stdout=stop.stdout, stderr=stop.stderr,
                              seconds=elapsed, request_ns=begin, completed_ns=completed))
            stop.check_returncode()
            terminal = json.loads(ledger_path.read_text())
            save("terminal", terminal)
            assert terminal["phase"] == "stopped" and terminal["cleanup_complete"] is True
            assert terminal["systemd_quit"] == {"attempted": True, "accepted": True}
            state = props(unit)
            assert state["ActiveState"] == "inactive" and state["MainPID"] == "0" and state["Result"] == "success"
            assert start_ticks(pid) != main_ticks
            for role, owner in admitted["owners"].items():
                if owner.get("external") and owner.get("unit") not in admitted.get("scoped_services", []):
                    assert start_ticks(owner["pid"]) == int(owner["start-ticks"]), role
                elif owner.get("pid", 0) and "start-ticks" in owner:
                    assert start_ticks(owner["pid"]) != int(owner["start-ticks"]), role
            save("stopped-unit", state)
            print(scope, "native Quit complete", elapsed, flush=True)
        finally:
            if started:
                system("stop", unit, timeout=90, check=False)
            journal = sp.run(["journalctl", "--user", "--no-pager", "-n", "300",
                              *[argument for name in [unit, *(item["unit"] for item in admitted.get("owners", {}).values() if "unit" in item)]
                                for argument in ("-u", name)]], capture_output=True, text=True, timeout=20)
            (output / "journal.log").write_text(journal.stdout)
            if fragment.is_symlink() and fragment.resolve() == app / "systemd/pipewireao-session@.service":
                fragment.unlink()
            if drop.is_dir():
                (drop / "fixture.conf").unlink(missing_ok=True)
                drop.rmdir()
            system("daemon-reload", check=False)


run()
