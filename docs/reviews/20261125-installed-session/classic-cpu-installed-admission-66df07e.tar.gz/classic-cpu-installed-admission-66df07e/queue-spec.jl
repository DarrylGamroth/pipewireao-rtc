function queue_spec(session, core, name, stem, media)
    sink = only(row for row in session["sinks"] if row["node.name"] == stem * "-queue-input")
    port = only(sink["ports"])
    output = stem * "-queue-output"
    modules = core["context.modules"]
    queue = only(
        row["args"] for row in modules if
        get(row, "name", "") == "libpipewire-module-queue" &&
        get(get(row["args"], "playback.props", Dict()), "node.name", "") == output
    )
    queue["queue.max-buffers"] == 1 &&
        queue["queue.storage"] == "copy" &&
        queue["queue.overflow"] == "drop-oldest" ||
        error("Unexpected queue storage policy for $output")
    queue["playback.props"]["media.name"] == media || error("Unexpected media name for $output")
    wire = getproperty(NdArray, Symbol(port["element-type"]))
    type = wire == NdArray.U16_LE ? UInt16 : Float32
    wire in (NdArray.U16_LE, NdArray.F32_LE) || error("Unsupported element type for $output")
    # An unconstrained port can negotiate the observer's row-major offer.
    get(port, "layout", nothing) in (nothing, "ROW_MAJOR") ||
        error("Unexpected layout for $output")
    rate = get(port, "rate", nothing)
    return (name = name, node = output, media = media, type, wire,
        shape = Tuple(Int.(port["shape"])), schema = port["schema"],
        rate = rate === nothing ? nothing : SPA.Fraction(parse.(Int, split(rate, '/'))...))
end

