import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
trial = root / "classic-direct-run"
admitted = json.loads((trial / "ready-ledger.json").read_text())
terminal = json.loads((trial / "terminal.json").read_text())
controls = json.loads((trial / "controls.json").read_text())
assert admitted["invocation"] == terminal["invocation"]
assert terminal["phase"] == "stopped" and terminal["cleanup_complete"]
assert terminal["systemd_quit"] == {"accepted": True, "attempted": True}
role = "closed-loop-correction:closed"
state = "pipewireao.correction-control." + role
assert controls["ready"]["reply"]["state"] == "Ready"
assert controls["ready"]["reply"]["result"]["owned_links"] == 20
assert controls["started"]["reply"]["state"] == "Running"
assert controls["held"]["reply"]["result"]["properties"][role]["value"] is False
assert controls["held"]["reply"]["result"]["properties"][state + ".primed"]["value"] is False
assert controls["running_open"]["reply"]["result"]["properties"][role]["value"] is False
assert controls["running_open"]["reply"]["result"]["properties"][state + ".primed"]["value"] is True
assert all(row["first_identity"] for row in controls["observation"]["streams"].values())
assert not Path(admitted["remote"]).exists()

units = [admitted["unit"], *(owner["unit"] for owner in admitted["owners"].values()),
         f'pipewireao-owner-{admitted["invocation"]}-cohort.target']
observed = {}
for name in units:
    props = "ActiveState,MainPID,Result,ControlGroup,LoadState"
    value = subprocess.run(["systemctl","--user","show",name,"-p",props],
                            check=True, capture_output=True, text=True).stdout
    state = dict(line.split("=",1) for line in value.splitlines())
    assert state.get("MainPID", "0") == "0", (name, state)
    assert state["ActiveState"] in ("inactive", "failed"), (name, state)
    observed[name] = state

snapshot = {"rtc": {"pid": admitted["session_pid"], "start-ticks": admitted["session_start_ticks"]},
            **admitted["owners"]}
for role, process in snapshot.items():
    if not process.get("pid"):
        continue
    stat = Path(f'/proc/{process["pid"]}/stat')
    current = int(stat.read_text().rsplit(")",1)[1].split()[19]) if stat.exists() else None
    assert current != int(process["start-ticks"]), role
    group = process.get("cgroup")
    if group:
        pids = Path("/sys/fs/cgroup" + group) / "cgroup.procs"
        assert not pids.exists() or not pids.read_text().strip(), role

scope = root.name[-5:].lower()
task_units = subprocess.run(["systemctl", "--user", "list-units", "--all", "--plain", "--no-legend",
    f"*{scope}*", f"*{admitted['invocation']}*"], check=True, capture_output=True, text=True).stdout
task_jobs = subprocess.run(["systemctl","--user","list-jobs","--all","--plain","--no-legend"],
                          check=True,capture_output=True,text=True).stdout
assert not any(word in task_jobs for word in (scope, admitted["invocation"]))
for row in task_units.splitlines():
    assert " running " not in row and " activating " not in row, row

baseline = os.getpid()
ancestors = set()
while baseline > 1:
    ancestors.add(baseline)
    fields = Path(f"/proc/{baseline}/stat").read_text().rsplit(")",1)[1].split()
    baseline = int(fields[1])
references = []
for proc in Path("/proc").iterdir():
    if not proc.name.isdecimal() or int(proc.name) in ancestors:
        continue
    try:
        if proc.stat().st_uid != os.getuid():
            continue
        args = (proc / "cmdline").read_bytes()
        if bytes(root) in args:
            references.append(int(proc.name))
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        continue
assert not references, references
summary = dict(invocation=admitted["invocation"], owned_links=20, owners=snapshot,
               final_units=observed, remaining_task_units=task_units, remaining_processes=references)
(root / "managed-audit.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({"invocation": admitted["invocation"], "remaining_processes":references},indent=2))
