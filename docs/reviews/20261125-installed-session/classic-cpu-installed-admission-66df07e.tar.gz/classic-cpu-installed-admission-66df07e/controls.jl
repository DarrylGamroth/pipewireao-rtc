using PipeWireAO, PipeWireAORTC
const RTC = PipeWireAORTC
include("/home/dgamroth/workspaces/codex/worktrees/rtc-installed-session-maintenance/test/integration/classic_observation.jl")
include("queue-spec.jl")
const C = RTC.ControlClient
const S = RTC.SessionCodec
const Graph = "revolt-classic-jfg-frame-graph"
const Correction = "closed-loop-correction:closed"
const State = "pipewireao.correction-control." * Correction

function request(connection, operation, arguments...)
    sent_ns = time_ns()
    completion = C.request!(connection, S.RunnerCommand(operation, arguments...);
                            deadline = C.monotonic() + 50)
    received_ns = time_ns()
    reply = RTC.RunnerCommands.render(completion)
    @assert reply["ok"] reply
    return (; sent_ns, received_ns, reply)
end

function open_property(connection; held)
    properties = request(connection, :properties, Graph)
    values = properties.reply["result"]["properties"]
    @assert values[Correction]["value"] === false values
    @assert values[State * ".state"]["value"] == "Open" values
    @assert values[State * ".requested"]["value"] === false values
    held && @assert values[State * ".primed"]["value"] === false values
    return properties
end

function observe(app, remote, armed)
    prefix = String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
    deployment = RTC.Common.read_json(joinpath(app, "deployment.conf"))
    decode(file) = RTC.DeploymentConfiguration.decode(joinpath(app, deployment[file]), prefix)
    core, session = decode("core"), decode("session")
    stems = (("detector", "simulator-detector", "detector-image"), ("slopes", "rtc-slopes", "shwfs-slopes"))
    specs = map(fields -> queue_spec(session, core, fields...), stems)
    return observe_classic(remote; stream_specs=specs, timeout=100, drive_interval=0.01,
                           on_ready=() -> (armed[] = true))
end

function check(ledger, output)
    record = RTC.Common.read_json(ledger)
    connection = C.connect(RTC.SessionProfile.Profile(), record["remote"],
        "pipewireao.rtc.session." * record["name"], record["session_pid"],
        record["session_control_instance"]; deadline = C.monotonic() + 35)
    receipts = Dict{String,Any}()
    save() = RTC.Common.write_json(output, receipts; atomic=true)
    try
        held = receipts["ready"] = request(connection, :status)
        @assert held.reply["state"] == "Ready" && held.reply["result"]["running"] === false held
        @assert held.reply["result"]["owned_links"] == 20 held
        receipts["held"] = open_property(connection; held = true)
        save()
        armed = Ref(false)
        capture = @async observe(dirname(Base.active_project()), record["remote"], armed)
        end_time = C.monotonic() + 30
        while !armed[] && C.monotonic() < end_time
            istaskdone(capture) && fetch(capture)
            sleep(0.05)
        end
        @assert armed[]
        started = receipts["started"] = request(connection, :session_start)
        @assert started.reply["state"] == "Running"
        receipts["running"] = request(connection, :status)
        @assert receipts["running"].reply["result"]["running"] === true
        save()
        observed = receipts["observation"] = fetch(capture)
        for stream in ("detector", "slopes")
            @assert observed["streams"][stream]["first_identity"] !== nothing observed
        end
        deadline = C.monotonic() + 20
        while C.monotonic() < deadline
            running = receipts["running_open"] = open_property(connection; held = false)
            fields = running.reply["result"]["properties"]
            fields[State * ".primed"]["value"] === true && break
            sleep(0.05)
        end
        save()
        @assert receipts["running_open"].reply["result"]["properties"][State * ".primed"]["value"] === true
    finally
        save()
        close(connection)
    end
end

check(ARGS...)
