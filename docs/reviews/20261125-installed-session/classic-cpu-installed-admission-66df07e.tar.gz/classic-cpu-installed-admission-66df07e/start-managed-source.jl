using PipeWireAO, PipeWireAORTC
const RTC=PipeWireAORTC
const B=RTC.OwnerBootstrapClient
const BOOT=RTC.OwnerBootstrapCodec
const C=RTC.ControlClient
const MS=RTC.MediaSession
const SRC=RTC.SourceControl
remote, bootstrap, boot_instance, proc, source, output, finish = ARGS
pid=parse(Int,proc)
client=B.connect(remote,bootstrap,pid,parse(Int64,boot_instance);deadline=C.monotonic()+500)
try
    @assert B.connect_owner!(client;deadline=C.monotonic()+300).lifecycle==BOOT.Connected
    native=client.client
    node=only(find_globals(native.registry;properties=("node.name"=>source,)))
    prefix=String(PipeWireAO.LibPipeWire.PipeWireAO_jll.artifact_dir)
    dump=RTC.Common.parse_json(read(`$(joinpath(prefix,"bin","pwao-dump")) -N -r $remote $(node.id)`,String))
    properties=only(dump)["info"]["props"]
    @assert string(properties["pipewireao.source-control.owner-pid"])==proc
    instance=parse(Int64,string(properties["pipewireao.source-control.instance"]))
    last=Ref{Union{Nothing,MS.SourceSnapshot}}(nothing)
    with_thread_loop_lock(native.loop) do _
        proxy=bind(native.registry,node,Node;on_param=function (_,sequence,id,index,next,pod)
            if id==SPA.PARAM_PROPS && pod!==nothing
                fields=MS.named_values(pod)
                if isempty(setdiff(SRC.SNAPSHOT_NAMES,keys(fields)))
                    last[]=MS.source_control_snapshot(Dict(name=>fields[name] for name in SRC.SNAPSHOT_NAMES),instance)
                end
            end
            return nothing
        end)
        subscribe_params!(proxy,(SPA.PARAM_PROPS,))
        enum_params!(proxy,SPA.PARAM_PROPS;count=UInt32(16))
        global source_proxy=proxy
    end
    function await(token)
        return C.poll(native,C._deadline_ns(C.monotonic()+65),Returns(nothing)) do _
            v=last[]
            v!==nothing && v.details.token==token ? v : nothing
        end
    end
    before=await(0)
    @assert !before.running
    function command(kind,token,state="")
        with_thread_loop_lock(native.loop) do _
            C.healthy(native)
            set_param!(source_proxy, SPA.PARAM_PROPS, MS.control_request(kind,token,state,instance))
        end
        result=await(token)
        @assert result.details.result==0
        return result
    end
    @assert command(:run,Int64(1),"running").running
    token=Int64(1)
    open(output,"w") do stream
        while !isfile(finish)
            token+=1
            cursor=command(:query,token)
            @assert cursor.running
            println(stream,RTC.Common.metadata_json((;host_monotonic_ns=time_ns(),pid,
                instance, generation=cursor.generation, sequence=cursor.sequence)))
            flush(stream)
            sleep(0.4)
        end
    end
    @assert !command(:run,token+1,"stopped").running
    @assert B.quit!(client;deadline=C.monotonic()+30).lifecycle==BOOT.Stopped
finally
    close(client)
end
